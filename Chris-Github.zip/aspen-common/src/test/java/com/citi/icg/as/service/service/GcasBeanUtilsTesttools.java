package com.citi.icg.as.service.service;

public class GcasBeanUtilsTesttools {

	private String test;

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}
}
