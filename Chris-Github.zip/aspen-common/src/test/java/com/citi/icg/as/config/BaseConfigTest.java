package com.citi.icg.as.config;

import org.apache.log4j.BasicConfigurator;
import org.junit.BeforeClass;

public class BaseConfigTest {
	@BeforeClass
	public static void setup()
	{
		BasicConfigurator.configure();
		ConfigEvnHelper.setRuntimeToLocal();
	}
}
