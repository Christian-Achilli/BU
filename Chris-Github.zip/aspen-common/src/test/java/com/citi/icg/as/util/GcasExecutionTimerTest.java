package com.citi.icg.as.util;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.citi.icg.as.common.util.ReflectUtils;

public class GcasExecutionTimerTest {
	
	private GcasExecutionTimer timer;
	
	@Before
	public void setUp() throws Exception {
		timer = new GcasExecutionTimer();
	}

	@Test
	public void testGcasExecutionTimer() throws Exception {
		GcasExecutionTimer timer = new GcasExecutionTimer();
		assertEquals(0L, ReflectUtils.getFieldValue(timer, "start"));
	}

	@Test
	public void testStart() throws Exception {
		timer.start();
		assertNotNull(ReflectUtils.getFieldValue(timer, "start"));
	}

	@Test
	public void testEnd() throws Exception {
		timer.end();
		assertNotNull(ReflectUtils.getFieldValue(timer, "end"));
	}

	@Test
	public void testDuration() {
		assertEquals(0L, timer.duration());
	}

	@Test
	public void testReset() throws Exception {
		timer.reset();
		assertEquals(0L, ReflectUtils.getFieldValue(timer, "start"));
	}

	@Test
	public void testGetPerformanceMessageStringString() {
		assertTrue(timer.getPerformanceMessage("test", "test").contains("test::test"));
	}

	@Test
	public void testGetPerformanceMessageStringStringString() {
		assertTrue(timer.getPerformanceMessage("test", "test", "a").contains("test::test"));
	}
	
	@Test
	public void testGetHourMinuteSeconds() throws Exception {
		ReflectUtils.setFieldValue(timer, "start", 10000);
		ReflectUtils.setFieldValue(timer, "end", 50000);
		assertNotNull(timer.getPerformanceMessage("test", "aaa"));
	}
	
	@Test
	public void testGetHourMinuteSeconds2() throws Exception {
		ReflectUtils.setFieldValue(timer, "start", 0);
		ReflectUtils.setFieldValue(timer, "end", 1000000);
		assertNotNull(timer.getPerformanceMessage("test", "aaa"));
	}
	
	@Test
	public void testGetHourMinuteSeconds3() throws Exception {
		ReflectUtils.setFieldValue(timer, "start", 0);
		ReflectUtils.setFieldValue(timer, "end", 1000000000);
		assertNotNull(timer.getPerformanceMessage("test", "aaa"));
	}
	
	@Test
	public void testGetHourMinuteSeconds4() throws Exception {
		ReflectUtils.setFieldValue(timer, "start", 0);
		ReflectUtils.setFieldValue(timer, "end", 1111);
		assertNotNull(timer.getPerformanceMessage("test", "aaa"));
	}
	
	@Test
	public void testGetHourMinuteSeconds5() throws Exception {
		ReflectUtils.setFieldValue(timer, "start", 0);
		ReflectUtils.setFieldValue(timer, "end", 999);
		assertNotNull(timer.getPerformanceMessage("test", "aaa"));
	}

}
