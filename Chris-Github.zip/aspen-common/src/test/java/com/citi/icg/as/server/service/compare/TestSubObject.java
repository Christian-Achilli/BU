package com.citi.icg.as.server.service.compare;

public class TestSubObject {
	private Long subId;

	public Long getSubId() {
		return subId;
	}

	public void setSubId(Long subId) {
		this.subId = subId;
	}

	
	

}
