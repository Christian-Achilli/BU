package com.citi.icg.as.config;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Constructor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor("com.citi.icg.as.config.ConfigEnv")
public class ConfigEnvTest{
	
	@Test
	public void testInitEnv()
	{
		assertEquals(null, ConfigEnv.getEnvironment());
	}
	
	@Test
	public void testInitEnv1() throws Exception
	{
		String method = "initEnv";
		
		System.setProperty("os.name", "Windows Unit");
		
		String env = Whitebox.invokeMethod(ConfigEnv.class, method);
		assertEquals("local", env);
	}
	
	@Test(expected = RuntimeException.class)
	public void testInitEnv2() throws Exception
	{
		String method = "initEnv";
		
		System.setProperty("os.name", "unit");
		System.clearProperty(ConfigEnv.GCAS_ENV);
		
		Whitebox.invokeMethod(ConfigEnv.class, method);
	}
	
	@Test
	public void testSet() throws Exception
	{
		ConfigEnv.set("local");
		assertEquals("local", System.getProperty("gcas.env"));
	}
	@Test
	public void testConstructor() throws Exception{
		Constructor<ConfigEnv> constructor=ConfigEnv.class.getDeclaredConstructor(new Class[]{});
		constructor.setAccessible(true);
		constructor.newInstance(new Object[]{});
	}
}
