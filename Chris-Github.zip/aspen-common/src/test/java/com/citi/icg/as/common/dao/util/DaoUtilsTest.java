package com.citi.icg.as.common.dao.util;

import java.text.ParseException;
import java.util.Date;
import java.util.TimeZone;

import junit.framework.Assert;

import org.junit.Test;

import com.citi.icg.as.core.dao.entities.business.Attribute;


public class DaoUtilsTest {
	
	@Test
	public void test1(){
		Date date=DaoUtils.convertDate(new Date(), TimeZone.getTimeZone("Europe/Copenhagen"));
	}
	@Test
	public void test2() throws ParseException{
		Date date=DaoUtils.getDate("2015-12-01", "yyyy-MM-dd");
	}
	@Test
	public void test3() throws ParseException{
		String date=DaoUtils.formatDate(new Date(),  "yyyy-MM-dd");
	}
	@Test
	public void test4() throws ParseException{
		String eventId=DaoUtils.removeLeadingZeros("0025");
		Assert.assertEquals(eventId, "25");
	}
	
	@Test
	public void test5(){
		DaoUtils.getBusinessObject(new Attribute());
	}
	
}
	

