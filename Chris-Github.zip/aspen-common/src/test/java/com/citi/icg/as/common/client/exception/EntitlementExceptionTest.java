package com.citi.icg.as.common.client.exception;

import org.junit.Test;

public class EntitlementExceptionTest {
	@Test
	public void testEntitlementException(){
		new EntitlementException();
		new EntitlementException("any");
	}
}
