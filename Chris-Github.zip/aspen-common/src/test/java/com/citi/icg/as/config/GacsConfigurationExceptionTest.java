package com.citi.icg.as.config;

import org.junit.Assert;
import org.junit.Test;

public class GacsConfigurationExceptionTest {
	
	@Test
	public void test()
	{
		Assert.assertNotNull(new GacsConfigurationException("test"));
	}
	
	@Test
	public void test2()
	{
		Assert.assertNotNull(new GacsConfigurationException("test", new Exception()));
	}
}
