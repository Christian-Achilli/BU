package com.citi.icg.as.common.enums;

import org.junit.Assert;
import org.junit.Test;

public class ProcessingUnitTypeTest {
	
	@Test
	public void dontIncludeDefaultPU() {
		for (ProcessingUnitType p : ProcessingUnitType.getAllExceptDefaultPU()) {
			Assert.assertTrue(p != ProcessingUnitType.DEFAULT_PU);
			Assert.assertTrue(p != ProcessingUnitType.Global_Window);
			Assert.assertTrue(p != ProcessingUnitType.US_DCC);
		}
	}
	
	@Test
	public void dontDispalyIncludeDefaultPU() {
		for (String p : ProcessingUnitType.getDisplayNameForAllExceptDefaultPU()) {
			Assert.assertTrue(p != "Default PU");
			Assert.assertTrue(p != "Global Window");
			Assert.assertTrue(p != "US DCC");
		}
	}
	
	@Test
	public void displayPUType(){
		Assert.assertNotNull(ProcessingUnitType.getPUType("CGMI Broadridge"));
		Assert.assertNotNull(ProcessingUnitType.getPUType("Main Firm Equity"));
		Assert.assertNotNull(ProcessingUnitType.getPUType("Swaps"));
		Assert.assertNotNull(ProcessingUnitType.getPUType("Fixed Income"));
		Assert.assertNotNull(ProcessingUnitType.getPUType("PB Equity"));
	}
}
