package com.citi.icg.as.common.workflow.jbpm3;

import com.citi.icg.as.common.workflow.ContextVariable;
import com.citi.icg.as.common.workflow.Workflow;

public interface TestDefinition3 extends Workflow {

	void goToState2(@ContextVariable(name="idVar",transientVar=false)Integer id);
	void goToState3();
	void goToState4(@ContextVariable(name="varValue",transientVar=true)String varValue);
	
}
