package com.citi.icg.as.server;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;


@RunWith(PowerMockRunner.class)
@PrepareForTest({HttpSession.class})
public class GcasRequestContextTest {


	@Before
	public void setUp() {
	}

	@After
	public void tearDown() { 

	}
	
	@Test
	public  void clear()
	{
		GcasRequestContext.clear();
		
	}

	@Test
	public  void setTest_userId()
	{
		GcasRequestContext.set("1234");
	}


	@Test
	public void getRequestContextTest()
	{
		GcasRequestContext.getRequestContext();
	}
	

	@Test
	public void getUserIdTest()
	{
		GcasRequestContext.set("1234");
		GcasRequestContext.getUserId();
		GcasRequestContext.clear();
		GcasRequestContext.getUserId();
		
	}

	@Test
	public void isInPortalTest()
	{
		GcasRequestContext.set("1234");
		GcasRequestContext.isInPortal();
		GcasRequestContext.clear();
		GcasRequestContext.isInPortal();
	}

	@Test
	public void getSessionTest()
	{
		GcasRequestContext.set("1234");
		GcasRequestContext.getSession();
		GcasRequestContext.clear();
		GcasRequestContext.getSession();
		
	}

	@Test
	public void  setTest_req()
	{
		//case1
		HttpServletRequest httpServletRequestMock = PowerMock.createMock(HttpServletRequest.class);
		HttpSession httpSessionMock =	PowerMock.createMock(HttpSession.class);
		EasyMock.expect(httpServletRequestMock.getSession(false)).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getSession(true)).andReturn(httpSessionMock);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getRemoteUser()).andReturn("123");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		httpSessionMock.setAttribute(EasyMock.isA(String.class), EasyMock.isA(String.class));
		EasyMock.expectLastCall();
		
		PowerMock.replayAll();
		GcasRequestContext.set(httpServletRequestMock);
		
		//case2
		PowerMock.resetAll();
		EasyMock.expect(httpServletRequestMock.getSession(false)).andReturn(httpSessionMock);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getRemoteUser()).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getAttribute(EasyMock.isA(String.class))).andReturn("22");
		
		httpSessionMock.setAttribute(EasyMock.isA(String.class), EasyMock.isA(String.class));
		EasyMock.expectLastCall();
		
		PowerMock.replayAll();
		GcasRequestContext.set(httpServletRequestMock);
		
		
		//case3
		PowerMock.resetAll();
		EasyMock.expect(httpServletRequestMock.getSession(false)).andReturn(httpSessionMock);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getRemoteUser()).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getAttribute(EasyMock.isA(String.class))).andReturn("22");
		
		httpSessionMock.setAttribute(EasyMock.isA(String.class), EasyMock.isA(String.class));
		EasyMock.expectLastCall();
		
		PowerMock.replayAll();
		GcasRequestContext.set(httpServletRequestMock);
		
		//case4
		PowerMock.resetAll();
		EasyMock.expect(httpServletRequestMock.getSession(false)).andReturn(httpSessionMock);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getRemoteUser()).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpSessionMock.getAttribute(EasyMock.isA(String.class))).andReturn("22");
		
		
		httpSessionMock.setAttribute(EasyMock.isA(String.class), EasyMock.isA(String.class));
		EasyMock.expectLastCall();
		
		PowerMock.replayAll();
		GcasRequestContext.set(httpServletRequestMock);
		
		//case5
		PowerMock.resetAll();
		EasyMock.expect(httpServletRequestMock.getSession(false)).andReturn(httpSessionMock);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getRemoteUser()).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpSessionMock.getAttribute(EasyMock.isA(String.class))).andReturn(null).andThrow(new RuntimeException());
	
		EasyMock.expect(httpServletRequestMock.getParameter(EasyMock.isA(String.class))).andReturn(null);
		
		
		httpSessionMock.setAttribute(EasyMock.isA(String.class), EasyMock.isNull());
		EasyMock.expectLastCall();
		
		PowerMock.replayAll();
		
		GcasRequestContext.set(httpServletRequestMock);
		
		//case6
		PowerMock.resetAll();
		EasyMock.expect(httpServletRequestMock.getSession(false)).andReturn(httpSessionMock);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn("22");
		EasyMock.expect(httpServletRequestMock.getRemoteUser()).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getHeader(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpSessionMock.getAttribute(EasyMock.isA(String.class))).andReturn(null);
		EasyMock.expect(httpServletRequestMock.getParameter(EasyMock.isA(String.class))).andReturn("dd").anyTimes();
		
		
		httpSessionMock.setAttribute(EasyMock.isA(String.class), EasyMock.isA(String.class));
		EasyMock.expectLastCall();
		
		PowerMock.replayAll();
		
		GcasRequestContext.set(httpServletRequestMock);
		
		
		
		
		
	}

	@Test
	public void isSystemUser()
	{
		GcasRequestContext.clear();
		GcasRequestContext.isSystemUser();
		GcasRequestContext.set("dd");
		GcasRequestContext.isSystemUser();
		GcasRequestContext.set(System.getProperty("user.name"));
		GcasRequestContext.isSystemUser();
	}
}
