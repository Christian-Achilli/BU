package com.citi.icg.as.config;


import org.junit.Assert;
import org.junit.Test;

public class GCASAppConfigurationTest extends BaseConfigTest{
	@Test
	public void testGetInstance()
	{	
		Assert.assertNotNull(GCASAppConfiguration.getInstance());
	}
	
	@Test
	public void testGetAppConfigDir()
	{
		GCASAppConfiguration instance = GCASAppConfiguration.getInstance();
		Assert.assertNotNull(instance.getAppConfigDir());
	}
}
