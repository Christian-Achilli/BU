package com.citi.icg.as.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import com.citi.icg.as.common.util.ReflectUtils;
import com.citi.icg.as.exception.GcasError;
import com.citi.icg.as.exception.GcasRuntimeException;

public class DatabaseConfigurationTest extends BaseConfigTest
{
	private static DatabaseConfiguration instance = null;

	private static String NON_EXIST_DATASOURCE = "non-exist-datasource";
	private static String CARIO_DATASOURCE = "CAIRO";

	@Before
	public void before()
	{
		instance = DatabaseConfiguration.getInstance();
	}

	@Test
	public void testGetInstance()
	{
		assertNotNull(instance);
	}

	@Test
	public void testGetDataSourceUsername()
	{
		String dataSourceUsername = instance.getDataSourceUsername(CARIO_DATASOURCE);
		assertNotNull(dataSourceUsername);
		assertEquals("cairod",dataSourceUsername);
		String dataSourceUsernameNonExist = instance.getDataSourceUsername(NON_EXIST_DATASOURCE);
		assertNull(dataSourceUsernameNonExist);
	}

	@Test
	public void testGetDataSourcePassword()
	{
		String dataSourcePassword = instance.getDataSourcePassword(CARIO_DATASOURCE);
		assertNotNull(dataSourcePassword);
		assertEquals("ENC(KRuRwViinr8=)",dataSourcePassword);
		String dataSourcePasswordNonExist = instance.getDataSourcePassword(NON_EXIST_DATASOURCE);
		assertNull(dataSourcePasswordNonExist);

	}

	@Test(expected = GcasError.class)
	public void testGetDataSourcePasswordWithNull()
	{
		instance.getDataSourcePassword(null);
	}

	@Test(expected = GcasRuntimeException.class)
	public void testGetDataSourceDriverClassWithNonExistName()
	{
		instance.getDataSourceDriverClass(NON_EXIST_DATASOURCE);
	}

	@Test
	public void testGetDataSourceDriverClass()
	{
		assertNotNull(instance.getDataSourceDriverClass(CARIO_DATASOURCE));
	}

	@Test(expected = GcasRuntimeException.class)
	public void testGetDataSourceDriverURLWithNonExistName()
	{
		instance.getDataSourceUrl(NON_EXIST_DATASOURCE);
	}

	@Test
	public void testGetDataSourceDriverURL()
	{
		String dataSourceUrl = instance.getDataSourceUrl(CARIO_DATASOURCE);
		assertNotNull(dataSourceUrl);
		assertEquals("[com.sybase.jdbc3.jdbc.SybDriver]jdbc:sybase:Tds:gccosyb1d.eur.nsroot.net:6110/CARecordDb",dataSourceUrl);
	}

	@Test
	public void testGetDataSources()
	{
		String[] dataSourceNames = instance.getDataSourceNames();
		assertNotNull(dataSourceNames);
		assertEquals(3,dataSourceNames.length);
		assertEquals("assetservicingdb",dataSourceNames[0]);
		assertEquals("IPB",dataSourceNames[1]);
		assertEquals("CAIRO",dataSourceNames[2]);
	}
	@Test
	public void testGetDataSourcesIndex() throws Exception{
		try {
			ReflectUtils.invokeInstanceMethod(instance, "getDataSourceIndex", new Object[]{""}, new Class[]{String.class});
		} catch (Exception e) {
			assertTrue(e.getCause() instanceof GcasError);
		}
		try {
			ReflectUtils.invokeInstanceMethod(instance, "getDataSourceIndex", new Object[]{null}, new Class[]{String.class});
		} catch (Exception e) {
			assertTrue(e.getCause() instanceof GcasError);
		}

	}
	@Test
	public void testCons() throws Exception {
//		DatabaseConfiguration.class.
		Logger logger=Logger.getLogger(DatabaseConfigurationTest.class);
		logger.info("ttt");
	}
	
}
