package com.citi.icg.as.dao;


import static org.junit.Assert.assertNotNull;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration(locations = { "classpath:data-source-context.xml" })
@RunWith(SpringJUnit4ClassRunner.class)
public class CurrencyLookupDaoTest {

	private static final Log LOGGER = LogFactory.getLog(CurrencyLookupDaoTest.class);

	@Autowired
	CurrencyLookupDao currencyLookupDao;

	@Test
	public void getCurrencyCodeIndex() {

		String code = "USD";
		String codeIndex = currencyLookupDao.getCodeIndex(code);
		System.out.println(codeIndex);
		assertNotNull(codeIndex);

	}
}
