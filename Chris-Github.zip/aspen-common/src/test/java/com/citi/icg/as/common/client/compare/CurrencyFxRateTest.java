package com.citi.icg.as.common.client.compare;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.Ignore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import com.citi.icg.as.common.service.CommonDataService;
import com.citi.icg.as.core.dao.entities.business.FXRate;

@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class })
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/common-service.xml",
		"classpath:/data-source-context.xml" })
@PrepareForTest({ CurrencyFxRateTest.class,CommonDataService.class })
@Ignore
public class CurrencyFxRateTest {

	@Autowired
	private CommonDataService commonDataService;
	
	@Test
	public void testCurrecyFxRate(){
		List<FXRate> fxRate = commonDataService.getCurrencyFxRate("AED", "USD");
		if(fxRate!=null && fxRate.size()>0){
			FXRate fXRate = fxRate.get(0);
			Assert.assertEquals("USD_AED_SPOT",fXRate.getInstrumentLabel());
		}
	}
}
