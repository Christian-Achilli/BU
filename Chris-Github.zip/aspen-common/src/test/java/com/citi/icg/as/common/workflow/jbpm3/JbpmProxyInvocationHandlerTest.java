package com.citi.icg.as.common.workflow.jbpm3;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.isA;
import static org.easymock.EasyMock.replay;
import static org.powermock.api.easymock.PowerMock.createMock;
import static org.powermock.api.easymock.PowerMock.createNiceMock;
import static org.powermock.api.easymock.PowerMock.replayAll;
import static org.powermock.api.easymock.PowerMock.reset;
import static org.powermock.api.easymock.PowerMock.verifyAll;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.easymock.EasyMock;
import org.jbpm.command.Command;
import org.jbpm.command.CommandService;
import org.jbpm.context.exe.ContextInstance;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.def.Transition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
import org.jbpm.graph.node.TaskNode;
import org.jbpm.taskmgmt.def.Task;
import org.jbpm.taskmgmt.exe.TaskInstance;
import org.jbpm.taskmgmt.exe.TaskMgmtInstance;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.citi.icg.as.common.workflow.GenericState;
import com.citi.icg.as.common.workflow.State;
import com.citi.icg.as.common.workflow.StateType;
import com.citi.icg.as.common.workflow.StringWorkflowKey;
import com.citi.icg.as.common.workflow.TaskExecution;
import com.citi.icg.as.common.workflow.Workflow;
import com.citi.icg.as.common.workflow.WorkflowConstants;
import com.citi.icg.as.common.workflow.WorkflowInstance;
import com.citi.icg.as.common.workflow.WorkflowService;
import com.citi.icg.as.common.workflow.WorkflowTaskExecution;

@RunWith(PowerMockRunner.class)
public class JbpmProxyInvocationHandlerTest extends TestCase
{ 
	CommandService commandService=new CommandService() {
		@Override
		public Object execute(Command arg0) {
			try {
				return arg0.execute(null);
			} catch (Exception e) {
				System.out.println(e.getMessage());
//				e.printStackTrace();
			}
			return null;
		}
	};
	
	CommandService cs;
	JbpmProxyInvocationHandler jbpmProxy;
	String processName ="testprocess";
	StringWorkflowKey key=new StringWorkflowKey("testkey");
	
	@Before
	public void before()
	{
		cs = EasyMock.createMock(CommandService.class);
		jbpmProxy = new JbpmProxyInvocationHandler(key, processName, cs);
	}
	
//	@Test
//	public void test_collectMethodVariables()
//	{
//		
//		String objectParm = "VALUE";
//		Map<String, Object> vars = new HashMap<String, Object>();
//		Method method = EasyMock.createMock(Method.class);
//				
//		jbpmProxy.collectMethodVariables(method, new Object[]{objectParm}, vars);
//				
//	}
	
	@Test 
	public void testIsWorkflowMethod() throws Exception{
		JbpmProxyInvocationHandler jbpmProxy = new JbpmProxyInvocationHandler(null, null, null);		
		//T
		Method method1 = Workflow.class.getMethod("getKey");
		assertTrue(Whitebox.<Boolean>invokeMethod(jbpmProxy,"isWorkflowMethod",method1));
		//F
		Method method2 = null;
		assertFalse(Whitebox.<Boolean>invokeMethod(jbpmProxy,"isWorkflowMethod",method2));
	}
	
	@Test 
	public void testProcessTask() throws Exception{
		JbpmProxyInvocationHandler jbpmProxy = new JbpmProxyInvocationHandler(null, null, null);
		Map<String, Object> methodContextVars;
		Collection<TaskInstance> taskInstances;
		String transiton = "nextNode";
		//F
		methodContextVars = new HashMap<String,Object>();
		taskInstances = new ArrayList<TaskInstance>();
		methodContextVars.put("taskId", 1L);
		methodContextVars.put("doTaskUser", "testUser");
		Whitebox.invokeMethod(jbpmProxy,"processTasks",methodContextVars, taskInstances, transiton);
		
		//TF

		taskInstances.clear();
		TaskInstance  ti = new TaskInstance();
		taskInstances.add(ti);
		Whitebox.invokeMethod(jbpmProxy,"processTasks",methodContextVars, taskInstances, transiton);
		
		//TT
		taskInstances.clear();
		ti.setId(1L);
		TaskNode node = new TaskNode();
		Transition leavingTransition = new Transition("nextNode");
		Task task = new Task();
		task.setTaskNode(node);
		node.addLeavingTransition(leavingTransition);
		ti.setTask(task);
		taskInstances.add(ti);
		Whitebox.invokeMethod(jbpmProxy,"processTasks",methodContextVars, taskInstances, transiton);
		assertFalse(ti.isOpen());
		//TTT
		ti.setEnd(null);
		methodContextVars.put(WorkflowConstants.TASK_DONE_BY, "testUser");
		Whitebox.invokeMethod(jbpmProxy,"processTasks",methodContextVars, taskInstances, transiton);
		assertEquals(ti.getActorId(), "testUser");
	}
	@Test 
	public void testProcessTasks() throws Exception{
		JbpmProxyInvocationHandler target = new JbpmProxyInvocationHandler(null,  null, null);
		String taskName="taskName";
		String transiton="";
		String taskDoneBy="";
		Collection<TaskInstance> taskInstances=new ArrayList<TaskInstance>();
		TaskInstance taskInstance = new TaskInstance();
		taskInstances.add(taskInstance);
		
		//TEST: processTasks(String taskName, String transiton, String taskDoneBy, Collection<TaskInstance> taskInstances)
		taskInstance.setName(taskName);
		//if
		Whitebox.invokeMethod(target,"processTasks",taskName, transiton,taskDoneBy,taskInstances);
		//else
		taskInstance.setName("Not a name");
		Whitebox.invokeMethod(target,"processTasks",taskName, transiton,taskDoneBy,taskInstances);
		
		//TEST: private void processTasks(String transiton, String taskDoneBy, Collection<TaskInstance> taskInstances)
		Whitebox.invokeMethod(target,"processTasks", transiton,taskDoneBy,taskInstances);
		
		//TEST: private void processTasks(Map<String, Object> methodContextVars, Collection<TaskInstance> taskInstances, String transiton)
		Map<String, Object> methodContextVars=new HashMap<String,Object>();
		methodContextVars.put("doTaskUser", "testUser");
		//if
		methodContextVars.put("taskId", 1L);
		Whitebox.invokeMethod(target,"processTasks",methodContextVars, taskInstances, transiton);
		//else if
		methodContextVars.remove("taskId");
		methodContextVars.put("taskName", "taskName");
		Whitebox.invokeMethod(target,"processTasks",methodContextVars, taskInstances, transiton);
		//else
		methodContextVars.remove("taskName");
		Whitebox.invokeMethod(target,"processTasks",methodContextVars, taskInstances, transiton);
	}
	
//	@Test
//	public void testAddContextVariables() throws SecurityException, NoSuchMethodException {
//		Map<String, Object> vars = new HashMap<String, Object>();
//		ContextInstance context = createMock(ContextInstance.class);
//		context.addVariables(vars);
//		context.createVariable("transitionName", "goToState2");
//		EasyMock.expectLastCall().anyTimes();
//		context.createVariable("varValue", "testVal1");
//		EasyMock.expectLastCall().anyTimes();
//		replay(context);
//		
//		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(null, null,  null);
//		Method method = TestDefinition1.class.getDeclaredMethod("goToState2", new Class[]{String.class});
//		
//		proxy.addContextVariables(method, new Object[]{"testVal1"}, context);
//		
//		assertEquals("testVal1", vars.get("varValue").toString());
////		verify(context);
//		
//	}
		
//	@Test
//	public void testAddTransientContextVariables() throws SecurityException, NoSuchMethodException {
//		
//		Map<String, Object> vars = new HashMap<String, Object>();
//		ContextInstance context = createMock(ContextInstance.class);
//		context.addVariables(vars);
//		EasyMock.expectLastCall().anyTimes();
//		context.createVariable("transitionName", "goToState4");
//		EasyMock.expectLastCall().anyTimes();
//		context.setTransientVariable("varValue", "testVal1");
//		EasyMock.expectLastCall().anyTimes();
//		replay(context);
//		
//		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(null, null,  null);
//		Method method = TestDefinition1.class.getDeclaredMethod("goToState4", new Class[]{String.class});
//		
//		proxy.addContextVariables(method, new Object[]{"testVal1"}, context);
//		verify(context);
//		
//	}
	
//	@Test
//	public void testAddContextVariablesNeg() throws SecurityException, NoSuchMethodException {
//		
//		Map<String, Object> vars = new HashMap<String, Object>();
//		ContextInstance context = createMock(ContextInstance.class);
//		context.addVariables(vars);
//		EasyMock.expectLastCall().anyTimes();
//		context.createVariable("transitionName", "goToState3");
//		EasyMock.expectLastCall().anyTimes();
//		replay(context);
//		
//		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(null, null,  null);
//		Method method = TestDefinition1.class.getDeclaredMethod("goToState3", new Class[]{});
//		
//		proxy.addContextVariables(method, new Object[]{}, context);
//		
//		assertEquals(0, vars.size());
//		verify(context);
//		
//	}
	
	@Test
	public void testInvokeWorkflowMethod() throws Throwable {
		
		StringWorkflowKey key = new StringWorkflowKey("key1");
		String processName = TestDefinition1.class.getSimpleName();
		
		
		ProcessInstance pi = createMock(ProcessInstance.class);
		ProcessDefinition pd = createMock(ProcessDefinition.class);
		WorkflowService ws = createMock(WorkflowService.class);
		
		expect(pi.getProcessDefinition()).andReturn(pd).anyTimes();
		expect(pd.getName()).andReturn(processName).anyTimes();
		expect(pi.getKey()).andReturn("key1").anyTimes();
		expect(pi.getRootToken()).andReturn(new Token()).anyTimes();
		
		Collection<TaskInstance> taskInstances=new ArrayList<TaskInstance>();
		TaskMgmtInstance taskMgmtInstance=createMock(TaskMgmtInstance.class);
		expect(taskMgmtInstance.getUnfinishedTasks(isA(Token.class))).andReturn(taskInstances).anyTimes();
		expect(pi.getTaskMgmtInstance()).andReturn(taskMgmtInstance).anyTimes();
		
		
		//
		ContextInstance context = createMock(ContextInstance.class);
		Map<String, Object> vars = new HashMap<String, Object>();
		context.addVariables(vars);
		EasyMock.expectLastCall().anyTimes();
		context.createVariable("transitionName", "goToState3");
		EasyMock.expectLastCall().anyTimes();
		context.createVariable("transitionName", "toString");
		EasyMock.expectLastCall().anyTimes();
		expect(context.getVariables()).andReturn(null);
//		replay(context);
		
		expect(pi.getContextInstance()).andReturn(context).anyTimes();
		pi.signal("toString");
		EasyMock.expectLastCall().anyTimes();

		WorkflowInstance wf = new WorkflowInstance(processName, key.toString());		
		List<TaskExecution> tasks = new ArrayList<TaskExecution>();
		WorkflowTaskExecution task = new WorkflowTaskExecution(1L, "testUser", null, "taskName", true);
		tasks.add(task);
		wf.setTasks(tasks);
		
		replayAll();
		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(key, processName, commandService) ;
		
		Method method = Workflow.class.getDeclaredMethod("getTasks", new Class[]{});
		Object[] methodArgs = new Object[]{};
		Object actual=null;
		//NC
		actual = proxy.invoke(proxy, method, methodArgs);
		//assertEquals(tasks, actual);
		//non WorkFlow method
		method= Object.class.getDeclaredMethod("toString" );
		wf.setCurrentState(new GenericState(0l,"",StateType.TASK));
		//non WorkFlow method - no task
		try{
			actual = proxy.invoke(proxy,method , methodArgs);
		}catch (RuntimeException e){
			//TODO Exception already catched by CommandService exe stub
			assertEquals(e.getMessage(), "No running task instances");
		}
		//non WorkFlow method - 1 task
		taskInstances.add(new TaskInstance());
		actual = proxy.invoke(proxy,method , methodArgs);
		//diff state 
		wf.setCurrentState(new GenericState(0l,"",StateType.ACTION));
		actual = proxy.invoke(proxy,method , methodArgs);
				
	}
	
	@Test
	public void testTaskTransition1() throws Throwable{
		//end a task with explicitly specify the task id
		
		String processName = TestDefinition1.class.getSimpleName();
		StringWorkflowKey key = new StringWorkflowKey("key1");
		String transitionName = "goToState5";
		Map<String, Object> vars = new HashMap<String, Object>();
		WorkflowInstance wf = new WorkflowInstance(processName, key.toString());	
		State currentState = new GenericState(1L, "currentState", StateType.TASK);
		List<TaskExecution> tasks = new ArrayList<TaskExecution>();
		WorkflowTaskExecution wfTaskExc = new WorkflowTaskExecution(1L, "testUser", currentState, "taskName", true);
		tasks.add(wfTaskExc);
		wf.setTasks(tasks);
		wf.setCurrentState(currentState);
		List<TaskInstance> taskInstances = new ArrayList<TaskInstance>();;
		TaskInstance  ti = new TaskInstance();
		ti.setId(1L);
		TaskNode node = new TaskNode();
		Transition leavingTransition = new Transition(transitionName);
		Task task = new Task();
		task.setTaskNode(node);
		node.addLeavingTransition(leavingTransition);
		ti.setTask(task);
		taskInstances.add(ti);
		//wf.setTasks(taskInstances);
		
		ProcessInstance pi = createMock(ProcessInstance.class);
		WorkflowService ws = createMock(WorkflowService.class);
		ContextInstance context = createMock(ContextInstance.class);
		context.addVariables(isA(Map.class));
		PowerMock.expectLastCall().anyTimes();
		context.createVariable("transitionName", transitionName);
		PowerMock.expectLastCall().anyTimes();
		TaskMgmtInstance taskMgmt = createMock(TaskMgmtInstance.class);
		
		
		expect(pi.getContextInstance()).andStubReturn(context);
		expect(pi.getTaskMgmtInstance()).andStubReturn(taskMgmt);
		expect(taskMgmt.getTaskInstances()).andStubReturn(taskInstances);	
		expect(context.getVariables()).andStubReturn(vars);

		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(key, processName,  commandService);
		Method method = TestDefinition1.class.getDeclaredMethod(transitionName, new Class[]{long.class});
		replayAll();			
		proxy.invoke(null, method, new Object[]{1L});		
//		verifyAll();
		
	}
	
	@Test
	public void testTaskTransition2() throws Throwable{
		//record the user who done the task
		
		String processName = TestDefinition1.class.getSimpleName();
		StringWorkflowKey key = new StringWorkflowKey("key1");
		String transitionName = "goToState6";
		Map<String, Object> vars = new HashMap<String, Object>();
		WorkflowInstance wf = new WorkflowInstance(processName, key.toString());	
		State currentState = new GenericState(1L, "currentState", StateType.TASK);
		List<TaskExecution> tasks = new ArrayList<TaskExecution>();
		WorkflowTaskExecution wfTaskExc = new WorkflowTaskExecution(1L, "testUser", currentState, "taskName", true);
		tasks.add(wfTaskExc);
		wf.setTasks(tasks);
		wf.setCurrentState(currentState);		
		List<TaskInstance> taskInstances = new ArrayList<TaskInstance>();
		TaskInstance  ti = new TaskInstance();
		ti.setId(1L);
		TaskNode node = new TaskNode();
		Transition leavingTransition = new Transition(transitionName);
		Task task = new Task();
		task.setTaskNode(node);
		node.addLeavingTransition(leavingTransition);
		ti.setTask(task);
		taskInstances.add(ti);
		
		ProcessInstance pi = createMock(ProcessInstance.class);
		WorkflowService ws = createMock(WorkflowService.class);
		ContextInstance context = createMock(ContextInstance.class);
		TaskMgmtInstance taskMgmt = createNiceMock(TaskMgmtInstance.class);
		context.addVariables(isA(Map.class));
		context.createVariable("transitionName", transitionName);
		
		
		expect(pi.getContextInstance()).andReturn(context);
		expect(pi.getTaskMgmtInstance()).andReturn(taskMgmt);
		expect(taskMgmt.getTaskInstances()).andStubReturn(taskInstances);	
		expect(context.getVariables()).andReturn(vars);
		context.setTransientVariable(isA(String.class), isA(Object.class));

		replayAll();
			
		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(key, processName, commandService);
		Method method = TestDefinition1.class.getDeclaredMethod(transitionName, new Class[]{String.class});
		proxy.invoke(null, method, new Object[]{"testUser"});
		
//		verifyAll();
	}
	@Test
	public void testTaskTransition3() throws Throwable{
		
		String processName = TestDefinition1.class.getSimpleName();
		StringWorkflowKey key = new StringWorkflowKey("key1");
		String transitionName = "goToState3";
		Map<String, Object> vars = new HashMap<String, Object>();
		WorkflowInstance wf = new WorkflowInstance(processName, key.toString());	
		State currentState = new GenericState(1L, "currentState", StateType.TASK);
		List<TaskExecution> tasks = new ArrayList<TaskExecution>();
		WorkflowTaskExecution wfTaskExc = new WorkflowTaskExecution(1L, "testUser", currentState, "taskName", true);
		tasks.add(wfTaskExc);
		wf.setTasks(tasks);
		wf.setCurrentState(currentState);
		List<TaskInstance> taskInstances = new ArrayList<TaskInstance>();
		
		ProcessInstance pi = createMock(ProcessInstance.class);
		WorkflowService ws = createMock(WorkflowService.class);
		ContextInstance context = createMock(ContextInstance.class);
		TaskInstance ti = createMock(TaskInstance.class);
		context.addVariables(vars);
		PowerMock.expectLastCall().anyTimes();
		context.createVariable("transitionName", transitionName);
		PowerMock.expectLastCall().anyTimes();
		TaskMgmtInstance taskMgmt = createMock(TaskMgmtInstance.class);
		
		expect(pi.getContextInstance()).andStubReturn(context);
		expect(pi.getTaskMgmtInstance()).andStubReturn(taskMgmt);
		expect(ti.hasEnded()).andStubReturn(false);
		ti.end(isA(String.class));
		taskInstances.add(ti);
		expect(taskMgmt.getTaskInstances()).andStubReturn(taskInstances);	
		expect(context.getVariables()).andStubReturn(vars);

		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(key, processName,  commandService);
		Method method = TestDefinition1.class.getDeclaredMethod(transitionName, new Class[]{});
		replayAll();			
		proxy.invoke(null, method, new Object[]{});		
//		verifyAll();
		
		
		currentState = new GenericState(1L, "currentState", StateType.ACTION);
		wfTaskExc = new WorkflowTaskExecution(1L, "testUser", currentState, "taskName", true);
		tasks.clear();
		tasks.add(wfTaskExc);
		wf.setTasks(tasks);
		wf.setCurrentState(currentState);
		reset(pi);
		expect(pi.getContextInstance()).andStubReturn(context);
		pi.signal(transitionName);
		replay(pi);
		proxy.invoke(null, method, new Object[]{});
//		verifyAll();
		
	}
	
	@Test
	public void testStateTransition() throws Throwable{
		
		String processName = TestDefinition1.class.getSimpleName();
		StringWorkflowKey key = new StringWorkflowKey("key1");
		Map<String, Object> vars = new HashMap<String, Object>();
		WorkflowInstance wf = new WorkflowInstance(processName, key.toString());	
		State currentState = new GenericState(1L, "currentState", StateType.ACTION);
		List<TaskExecution> tasks = new ArrayList<TaskExecution>();
		WorkflowTaskExecution wfTaskExc = new WorkflowTaskExecution(1L, "testUser", currentState, "taskName", true);
		tasks.add(wfTaskExc);
		wf.setTasks(tasks);
		wf.setCurrentState(currentState);		
		
		ProcessInstance pi = createMock(ProcessInstance.class);
		pi.signal("goToState3");
		WorkflowService ws = createMock(WorkflowService.class);
		ContextInstance context = createMock(ContextInstance.class);
		context.addVariables(isA(Map.class));
		context.createVariable("transitionName", "goToState3");
		
		
		expect(pi.getContextInstance()).andReturn(context);
		expect(context.getVariables()).andReturn(vars);

		replayAll();
			
		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(key, processName,  commandService);
		Method method = TestDefinition1.class.getDeclaredMethod("goToState3", new Class[]{});
		proxy.invoke(null, method, new Object[]{});
		
//		verifyAll();	
		
	}
	
	@Test
	public void testTransitionThrowException() throws Throwable{
		//test throw RuntimeException("No running task instances.")
		
		String processName = TestDefinition1.class.getSimpleName();
		StringWorkflowKey key = new StringWorkflowKey("key1");
		String transitionName = "goToState3";
		ProcessInstance pi = createMock(ProcessInstance.class);
		WorkflowService ws = createMock(WorkflowService.class);
		Workflow wf = createMock(Workflow.class);
		State state = createMock(State.class);
		TaskMgmtInstance taskMgmt = createNiceMock(TaskMgmtInstance.class);
		ContextInstance context = createMock(ContextInstance.class);
		context.addVariables(isA(Map.class));
		context.createVariable("transitionName", "goToState3");
		
		expect(pi.getContextInstance()).andStubReturn(context);
		expect(pi.getTaskMgmtInstance()).andReturn(taskMgmt);
		expect(state.getStateType()).andReturn(StateType.TASK);
		expect(wf.getTasks()).andReturn(new ArrayList<TaskExecution>());
		expect(wf.getCurrentState()).andReturn(state);
		replayAll();
		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(key, processName,  commandService);
		Method method = TestDefinition1.class.getDeclaredMethod(transitionName, new Class[]{});
		try{
			proxy.invoke(null, method, new Object[]{});
//			fail();
		}catch(Exception e){
			assertTrue(e.getMessage().contains("No running task instances."));
		}
//		verifyAll();
	}
	@Test
	public void testInvokeWithException() throws Throwable {
		String processName = TestDefinition1.class.getSimpleName();
		StringWorkflowKey key = new StringWorkflowKey("key1");
		WorkflowService ws = createMock(WorkflowService.class);
		
		JbpmProxyInvocationHandler proxy = new JbpmProxyInvocationHandler(key, processName, commandService);
		Method method = TestDefinition1.class.getDeclaredMethod("goToState3", new Class[]{});
		//CASE: exception when invoke
		//without cause
		
		try{
			proxy.invoke(null, method, new Object[]{});
		}catch (Exception e) {
			//OK
			assertNotNull(e);
		}
		try{
			proxy.invoke(null, method, new Object[]{});
		}catch (Exception e) {
			//OK
			assertNotNull(e);
		}
	}
	
	
}
