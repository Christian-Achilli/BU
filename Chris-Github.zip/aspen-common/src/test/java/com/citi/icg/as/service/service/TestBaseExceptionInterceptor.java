package com.citi.icg.as.service.service;

import static org.junit.Assert.*;

import org.junit.Test;

import com.citi.icg.as.hessian.ResultWrapper;
import com.citi.icg.as.server.service.BaseExceptionInterceptor;
import com.citi.icg.as.server.service.ServiceExceptionInterceptor;
import com.citi.icg.as.server.service.ServiceExecutor;

public class TestBaseExceptionInterceptor {

	interface TestInterface {
		String getRuntimeException();
	}

	class TestService implements TestInterface {

		private static final String ERROR_MESSAGE = "Ops!";

		@Override
		public String getRuntimeException() {
			throw new RuntimeException(ERROR_MESSAGE);
		}

	}

	@Test
	public void should_return_result_wrapper_even_on_service_exception() throws Exception {
		ServiceExceptionInterceptor vh = new BaseExceptionInterceptor();
		ResultWrapper<String> s = vh.execute(null, new ServiceExecutor<String>() {

			@Override
			public String execute() throws Exception {
				return new TestService().getRuntimeException();
			}
		});
		assertTrue(s.hasFailure());
		assertNotNull(s.getErrorMessage());
	}

	class CustomMessageExceptionInterceptor extends BaseExceptionInterceptor {
		
		@Override
		protected String getBusinessErrorMessage(Exception e) {
			if(e instanceof RuntimeException) return "Something unexpected just happened. Please contact Support.";
			else return e.getMessage();
		}
		
	}
	
	@Test
	public void should_return_custom_message_for_runtime_exceptions() throws Exception {
		ServiceExceptionInterceptor vh = new CustomMessageExceptionInterceptor();
		ResultWrapper<String> s = vh.execute(null, new ServiceExecutor<String>() {

			@Override
			public String execute() throws Exception {
				return new TestService().getRuntimeException();
			}
		});
		assertTrue(s.hasFailure());
		assertEquals("Something unexpected just happened. Please contact Support.", s.getErrorMessage());
	}
	
}
