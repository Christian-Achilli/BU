package com.citi.icg.as.config;


import org.junit.Assert;
import org.junit.Test;

public class ConfigEvnHelperTest {

	private String getEnv()
	{
		return System.getProperty(ConfigEvnHelper.ICG_ENV);
	}
	
	@Test
	public void testSetRuntimeToAutoTest()
	{
		ConfigEvnHelper.setRuntimeToAutoTest();
		Assert.assertEquals(ConfigEvnHelper.RUNTIME_AUTO_TEST, getEnv());
	}
	
	@Test
	public void testSetRuntimeToDev()
	{
		ConfigEvnHelper.setRuntimeToDev();
		Assert.assertEquals(ConfigEvnHelper.RUNTIME_DEV, getEnv());
	}
	
	@Test
	public void testSetRuntimeToInt()
	{
		ConfigEvnHelper.setRuntimeToInt();
		Assert.assertEquals(ConfigEvnHelper.RUNTIME_INT, getEnv());
	}
	
	@Test
	public void testSetRuntimeToUat()
	{
		ConfigEvnHelper.setRuntimeToUat();
		Assert.assertEquals(ConfigEvnHelper.RUNTIME_UAT, getEnv());
	}
	
	@Test
	public void testSetRuntimeToProd()
	{
		ConfigEvnHelper.setRuntimeToProd();
		Assert.assertEquals(ConfigEvnHelper.RUNTIME_PROD, getEnv());
	}
	
}
