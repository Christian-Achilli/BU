/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import org.springframework.stereotype.Component;

/**
 * @author ap72338
 *
 */

@Component
@ConditionalRunningOnServer
public class DummySpringComponent {

}
