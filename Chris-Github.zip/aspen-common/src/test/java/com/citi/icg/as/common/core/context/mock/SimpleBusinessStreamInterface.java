/**
 * 
 */
package com.citi.icg.as.common.core.context.mock;

/**
 * @author AP72338
 *
 */
public interface SimpleBusinessStreamInterface {

	int calculateTotal(String ...strings);
}
