package com.citi.icg.as.service.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.MDC;
import org.apache.log4j.spi.LoggingEvent;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.citi.icg.as.common.util.ReflectUtils;
import com.citi.icg.as.server.service.GcasRpcContext;

@RunWith(PowerMockRunner.class)
@PrepareForTest( {MDC.class})
public class GcasRpcContextTest {

	private GcasRpcContext gcasRpcContext;
	private Map<String, String> map;
	
	@Before
	public void init() {
		map = new HashMap<String, String>();
		map.put("key", "value");
		PowerMock.mockStatic(MDC.class);
		gcasRpcContext = new GcasRpcContext("super", GcasRpcContext.class, GcasRpcContext.class.getMethods()[0]);
	}

	@Test
	public void testGet_Finish() {
		EasyMock.expect(MDC.get(EasyMock.isA(String.class))).andReturn(gcasRpcContext).anyTimes();
		PowerMock.replayAll();
		Assert.assertNotNull(GcasRpcContext.get());
		GcasRpcContext.finish();
		gcasRpcContext = new GcasRpcContext("super", GcasRpcContext.class.getName(), GcasRpcContext.class.getMethods()[0].getName(), map);
		gcasRpcContext.toString();
		gcasRpcContext.toRpcLogEntry();
		gcasRpcContext.getStartTimeMs();
		gcasRpcContext.getStopTimeMs();
		gcasRpcContext.getRemoteUser();
		gcasRpcContext.getTargetName();
		gcasRpcContext.getMethodName();
		gcasRpcContext.getArgs();
		gcasRpcContext.isFailed();
		gcasRpcContext.setFailed(false);
	}
	
	@Test
	public void testGet_2() {
		LoggingEvent loggingEventMock = PowerMock.createMock(LoggingEvent.class);
		EasyMock.expect(loggingEventMock.getMDC(EasyMock.isA(String.class))).andReturn(gcasRpcContext);
		PowerMock.replayAll();
		Assert.assertNotNull(GcasRpcContext.get(loggingEventMock));
	}
	
	@Test
	public void testStart() {
		Assert.assertNotNull(GcasRpcContext.start("super", GcasRpcContext.class, GcasRpcContext.class.getMethods()[0]));
		Assert.assertNotNull(GcasRpcContext.start("super", GcasRpcContext.class, GcasRpcContext.class.getMethods()[0]));
	}
	
	@Test
	public void testStart_2() {
		Assert.assertNotNull(GcasRpcContext.start("super", GcasRpcContext.class.getName(), GcasRpcContext.class.getMethods()[0].getName(), map));
	}
	
	@Test
	public void testDescribeParameter() throws Exception {
		Object obj = null;
		Whitebox.invokeMethod(gcasRpcContext, "describeParameter", obj);
		Whitebox.invokeMethod(gcasRpcContext, "describeParameter", 1);
		Whitebox.invokeMethod(gcasRpcContext, "describeParameter", new Date());
		Whitebox.invokeMethod(gcasRpcContext, "describeParameter", new ArrayList<String>());
		Whitebox.invokeMethod(gcasRpcContext, "describeParameter", map);
		Whitebox.invokeMethod(gcasRpcContext, "describeParameter", Boolean.TRUE);
	}
	@Test
	public void testConstructor() throws Exception {
		gcasRpcContext = new GcasRpcContext("super", GcasRpcContext.class, 
				GcasRpcContext.class.getDeclaredMethod("setFailed", new Class[]{boolean.class}),"name");
	}
	@Test
	public void testToString() throws Exception {
		gcasRpcContext = new GcasRpcContext("super", GcasRpcContext.class.getName(), GcasRpcContext.class.getMethods()[0].getName(), new HashMap<String, String>());
		ReflectUtils.setFieldValue(gcasRpcContext, "stopTimeMs", 1L);
		gcasRpcContext.toString();
	}
}
