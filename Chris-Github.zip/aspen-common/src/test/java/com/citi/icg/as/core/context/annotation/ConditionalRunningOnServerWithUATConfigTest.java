/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.citi.icg.as.common.constants.CommonConstants;


/**
 * @author ap72338
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=TestSpringConfiguration.class)
@DirtiesContext
public class ConditionalRunningOnServerWithUATConfigTest {

	@Autowired(required=false)
	private DummySpringComponent springComponent;	
	
	@Autowired(required=false)
	private LocalSpringComponent localSpringComponent;	
	
	@BeforeClass
	public static void setUp(){
		System.setProperty(CommonConstants.SYSTEM_ENV_PROPERTY, "uat");
	}
	@Test
	public void testDummyComponentToBeNotNull(){
		Assert.assertNotNull(springComponent);
	}	
	
	@Test
	public void testLocalComponentToBeNull(){
		Assert.assertNull(localSpringComponent);
	}
}
