package com.citi.icg.as.server.service.comparator;

import org.junit.Before;

import com.citi.icg.as.server.service.compare.BaseTest;
import com.citi.icg.as.server.service.compare.BeanCompareService;

public class ComparatorUtilTest extends BaseTest {
	BeanCompareService beanCompareService;

	@Before
	public void setUp() {
		beanCompareService = new BeanCompareService();
//		beanCompareService.registerEquivalenceComparator(TestObject.class, getComparator());
	}
}
