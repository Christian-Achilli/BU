package com.citi.icg.as.common.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import com.citi.icg.as.common.dao.CommonDataDao;
import com.citi.icg.as.core.dao.entities.business.LegalEntity;
import com.citi.icg.as.core.dao.entities.business.ProcessingUnit;

public class CommonDataServiceImplTest {
	private CommonDataServiceImpl commonDataServiceImpl; 
	
	@Before
	public void setup() throws Exception {
		commonDataServiceImpl = new CommonDataServiceImpl();
		CommonDataDao commonDataDao = EasyMock.createMock(CommonDataDao.class);
		
		Set<ProcessingUnit> processingUnits = new HashSet<ProcessingUnit>();
		processingUnits.add(buildProcessingUnit(1,"Default PU"));
		processingUnits.add(buildProcessingUnit(2,"US DCC"));
		EasyMock.expect(commonDataDao.getProcessingUnits()).andReturn(processingUnits).anyTimes();
		
		List<LegalEntity> allLegalEntity = new ArrayList<LegalEntity>();
		allLegalEntity.add(buildLegalEntity(1, "01", "CGMI", null));
		allLegalEntity.add(buildLegalEntity(2, "02", "CGML", null));
		allLegalEntity.add(buildLegalEntity(3, "X1", "INC", "CGMI"));
		EasyMock.expect(commonDataDao.getAllDefaultLegalEntities()).andReturn(allLegalEntity).anyTimes();
		
		List<LegalEntity> allLegalEntityForBR = new ArrayList<LegalEntity>();
		allLegalEntityForBR.add(buildLegalEntity(4, "0A", "CGMI", null));
		EasyMock.expect(commonDataDao.getAllLegalEntitiesForBR()).andReturn(allLegalEntityForBR).anyTimes();
		
		EasyMock.replay(commonDataDao);
		Whitebox.setInternalState(commonDataServiceImpl , "commonDataDao", commonDataDao);
		Whitebox.invokeMethod(commonDataServiceImpl, "initialise");
	}
	
	private ProcessingUnit buildProcessingUnit(Integer pkProcessingUnitId,String unitName){
		ProcessingUnit processingUnit = new ProcessingUnit();
		processingUnit.setPkProcessingUnitId(pkProcessingUnitId);
		processingUnit.setUnitName(unitName);
		return processingUnit;
	}

	private LegalEntity buildLegalEntity(int pk, String code, String name, String aliasName) {
		LegalEntity legalEntity = new LegalEntity();
		legalEntity.setPkLegalEntityId(pk);
		legalEntity.setLegalEntityCode(code);
		legalEntity.setLegalEntityName(name);
		legalEntity.setAliasName(aliasName);
		return legalEntity;
	}
	
	@Test
	public void testGetLegalEntities() {
		List<LegalEntity> allLegalEntity = commonDataServiceImpl.getLegalEntities();
		assertNotNull(allLegalEntity);
		assertEquals(allLegalEntity.size(), 2);
	}
	
	@Test
	public void testGetLegalEntitiesForBR() {
		List<LegalEntity> allLegalEntity = commonDataServiceImpl.getLegalEntitiesForBR();
		assertNotNull(allLegalEntity);
		assertEquals(allLegalEntity.size(), 1);
	}

	@Test
	public void testGetLegalEntity() {
		LegalEntity entity = commonDataServiceImpl.getLegalEntity(1);
		assertNotNull(entity);
		assertEquals(entity.getLegalEntityCode(), "01");
	}

	@Test
	public void testGetAllLegalEntityFiterAliasName() {
		Map<String, LegalEntity> allLegalEntity = commonDataServiceImpl.getAllLegalEntityFiterAliasName();
		assertNotNull(allLegalEntity);
		assertEquals(allLegalEntity.size(), 2);
	}

	@Test
	public void testGetLegalEntityByCode() {
		LegalEntity entity = commonDataServiceImpl.getLegalEntityByCode("01");
		assertNotNull(entity);
		assertEquals(entity.getLegalEntityName(), "CGMI");
		
		LegalEntity entityForBR = commonDataServiceImpl.getLegalEntityByCode("0A");
		assertNotNull(entityForBR);
		assertEquals(entityForBR.getLegalEntityName(), "CGMI");
	}
	
	@Test
	public void testGetProcessingUnits(){
		List<ProcessingUnit> processingUnits = commonDataServiceImpl.getProcessingUnits();
		assertEquals(2,processingUnits.size());
	}

}
