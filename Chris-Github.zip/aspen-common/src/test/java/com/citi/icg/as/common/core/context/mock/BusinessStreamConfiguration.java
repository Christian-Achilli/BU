/**
 * 
 */
package com.citi.icg.as.common.core.context.mock;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citi.icg.as.core.context.annotation.ConditionalSystemStream;

/**
 * @author AP72338
 *
 */

@Configuration
public class BusinessStreamConfiguration {

	@Bean
	@ConditionalSystemStream("markets")
	public SimpleBusinessStreamInterface marketsStream(){
		return new SimpleMarketsImpl();
	}
	
	@Bean
	@ConditionalSystemStream("custody")
	public SimpleBusinessStreamInterface custodyStream(){
		return new SimpleCustodyImpl();
	}
}
