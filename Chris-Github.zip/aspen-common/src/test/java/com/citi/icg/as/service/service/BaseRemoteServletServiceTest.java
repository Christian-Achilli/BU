package com.citi.icg.as.service.service;

import java.lang.reflect.Method;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.citi.icg.as.common.client.exception.EntitlementException;
import com.citi.icg.as.common.util.ReflectUtils;
import com.citi.icg.as.server.GcasRequestContext;
import com.citi.icg.as.server.service.BaseRemoteServletService;
import com.citi.icg.as.server.service.GcasRpcContext;
import com.citi.icg.toolkit.web.server.RequestContext;
import com.google.gwt.user.client.rpc.IncompatibleRemoteServiceException;
import com.google.gwt.user.client.rpc.SerializationException;
import com.google.gwt.user.server.rpc.AbstractRemoteServiceServlet;
import com.google.gwt.user.server.rpc.RPC;
import com.google.gwt.user.server.rpc.RPCRequest;
import com.google.gwt.user.server.rpc.RPCServletUtils;
import com.google.gwt.user.server.rpc.SerializationPolicy;
import com.google.gwt.user.server.rpc.SerializationPolicyProvider;
import com.google.gwt.user.server.rpc.UnexpectedException;

@RunWith(PowerMockRunner.class) 
@PrepareForTest({RPCServletUtils.class, ServletContext.class, HttpServletResponse.class, BaseRemoteServletService.class, RPC.class, RPCRequest.class, GcasRpcContext.class,GcasRequestContext.class})
public class BaseRemoteServletServiceTest {
	
	@Before
	public void setup(){
		RequestContext.set("ca_super_emea_1");
	}

	@Test
	public void doUnexpectedFailureTest() throws Exception {
		BaseRemoteServletService service = PowerMock.createPartialMock(BaseRemoteServletService.class, "getServletContext", "getThreadLocalResponse");
		PowerMock.mockStatic(RPCServletUtils.class);
		ServletContext context = PowerMock.createMock(ServletContext.class);
		HttpServletResponse response = PowerMock.createMock(HttpServletResponse.class);
		EasyMock.expect(service.getServletContext()).andStubReturn(context);
		Method getThreadLocalResponseMethod = BaseRemoteServletService.class.getSuperclass().getSuperclass().getDeclaredMethod("getThreadLocalResponse");
		getThreadLocalResponseMethod.setAccessible(true);
		EasyMock.expect(getThreadLocalResponseMethod.invoke(service)).andReturn(response).anyTimes();
		RPCServletUtils.writeResponse(EasyMock.isA(ServletContext.class), EasyMock.isA(HttpServletResponse.class), EasyMock.isA(String.class), EasyMock.anyBoolean());
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		Method method = service.getClass().getDeclaredMethod("doUnexpectedFailure", Throwable.class);
		method.setAccessible(true);
		method.invoke(service, new NullPointerException());
		method.invoke(service, new UnexpectedException("123", new NullPointerException()));
	}
	
	@Test(expected = NullPointerException.class)
	public void doUnexpectedFailureWhenThrowExceptionTest() throws Exception {
		BaseRemoteServletService service = PowerMock.createPartialMock(BaseRemoteServletService.class, "getServletContext", "getThreadLocalResponse");
		PowerMock.mockStatic(RPCServletUtils.class);
		ServletContext context = PowerMock.createMock(ServletContext.class);
		EasyMock.expect(service.getServletContext()).andStubReturn(context);
		Method getThreadLocalResponseMethod = BaseRemoteServletService.class.getSuperclass().getSuperclass().getDeclaredMethod("getThreadLocalResponse");
		getThreadLocalResponseMethod.setAccessible(true);
		EasyMock.expect(getThreadLocalResponseMethod.invoke(service)).andThrow(new NullPointerException()).anyTimes();
		RPCServletUtils.writeResponse(EasyMock.isA(ServletContext.class), EasyMock.isA(HttpServletResponse.class), EasyMock.isA(String.class), EasyMock.anyBoolean());
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		Method method = service.getClass().getDeclaredMethod("doUnexpectedFailure", Throwable.class);
		method.setAccessible(true);
		method.invoke(service, new NullPointerException());
	}
	
	@Test
	public void serviceTest() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		BaseRemoteServletService service = new BaseRemoteServletService();
		service.service(request, response);
	}
	
	@Test
	public void processCallTest() throws Exception {
		RequestContext.set("ca_super_emea_1");
		
		//test normal case
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		PowerMock.mockStatic(GcasRequestContext.class);
		SerializationPolicy policy = PowerMock.createMock(SerializationPolicy.class);
		RPCRequest request = PowerMock.createMock(RPCRequest.class);
		GcasRpcContext context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andReturn(request).anyTimes();
		Method method = BaseRemoteServletService.class.getDeclaredMethod("getEntitlement");
		EasyMock.expect(request.getMethod()).andReturn(method).anyTimes();
		EasyMock.expect(request.getParameters()).andReturn(new Object[0]).anyTimes();
		EasyMock.expect(request.getSerializationPolicy()).andReturn(policy).anyTimes();
		EasyMock.expect(RPC.encodeResponseForSuccess(EasyMock.isA(Method.class), EasyMock.isNull(), EasyMock.isA(SerializationPolicy.class))).andReturn("123").anyTimes();
		EasyMock.expect(GcasRpcContext.start(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(Method.class))).andReturn(context).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		EasyMock.expect(GcasRequestContext.getUserId()).andReturn("").times(3);
		EasyMock.expect(GcasRequestContext.getRequestId()).andReturn("").times(2);
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		context.setFailed(true);
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		BaseRemoteServletService service = new BaseRemoteServletService();
		service.processCall("hello");
		
		//test catch IllegalArgumentException case
		PowerMock.resetAll();
		IllegalArgumentException e1 = null;
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andThrow(new IllegalArgumentException()).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		context.setFailed(EasyMock.anyBoolean());
		EasyMock.expectLastCall().anyTimes();
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		try {
			service.processCall("hello");
		} catch (IllegalArgumentException e) {
			e1 = e;
		}
		Assert.assertNotNull(e1);
		
		//test catch IncompatibleRemoteServiceException case
		PowerMock.resetAll();
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		policy = PowerMock.createMock(SerializationPolicy.class);
		request = PowerMock.createMock(RPCRequest.class);
		context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andReturn(request).anyTimes();
		EasyMock.expect(request.getMethod()).andThrow(new IncompatibleRemoteServiceException()).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		context.setFailed(EasyMock.anyBoolean());
		EasyMock.expectLastCall().anyTimes();
		EasyMock.expect(request.getSerializationPolicy()).andReturn(policy).anyTimes();
		EasyMock.expect(RPC.encodeResponseForFailure((Method) EasyMock.isNull(), EasyMock.isA(Throwable.class), EasyMock.isA(SerializationPolicy.class))).andReturn("123").anyTimes();
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		service.processCall("hello");
		
		PowerMock.resetAll();
		EntitlementException e2 = null;
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andThrow(new EntitlementException()).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		context.setFailed(EasyMock.anyBoolean());
		EasyMock.expectLastCall().anyTimes();
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		try {
			service.processCall("hello");
		} catch (EntitlementException e) {
			e2 = e;
		}
		Assert.assertNotNull(e2);
		
		PowerMock.resetAll();
		RuntimeException e3 = null;
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andThrow(new RuntimeException()).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		context.setFailed(EasyMock.anyBoolean());
		EasyMock.expectLastCall().anyTimes();
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		try {
			service.processCall("hello");
		} catch (RuntimeException e) {
			e3 = e;
		}
		Assert.assertNotNull(e3);
	}
	
	@Test(expected=NullPointerException.class)
	public void processCallWhenPayloadIsNullTest() throws SerializationException{
		BaseRemoteServletService service = new BaseRemoteServletService();
		String n = null;
		service.processCall(n);
	}
	
	@Test(expected=NullPointerException.class)
	public void processCallWhenRpcRequestIsNullTest() throws Exception{
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		SerializationPolicy policy = PowerMock.createMock(SerializationPolicy.class);
		RPCRequest request = PowerMock.createMock(RPCRequest.class);
		GcasRpcContext context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andReturn(null).anyTimes();
		Method method = BaseRemoteServletService.class.getDeclaredMethod("getEntitlement");
		EasyMock.expect(request.getMethod()).andReturn(method).anyTimes();
		EasyMock.expect(request.getParameters()).andReturn(new Object[0]).anyTimes();
		EasyMock.expect(request.getSerializationPolicy()).andReturn(policy).anyTimes();
		EasyMock.expect(RPC.encodeResponseForSuccess(EasyMock.isA(Method.class), EasyMock.isNull(), EasyMock.isA(SerializationPolicy.class))).andReturn("123").anyTimes();
		EasyMock.expect(GcasRpcContext.start(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(Method.class))).andReturn(context).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		context.setFailed(EasyMock.anyBoolean());
		EasyMock.expectLastCall();
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		BaseRemoteServletService service = new BaseRemoteServletService();
		service.processCall("hello");
	}
	
	@Test(expected=NullPointerException.class)
	public void processCallWhenMethodIsNullTest() throws Exception{
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		SerializationPolicy policy = PowerMock.createMock(SerializationPolicy.class);
		RPCRequest request = PowerMock.createMock(RPCRequest.class);
		GcasRpcContext context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andReturn(request).anyTimes();
//		Method method = BaseRemoteServletService.class.getDeclaredMethod("getEntitlement");
		EasyMock.expect(request.getMethod()).andReturn(null).anyTimes();
		EasyMock.expect(request.getParameters()).andReturn(new Object[0]).anyTimes();
		EasyMock.expect(request.getSerializationPolicy()).andReturn(policy).anyTimes();
		EasyMock.expect(RPC.encodeResponseForSuccess(EasyMock.isA(Method.class), EasyMock.isNull(), EasyMock.isA(SerializationPolicy.class))).andReturn("123").anyTimes();
		EasyMock.expect(GcasRpcContext.start(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(Method.class))).andReturn(context).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		context.setFailed(EasyMock.anyBoolean());
		EasyMock.expectLastCall();
		PowerMock.replayAll();
		BaseRemoteServletService service = new BaseRemoteServletService();
		service.processCall("hello");
	}
	
	@Test
	public void processCallWhenReturnStringIsNullTest() throws Exception{
		PowerMock.mockStatic(RPC.class);
		PowerMock.mockStatic(GcasRpcContext.class);
		PowerMock.mockStatic(GcasRequestContext.class);
		SerializationPolicy policy = PowerMock.createMock(SerializationPolicy.class);
		RPCRequest request = PowerMock.createMock(RPCRequest.class);
		GcasRpcContext context = PowerMock.createMock(GcasRpcContext.class);
		EasyMock.expect(RPC.decodeRequest(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(SerializationPolicyProvider.class))).andReturn(request).anyTimes();
		Method method = BaseRemoteServletService.class.getDeclaredMethod("getEntitlement");
		EasyMock.expect(request.getMethod()).andReturn(method).anyTimes();
		EasyMock.expect(request.getParameters()).andReturn(new Object[0]).anyTimes();
		EasyMock.expect(request.getSerializationPolicy()).andReturn(policy).anyTimes();
		EasyMock.expect(RPC.encodeResponseForSuccess(EasyMock.isA(Method.class), EasyMock.isNull(), EasyMock.isA(SerializationPolicy.class))).andReturn(null).anyTimes();
		EasyMock.expect(GcasRpcContext.start(EasyMock.isA(String.class), EasyMock.isA(Class.class), EasyMock.isA(Method.class))).andReturn(context).anyTimes();
		EasyMock.expect(GcasRpcContext.get()).andReturn(context).anyTimes();
		EasyMock.expect(GcasRequestContext.getUserId()).andReturn("").times(3);
		EasyMock.expect(GcasRequestContext.getRequestId()).andReturn("").times(2);
		GcasRpcContext.finish();
		EasyMock.expectLastCall().anyTimes();
		context.setFailed(true);
		EasyMock.expectLastCall().anyTimes();
		PowerMock.replayAll();
		BaseRemoteServletService service = new BaseRemoteServletService();
		service.processCall("hello");
	}
	@Test
	public void testValidateThreadLocalData() throws Exception{
		BaseRemoteServletService service = new BaseRemoteServletService();
//		ReflectUtils.setFieldValue(service, "perThreadRequest", new ThreadLocal<HttpServletRequest>());
//		ReflectUtils.setFieldValue(service, "perThreadResponse", new ThreadLocal<HttpServletResponse>());
		Whitebox.setInternalState(service, "perThreadRequest",  new ThreadLocal<HttpServletRequest>(), AbstractRemoteServiceServlet.class);
		Whitebox.setInternalState(service, "perThreadResponse",  new ThreadLocal<HttpServletResponse>(), AbstractRemoteServiceServlet.class);
		ReflectUtils.invokeInstanceMethod(service, "validateThreadLocalData", new Object[]{}, new Class[]{});
	}
}
