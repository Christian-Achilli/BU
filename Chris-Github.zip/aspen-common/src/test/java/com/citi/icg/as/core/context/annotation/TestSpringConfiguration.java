package com.citi.icg.as.core.context.annotation;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author ap72338
 *
 */

@Configuration
@ComponentScan("com.citi.icg.as.core.context.annotation")
public class TestSpringConfiguration {

}
