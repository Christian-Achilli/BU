package com.citi.icg.as.dao;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.orm.hibernate3.HibernateOperations;
import org.springframework.util.Assert;

import com.citi.icg.as.map.BeanMapper;

public class BaseEntityDaoComponentTest {

	BaseEntityDaoComponent<EntityA, EntityB> dao;
	HibernateOperations ho;
	BeanMapper bm;

	@Before
	public void before() {

		ho = EasyMock.createMock(HibernateOperations.class);
		bm = EasyMock.createMock(BeanMapper.class);
		dao = new BaseEntityDaoComponent<EntityA, EntityB>(ho, bm) {
		};

	}

	@Test
	public void test_convertToBusinessEntity() throws InstantiationException, IllegalAccessException {
		EntityA bus = new EntityA();
		EntityB hbm = new EntityB();
		EasyMock.expect(bm.map(hbm, EntityA.class)).andReturn(bus);
		EasyMock.replay(bm);
		Assert.notNull(dao.convertToBusinessEntity(hbm));
		EasyMock.verify(bm);
	}

	@Test
	public void test_convertToHibernateEntity() {
		EntityA bus = new EntityA();
		EntityB hbm = new EntityB();
		EasyMock.expect(bm.map(bus, EntityB.class)).andReturn(hbm);
		EasyMock.replay(bm);
		Assert.notNull(dao.convertToHibernateEntity(bus));
		EasyMock.verify(bm);
	}


}
