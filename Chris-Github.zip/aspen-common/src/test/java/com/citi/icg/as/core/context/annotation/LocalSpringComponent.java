/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import org.springframework.stereotype.Component;

/**
 * @author ap72338
 *
 */

@Component
@ConditionalRunningLocally
public class LocalSpringComponent {

}
