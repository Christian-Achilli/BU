package com.citi.icg.as.common.client.compare;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.Ignore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateSystemException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import com.citi.icg.as.common.dao.impl.HbmUserDao;
import com.citi.icg.as.core.dao.entities.business.ProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.Region;
import com.citi.icg.as.core.dao.entities.business.User;
import com.citi.icg.as.core.dao.entities.business.UserProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.UserRegion;

@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class })
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/common-service.xml",
		"classpath:/data-source-context.xml" })
@PrepareForTest({ TestConverter.class })
@Ignore
public class TestConverter {

	@Autowired
	private HbmUserDao hbmUserDao;

	@Test
	public void test13() throws SQLException {
		UserProcessingUnit u=new UserProcessingUnit();
		u.setUser(new User());
		u.setLastUpdatedBy("abc");
		ProcessingUnit unit=new ProcessingUnit();
		unit.setPkProcessingUnitId(4);
		unit.setUnitName("MF");
		u.setProcessingUnit(unit);
		u.setIsDefault("no");
		hbmUserDao.getUserProcessingUnitFromDb(u);
	}
	
	@Test
	public void test14() throws SQLException {
		UserRegion ur=new UserRegion();
		ur.setPrimaryRegion("EMEA");
		User user=new User();
		user.setUserId("test");
		ur.setUser(user);
		Region r=new  Region();
		r.setRegionCode("IN");
		ur.setRegion(r);
		hbmUserDao.getUserRegionFromDb(ur);
	}

	@Test
	public void test6() throws SQLException {
		hbmUserDao.getUserAttributes("test");
	}

	@Test
	public void test7() throws SQLException {
		hbmUserDao.getUsers();
	}

	@Test
	public void test8() throws SQLException {
		com.citi.icg.as.core.dao.entities.business.UserSavedSearches bean = new com.citi.icg.as.core.dao.entities.business.UserSavedSearches();
		bean.setPkSearchId(1);
		hbmUserDao.getUserSavedSearchesByExample(bean);
	}

	@Test(expected = NullPointerException.class)
	@Ignore
	public void test9() throws SQLException {
		com.citi.icg.as.core.dao.entities.business.UserSavedSearches bean = new com.citi.icg.as.core.dao.entities.business.UserSavedSearches();
		bean.setPkSearchId(1);
		bean.setQueueType("A");
		hbmUserDao.saveOrUpdateUserSavedSearches(bean);
	}

	@Test
	public void test10() throws SQLException {
		hbmUserDao.getDateSaveSearchData("test", "test");
	}

	@Test
	public void test11() throws SQLException {
		hbmUserDao.getDateSaveSearchLayout("test", "test", "test", "test");
	}

	@Test
	public void test12() {
		try {
			hbmUserDao.removeDateSearchLayout("test", "test", "test");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	@Test(expected = HibernateSystemException.class)
	public void test1() throws SQLException {
		List<User> users = new ArrayList<User>();
		User user = new User();
		user.setUserNameFirst("No First Name");
		user.setUserNameLast("No Last Name");
		users.add(user);
		hbmUserDao.addUsers(users);
	}

	@Test
	public void test2() throws SQLException {
			User user=	hbmUserDao.getUser("test");
			Assert.assertNull(user);
	}

	@Test
	public void test3() throws SQLException {
		hbmUserDao.getAttributesForUserId("1");
	}

	@Test(expected = IllegalArgumentException.class)
	public void test4() throws SQLException {
		List<User> users = new ArrayList<User>();
		User user = new User();
		user.setUserNameFirst("No First Name");
		user.setUserNameLast("No Last Name");
		users.add(user);
		hbmUserDao.removeUsers(users);
	}

	@Test(expected = NullPointerException.class)
	@Ignore
	public void test5() throws SQLException {
		User user = new User();
		user.setUserNameFirst("No First Name");
		user.setUserNameLast("No Last Name");
		hbmUserDao.mergeUser(user);
	}
}
