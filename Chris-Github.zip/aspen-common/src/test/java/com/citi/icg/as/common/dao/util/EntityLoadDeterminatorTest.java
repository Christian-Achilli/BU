/**
 * 
 */
package com.citi.icg.as.common.dao.util;

import org.junit.Assert;
import org.junit.Test;

import com.citi.icg.as.common.dao.EntityLoadDeterminator;
import com.citi.icg.as.core.dao.entities.ext.beans.AnnouncementCopyType;
import com.citi.icg.as.core.dao.entities.ext.beans.Region;

/**
 * @author ap72338
 *
 */
public class EntityLoadDeterminatorTest {

	@Test
	public void defaultCaseEntityShouldBeLoaded() {
		Assert.assertTrue("Region should be loaded", EntityLoadDeterminator.isEntityToBeLoaded(Region.class));
	}

	@Test
	public void regionNotToBeLoaded() {
		EntityLoadDeterminator.dontLoadEntity(Region.class);
		Assert.assertFalse("Region should not be loaded", EntityLoadDeterminator.isEntityToBeLoaded(Region.class));
	}

	@Test
	public void afterClearingParticularEntityItShouldBeLoaded() {
		EntityLoadDeterminator.dontLoadEntity(Region.class);
		Assert.assertFalse("Region should not be loaded", EntityLoadDeterminator.isEntityToBeLoaded(Region.class));
		EntityLoadDeterminator.clearEntity(Region.class);
		Assert.assertTrue("Region should be loaded", EntityLoadDeterminator.isEntityToBeLoaded(Region.class));		
	}

	@Test
	public void afterClearingEveryThingAllShouldBeLoaded() {
		EntityLoadDeterminator.dontLoadEntity(Region.class);
		EntityLoadDeterminator.dontLoadEntity(AnnouncementCopyType.class);
		Assert.assertFalse("Region should not be loaded", EntityLoadDeterminator.isEntityToBeLoaded(Region.class));
		Assert.assertFalse("Region should not be loaded", EntityLoadDeterminator.isEntityToBeLoaded(AnnouncementCopyType.class));
		
		EntityLoadDeterminator.clearAll();
		
		Assert.assertTrue("Region should be loaded", EntityLoadDeterminator.isEntityToBeLoaded(Region.class));		
		Assert.assertTrue("Region should be loaded", EntityLoadDeterminator.isEntityToBeLoaded(AnnouncementCopyType.class));
	}
}
