package com.citi.icg.as.common.workflow.jbpm3;

import com.citi.icg.as.common.workflow.Workflow;

public interface TestDefinition2 extends Workflow
{

	void start();
	
	void goToState1();
	
	void goToState2();
	
	void goToState3();
	
}
