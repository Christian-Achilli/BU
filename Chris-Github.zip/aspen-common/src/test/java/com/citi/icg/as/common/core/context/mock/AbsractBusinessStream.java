/**
 * 
 */
package com.citi.icg.as.common.core.context.mock;

/**
 * @author AP72338
 *
 */
public abstract class AbsractBusinessStream implements SimpleBusinessStreamInterface {

	@Override
	public int calculateTotal(String... values) {
		for (String v : values) {
			if (!v.matches("^[\\d]+$"))
				throw new IllegalArgumentException(String.format("%s not a valid number", v));
		}
		return calculateTotalInternal(values);
	}

	protected int calculateTotalInternal(String... values) {
		return 0;
	}
}
