package com.citi.icg.as.common.client.util;

import org.apache.commons.configuration.XMLConfiguration;

public class TestHessianConfiguration extends XMLConfiguration{
	private String alertUrl;
	
	private String announcementUrl;
	
	private String positionUrl;
	
	private String notificationUrl;
	
	private String wcUrl;
	
	public String getAlertUrl() {
		return getString("app.alert-url");
	}
	
	public String getAnnouncementUrl() {
		return getString("app.announcement-url");
	}

	public String getPositionUrl() {
		return getString("app.position-url");
	}

	public String getNotificationUrl() {
		return getString("app.notification-url");
	}

	public String getWcUrl() {
		return getString("app.wc-url");
	}
}
