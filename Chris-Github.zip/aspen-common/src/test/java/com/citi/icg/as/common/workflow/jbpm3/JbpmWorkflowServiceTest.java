package com.citi.icg.as.common.workflow.jbpm3;

import java.lang.reflect.InvocationHandler;

import org.easymock.EasyMock;
import org.jbpm.command.CommandService;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.citi.icg.as.common.util.IProxyHelper;
import com.citi.icg.as.common.workflow.StringWorkflowKey;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.DeployDefinitionCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.GetProcessCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.NewProcessCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.RetrieveDefinitionCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.SetPooledActorsCallback;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ProcessDefinition.class})
public class JbpmWorkflowServiceTest {

	JbpmWorkflowService svc;
	CommandService cs;
	IProxyHelper ph;
	CallbackManager cbm;
	
	@Before
	public void before()
	{
		cs = EasyMock.createMock(CommandService.class);
		ph = EasyMock.createMock(IProxyHelper.class);
		cbm = EasyMock.createMock(CallbackManager.class);
		svc = new JbpmWorkflowService(cs, ph, cbm);
	}
	
	public void test_JbpmWorkflowService1()
	{
		svc = new JbpmWorkflowService(cs, ph);
		Assert.assertEquals(CommandServiceCallbackManager.class, svc.callbackManager.getClass());
	}
	
	public void test_setPooledActors()
	{
		cbm.executeCallback(EasyMock.isA(SetPooledActorsCallback.class));
		EasyMock.replay(cbm);
		svc.setPooledActors(null, null);
		EasyMock.verify(cbm);
	}
	
	@Test
	public void test_deployWorkflow()
	{
		String xml = "jpdl/TestDefinition1/processdefinition.xml";
		ProcessDefinition pd = new ProcessDefinition();
		
		EasyMock.expect(cbm.executeCallback(EasyMock.isA(RetrieveDefinitionCallback.class))).andReturn(null);
		PowerMock.mockStatic(ProcessDefinition.class);
		EasyMock.expect(ProcessDefinition.parseXmlResource(xml)).andReturn(pd);
		EasyMock.expect(cbm.executeCallback(EasyMock.isA(DeployDefinitionCallback.class))).andReturn(pd);
		
		PowerMock.replay(cbm, ProcessDefinition.class);
		svc.deployWorkflow(TestDefinition1.class);
		PowerMock.verify(ProcessDefinition.class, cbm);
		
	}
		
	@Test
	public void test_deployWorkflow_2()
	{
		
		ProcessDefinition pd = new ProcessDefinition();
		EasyMock.expect(cbm.executeCallback(EasyMock.isA(RetrieveDefinitionCallback.class))).andReturn(pd);
		
		EasyMock.replay(cbm);
		svc.deployWorkflow(TestDefinition1.class);
		EasyMock.verify(cbm);
		
	}
	
	@Test
	public void test_getProxyWorkflowInstance()
	{
		StringWorkflowKey key = new StringWorkflowKey("key");
		
		InvocationHandler def = EasyMock.createMock(InvocationHandler.class);
		
		EasyMock.expect(cbm.executeCallback(EasyMock.isA(GetProcessCallback.class))).andReturn(new ProcessInstance());
		EasyMock.expect(ph.getTransactionalInstance(EasyMock.isA(InvocationHandler.class))).andReturn(def);
		
		EasyMock.replay(cbm, ph);
		TestDefinition1 proxy = svc.getProxyWorkflowInstance(TestDefinition1.class, key);
		Assert.assertNotNull(proxy);
		EasyMock.verify(cbm, ph);
		
	}
	
	
	public void test_getProxyWorkflowInstance_2()
	{
		StringWorkflowKey key = new StringWorkflowKey("key");
		
		InvocationHandler def = EasyMock.createMock(InvocationHandler.class);
		
		EasyMock.expect(cbm.executeCallback(EasyMock.isA(GetProcessCallback.class))).andReturn(null);
		EasyMock.expect(cbm.executeCallback(EasyMock.isA(RetrieveDefinitionCallback.class))).andReturn(new ProcessDefinition());
		EasyMock.expect(ph.getTransactionalInstance(EasyMock.isA(InvocationHandler.class))).andReturn(def);
		EasyMock.expect(cbm.executeCallback(EasyMock.isA(NewProcessCallback.class))).andReturn(new ProcessInstance());
		
		EasyMock.replay(cbm, ph);
		TestDefinition1 proxy = svc.getProxyWorkflowInstance(TestDefinition1.class, key);
		EasyMock.verify(cbm, ph);
		
	}
	
	
	
}
