package com.citi.icg.as.server.service.comparator;

import java.util.Arrays;

import org.junit.Test;

import com.citi.icg.as.server.service.compare.TestObject;

public class BeanPropertyValuesComparatorTest extends ComparatorUtilTest {
	@Test
	public void testConstructor() throws InterruptedException {
		new BeanPropertyValuesComparator<TestObject>(Arrays.asList("id")).compare(constructTestObject(1),
				constructTestObject(2));
	}
}
