/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.citi.icg.as.common.constants.CommonConstants;


/**
 * @author ap72338
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=TestSpringConfiguration.class)
@DirtiesContext
public class ConditionalRunningOnServerWithLocalConfigTest {

	@Autowired(required=false)
	private DummySpringComponent springComponent;	
	
	@Autowired(required=false)
	private LocalSpringComponent localSpringComponent;	
	
	@BeforeClass
	public static void setUp(){
		System.setProperty(CommonConstants.SYSTEM_ENV_PROPERTY, "local");
	}
	@Test
	public void testDummyComponentToBeNull(){
		Assert.assertNull("In local environment the server component should not be created",springComponent);
	}	
	@Test
	public void testLocalComponentToBeNotNull(){
		Assert.assertNotNull("In local environment the local component should always be created" , localSpringComponent);
	}		
	
}
