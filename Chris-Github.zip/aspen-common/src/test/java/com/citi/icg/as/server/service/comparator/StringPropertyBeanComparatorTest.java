package com.citi.icg.as.server.service.comparator;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;
import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.citi.icg.as.server.service.compare.TestObject;

@PrepareForTest(BeanUtils.class)
@RunWith(PowerMockRunner.class)
public class StringPropertyBeanComparatorTest extends ComparatorUtilTest {
	@Test
	public void testCompare() {
		new StringPropertyBeanComparator<TestObject>("username")
				.compare(constructTestObject(1), constructTestObject(2));
		new StringPropertyBeanComparator<TestObject>("username").compare(null, null);
		new StringPropertyBeanComparator<TestObject>("username").compare(constructTestObject(1), null);
		new StringPropertyBeanComparator<TestObject>("username").compare(null, constructTestObject(1));
	}

	@Test(expected = ClassCastException.class)
	public void testCompare_2() throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		PowerMock.mockStatic(BeanUtils.class);
		EasyMock.expect(BeanUtils.getProperty(EasyMock.isA(Object.class), EasyMock.isA(String.class))).andThrow(
				new RuntimeException());
		PowerMock.replayAll();
		new StringPropertyBeanComparator<TestObject>("username")
				.compare(constructTestObject(1), constructTestObject(2));
	}

}
