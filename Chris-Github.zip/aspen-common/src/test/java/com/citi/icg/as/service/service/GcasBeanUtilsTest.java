package com.citi.icg.as.service.service;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.citi.icg.as.exception.GcasException;
import com.citi.icg.as.server.service.GcasBeanUtils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({BeanUtils.class, PropertyUtils.class})
public class GcasBeanUtilsTest {

	@Test
	public void setPropertyTest() throws GcasException {
		GcasBeanUtils.setProperty(new GcasBeanUtilsTesttools(), "test", "12");
	}
	
	@Test(expected=GcasException.class)
	public void setPropertyWhenCatchIllegalAccessExceptionTest() throws Exception {
		PowerMock.mockStatic(BeanUtils.class);
		BeanUtils.setProperty(EasyMock.isA(Object.class), EasyMock.isA(String.class), EasyMock.isA(Object.class));
		EasyMock.expectLastCall().andThrow(new IllegalAccessException());
		PowerMock.replayAll();
		GcasBeanUtils.setProperty(new GcasBeanUtilsTest(), "test", "123");
	}
	
	@Test(expected=GcasException.class)
	public void setPropertyWhenCatchInvocationTargetExceptionTest() throws Exception {
		PowerMock.mockStatic(BeanUtils.class);
		BeanUtils.setProperty(EasyMock.isA(Object.class), EasyMock.isA(String.class), EasyMock.isA(Object.class));
		EasyMock.expectLastCall().andThrow(new InvocationTargetException(new NullPointerException()));
		PowerMock.replayAll();
		GcasBeanUtils.setProperty(new GcasBeanUtilsTest(), "test", "123");
	}
	
	@Test
	public void getPorpertyTest(){
		GcasBeanUtils.getProperty(new GcasBeanUtilsTesttools(), "test", "123");
	}
	
	@Test
	public void getPorpertyWhenCatchGcasExceptionTest() throws Exception{
		PowerMock.mockStatic(PropertyUtils.class);
		EasyMock.expect(PropertyUtils.getProperty(EasyMock.isA(Object.class), EasyMock.isA(String.class))).andThrow(new RuntimeException());
		PowerMock.replayAll();
		GcasBeanUtils.getProperty(new GcasBeanUtilsTesttools(), "test", "123");
	}
	
	@Test
	public void convertTest(){
		GcasBeanUtils.convert("123", null);
		GcasBeanUtils.convert("123", String.class);
		GcasBeanUtils.convert("123", GcasBeanUtilsTest.class);
	}
	
	@Test
	public void getPropertiesTest(){
		GcasBeanUtils.getProperties(new GcasBeanUtilsTest());
	}
	
	@Test(expected=RuntimeException.class)
	public void getPropertiesWhenCatchExceptionTest() throws Exception{
		PowerMock.mockStatic(BeanUtils.class);
		EasyMock.expect(BeanUtils.describe(EasyMock.isA(Object.class))).andThrow(new RuntimeException());
		PowerMock.replayAll();
		GcasBeanUtils.getProperties(new GcasBeanUtilsTest());
	}
	
	@Test
	public void describeTest(){
		GcasBeanUtils.describe(new GcasBeanUtilsTest());
	}
	
	@Test(expected=RuntimeException.class)
	public void describeWhenCatchExceptionTest() throws Exception{
		PowerMock.mockStatic(BeanUtils.class);
		EasyMock.expect(BeanUtils.describe(EasyMock.isA(Object.class))).andThrow(new RuntimeException());
		PowerMock.replayAll();
		GcasBeanUtils.describe(new GcasBeanUtilsTest());
	}
}
