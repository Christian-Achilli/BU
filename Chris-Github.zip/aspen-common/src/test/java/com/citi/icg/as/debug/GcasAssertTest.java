package com.citi.icg.as.debug;

import org.junit.Test;

import com.citi.icg.as.exception.GcasAssertError;

public class GcasAssertTest {

	@Test(expected = GcasAssertError.class)
	public void testNotNull(){
		GcasAssert.notNull("", "");
		GcasAssert.notNull(null, "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrBlank(){
		GcasAssert.notNullOrBlank("a", "");
		GcasAssert.notNullOrBlank("", "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrEmpty(){
		GcasAssert.notNullOrEmpty(new Object[]{new Object()}, "");
		GcasAssert.notNullOrEmpty(new Object[0], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrEmpty2(){
		GcasAssert.notNullOrEmpty(new byte[]{1}, "");
		GcasAssert.notNullOrEmpty(new byte[0], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrEmpty3(){
		GcasAssert.notNullOrEmpty(new short[]{1}, "");
		GcasAssert.notNullOrEmpty(new short[0], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrEmpty4(){
		GcasAssert.notNullOrEmpty(new int[]{1}, "");
		GcasAssert.notNullOrEmpty(new int[0], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrEmpty5(){
		GcasAssert.notNullOrEmpty(new long[]{1}, "");
		GcasAssert.notNullOrEmpty(new long[0], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrEmpty6(){
		GcasAssert.notNullOrEmpty(new float[]{1}, "");
		GcasAssert.notNullOrEmpty(new float[0], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNotNullOrEmpty7(){
		GcasAssert.notNullOrEmpty(new double[]{1}, "");
		GcasAssert.notNullOrEmpty(new double[0], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testPositiveInteger(){
		GcasAssert.positiveInteger(new Integer(1), "");
		GcasAssert.positiveInteger(new Integer(-1), "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testNonNegativeInteger(){
		GcasAssert.nonNegativeInteger(new Integer(0), "");
		GcasAssert.nonNegativeInteger(new Integer(-1), "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testPositiveNumber(){
		GcasAssert.positiveNumber(1, "");
		GcasAssert.positiveNumber(-1, "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testPositiveNumber2(){
		GcasAssert.positiveNumber(new Integer(1), "");
		GcasAssert.positiveNumber(new Integer(-1), "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testInRange(){
		GcasAssert.inRange(1, 0, 2, "");
		GcasAssert.inRange(-1, 0, 2, "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testInRange2(){
		GcasAssert.inRange(new Integer(1), 0, 2, "");
		GcasAssert.inRange(new Integer(-1), 0, 2, "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testWithinBounds(){
		GcasAssert.withinBounds(1, new byte[2], "");
		GcasAssert.withinBounds(-1, new byte[2], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testWithinBounds2(){
		GcasAssert.withinBounds(1, new int[2], "");
		GcasAssert.withinBounds(-1, new int[2], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testWithinBounds3(){
		GcasAssert.withinBounds(1, new long[2], "");
		GcasAssert.withinBounds(-1, new long[2], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testWithinBounds4(){
		GcasAssert.withinBounds(1, new float[2], "");
		GcasAssert.withinBounds(-1, new float[2], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testWithinBounds5(){
		GcasAssert.withinBounds(1, new double[2], "");
		GcasAssert.withinBounds(-1, new double[2], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testWithinBounds6(){
		GcasAssert.withinBounds(1, new Object[2], "");
		GcasAssert.withinBounds(-1, new Object[2], "");
	}
	
	@Test(expected = GcasAssertError.class)
	public void testInstanceOf(){
		GcasAssert.instanceOf("a", String.class, "");
		GcasAssert.instanceOf(new Integer(1), String.class, "");
		
	}
}
