/**
 * 
 */
package com.citi.icg.as.config;

import java.io.Writer;
import java.util.HashMap;

import org.junit.Before;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;

import com.citi.icg.as.server.common.template.engine.FreeMarkerTemplateUtility;

import freemarker.core.Environment;
import freemarker.template.Configuration;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

/**
 * @author ap72338
 *
 */
public abstract class BaseDynamicPropertiesTest extends BaseConfigTest {

	@Before
	public final void before() {
		FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
		bean.setTemplateLoaderPath("classpath:/");
		bean.setPreferFileSystemAccess(false);
		try {
			bean.afterPropertiesSet();
			Configuration config = bean.getObject();
			config.setTemplateExceptionHandler(new TemplateExceptionHandler() {
				public void handleTemplateException(TemplateException te, Environment env, Writer out)
						throws TemplateException {
				}
			});
			FreeMarkerTemplateUtility.getInstance().setConfiguration(config);
			beforeInternal();
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
	
	protected abstract void beforeInternal();
}
