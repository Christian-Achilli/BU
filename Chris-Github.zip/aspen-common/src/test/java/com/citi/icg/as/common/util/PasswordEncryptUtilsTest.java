package com.citi.icg.as.common.util;

import java.io.File;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.powermock.reflect.Whitebox;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;


public class PasswordEncryptUtilsTest {
	
	PasswordEncryptUtils pUtl = null;
	Resource resource = null;
	File file = null;
	
	@Before
	public void setup() throws IOException{
		File dir1 = new File (".");
		if(System.getProperty("os.name").startsWith("Windows")){
			file=new File(dir1.getCanonicalPath()+"\\src\\test\\resources\\key.dat");
		}else{
			file=new File(dir1.getCanonicalPath()+"/src/test/resources/key.dat");
			System.out.println("Inside PasswordEncryptUtilTest test "+file.getAbsolutePath());
		}
		//System.out.println(file.getAbsolutePath());
		if (file.exists()) {
		    resource=new FileSystemResource(file);
		}else{
			System.out.println("File does not exists");
		}
		pUtl = new PasswordEncryptUtils(resource);
		
		Whitebox.setInternalState(pUtl, "keyDat", resource);
		Whitebox.setInternalState(pUtl, "key", "TPnEFtmRVt4RqjZHZG0BtsBezFUPeX7FeYrWLlH9Kqj2VKvrXhdLacm8lgJenigEoTE134Az5wjuw6hGbZqJp66MaE0ndimevOgFJwuIrZkw9jqmJ0pItw7sDI14Hak8WixE27XKFaHHTf9Nh0YJ1Ws0SYBu2PkMJQK1zW4sWazqNVtLFClWuZ02jrOm60EsywV0tyL0xT9TIYlooMh8e7mWANYZj0UE5j47wURK3j0MUL783aQJeTpAl99OOR2a");
	}

	
	
	
	@Test
	public void testDecryptIfEncryptedCypherInitiated() throws Exception {
		Assert.assertEquals("ENC(Y6c8/MzYQln+NO1OBeHT1w==)",pUtl.decryptIfEncrypted("ENC(Y6c8/MzYQln+NO1OBeHT1w==)"));
	}
	
	
	
	@Test(expected=Exception.class)
	public void testDecryptIfEncryptedWithException() throws Exception {
		File dir1 = new File (".");
		file=new File(dir1.getCanonicalPath());
		pUtl = new PasswordEncryptUtils(resource);
		Whitebox.setInternalState(pUtl, "instance", pUtl);
		pUtl.decryptIfEncrypted("ENC(Y6c8/MzYQln+NO1OBeHT1w==)");
	}
	
	@Test(expected=NullPointerException.class)
	public void testIsKeyFileExistsWithException() throws Exception {
		resource=null;
		pUtl = new PasswordEncryptUtils(resource);
		Whitebox.setInternalState(pUtl, "instance", pUtl);
		Assert.assertTrue(pUtl.isKeyFileExists());
	}
	
	@Test
	public void testCreateAndStoreApplicaitonKeyWithException(){
		resource=null;
		pUtl = new PasswordEncryptUtils(resource);
		Whitebox.setInternalState(pUtl, "instance", pUtl);
		
	}

	
	@Test
	public void testIsKeyFileNotExists() throws Exception {
		if(System.getProperty("os.name").startsWith("Windows")){
			file=new File("\\src\\key.dat");
		}else{
			file=new File("/src/key.dat");
		}
		resource=new FileSystemResource(file);
		pUtl = new PasswordEncryptUtils(resource);
		Whitebox.setInternalState(pUtl, "instance", pUtl);
		Assert.assertFalse(pUtl.isKeyFileExists());
	}
	
	@Test
	public void testGetInstance() throws Exception {
		System.out.println(pUtl.getInstance());
	}

}
