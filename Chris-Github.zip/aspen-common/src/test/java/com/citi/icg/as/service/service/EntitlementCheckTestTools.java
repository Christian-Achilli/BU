package com.citi.icg.as.service.service;

import com.citi.icg.toolkit.web.client.IcgGwtException;

public class EntitlementCheckTestTools {

	public void toolThrowIcgGwtExcption(){
		throw new IcgGwtException();
	}
	
	public void toolThrowNotIcgGwtExcption(){
		throw new NullPointerException();
	}
}
