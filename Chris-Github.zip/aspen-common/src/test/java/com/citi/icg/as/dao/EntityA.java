package com.citi.icg.as.dao;

public class EntityA {
	//Dummy classes for Test cases.
}
