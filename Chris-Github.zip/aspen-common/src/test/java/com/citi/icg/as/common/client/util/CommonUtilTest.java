/**
 * 
 */
package com.citi.icg.as.common.client.util;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.citi.icg.as.common.util.CommonUtil;
import com.citi.icg.as.server.common.config.FreeMarkerTemplateConfiguration;
import com.citi.icg.as.server.common.template.engine.FreeMarkerTemplateUtility;

/**
 * @author ap72338
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { FreeMarkerTemplateConfiguration.class })
public class CommonUtilTest {

	@Autowired
	private FreeMarkerTemplateUtility freeMarkerTemplateUtility;

	@Test
	public void xmlConfigurationinstanceHasAllValuesPopulated() throws Exception {
		Map<String, Object> model = new HashMap<>();
		String annURL = "ANNURL";
		String notificationURL = "NOTIFICATIONURL";
		String positionURL = "POSITIONURL";
		String wcURL = "WCURL";
		String alertURL = "ALERTURL";
				
		model.put("announcement.url", annURL);
		model.put("notification.url", notificationURL);
		model.put("position.url", positionURL);
		model.put("wc.url", wcURL);
		model.put("alert.url", alertURL);
		
		/*This test will use configuration-testhessian.xml
		 * The XML file contains .data_model which is FreeMarker's implicit datamodel.
		 * Since we cannot directly access properties with (.) dots, hence we need to use .data_model 
		*/
		TestHessianConfiguration instance = CommonUtil
				.createDynamicConfigurationInstance(TestHessianConfiguration.class, null, model);
		
		Assert.assertEquals(annURL, instance.getAnnouncementUrl());
		Assert.assertEquals(positionURL, instance.getPositionUrl());
		Assert.assertEquals(wcURL, instance.getWcUrl());
		Assert.assertEquals(notificationURL, instance.getNotificationUrl());
		Assert.assertEquals(alertURL, instance.getAlertUrl());
	}
}
