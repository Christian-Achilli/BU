package com.citi.icg.as.server.util;

import org.junit.Assert;
import org.junit.Test;

public class AnnouncementConstantHelperTest {

	@Test
	public void test()
	{
		Assert.assertNotNull(AnnouncementConstantHelper.STOCK_PAYOUT);
	}
}
