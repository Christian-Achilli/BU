package com.citi.icg.as.exception;

import org.junit.Test;

public class GcasExceptionTest {
	@Test
	public void testGcasExceptioin(){
		new GcasException("message");
		new GcasException("message", new RuntimeException());
		GcasException.asString(null);
		GcasException.asString(new RuntimeException());
	}
}
