/**
 * 
 */
package com.citi.icg.as.common.core.context.mock;

import org.apache.commons.lang.math.NumberUtils;

/**
 * @author AP72338
 *
 */
public class SimpleCustodyImpl extends AbsractBusinessStream {

	@Override
	protected int calculateTotalInternal(String... values) {
		int sum = 0;
		for (String v : values) {
			if (NumberUtils.toInt(v) % 2 != 0) {
				sum += NumberUtils.toInt(v);
			}
		}
		return sum;
	}
}
