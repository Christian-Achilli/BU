package com.citi.icg.as.common.exception;

import static org.easymock.EasyMock.createNiceMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;

import java.util.HashMap;

import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.spi.LocationInfo;
import org.junit.Test;
import org.powermock.core.classloader.annotations.PrepareForTest;

import com.citi.icg.as.exception.AspenRuntimeException;
import com.citi.icg.as.exception.ErrorType;
import com.citi.icg.as.server.service.GcasRpcContext;

@PrepareForTest(ExceptionHandler.class)
public class ExceptionHandlerTest {
	
	@Test
	public void test1(){
		ExceptionHandler exHandler=new ExceptionHandler();
		exHandler.handleException(new Throwable("null message"));
	}
	@Test
	public void test2(){
		ExceptionHandler exHandler=new ExceptionHandler();
		exHandler.handleException(new AspenRuntimeException("null message",ErrorType.DATA_ERROR));
	}
	
	@Test
	public void test3(){
		ExceptionHandler exHandler=new ExceptionHandler();
		exHandler.handleException(new AspenRuntimeException("null message",ErrorType.WARNING));
	}
	@Test
	public void test4(){
		ExceptionHandler exHandler=new ExceptionHandler();
		exHandler.handleException(new AspenRuntimeException("null message",ErrorType.INFO));
	}
	
	@Test
	public void test5(){
		String exceptionName="Throwable";
		ExceptionHandlerConfiguration excepConfg=createNiceMock(ExceptionHandlerConfiguration.class);
		expect(excepConfg.getIgnoreTimeOfException(exceptionName)).andReturn("20");
		expect(excepConfg.isDBAvailable()).andReturn(true);
		replay(excepConfg);
		ExceptionHandler exHandler=new ExceptionHandler();
		exHandler.setExceptionConfiguration(excepConfg);
		exHandler.handleException("INFO", new Throwable("not enough info"), LocationInfo.NA_LOCATION_INFO);
	}
	
	@Test
	public void test6(){
		String exceptionName="Throwable";
		ExceptionHandlerConfiguration excepConfg=createNiceMock(ExceptionHandlerConfiguration.class);
		expect(excepConfg.getIgnoreTimeOfException(exceptionName)).andReturn("20");
		expect(excepConfg.isDBAvailable()).andReturn(true);
		replay(excepConfg);
		ExceptionHandler exHandler=new ExceptionHandler();
		exHandler.setExceptionConfiguration(excepConfg);
		HashMap<String,String> map=new HashMap();
		map.put("1","1");
		GcasRpcContext gcax=new GcasRpcContext("an36812", "target", "method", map);
		exHandler.handleException("INFO", new Throwable("not enough info"), LocationInfo.NA_LOCATION_INFO,gcax,Long.getLong("100"));
	}

}
