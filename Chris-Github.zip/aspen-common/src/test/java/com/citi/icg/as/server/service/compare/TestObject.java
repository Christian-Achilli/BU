package com.citi.icg.as.server.service.compare;

import java.util.List;

public class TestObject {
	private Long id;
	private String username;
	private String password;
	
	private TestSubObject sub;
	
	private List<TestSubObject> subs;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public TestSubObject getSub() {
		return sub;
	}

	public void setSub(TestSubObject sub) {
		this.sub = sub;
	}

	public List<TestSubObject> getSubs() {
		return subs;
	}

	public void setSubs(List<TestSubObject> subs) {
		this.subs = subs;
	}

	@Override
	public String toString() {
		return "TestObject [id=" + id + ", password=" + password
				+ ", username=" + username + "]";
	}

}
