package com.citi.icg.as.util;

import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;

public class DateTimeHelperTest {

	@Test
	public void test1() {
		int yearsPassed=DateTimeHelper.yearsPassedSince(new Date(), new Date());
		Assert.assertEquals(yearsPassed, 0);
	}

	@Test
	public void test2() {
		int datesPassed=DateTimeHelper.datesPassedSince(new Date(), new Date());
		Assert.assertEquals(datesPassed, 0);
	}

	@Test
	public void test3() {
		int hoursPassed=DateTimeHelper.hoursPassedSince(new Date(), new Date());
		Assert.assertEquals(hoursPassed, 0);
	}
}
