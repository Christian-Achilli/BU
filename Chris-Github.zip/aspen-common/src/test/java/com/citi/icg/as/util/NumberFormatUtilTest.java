package com.citi.icg.as.util;

import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.text.NumberFormat;

import org.junit.Test;


public class NumberFormatUtilTest {
	
	@Test
	public void testOPTION_REPEAT_NUMBER_FORMAT()
	{
		ThreadLocal<NumberFormat> local = NumberFormatUtil.OPTION_REPEAT_NUMBER_FORMAT;
		assertNotNull(local.get());
	}
	@Test
	public void testConstructor() throws Exception{
		Constructor<NumberFormatUtil> constructor= NumberFormatUtil.class.getDeclaredConstructor();
		constructor.setAccessible(true);
		constructor.newInstance(new Object[]{});
	}

}
