package com.citi.icg.as.common.exception;

import org.junit.Before;
import org.junit.Test;
import org.powermock.core.classloader.annotations.PrepareForTest;


@PrepareForTest(ExceptionHandlerConfigurationTest.class)
public class ExceptionHandlerConfigurationTest {

	ExceptionHandlerConfiguration  exceptionHandlerConfiguration ;
	@Before
	public void setUp(){
		exceptionHandlerConfiguration=new ExceptionHandlerConfiguration();
		
	}
	
	@Test
	public void test1(){
		exceptionHandlerConfiguration.getBatchNumber();
	}
	
	@Test
	public void test2(){
		exceptionHandlerConfiguration.getMaximumUnsentExceptions();
	}
	
	@Test
	public void test3(){
		exceptionHandlerConfiguration.getMaximumExistsDays();
	}
	
	@Test
	public void test4(){
		exceptionHandlerConfiguration.isDBAvailable();
	}
	
	@Test
	public void test5(){
		exceptionHandlerConfiguration.isSendEmail();
	}
	

}
