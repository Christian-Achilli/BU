package com.citi.icg.as.exception;

import org.junit.Test;

public class GcasRuntimeExceptionTest {
	@Test
	public void TestGcasRuntimeException(){
		new GcasRuntimeException("message");
		new GcasRuntimeException("message", new RuntimeException());
	}
}
