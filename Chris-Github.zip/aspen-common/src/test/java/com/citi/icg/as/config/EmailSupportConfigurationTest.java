package com.citi.icg.as.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest( { EmailSupportConfiguration.class })
public class EmailSupportConfigurationTest extends BaseDynamicPropertiesTest {

	private static EmailSupportConfiguration instance = null;

	@Override
	public void beforeInternal() {
		instance = EmailSupportConfiguration.createInstance(new HashMap<String,String>());
	}

	@Test
	public void testGetInstance() {
		assertNotNull(instance);
	}

	@Test
	public void testGetEmailServer() {
		String emailServer = instance.getEmailServer();
		assertNotNull(emailServer);
		assertEquals("localhost", emailServer);
	}

	@Test
	public void testGetSupportEmail() {
		String supportEmail = instance.getSupportEmail();
		assertNotNull(supportEmail);
		//Commenting the below as it depends on environment and is thus non-deterministic
		
		/*assertEquals("dl.gt.global.aspen.nonprod.env.tech@imceu.eu.ssmb.com",
				supportEmail); */
	}

	@Test
	public void testGetSupportEmailDisabled() {
		boolean supportEmailDisabled = instance.getSupportEmailDisabled();
		assertTrue(supportEmailDisabled);
	}

	@Test
	public void testGetApplicationName() {
		String applicationName = instance.getApplicationName();
		assertEquals("CorporateActions", applicationName);
	}

	@Test
	public void testGetSupportEmailDisabledNullFalse() {
		PowerMock.mockStatic(EmailSupportConfiguration.class);
		EmailSupportConfiguration mockConfig = EasyMock.createMockBuilder(
				EmailSupportConfiguration.class).addMockedMethod("getString",
				String.class).createMock();
		EasyMock.expect(mockConfig.getString(EasyMock.isA(String.class)))
				.andReturn(null).anyTimes();
		EasyMock.expect(EmailSupportConfiguration.getInstance()).andReturn(
				mockConfig).anyTimes();

		PowerMock.replayAll();
		EasyMock.replay(mockConfig);

		boolean result = EmailSupportConfiguration.getInstance()
				.getSupportEmailDisabled();
		assertFalse(result);
	}
	
	@Test
	public void testGetSupportEmailDisabledFalse() {
		PowerMock.mockStatic(EmailSupportConfiguration.class);
		EmailSupportConfiguration mockConfig = EasyMock.createMockBuilder(
				EmailSupportConfiguration.class).addMockedMethod("getString",
				String.class).createMock();
		EasyMock.expect(mockConfig.getString(EasyMock.isA(String.class)))
				.andReturn("false").anyTimes();
		EasyMock.expect(EmailSupportConfiguration.getInstance()).andReturn(
				mockConfig).anyTimes();

		PowerMock.replayAll();
		EasyMock.replay(mockConfig);

		boolean result = EmailSupportConfiguration.getInstance()
				.getSupportEmailDisabled();
		assertFalse(result);
	}

}
