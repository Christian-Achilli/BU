package com.citi.icg.as.server.service.compare;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorSupport;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.citi.icg.as.common.client.compare.CompareResult;
import com.citi.icg.as.common.client.util.PlaceHolder;
import com.citi.icg.as.exception.GcasError;
import com.citi.icg.as.exception.GcasException;
import com.citi.icg.as.server.service.compare.BeanCompareService.PropertyType;
import com.citi.icg.toolkit.web.client.grid.dataobjects.TransferObject;

@RunWith(PowerMockRunner.class)
@PrepareForTest(CollectionUtils.class)
public class BeanCompareServiceTest extends BaseTest {
	BeanCompareService beanCompareService;

	@Before
	public void setUp() {
		beanCompareService = new BeanCompareService();
	}

	@After
	public void tearDown() { 

	}

	@Test
	public void testRegisterEquivalenceComparator() {
		beanCompareService.registerEquivalenceComparator(TestObject.class,
				this.getComparator());
	}

	@Test
	public void testUnregisterEquivalenceComparator() {
		beanCompareService.unregisterEquivalenceComparator(TestObject.class);
	}

	@Test
	public void testRegisterListMergeComparator() {
		beanCompareService.registerListMergeComparator(TestObject.class, this
				.getComparator());
	}

	@Test
	public void testRegisterValuePropertyEditor() {
		beanCompareService.registerValuePropertyEditor(TestObject.class,
				new PropertyEditorSupport() {
					@Override
					public String getAsText() {
						return null;
					}
				});
	}

	@Test
	public void testRegisterNamePropertyEditor() {
		beanCompareService.registerNamePropertyEditor(TestObject.class,
				new PropertyEditorSupport() {
					@Override
					public String getAsText() {
						return null;
					}
				});
	}

	@Test
	public void testUnregisterListMergeComparator() {
		beanCompareService.unregisterListMergeComparator(TestObject.class);

	}

	@Test
	public void testAddExcludedProperties() {
		List<String> excludedProperties = new ArrayList<String>();
		excludedProperties.add("options");
		beanCompareService.addExcludedProperties(excludedProperties);

	}

	@Test
	public void testAddExcludedProperty() {
		beanCompareService.addExcludedProperty("TestObjectCustomFields");
	}

	@Test
	public void testRegisterListPredicate() {
		beanCompareService.registerListPredicate(TestObject.class,
				new Predicate() {
					public boolean evaluate(Object arg0) {
						TestObject dv = (TestObject) arg0;
						return (dv.getPassword().equalsIgnoreCase("password1"));
					}
				});
	}

	@Test
	public void testUnregisterListPredicate() {
		beanCompareService.unregisterListPredicate(TestObject.class);
		
	}

	@Test
	public void testCompare() {
		try{
			this.testAddExcludedProperties();
			TestObject to1 =  BaseTest.constructTestObject(1l);
			TestObject to2 =  BaseTest.constructTestObject(1l);
			CompareResult compareResult = beanCompareService.compare(to1,to2);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testRCompare() {
		try{
			//case1
			this.testAddExcludedProperties();
			TestObject to1 =  BaseTest.constructTestObject(1l);
			TestObject to2 =  BaseTest.constructTestObject(1l);
			beanCompareService.rCompare(new Object[]{to1,to2}, null, false);
			//case2
			try{
				beanCompareService.rCompare(new Object[]{new HashMap(), new HashMap()}, null, false);
			}catch(Error e ){
			}
			
			//case3
			beanCompareService.rCompare(new Object[]{new ArrayList(), new ArrayList()}, null, false);
		
			//case4
			beanCompareService.rCompare(new Object[]{"d", "t"}, null, false);
			
			//case5
			beanCompareService.rCompare(new Object[]{new Integer[]{2, 3}, new Integer[]{1, 2}}, null, false);
			
			//case6
			try{
				beanCompareService.rCompare(new Object[]{to1, "d"}, null, false);
			}catch(GcasError e){
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testCompareAtomic() {
		try{
			//case1
			Integer i1 = new Integer("1");
			Integer i2 = new Integer("2");
			CompareResult result = beanCompareService.compareAtomic(new Object[]{i1,i2}, null);
			Assert.assertTrue(result.getMatchedProperties().isEmpty());
			
			//case2
			i2 = new Integer("1");
			result =beanCompareService.compareAtomic(new Object[]{i1,i2}, null);
			Assert.assertTrue(result.getUnmatchedProperties().isEmpty());
			
			//case3
			result = beanCompareService.compareAtomic(new Object[]{i1}, null);
			Assert.assertTrue(result.getUnmatchedProperties().isEmpty());
			
			//case4
			result = beanCompareService.compareAtomic(new Object[]{null , null}, null);
			Assert.assertTrue(result.getUnmatchedProperties().isEmpty());
			
			//case5
			result = beanCompareService.compareAtomic(new Object[]{i1 , null}, null);
			Assert.assertTrue(result.getMatchedProperties().isEmpty());
			
			//case6
			try{
				result = beanCompareService.compareAtomic(new Object[]{i1 , "d"}, null);
				Assert.assertTrue(result.getMatchedProperties().isEmpty());
			}catch(Exception e){
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testCompareBean() {
		try {
			
			//case1
			this.testAddExcludedProperties();
			TestObject to1 =  BaseTest.constructTestObject(1l);
			TestObject to2 =  BaseTest.constructTestObject(1l);
			CompareResult result = beanCompareService.compareBean(new Object[]{to1,to2}, null, false);
			System.out.println(Arrays.toString(result.getMatchedProperties().toArray())+"--");
			System.out.println(Arrays.toString(result.getUnmatchedProperties().toArray())+"-");
			Assert.assertTrue(result.getUnmatchedProperties().isEmpty());
			Assert.assertFalse(result.getMatchedProperties().isEmpty());
			
			//case2
			to2 = BaseTest.constructTestObject(2l);
			result = beanCompareService.compareBean(new Object[]{to1,to2}, null, false);
			System.out.println(Arrays.toString(result.getUnmatchedProperties().toArray())+"--");
			System.out.println(Arrays.toString(result.getMatchedProperties().toArray())+"-");
			Assert.assertFalse(result.getMatchedProperties().isEmpty());
			Assert.assertFalse(result.getUnmatchedProperties().isEmpty());
			
			//case3
			to1 = BaseTest.constructTestObjectComplex(1l, 1l);
			to2 = BaseTest.constructTestObjectComplex(1l ,2l);
			beanCompareService.registerListMergeComparator(TestSubObject.class, new  Comparator<TestSubObject>(){
				@Override
				public int compare(TestSubObject o1, TestSubObject o2) {
					return o1.getSubId().compareTo(o2.getSubId());
				}
			});
			
			result = beanCompareService.compareBean(new Object[]{to1,to2}, null, false);
			System.out.println(Arrays.toString(result.getMatchedProperties().toArray())+"--");
			System.out.println(Arrays.toString(result.getUnmatchedProperties().toArray())+"-");
			Assert.assertFalse(result.getMatchedProperties().isEmpty());
			Assert.assertFalse(result.getUnmatchedProperties().isEmpty());
			
			//case4

			result = beanCompareService.compareBean(new Object[]{to1,to2}, null, true);
			System.out.println(Arrays.toString(result.getMatchedProperties().toArray())+"--");
			System.out.println(Arrays.toString(result.getUnmatchedProperties().toArray())+"-");
			
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetIdForBean() {
		try {
			beanCompareService.getIdForBean(null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testPopulateEntityAndId() {
		try{
			//case1
			this.testAddExcludedProperties();
			TestObject to1 =  BaseTest.constructTestObject(1l);
			TestObject to2 =  BaseTest.constructTestObject(1l);
			CompareResult compareResult  = new CompareResult();
			beanCompareService.populateEntityAndId(new Object[]{to1,to2}, null, compareResult);
			Assert.assertNull(compareResult.getIds()[0]);
			
			//case2
			beanCompareService.populateEntityAndId(new Object[]{new TransferObject(){}}, null, compareResult);
			Assert.assertNull(compareResult.getIds()[0]);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testSortAndFilterCollection() {
		try{
			//case1
			List<TestObject> list = Whitebox.invokeMethod(beanCompareService, "sortAndFilterCollection", EasyMock.isNull() , null , null);
			Assert.assertTrue(list.isEmpty());
			
			//case2
			Predicate predicate = new Predicate() {
				@Override
				public boolean evaluate(Object arg0) {
					TestObject dv = (TestObject) arg0;
					return (dv.getPassword().equalsIgnoreCase("password1"));
				}
			};
			Comparator<TestObject> comparator = new Comparator<TestObject>(){
				@Override
				public int compare(TestObject o1, TestObject o2) {
					return o1.getId().compareTo(o2.getId());
				}
			};		
			
			List<TestObject> testObjects = new ArrayList<TestObject>();
			testObjects.add(BaseTest.constructTestObject(1l));
			testObjects.add(BaseTest.constructTestObject(2l));
			list = Whitebox.invokeMethod(beanCompareService, "sortAndFilterCollection", testObjects , comparator , predicate);
			Assert.assertEquals(list.size(), 1);
			Assert.assertEquals("password1", list.get(0).getPassword());
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	@Test
	public void testCompareCollection() {
		try{
			//case1 
			List<String> list1 =new ArrayList<String>();
			try{
				Whitebox.invokeMethod(beanCompareService, "compareCollection", new Object[]{list1} ,null);
			}catch(Exception e){
				Assert.assertTrue(e instanceof GcasException);
			}
			
			//case2
			List<String> list2 =new ArrayList<String>();
			Whitebox.invokeMethod(beanCompareService, "compareCollection", new Object[]{list1,list2} ,null);
			
			//case3
			beanCompareService.registerListMergeComparator(TestSubObject.class, new  Comparator<TestSubObject>(){
				@Override
				public int compare(TestSubObject o1, TestSubObject o2) {
					return o1.getSubId().compareTo(o2.getSubId());
				}
			});
			
			List<TestSubObject> subs = new ArrayList<TestSubObject>();
			subs.add(BaseTest.constructTestSubObject(1l));
			
			List<TestSubObject> subs1 = new ArrayList<TestSubObject>();
			subs1.add(BaseTest.constructTestSubObject(2l));
			
			Whitebox.invokeMethod(beanCompareService, "compareCollection", new Object[]{subs,subs1} ,null);
			
			//case4
			subs1 = new ArrayList<TestSubObject>();
			subs1.add(BaseTest.constructTestSubObject(1l));
			
			Whitebox.invokeMethod(beanCompareService, "compareCollection", new Object[]{subs,subs1} ,null);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testGetListFilter() {
		
		beanCompareService.getListFilter(TestObject.class, null);
	}

	@Test
	public void testCompareMap() {
		try{
			Whitebox.invokeMethod(beanCompareService, "compareMap", new Object[]{1,1} ,null);
		}catch(Exception e){
			e.printStackTrace();
		}catch(Error e){
			
		}
	}

	@Test
	public void testGetValues() {
		try{
			
			List<Map<String, Object>> list = new ArrayList<Map<String, Object>> ();
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("username", "name1");
			map.put("password", "pass1");
			list.add(map);
			Object[] objs =  Whitebox.invokeMethod(beanCompareService, "getValues", list ,"username");
			for(Object obj :objs){
				Assert.assertEquals("name1", (String)obj);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testIsAllMatched() {
		try{
			//case1
			CompareResult compareResult = new CompareResult();
			compareResult.setUnmatchedProperties(new HashSet<String>());
			Boolean flag =Whitebox.invokeMethod(beanCompareService, "isAllMatched", (Object)new CompareResult[]{compareResult});
		    Assert.assertTrue(flag);
		    
			//case2
			Set<String> set = new HashSet<String>();
			set.add("password1");
			compareResult.setUnmatchedProperties(set);
			flag =Whitebox.invokeMethod(beanCompareService, "isAllMatched", (Object)new CompareResult[]{compareResult});
		    Assert.assertFalse(flag);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testStringRepresentationForArray() {
		try{
			
			//case1
			TestObject to1 =  BaseTest.constructTestObject(1l);
			TestObject to2 =  BaseTest.constructTestObject(1l);
			String[]  strs = Whitebox.invokeMethod(beanCompareService, "stringRepresentationForArray", new Object[]{to1,to2},new HashMap<Class, PropertyEditor>(),null);
			Assert.assertNotNull(strs);
			
			//case2
			strs = Whitebox.invokeMethod(beanCompareService, "stringRepresentationForArray", EasyMock.isNull() , new HashMap<Class, PropertyEditor>(),null);
			Assert.assertNull(strs);
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testStringRepresenation() {
		try{
			//case1
			String temp = Whitebox.invokeMethod(beanCompareService, "stringRepresenation" , EasyMock.isNull() , EasyMock.isNull(), EasyMock.isNull());
			Assert.assertEquals(temp, StringUtils.EMPTY);
			
			//case2
			Map<Class, PropertyEditor> editors = new HashMap<Class, PropertyEditor>();
			editors.put(TestObject.class, null);
			
			temp = Whitebox.invokeMethod(beanCompareService, "stringRepresenation" , BaseTest.constructTestObject(1l) , editors , EasyMock.isNull());
			Assert.assertNotNull(temp);
			
			//case3
			editors.put(TestObject.class, new PropertyEditorSupport(){
				@Override
				public void setValue(Object value) {
					TestObject t =(TestObject)value;
					super.setValue(t.getPassword());
				}
			});
			temp = Whitebox.invokeMethod(beanCompareService, "stringRepresenation" , BaseTest.constructTestObject(1l) , editors , EasyMock.isNull());
			Assert.assertNotNull(temp);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testGetConsistentType() {
		try{
			//case1
			PropertyType propertyType = Whitebox.invokeMethod(beanCompareService, "getConsistentType" , new Object[]{BaseTest.constructTestObject(1l),BaseTest.constructTestObject(2l)} , "");
			Assert.assertEquals(PropertyType.BEAN , propertyType);
			
			//case2
			try{
				Whitebox.invokeMethod(beanCompareService, "getConsistentType" , new Object[]{BaseTest.constructTestObject(1l) , new ArrayList<String>()} , "");
			}catch(GcasError error){
				Assert.assertNotNull(error);
			}
			
			//case3
			propertyType = Whitebox.invokeMethod(beanCompareService, "getConsistentType" , new Object[]{new PlaceHolder()} , "");
			Assert.assertEquals(PropertyType.BEAN , propertyType);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testGetListMergeComparator() {
		try{
			
			Comparator comparator = Whitebox.invokeMethod(beanCompareService, "getListMergeComparator" , TestObject.class , "");
			Assert.assertNotNull(comparator);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testGetEquivalenceComparator() {
		try{
			
			Comparator comparator = Whitebox.invokeMethod(beanCompareService, "getEquivalenceComparator" , TestObject.class , "");
			Assert.assertNotNull(comparator);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testGetPropertyEditor() {
		try {
			
			//case1
			Map<Class, PropertyEditor> editors = new HashMap<Class, PropertyEditor>();
			editors.put(TestObject.class, null);
			PropertyEditor editor =  Whitebox.invokeMethod(beanCompareService, "getPropertyEditor",TestObject.class , editors);
			Assert.assertNull(editor);
			
			//case2
			editors.put(TestObject.class, new PropertyEditorSupport());
			editor =  Whitebox.invokeMethod(beanCompareService, "getPropertyEditor",TestObject.class , editors);
			Assert.assertNotNull(editor);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testClassOf(){
		try{
//			PowerMock.mockStatic(CollectionUtils.class);
			//case1
			Collection<String> collection = new ArrayList<String>();
//			EasyMock.expect(CollectionUtils.isNotEmpty(EasyMock.isA(Collection.class))).andReturn(false);
//			PowerMock.replayAll();
			Class c = beanCompareService.classOf(new Object[]{collection});
			Assert.assertNull(c);
			
			
			//case2
			collection.add("d");
//			PowerMock.reset(CollectionUtils.class);
//			EasyMock.expect(CollectionUtils.isNotEmpty(EasyMock.isA(Collection.class))).andReturn(true);
//			PowerMock.replayAll();
			c = beanCompareService.classOf(new Object[]{collection});
			Assert.assertNotNull(c.getName());
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testTypeOf() {
		try{
			//case1
			PropertyType type = Whitebox.invokeMethod(beanCompareService, "typeOf",1l , null);
			Assert.assertEquals(PropertyType.ATOMIC.name(),type.name());
			
			//case2
			PropertyType type2 = Whitebox.invokeMethod(beanCompareService, "typeOf", BaseTest.constructTestObject(1l) , null);
			Assert.assertEquals(PropertyType.BEAN.name(),type2.name());
			
			//case3
			PropertyType type3 = Whitebox.invokeMethod(beanCompareService, "typeOf", new Object[]{1,1} , null);
			Assert.assertEquals(PropertyType.ARRAY.name(),type3.name());
			
			//case4
			PropertyType type4 = Whitebox.invokeMethod(beanCompareService, "typeOf", new ArrayList() , null);
			Assert.assertEquals(PropertyType.COLLECTION.name(),type4.name());
			
			//case5
			PropertyType type5 = Whitebox.invokeMethod(beanCompareService, "typeOf", new HashMap() , null);
			Assert.assertEquals(PropertyType.MAP.name(),type5.name());
			
			//case6
			PropertyType type6 = Whitebox.invokeMethod(beanCompareService, "typeOf", EasyMock.isNull() , null);
			Assert.assertNull(type6);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testDescribe() {
		try{
			//case1
			TestObject to1 =  BaseTest.constructTestObject(1l);
			Map<String ,Object> map = Whitebox.invokeMethod(beanCompareService, "describe", to1 , null , null);
			Set<Entry<String , Object>> entrys  = map.entrySet();
			for(Entry<String , Object> entry : entrys){
				System.out.println(entry.getKey() + "--" +entry.getValue());
				Assert.assertNotNull(entry);
			}
			
			//case2
			Map<String ,Object> map1 = Whitebox.invokeMethod(beanCompareService, "describe", EasyMock.isNull() , null , null);
			Assert.assertEquals(map1.isEmpty(), true);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testArrayAllEqual() {
		try{
			//case1
			Method method1 = beanCompareService.getClass().getDeclaredMethod("arrayAllEqual" ,String[].class );
			method1.setAccessible(true);
			Boolean flag =(Boolean) method1.invoke(beanCompareService , EasyMock.isNull());
			Assert.assertTrue(flag);
			
			//case2
			Method method = beanCompareService.getClass().getDeclaredMethod("arrayAllEqual" , String[].class);
			method.setAccessible(true);
			Boolean flag1 =(Boolean) method.invoke(beanCompareService , (Object)new String[]{"d" , "d"});
			Assert.assertTrue(flag1);
			
			//case3
			Boolean flag2 =(Boolean) method.invoke(beanCompareService , (Object)new String[]{"d" , "t"});
			Assert.assertFalse(flag2);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testInnerClass1() {
		Object o1=new Object();
		Object o2=new Object();
		Comparator<Object> comparator=(Comparator<Object>) beanCompareService.StringRepresentationComparator;
		Assert.assertNotSame(0, comparator.compare(o1, o2));
		Assert.assertEquals(0,comparator.compare(null, null));
		Assert.assertEquals(1,comparator.compare(null, o1));
		Assert.assertEquals(-1,comparator.compare(o1, null));
	}
}
