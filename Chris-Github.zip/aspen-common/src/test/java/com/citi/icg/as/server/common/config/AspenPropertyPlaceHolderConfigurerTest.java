package com.citi.icg.as.server.common.config;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class AspenPropertyPlaceHolderConfigurerTest {

	public static final String ASPEN_STREAM = "aspen.stream";
	public static final String ASPEN_ENV = "aspen.env";
	public static final String ICG_CONFIG_XML_NAME = "ICG_CONFIG_XML_FILE_NAME";


	@Test
	public void testIcgCofigOracleCustody() {
		System.setProperty(ASPEN_ENV, "uat2");
		System.setProperty(ASPEN_STREAM, "custody");
		
		AspenPropertyPlaceHolderConfigurer config = new AspenPropertyPlaceHolderConfigurer();
		
		assertEquals("icg-config-oracle.custody.xml", System.getProperty(ICG_CONFIG_XML_NAME));
	}

	@Test
	public void testIcgCofigOracleMarekts() {
		System.setProperty(ASPEN_ENV, "uat1");
		System.setProperty(ASPEN_STREAM, "markets");
		
		AspenPropertyPlaceHolderConfigurer config = new AspenPropertyPlaceHolderConfigurer();
		
		assertEquals("icg-config-oracle.markets.xml", System.getProperty(ICG_CONFIG_XML_NAME));
	}

	@Test
	public void testIcgCofigLocalMarekts() {
		System.setProperty(ASPEN_ENV, "local");
		System.setProperty(ASPEN_STREAM, "markets");
		
		AspenPropertyPlaceHolderConfigurer config = new AspenPropertyPlaceHolderConfigurer();
		
		assertEquals("icg-config-h2.markets.xml", System.getProperty(ICG_CONFIG_XML_NAME));
	}

	@Test
	public void testIcgCofigLocalCustody() {
		System.setProperty(ASPEN_ENV, "local");
		System.setProperty(ASPEN_STREAM, "custody");
		
		AspenPropertyPlaceHolderConfigurer config = new AspenPropertyPlaceHolderConfigurer();
		
		assertEquals("icg-config-h2.custody.xml", System.getProperty(ICG_CONFIG_XML_NAME));
	}
}
