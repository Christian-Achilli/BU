package com.citi.icg.as.service.service;

import org.junit.Assert;
import org.junit.Test;

import com.citi.icg.as.hessian.ResultWrapper;
import com.citi.icg.as.server.service.BaseServiceVisitorHandler;
import com.citi.icg.as.server.service.ServiceVisitor;

@SuppressWarnings("unchecked")
public class BaseServiceVisitorHandlerTest {

	class TestVisitor implements ServiceVisitor{

		@Override
		public Object execute() throws Exception {
			return null;
		}
		
	}
	
	class ExceptionVisitor implements ServiceVisitor {

		@Override
		public Object execute() throws Exception {
			throw new Exception();
		}
		
	}
	
	class TestResultWrapperVisitor<T> implements ServiceVisitor<ResultWrapper<T>>{

		@Override
		public ResultWrapper<T> execute() throws Exception {
			return null;
		}
		
	}
	
	class ExceptionResultWrapperVisitor<T> implements ServiceVisitor<ResultWrapper<T>> {

		@Override
		public ResultWrapper<T> execute() throws Exception {
			throw new Exception();
		}
		
	}
	
	@Test
	public void excute1Test(){
		new BaseServiceVisitorHandler().execute(String.class, new TestVisitor());
	}
	
	@Test(expected=RuntimeException.class)
	public void excute2Test(){
		new BaseServiceVisitorHandler().execute(String.class, new ExceptionVisitor());
	}
	
	@Test
	public void excute3Test(){
		new BaseServiceVisitorHandler().execute("123", new TestVisitor());
	}
	
	@Test
	public void excuteSilentlyTest(){
		 new BaseServiceVisitorHandler().executeSilently("123", new TestResultWrapperVisitor());
		
	}
	
	
	public void excuteSilentlyExceptionTest(){
		ResultWrapper r = new BaseServiceVisitorHandler().executeSilently("123", new ExceptionResultWrapperVisitor());
		Assert.assertNotNull(r);
		Assert.assertNotNull(r.getErrorMessage());
	}

}
