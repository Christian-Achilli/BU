package com.citi.icg.as.dao;

public class EntityB {
	//Dummy classes for Test cases.
}
