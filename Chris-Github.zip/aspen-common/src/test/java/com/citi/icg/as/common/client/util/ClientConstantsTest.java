package com.citi.icg.as.common.client.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.google.gwt.core.client.GWT;

@RunWith(PowerMockRunner.class)
@PrepareForTest(GWT.class)
public class ClientConstantsTest {
	@Test
	public void testClientConstants() throws SecurityException, NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
		new ClientConstants.APPLICATION_IMAGE_CONSTANTS();
		new ClientConstants.APPLICATION_TOOLTIP_CONSTANTS();
		new ClientConstants.HTML_CONSTANTS();
		new ClientConstants.AUDIT_CONSTANTS();
		PowerMock.mockStatic(GWT.class);
		EasyMock.expect(GWT.getHostPageBaseURL()).andReturn("").anyTimes();
		PowerMock.replay(GWT.class);
		Constructor<ClientConstants> constructor1= ClientConstants.class.getDeclaredConstructor(new Class[]{});
		constructor1.setAccessible(true);
		constructor1.newInstance(new Object[]{});
		Constructor<ClientConstants.SECURITY_IND> constructor2= ClientConstants.SECURITY_IND.class.getDeclaredConstructor(new Class[]{});
		constructor2.setAccessible(true);
		constructor2.newInstance(new Object[]{});
	}
	
	@Test
	public void testOptionStatus() {
		ClientConstants.OptionStatus.CANC.getCode();
		ClientConstants.OptionStatus.CANC.getDisplayName();
		ClientConstants.OptionStatus.getElementByCode("CANC");
		ClientConstants.OptionStatus.getElementByCode("any");
	}
}
