/**
 * 
 */
package com.citi.icg.as.common.core.context.mock;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author AP72338
 *
 */
@Ignore
public class BusinessStreamTest {

	@Test(expected=NoSuchBeanDefinitionException.class)
	public void whenMarketsStreamThenMarketsBeanIsCreated() throws Exception {
		System.setProperty("stream", "markets");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/citi/icg/as/common/core/context/mock/stream-test-context.xml");
		SimpleBusinessStreamInterface obj= ctx.getBean(SimpleBusinessStreamInterface.class);
		
		Assert.assertTrue(obj instanceof SimpleMarketsImpl);
		
		int sum = obj.calculateTotal("1","2","3","4");
		Assert.assertEquals(6,sum);
		Assert.assertTrue(ctx.getBean(SimpleBusinessStreamInterface.class) instanceof SimpleMarketsImpl);		
		ctx.getBean("custodyStream"); //This will throw the expected exception		
	}

	@Test(expected=NoSuchBeanDefinitionException.class)
	public void whenCustodyStreamThenCustodyBeanIsCreated() throws Exception {
		System.setProperty("stream", "custody");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/citi/icg/as/common/core/context/mock/stream-test-context.xml");
		SimpleBusinessStreamInterface obj= ctx.getBean(SimpleBusinessStreamInterface.class);
		
		Assert.assertTrue(obj instanceof SimpleCustodyImpl);	
		int sum = obj.calculateTotal("1","2","3","4");
		Assert.assertEquals(4,sum);
		ctx.getBean("marketsStream"); //This will throw the expected exception		
	}
	
	@Test
	public void whenNoStreamThenErrorIsReported() throws Exception {
		System.setProperty("stream", "");
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/citi/icg/as/common/core/context/mock/stream-test-context.xml");
		try{
			ctx.getBean("marketsStream");
			Assert.fail();
		}catch(NoSuchBeanDefinitionException e){
			//Expected
		}
		
		try{
			ctx.getBean("custodyStream"); 
			Assert.fail();
		}catch(NoSuchBeanDefinitionException e){
			//Expected
		}
	}
}
