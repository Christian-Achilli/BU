package com.citi.icg.as.server.service.compare;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BaseTest {
	
	public Comparator<TestObject> getComparator(){
		return new Comparator<TestObject>(){
			@Override
			public int compare(TestObject o1, TestObject o2) {
				if (o1 == null && o2 == null)
				{
					return 0;
				}
				else if (o1 == null)
				{
					return 1;
				}
				else if (o2 == null)
				{
					return -1;
				}
				
				return o1.getId().compareTo(o2.getId());
			
			}
			
		};
	}
	

	public static TestObject constructTestObject(long id) {
		TestObject testObject = new TestObject();
		testObject.setId(id);
		testObject.setPassword("password"+id);
		testObject.setUsername("username"+id);
		return testObject;
	}
	
	public static TestObject constructTestObjectComplex(long id, long subId){
		TestObject testObject = new TestObject();
		testObject.setId(id);
		testObject.setPassword("password"+id);
		testObject.setUsername("username"+id);
		
		TestSubObject sub = new TestSubObject();
		sub.setSubId(subId);
		
		TestSubObject subList = new TestSubObject();
		subList.setSubId(subId+1);
		testObject.setSub(sub);
		
		List<TestSubObject> subs = new ArrayList<TestSubObject>();
		subs.add(subList);
		testObject.setSubs(subs);
		
		return testObject;
		
	}
	
	public static TestSubObject constructTestSubObject(Long id){
		TestSubObject sub = new TestSubObject();
		sub.setSubId(id);
		return sub;
	}
	
	

	
	


}
