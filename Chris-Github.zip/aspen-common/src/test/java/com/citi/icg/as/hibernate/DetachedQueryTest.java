package com.citi.icg.as.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.hibernate.Query;
import org.hibernate.Session;
import org.junit.Assert;
import org.junit.Test;

public class DetachedQueryTest {

	@Test
	public void testGetExecutableQueryWithPageSize() {
		DetachedQuery query = new DetachedQuery();
		String queryStr = "from AlertTask";
		int firstResult = 1;
		int maxResults = 10;
		query.setHQL(queryStr);
		query.setFirstResult(firstResult);
		query.setMaxResults(maxResults);
		Session mockSession = EasyMock.createMock(Session.class);
		Query mockQuery = EasyMock.createMock(Query.class);
		EasyMock.expect(mockSession.createQuery(queryStr)).andReturn(mockQuery);
		EasyMock.expect(mockQuery.setFirstResult(EasyMock.eq(firstResult))).andReturn(mockQuery);
		EasyMock.expect(mockQuery.setMaxResults(EasyMock.eq(maxResults))).andReturn(mockQuery);;
		EasyMock.replay(mockSession, mockQuery);
		
		Query executedableQuery = query.getExecutableQuery(mockSession);
		Assert.assertEquals(mockQuery, executedableQuery);
		EasyMock.verify(mockSession, mockQuery);
	}

	@Test
	public void testGetExecutableQueryWithPositionalParameters() {
		DetachedQuery query = new DetachedQuery();
		String queryStr = "from AlertTask";
		List<Object> parameters = new ArrayList<Object>();
		Object p1 = new Integer(1);
		Object p2 = new String();
		parameters.add(p1);
		parameters.add(p2);
		query.setHQL(queryStr);
		query.addParameters(parameters);
		
		Session mockSession = EasyMock.createMock(Session.class);
		Query mockQuery = EasyMock.createMock(Query.class);
		EasyMock.expect(mockSession.createQuery(queryStr)).andReturn(mockQuery);
		EasyMock.expect(mockQuery.setParameter(0, p1)).andReturn(mockQuery);
		EasyMock.expect(mockQuery.setParameter(1, p2)).andReturn(mockQuery);
		EasyMock.replay(mockSession, mockQuery);
		
		Query executedableQuery = query.getExecutableQuery(mockSession);
		Assert.assertEquals(mockQuery, executedableQuery);
		EasyMock.verify(mockSession, mockQuery);
	}

}
