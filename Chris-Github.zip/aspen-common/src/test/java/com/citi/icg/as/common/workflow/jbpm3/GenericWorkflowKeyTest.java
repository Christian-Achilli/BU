package com.citi.icg.as.common.workflow.jbpm3;


import org.junit.Assert;
import org.junit.Test;
import org.powermock.reflect.Whitebox;

import com.citi.icg.as.common.workflow.WorkflowException;
import com.citi.icg.as.common.workflow.WorkflowKey;

public class GenericWorkflowKeyTest {
	@Test
	public void testFormatKey(){
		JbpmWorkflowKey<String> key1 = new JbpmWorkflowKey<String>(String.class, 1L);
		Assert.assertEquals("java.lang.String:[1]", key1.toString());
		JbpmWorkflowKey<String> key2 = new JbpmWorkflowKey<String>(String.class, new Long[]{2L,1L});
		Assert.assertEquals("java.lang.String:[1],[2]", key2.toString());
	}
	
	@Test
	public void testParseKey(){
		WorkflowKey<String> key = JbpmWorkflowKey.parseKey("java.lang.String:[1],[2]");
		Assert.assertEquals(String.class, key.getEntityType());
		Assert.assertEquals(new Long(1), key.getEntityIds()[0]);
		Assert.assertEquals(new Long(2), key.getEntityIds()[1]);
	}
	@Test
	public void testBlankCheck(){
		try {
			Whitebox.invokeMethod(JbpmWorkflowKey.class,"blankCheck", "");
		} catch (Exception e) {
//			e.printStackTrace();
			Assert.assertTrue(e instanceof WorkflowException);
			Assert.assertTrue(e.getMessage().startsWith("The key to be parsed should not be blank"));
		}
	}
	@Test
	public void testSplitClassAndIds(){
		try {
			Whitebox.invokeMethod(JbpmWorkflowKey.class,"splitClassAndIds", "");
		} catch (Exception e) {
//			e.printStackTrace();
			Assert.assertTrue(e instanceof WorkflowException);
			Assert.assertTrue(e.getMessage().startsWith("Unknow key format, ke"));
		}
	}
	@Test
	public void testParseClass(){
		try {
			Whitebox.invokeMethod(JbpmWorkflowKey.class,"parseClass", "class not exist","key");
		} catch (Exception e) {
//			e.printStackTrace();
			Assert.assertTrue(e instanceof WorkflowException);
			Assert.assertTrue(e.getMessage().startsWith("Unknow class typ"));
		}
	}
	@Test
	public void testParseIds(){
		try {
			Whitebox.invokeMethod(JbpmWorkflowKey.class,"parseIds", ",","key");
		} catch (Exception e) {
//			e.printStackTrace();
			Assert.assertTrue(e instanceof WorkflowException);
			Assert.assertTrue(e.getMessage().startsWith("Unknow key format, ke"));
		}
	}
	@Test
	public void testParseLong(){
		try {
			Whitebox.invokeMethod(JbpmWorkflowKey.class,"parseLong", "[not number]","key");
		} catch (Exception e) {
//			e.printStackTrace();
			Assert.assertTrue(e instanceof WorkflowException);
			Assert.assertTrue(e.getMessage().startsWith("Can not parse '"));
		}
	}
}
