package com.citi.icg.as.common.workflow.jbpm3;

import com.citi.icg.as.common.workflow.ContextVariable;
import com.citi.icg.as.common.workflow.Workflow;
import com.citi.icg.as.common.workflow.WorkflowConstants;

public interface TestDefinition1 extends Workflow
{
	void goToState2(@ContextVariable(name="varValue",transientVar=false)@Deprecated String varValue);
	void goToState3();
	void goToState4(@ContextVariable(name="varValue",transientVar=true)String varValue);
	void goToState5(@ContextVariable(name="taskId",transientVar=false)long taskId);
	void goToState6(@ContextVariable(name=WorkflowConstants.TASK_DONE_BY,transientVar=true)String taskDoneBy);
}
