package com.citi.icg.as.transform;

import junit.framework.Assert;

import org.junit.Test;

public class StringTransformerTest {
	
	@Test
	public void transformTest1(){
		String input="MADAM%I%AM%ADAM";
		String output="";
		output=StringTransformer.transform(StringTransformer.SWIFT_X_CHAR_SET, input, output);
		Assert.assertEquals(output, "MADAMIAMADAM");
	}
	@Test
	public void transformTest2(){
		String input="MADAM@I@AM@ADAM";
		String output="";
		output=StringTransformer.transform(StringTransformer.SWIFT_Y_CHAR_SET, input, output);
		Assert.assertEquals(output, "MADAMIAMADAM");
	}
	@Test
	public void transformTest3(){
		String input="MADAM@I@AM@ADAM";
		String output="";
		output=StringTransformer.transform(StringTransformer.SWIFT_Z_CHAR_SET, input, output);
		Assert.assertEquals(output, "MADAM@I@AM@ADAM");
	}
	@Test
	public void validate1(){
		String input="MADAM I AM ADAM IS % PALIDROME";
		boolean output=StringTransformer.validate(StringTransformer.SWIFT_X_CHAR_SET, input);
		Assert.assertEquals(output, false);
	}
	@Test
	public void validate2(){
		String input="MADAM I AM ADAM IS : PALIDROME";
		boolean output=StringTransformer.validate(StringTransformer.SWIFT_X_ALLOWED_CHAR_SET, input);
		Assert.assertEquals(output, true);
	}
}
