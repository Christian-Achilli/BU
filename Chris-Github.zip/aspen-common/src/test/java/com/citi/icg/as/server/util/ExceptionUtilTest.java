package com.citi.icg.as.server.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.citi.icg.as.common.client.exception.EntitlementException;
import com.citi.icg.toolkit.web.client.IcgGwtException;
import com.citi.icg.toolkit.web.client.IcgGwtUIException;
import com.citi.icg.toolkit.web.client.common.ErrorType;

public class ExceptionUtilTest {

	@Test
	public void testGetUIException(){
		IcgGwtUIException icgGwtUIException = new IcgGwtUIException();
		assertEquals(ExceptionUtil.getUIException(icgGwtUIException) instanceof IcgGwtUIException, true);
		
		ErrorType errorType =ErrorType.UNKNOW;
		icgGwtUIException.setErrorType(errorType);
		assertEquals(ExceptionUtil.getUIException(icgGwtUIException) instanceof IcgGwtUIException, true);
		
		IcgGwtException icgGwtException = new IcgGwtException();
		assertEquals(ExceptionUtil.getUIException(icgGwtException) instanceof IcgGwtUIException, true);
		
		icgGwtException.setErrorType(errorType);
		assertEquals(ExceptionUtil.getUIException(icgGwtException) instanceof IcgGwtUIException, true);
		
		Exception exception = new Exception();
		assertEquals(ExceptionUtil.getUIException(exception) instanceof IcgGwtUIException, true);
	}
	
	@Test
	public void testWrapInRuntimeException(){
		assertEquals(ExceptionUtil.wrapInRuntimeException(new RuntimeException()) instanceof RuntimeException, true);
		assertEquals(ExceptionUtil.wrapInRuntimeException(new Exception()) instanceof RuntimeException, true);
	}
	
	@Test
	public void testCreateEntitlementException(){
		assertEquals(ExceptionUtil.createEntitlementException("test") instanceof EntitlementException, true);
	}
}
