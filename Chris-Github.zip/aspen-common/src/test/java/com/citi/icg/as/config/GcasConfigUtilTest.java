package com.citi.icg.as.config;

import java.io.InputStream;
import java.lang.reflect.Constructor;

import javax.naming.InitialContext;

import org.apache.commons.configuration.XMLConfiguration;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.citi.icg.as.common.client.compare.CompareResultVisitor;
import com.citi.icg.as.exception.GcasError;
import com.citi.icg.as.exception.GcasException;
import com.citi.icg.as.server.util.ExceptionUtil;

@RunWith(PowerMockRunner.class) 
@PrepareForTest({GcasConfigUtil.class})
public class GcasConfigUtilTest extends BaseConfigTest{

	@Test(expected = GcasError.class)
	public void testNetInstanceInstantiationException()
	{
		GcasConfigUtil.newInstance(CompareResultVisitor.class);
	}
	
	@Test(expected = GcasError.class)
	public void testNetInstanceIllegalAccessException()
	{
		GcasConfigUtil.newInstance(ExceptionUtil.class);
	}
	
	@Test
	public void testNetInstance()
	{
		String newInstance = GcasConfigUtil.newInstance(String.class);
		Assert.assertNotNull(newInstance);
	}
	
	class BConfig extends XMLConfiguration{
		
	}
	
	class BConfigurations extends XMLConfiguration{
		
	}
	
	@Test(expected = GcasError.class)
	public void testGetInstanceGcasError()
	{
		GcasConfigUtil.getInstance(BConfig.class);
	}
	
//	@Test(expected = GacsConfigurationException.class)
//	public void testGetInstanceException()
//	{
//		PowerMock.mockStatic(GcasConfigUtil.class);
//		EasyMock.expect(GcasConfigUtil.getInstance(EasyMock.isA(XMLConfiguration.class), EasyMock.isA(String.class)))
//		.andThrow(new GacsConfigurationException("test"));
//		PowerMock.replay(GcasConfigUtil.class);
//		
//		GcasConfigUtil.getInstance(BConfigurations.class);
//	}
	
	@Test
	public void testGetInstance()
	{
		Assert.assertNotNull(GcasConfigUtil.getInstance(GCASAppConfiguration.class));
	}
	
	@Test
	public void testGetConfigName2()
	{
		String c2 = GcasConfigUtil.getConfigName(BConfig.class);
		Assert.assertEquals("b", c2);
		
		String configName = GcasConfigUtil.getConfigName(GCASAppConfiguration.class);
		Assert.assertEquals("gcasapp", configName);
		
		String cn = GcasConfigUtil.getConfigName(BConfigurations.class);
		Assert.assertEquals("b", cn);
		
		String e = GcasConfigUtil.getConfigName(ExceptionUtil.class);
		Assert.assertEquals("exceptionutil", e);
	}
	
	@Test
	public void testGetInstance2()
	{
		
		GCASAppConfiguration config = GcasConfigUtil.getInstance(GCASAppConfiguration.class);
		Assert.assertNotNull(config);
		
		class A extends XMLConfiguration{
			A(String a)
			{
			}
		}
		try
		{
			GcasConfigUtil.getInstance(A.class);
		}
		catch (Throwable e) {
			Assert.assertNotNull(e);
			Assert.assertTrue(e instanceof GcasError);
		}
		
		
		try
		{
			GcasConfigUtil.getInstance(BConfig.class);
		}
		catch (Throwable e) {
			Assert.assertNotNull(e);
		}
		
	}
	
	@Test
	public void testGetInstanceWithName()
	{
		GCASAppConfiguration c = new GCASAppConfiguration();
		GCASAppConfiguration config = GcasConfigUtil.getInstance(c, "gcasapp");
		Assert.assertNotNull(config);
		
		try
		{
			BConfig b = new BConfig();
			GcasConfigUtil.getInstance(b, "B");
		}
		catch (Throwable e) {
			Assert.assertNotNull(e);
			Assert.assertTrue(e instanceof GacsConfigurationException);
		}
		
	}
	
	@Test
	public void testGetInstanceWithNameAndConfig()
	{
		GCASAppConfiguration c = new GCASAppConfiguration();
		GCASAppConfiguration config = GcasConfigUtil.getInstance(c, "gcasapp", Boolean.TRUE);
		Assert.assertNotNull(config);
	}
	
	@Test
	public void testGetConfigFileStream()
	{
		InputStream configFileStream;
		try {
			configFileStream = GcasConfigUtil.getConfigFileStream("configuration-gcasapp-local.xml");
			Assert.assertNotNull(configFileStream);
		} catch (Error e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testGetConfigFileStreamNC()
	{
		InputStream configFileStream;
		try {
			configFileStream = GcasConfigUtil.getConfigFileStream("src/test/resources/configuration-gcasapp-local.xml");
			Assert.assertNotNull(configFileStream);
		} catch (Error e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetConfigFileStreamWitException() {
		try {
			InputStream configFileStream = GcasConfigUtil.getConfigFileStream(null);
		} catch (Error e) {
			e.printStackTrace();
		} catch (Exception e) {
			Assert.assertNotNull(e);
			Assert.assertTrue(e instanceof NullPointerException);
		}
		
	}
	
	@Test
	public void testGetConfigName()
	{
		String configName = GcasConfigUtil.getConfigName(GCASAppConfiguration.class);
		Assert.assertEquals("gcasapp", configName);
		
		String c2 = GcasConfigUtil.getConfigName(BConfig.class);
		Assert.assertEquals("b", c2);
	}
	
	@Test(expected = GcasException.class)
	public void testGetInstanceFromName() throws GcasException{
		GcasConfigUtil.getInstanceFromName("java.lang.String", String.class);
		GcasConfigUtil.getInstanceFromName("java.lang.String", Integer.class);
	}
	
	@Test
	public void testGetInstanceFromName2() throws GcasException{
		GcasConfigUtil.getInstanceFromName("java.lang.String");
	}
	
	@Test(expected = GcasError.class)
	public void testGetClass(){
		GcasConfigUtil.getClass("java.lang.String");
		GcasConfigUtil.getClass("java.not.exist");
	}
	
	@Test
	public void testGetConfigFileName() throws Exception{
		InitialContext initialContext  = PowerMock.createMock(InitialContext.class);
		EasyMock.expect(initialContext.lookup(EasyMock.isA(String.class))).andReturn("fileName");
		PowerMock.replay(initialContext);
		
		PowerMock.expectNew(InitialContext.class).andReturn(initialContext);
		PowerMock.replay(InitialContext.class);
		Whitebox.invokeMethod(GcasConfigUtil.class, "getConfigFileName", "",true);
	}
	@Test
	public void testGetConfigFileNameNullName() throws Exception{
		InitialContext initialContext  = PowerMock.createMock(InitialContext.class);
		EasyMock.expect(initialContext.lookup(EasyMock.isA(String.class))).andReturn(null);
		PowerMock.replay(initialContext);
		
		PowerMock.expectNew(InitialContext.class).andReturn(initialContext);
		PowerMock.replay(InitialContext.class);
		System.setProperty("icg.configuration.","junit name");
		Whitebox.invokeMethod(GcasConfigUtil.class, "getConfigFileName", "",true);
	}
	@Test
	public void testGetAppConfigDirectory() throws Exception{
		System.setProperty("gcas.config.folder","junit name");
		Whitebox.invokeMethod(GcasConfigUtil.class, "getAppConfigDirectory", new Class[]{});
	}
	
	@Test
	public void testConstructor() throws Exception{
		Constructor<GcasConfigUtil> constructor1= GcasConfigUtil.class.getDeclaredConstructor(new Class[]{});
		constructor1.setAccessible(true);
		constructor1.newInstance(new Object[]{});
	}
	
}
