package com.citi.icg.as.common.client.util;


import org.junit.Assert;
import org.junit.Test;

public class StringUtilGwtTest {
	@Test
	public void testGetAsPercentString(){
		Assert.assertEquals("1%", StringUtilGwt.getAsPercentString(1));
	}
	
	@Test
	public void testIsNotBlank(){
		Assert.assertFalse(StringUtilGwt.isNotBlank(null));
		Assert.assertFalse(StringUtilGwt.isNotBlank(""));
		Assert.assertTrue(StringUtilGwt.isNotBlank("any"));
	}
	
	@Test
	public void testIsNotEmpty(){
		Assert.assertFalse(StringUtilGwt.isNotEmpty(null));
		Assert.assertFalse(StringUtilGwt.isNotEmpty(""));
		Assert.assertTrue(StringUtilGwt.isNotEmpty("any"));
	}
	
	@Test
	public void testIsEmpty(){
		Assert.assertTrue(StringUtilGwt.isEmpty(""));
		Assert.assertFalse(StringUtilGwt.isEmpty("any"));
	}
	
	@Test
	public void testIsNullOrEmpty(){
		Assert.assertTrue(StringUtilGwt.isNullOrEmpty(""));
		Assert.assertTrue(StringUtilGwt.isNullOrEmpty(null));
		Assert.assertFalse(StringUtilGwt.isNullOrEmpty("any"));
	}
	
	@Test
	public void testIsInteger(){
		Assert.assertTrue(StringUtilGwt.isInteger("1"));
		Assert.assertFalse(StringUtilGwt.isInteger("9999999999"));
		Assert.assertFalse(StringUtilGwt.isInteger("2999999999"));
		Assert.assertTrue(StringUtilGwt.isInteger("0999999999"));
	}
	
	@Test
	public void testIsBigDecimal(){
		Assert.assertTrue(StringUtilGwt.isBigDecimal("1"));
		Assert.assertFalse(StringUtilGwt.isBigDecimal("a"));
	}
	
	@Test
	public void testIsNumber(){
		Assert.assertFalse(StringUtilGwt.isNumber(null));
		Assert.assertFalse(StringUtilGwt.isNumber(""));
		Assert.assertTrue(StringUtilGwt.isNumber("+"));
		Assert.assertTrue(StringUtilGwt.isNumber("-"));
		Assert.assertFalse(StringUtilGwt.isNumber("a"));
		Assert.assertFalse(StringUtilGwt.isNumber("12a"));
		Assert.assertTrue(StringUtilGwt.isNumber("123"));
	}
	
	@Test
	public void testSplitByDelemiter(){
		String[] result = StringUtilGwt.splitByDelemiter("0-1", "-");
		Assert.assertEquals("0", result[0]);
		Assert.assertEquals("1", result[1]);
	}
	
	@Test
	public void testChangeFirstLetterToUppercase(){
		Assert.assertEquals("Aaa", StringUtilGwt.changeFirstLetterToUppercase("aaa"));
	}
	
	@Test
	public void testTrimToEmpty(){
		Assert.assertEquals("", StringUtilGwt.trimToEmpty(null));
		Assert.assertEquals("aa", StringUtilGwt.trimToEmpty(" aa"));
	}
	
	@Test
	public void testTrimToNull(){
		Assert.assertEquals(null, StringUtilGwt.trimToNull(null));
		Assert.assertEquals("aa", StringUtilGwt.trimToNull(" aa"));
	}
	
	@Test
	public void testAbbreviate(){
		Assert.assertEquals(null, StringUtilGwt.abbreviate(null, 1));
		Assert.assertEquals("aa", StringUtilGwt.abbreviate("aa", 3));
		Assert.assertEquals("...", StringUtilGwt.abbreviate("aa", 1));
		Assert.assertEquals("a...", StringUtilGwt.abbreviate("aaaaa", 4));
	}
	
	@Test
	public void testStripCRLF(){
		Assert.assertEquals(null, StringUtilGwt.stripCRLF(null));
		Assert.assertEquals("aa a", StringUtilGwt.stripCRLF("aa\na"));
	}
	
	@Test
	public void testJoin(){
		Assert.assertEquals("ab", StringUtilGwt.join("a", "", "b"));
	}
	
	@Test
	public void testJoinWithDelimeter(){
		Assert.assertEquals("a,b", StringUtilGwt.joinWithDelimeter(",", "a", "b"));
		Assert.assertEquals("", StringUtilGwt.joinWithDelimeter(",", null));
	}
	
	@Test
	public void testWrap(){
		Assert.assertEquals(null, StringUtilGwt.wrap(null, 0, null, false));
		Assert.assertEquals("abcde", StringUtilGwt.wrap(" abcde", 0, null, false));
		Assert.assertEquals("a\nb\nc\nd\ne", StringUtilGwt.wrap(" ab cde", 1, "\n", true));
	}
	
	@Test
	public void testEquals(){
		Assert.assertTrue(StringUtilGwt.equals(null, null));
		Assert.assertFalse(StringUtilGwt.equals("a", null));
		Assert.assertTrue(StringUtilGwt.equals("a", "a"));
	}
	
	@Test
	public void testSubstringBetween(){
		Assert.assertNull(StringUtilGwt.substringBetween(null, null));
	}
	
	@Test
	public void testSubstringBetween2(){
		Assert.assertNull(StringUtilGwt.substringBetween(null, null, null));
		Assert.assertNull(StringUtilGwt.substringBetween("a", null, null));
		Assert.assertNull(StringUtilGwt.substringBetween("a", "b", null));
		Assert.assertNull(StringUtilGwt.substringBetween("b", "b", "b"));
		Assert.assertNull(StringUtilGwt.substringBetween("b", "b", "c"));
		Assert.assertEquals("b",StringUtilGwt.substringBetween("bbcc", "b", "c"));
	}
}
