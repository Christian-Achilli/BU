package com.citi.icg.as.common.logging;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class LoggingTest {
	
	private static final Logger LOG=Logger.getLogger(LoggingTest.class);
	Logging logging;
	@Before
	public void setUp(){
		logging=new Logging();
	}
	
	@After
	public void tearOut(){
		logging=null;
	}
	
	@Test
	public void test1(){
		String encoded=logging.simpleEncode("test<>&\"");
		Assert.assertEquals(encoded, "test&lt;&gt;&amp;&quot;");
	}
	
	@Test
	public void test2(){
		boolean check=logging.isBlank("test<>&\"");
		Assert.assertEquals(check, false);
	}
	
	@Test
	public void test3(){
		boolean check=logging.isBlank(" ");
		Assert.assertEquals(check, true);
	}
	
	@Test
	public void test4() throws IOException{
		MockHttpServletRequest request=new MockHttpServletRequest();
		MockHttpServletResponse response=new MockHttpServletResponse();
		request.setParameter("cat", "test");
		request.setParameter("", "WARN");
		PrintWriter out=response.getWriter(); 
		logging.setPriority(request, out);
	}
	
	@Test
	public void test5() throws IOException{
		MockHttpServletRequest request=new MockHttpServletRequest();
		MockHttpServletResponse response=new MockHttpServletResponse();
		PrintWriter out=response.getWriter(); 
		logging.renderCategoryList(request, out);
	}
	
	@Test
	public void test6() throws IOException{
		MockHttpServletRequest request=new MockHttpServletRequest();
		MockHttpServletResponse response=new MockHttpServletResponse();
		PrintWriter out=response.getWriter(); 
		logging.printCategory(LOG, "test", out);
	}
	
	@Test
	public void test7() throws IOException{
		MockHttpServletRequest request=new MockHttpServletRequest();
		MockHttpServletResponse response=new MockHttpServletResponse();
		PrintWriter out=response.getWriter(); 
		logging.renderEditForm(request, out);
	}
	
	@Test
	public void test8() throws ServletException, IOException{
		MockHttpServletRequest request=new MockHttpServletRequest();
		request.setContextPath("/src/test/");
		request.setServletPath("test8");
		MockHttpServletResponse response=new MockHttpServletResponse();
		PrintWriter out=response.getWriter(); 
		logging.printPriorityOption(out, "test", "test", "test");
		logging.renderHead(out);
		logging.renderFoot(out);
		logging.getCategory("root");
		logging.getScriptName(request);
		logging.doGet(request, response);
		
	}
}
