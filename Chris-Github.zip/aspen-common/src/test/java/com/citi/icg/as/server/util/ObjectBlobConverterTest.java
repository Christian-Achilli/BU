package com.citi.icg.as.server.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.sql.Blob;
import java.sql.SQLException;

import org.junit.Assert;
import org.junit.Test;

public class ObjectBlobConverterTest {
	@Test
	public void testObjectToBlob() {
		Blob blob=ObjectBlobConverter.ObjectToBlob(new OIOTest("Juint"));
		Assert.assertNotNull(blob);
		blob=ObjectBlobConverter.ObjectToBlob(null);
		Assert.assertNotNull(blob);
		ObjectBlobConverter.ObjectToBlob(new Serializable(){
		});
	}

	@Test
	public void testBlobToObject() {
		Object result=ObjectBlobConverter.BlobToObject(ObjectBlobConverter.ObjectToBlob(new OIOTest("Juint")));
		Assert.assertNotNull(result);
		Assert.assertTrue(result instanceof OIOTest);
		Assert.assertTrue("Juint".equals(((OIOTest)result).getName()));
		ObjectBlobConverter.BlobToObject(new Blob() {
			
			@Override
			public void truncate(long len) throws SQLException {
				
			}
			
			@Override
			public int setBytes(long pos, byte[] bytes, int offset, int len)
					throws SQLException {
				return 0;
			}
			
			@Override
			public int setBytes(long pos, byte[] bytes) throws SQLException {
				return 0;
			}
			
			@Override
			public OutputStream setBinaryStream(long pos) throws SQLException {
				return null;
			}
			
			@Override
			public long position(Blob pattern, long start) throws SQLException {
				return 0;
			}
			
			@Override
			public long position(byte[] pattern, long start) throws SQLException {
				return 0;
			}
			
			@Override
			public long length() throws SQLException {
				return 0;
			}
			
			@Override
			public byte[] getBytes(long pos, int length) throws SQLException {
				return null;
			}
			
			@Override
			public InputStream getBinaryStream(long pos, long length)
					throws SQLException {
				return null;
			}
			
			@Override
			public InputStream getBinaryStream() throws SQLException {
				return null;
			}
			
			@Override
			public void free() throws SQLException {
				
			}
		});
	}
}

class OIOTest implements Serializable{
	private static final long serialVersionUID = 1L;
	private String name;
	public OIOTest(String name){
		this.name=name;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "OIOTest [name=" + name + "]";
	}
}
