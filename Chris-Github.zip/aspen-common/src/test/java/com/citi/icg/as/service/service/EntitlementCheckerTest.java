package com.citi.icg.as.service.service;

import java.lang.reflect.Constructor;

import org.junit.Assert;
import org.junit.Test;

import com.citi.icg.as.common.client.exception.EntitlementException;
import com.citi.icg.as.server.service.EntitlementChecker;
import com.citi.icg.toolkit.web.client.IcgGwtException;

public class EntitlementCheckerTest {

	@Test(expected = IcgGwtException.class)
	public void isAllowedTest() {
		//test when object is null
		EntitlementChecker.isAllowed(null, null, null, null);
		
		EntitlementChecker.isAllowed(new Object(), "toString", new Object[]{}, new Class[]{});
		
		EntitlementChecker.isAllowed(new Object(), "test", new Object[]{}, new Class[]{});
		
	}
	
	@Test
	public void isAllowedWhenCatchExceptionTest(){
		IcgGwtException ige = null;
		try{
			EntitlementChecker.isAllowed(new EntitlementCheckTestTools(), "toolThrowIcgGwtExcption", new Object[]{}, new Class[]{});
		} catch (IcgGwtException e){
			ige = e;
		}
		Assert.assertNotNull(ige);
		
		EntitlementException ee = null;
		try {
			EntitlementChecker.isAllowed(new EntitlementCheckTestTools(), "toolThrowNotIcgGwtExcption", new Object[]{}, new Class[]{});
		} catch (EntitlementException e) {
			ee = e;
		}
		Assert.assertNotNull(ee);
	}
	@Test
	public void testConstructor() throws Exception{
		Constructor<EntitlementChecker> constructor=EntitlementChecker.class.getDeclaredConstructor(new Class[]{});
		constructor.setAccessible(true);
		constructor.newInstance(new Object[]{});
	}
}
