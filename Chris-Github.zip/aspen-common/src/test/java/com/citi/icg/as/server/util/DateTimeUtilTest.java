package com.citi.icg.as.server.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.citi.icg.as.exception.GcasRuntimeException;

@RunWith(PowerMockRunner.class)
@PrepareForTest({DateTimeUtil.class})
public class DateTimeUtilTest {
	
	@Before
	public void setup() {
		System.setProperty("user.timezone", "UTC");
	}
	
	@Test
	public void testConstractor() throws Exception {
		Whitebox.invokeConstructor(DateTimeUtil.class, null);
	}
	
	@Test
	public void testAssertUTCTimeZone() {
		System.setProperty("user.timezone", "UTC");
		DateTimeUtil.assertUTCTimeZone();
	}

	@Test(expected = GcasRuntimeException.class)
	public void testAssertUTCTimeZone$2() {
		System.setProperty("user.timezone", "Others");
		DateTimeUtil.assertUTCTimeZone();
	}
	
	@Test
	public void testGetTimeZone() {
		assertEquals(DateTimeUtil.getTimeZone(DateTimeUtil.EMEA_REGION),DateTimeUtil.TIMEZONE_EMEA);
		assertEquals(DateTimeUtil.getTimeZone(DateTimeUtil.ASPAC_REGION),DateTimeUtil.TIMEZONE_ASPAC);
		assertEquals(DateTimeUtil.getTimeZone(DateTimeUtil.APAC_REGION),DateTimeUtil.TIMEZONE_APAC);
		assertEquals(DateTimeUtil.getTimeZone("Default"),DateTimeUtil.TIMEZONE_NAM);
	}
	
	@Test
	public void testConvertToUTC() {
		DateTimeUtil.convertToUTC(new Date(), DateTimeUtil.TIMEZONE_NAM);
		DateTimeUtil.convertToUTC(new Date(), DateTimeUtil.TIMEZONE_EMEA);
		DateTimeUtil.convertToUTC(new Date(), DateTimeUtil.TIMEZONE_ASPAC);
		DateTimeUtil.convertToUTC(new Date(), DateTimeUtil.TIMEZONE_APAC);
		DateTimeUtil.convertToUTC(new Date(), DateTimeUtil.TIMEZONE_UTC);
		DateTimeUtil.convertToUTC(new Date(), null);
		DateTimeUtil.convertToUTC(null, DateTimeUtil.TIMEZONE_UTC);
		DateTimeUtil.convertToUTC(null, null);
	}
	
	@Test(expected = NullPointerException.class)
	public void testConvertDate() {
		DateTimeUtil.convertDate(new Date(), DateTimeUtil.TIMEZONE_NAM);
		DateTimeUtil.convertDate(new Date(), DateTimeUtil.TIMEZONE_EMEA);
		DateTimeUtil.convertDate(new Date(), DateTimeUtil.TIMEZONE_ASPAC);
		DateTimeUtil.convertDate(new Date(), DateTimeUtil.TIMEZONE_APAC);
		DateTimeUtil.convertDate(new Date(), DateTimeUtil.TIMEZONE_UTC);
		DateTimeUtil.convertDate(new Date(), null);
	}
	
	@Test
	public void testFormatDate() {
		try {
			assertEquals(DateTimeUtil.formatDate(new Date(2013-1900, 0, 28), "YYYY-MM-DD"), "2013-01-28");
		} catch (Exception e) {
			Assert.assertTrue(e instanceof IllegalArgumentException);
		}
	}
	
	@Test
	public void testFormatDate$2() {
		assertEquals(DateTimeUtil.formatDate(new Date(2013-1900, 0, 28), "yyyy-MM-DD"), "2013-01-28");
	}
	
	@Test (expected = NullPointerException.class)
	public void testFormatDate$3() {
		assertEquals(DateTimeUtil.formatDate(null, "YYYY-MM-DD"), null);
		DateTimeUtil.formatDate(new Date(), null);
	}
	
	@Test
	public void testGetDate() throws ParseException {
		assertEquals(DateTimeUtil.getDate(new Date().toString(), null), null);
		assertEquals(DateTimeUtil.getDate(null, "YYYY-MM-DD"), null);
		assertEquals(DateTimeUtil.getDate(null, null), null);
		Date date = DateTimeUtil.getDate("2013-01-28", "yyyy-MM-DD");
		assertEquals(date.getYear()+1900, 2013);
		assertEquals(date.getMonth() +1 , 1);
		assertEquals(date.getDay(), 1);
	}
	
	@Test
	public void testGetFormattedDate() throws Exception {
		assertEquals(DateTimeUtil.getFormattedDate(DateTimeUtil.getDate("2013-01-28", "yyyy-MM-DD")), "20130128");
		assertEquals(DateTimeUtil.getFormattedDate(null), null);
		
		PowerMock.mockStaticPartial(DateTimeUtil.class, "formatDate");
		PowerMock.expectPrivate(DateTimeUtil.class, "formatDate", EasyMock.isA(Date.class), EasyMock.isA(String.class)).andThrow(new RuntimeException());
		PowerMock.replay(DateTimeUtil.class);
		
		assertEquals(DateTimeUtil.getFormattedDate(new Date()), null);
	}
	
	@Test
	public void testGetFormattedDateWithPattern() throws Exception {		
		assertEquals(DateTimeUtil.getFormattedDate(new Date().toString(), null), null);
		assertEquals(DateTimeUtil.getFormattedDate(null, "yyyy-MM-DD"), null);
		assertEquals(DateTimeUtil.getFormattedDate(null, null), null);
		Date date = DateTimeUtil.getFormattedDate("2013-01-28", "yyyy-MM-DD");
		assertEquals(date.getYear()+1900, 2013);
		assertEquals(date.getMonth() +1 , 1);
		assertEquals(date.getDay(), 1);
		
		PowerMock.mockStaticPartial(DateTimeUtil.class, "getDate");
		PowerMock.expectPrivate(DateTimeUtil.class, "getDate", EasyMock.isA(String.class), EasyMock.isA(String.class)).andThrow(new RuntimeException());
		PowerMock.replay(DateTimeUtil.class);
		
		assertEquals(DateTimeUtil.getFormattedDate("2013-01-28", "yyyy-MM-DD"), null);
	}
	
	@Test
	public void testGetDateWithoutTime() throws Exception {
		assertEquals(DateTimeUtil.getDateWithoutTime(null), null);
		DateTimeUtil.getDateWithoutTime(new Date());
		
		PowerMock.mockStaticPartial(DateTimeUtil.class, "getDate");
		PowerMock.expectPrivate(DateTimeUtil.class, "getDate", EasyMock.isA(String.class), EasyMock.isA(String.class)).andThrow(new RuntimeException());
		PowerMock.replay(DateTimeUtil.class);
		
		assertEquals(DateTimeUtil.getDateWithoutTime(new Date()), null);
	}
	
	@Test
	public void testGetCalendar() {
		Calendar calender1 = DateTimeUtil.getCalendar(Calendar.getInstance());
		Calendar calender2 = DateTimeUtil.getCalendar(null);
		assertEquals(calender1, calender2);
	}
	
	@Test
	public void testIsSameDay() {
		assertEquals(DateTimeUtil.isSameDay(new Date(), new Date(), DateTimeUtil.TIMEZONE_UTC), true);
		assertEquals(DateTimeUtil.isSameDay(new Date(), DateTimeUtil.getFormattedDate("2013-01-27", "yyyy-MM-DD"), DateTimeUtil.TIMEZONE_UTC), false);
	}
	
	@Test
	public void testDefaultCreateDayComparator() {
		Comparator<Date> comparator = DateTimeUtil.createDayComparator(DateTimeUtil.TIMEZONE_UTC);
		assertEquals(comparator.compare(new Date(), new Date()), 0);
		assertEquals(comparator.compare(new Date(), null), 1);
		assertEquals(comparator.compare(null, new Date()), -1);
	}
	
	@Test
	public void testCreateDayComparator() {
		Comparator<Date> comparator = DateTimeUtil.createDayComparator(DateTimeUtil.TIMEZONE_UTC, true);
		assertEquals(comparator.compare(new Date(), new Date()), 0);
		assertEquals(comparator.compare(new Date(), null), -1);
		assertEquals(comparator.compare(null, new Date()), 1);
	}
	
	@Test
	public void testIsWeekend_SaturDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		boolean isWeekend = DateTimeUtil.isWeekend(calendar.getTime(), calendar.getTimeZone());
		assertTrue(isWeekend);
	}
	
	@Test
	public void testIsWeekend_SunDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		boolean isWeekend = DateTimeUtil.isWeekend(calendar.getTime(), calendar.getTimeZone());
		assertTrue(isWeekend);
	}
	
	@Test
	public void testIsWeekend_MonDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		boolean isWeekend = DateTimeUtil.isWeekend(calendar.getTime(), calendar.getTimeZone());
		assertFalse(isWeekend);
	}
	
	@Test
	public void testIsNotWeekend_SaturDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		boolean isWeekend = DateTimeUtil.isNotWeekend(calendar.getTime(), calendar.getTimeZone());
		assertFalse(isWeekend);
	}
	
	@Test
	public void testIsNotWeekend_SunDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		boolean isWeekend = DateTimeUtil.isNotWeekend(calendar.getTime(), calendar.getTimeZone());
		assertFalse(isWeekend);
	}
	
	@Test
	public void testIsNotWeekend_MonDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		boolean isWeekend = DateTimeUtil.isNotWeekend(calendar.getTime(), calendar.getTimeZone());
		assertTrue(isWeekend);
	}
	
	@Test
	public void testCalculateWorkdates_NotCrossWeekend() {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();
		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, calendar1.getTimeZone());
		assertEquals(1, workDates);
	}
	
	@Test
	public void testCalculateWorkdates_CrossWeekend() {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.add(Calendar.DAY_OF_WEEK, -7);
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.TUESDAY);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();
		
		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, calendar1.getTimeZone());
		assertEquals(6, workDates);
	}
	
	
	@Test
	public void testCalculateWorkdates_CurrentDateAtSaturday() {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();

		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, calendar1.getTimeZone());
		assertEquals(2, workDates);
	}
	
	@Test
	public void testCalculateWorkdates_CurrentDateAtSunday() {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.add(Calendar.DAY_OF_WEEK, -7);
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();

		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, calendar1.getTimeZone());
		assertEquals(2, workDates);
	}
	
	@Test
	public void testCalculateWorkdates_StartDateAtSaturday() {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.add(Calendar.DAY_OF_WEEK, -7);
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();

		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, calendar1.getTimeZone());
		assertEquals(0, workDates);
	}
	
	@Test
	public void testCalculateWorkdates_StartDateAtSunday() {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();

		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, calendar1.getTimeZone());
		assertEquals(0, workDates);
	}
	
	@Test
	public void testCalculateWorkdates_StartDateAtSaturdayAndCurrentDateAtSunday() {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.add(Calendar.DAY_OF_WEEK, -7);
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();

		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, calendar1.getTimeZone());
		assertEquals(0, workDates);
	}
	
	@Test
	public void testCalculateWorkdates_sameDateAtEMEAdiffAtASPAC() {
		Calendar calendar1 = Calendar.getInstance(DateTimeUtil.TIMEZONE_EMEA);
		calendar1.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		calendar1.set(Calendar.HOUR_OF_DAY, 12);
		
		Calendar calendar2 = Calendar.getInstance(DateTimeUtil.TIMEZONE_EMEA);
		calendar2.set(Calendar.DAY_OF_WEEK, Calendar.THURSDAY);
		calendar2.set(Calendar.HOUR_OF_DAY, 22);
		
		Date date1 = calendar1.getTime();
		Date date2 = calendar2.getTime();

		System.out.println(date1);
		System.out.println(date2);
		int workDates = DateTimeUtil.calculateWorkdates(date1, date2, DateTimeUtil.TIMEZONE_ASPAC);
		assertEquals(1, workDates);
	}
}
