package com.citi.icg.as.server.service.compare;

import org.apache.commons.logging.Log;
import org.easymock.EasyMock;
import org.junit.Test;
import org.powermock.api.easymock.PowerMock;

import com.citi.icg.as.common.client.compare.CompareResult;
import com.citi.icg.as.common.client.compare.CompareResultVisitor;

public class StringDescriptionCompareResultVisitorTest {

	@Test
	public void testLogToDebug(){
		StringDescriptionCompareResultVisitor.logToDebug(null);
		StringDescriptionCompareResultVisitor.logToDebug(null,null);
		
		Log log = PowerMock.createMock(Log.class);
		EasyMock.expect(log.isDebugEnabled()).andReturn(false).anyTimes();
		log.debug(EasyMock.isA(String.class));
		PowerMock.expectLastCall().anyTimes();
		EasyMock.replay(log);

		StringDescriptionCompareResultVisitor.logToDebug(log,null);
		
		PowerMock.reset(log);
		EasyMock.expect(log.isDebugEnabled()).andReturn(true).anyTimes();
		log.debug(EasyMock.isA(String.class));
		PowerMock.expectLastCall().anyTimes();
		PowerMock.replay(log);

		StringDescriptionCompareResultVisitor.logToDebug(log,null);
		
		CompareResult compareResult = PowerMock.createMock(CompareResult.class);
		compareResult.visit(EasyMock.isA(CompareResultVisitor.class));
		EasyMock.expectLastCall().andDelegateTo(new CompareResult(){
			@Override
			public void visit(CompareResultVisitor visitor){
				((StringDescriptionCompareResultVisitor)visitor).startRootCompareResult();
			}
		});
		PowerMock.replay(compareResult);
		
		StringDescriptionCompareResultVisitor.logToDebug(log, compareResult);
	}
	
	@Test
	public void testLogToInfo(){
		StringDescriptionCompareResultVisitor.logToInfo(null);
		StringDescriptionCompareResultVisitor.logToInfo(null,null);
		
		Log log = PowerMock.createMock(Log.class);
		EasyMock.expect(log.isInfoEnabled()).andReturn(false).anyTimes();
		log.debug(EasyMock.isA(String.class));
		PowerMock.expectLastCall().anyTimes();
		EasyMock.replay(log);

		StringDescriptionCompareResultVisitor.logToInfo(log,null);
		
		PowerMock.reset(log);
		EasyMock.expect(log.isInfoEnabled()).andReturn(true).anyTimes();
		log.info(EasyMock.isA(String.class));
		PowerMock.expectLastCall().anyTimes();
		PowerMock.replay(log);

		StringDescriptionCompareResultVisitor.logToInfo(log,null);
		
		CompareResult compareResult = PowerMock.createMock(CompareResult.class);
		compareResult.visit(EasyMock.isA(CompareResultVisitor.class));
		EasyMock.expectLastCall().andDelegateTo(new CompareResult(){
			@Override
			public void visit(CompareResultVisitor visitor){
				((StringDescriptionCompareResultVisitor)visitor).startRootCompareResult();
			}
		});
		PowerMock.replay(compareResult);
		
		StringDescriptionCompareResultVisitor.logToInfo(log, compareResult);
	}

	@Test
	public void testAcceptCompareResult(){
		StringDescriptionCompareResultVisitor target = new StringDescriptionCompareResultVisitor();
		target.startRootCompareResult();
		target.acceptCompareResult(null, null);
	}
	
	@Test
	public void testAcceptProperty(){
		StringDescriptionCompareResultVisitor target = new StringDescriptionCompareResultVisitor();
		target.startRootCompareResult();
		target.acceptProperty(null, new CompareResult(), false, new String[]{"",""});
	}
	
}
