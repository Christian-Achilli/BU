package com.citi.icg.as.common.client.compare;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class) 
@PrepareForTest(CompareResult.class)
public class CompareResultTest {
	CompareResult compareResult;
	String ATOMIC_VALUES_KEY = "__ATOMIC_VALUES__";
	CompareResultVisitor visitor = new InnerCompareResultVisitor();
	
	private CompareResult createMockCompareResult() throws Exception{
		CompareResult mockCR = PowerMock.createPartialMock(CompareResult.class, "visitR");
		PowerMock.expectPrivate(mockCR, "visitR", EasyMock.isA(CompareResult.class), EasyMock.isA(CompareResultVisitor.class),EasyMock.isA(String.class));
		PowerMock.expectLastCall();
		return mockCR;
	}
	
	@Before
	public void setUp(){
		compareResult = new CompareResult();
	}

	@Test
	public void testVisit() throws Exception{
		CompareResult cr= createMockCompareResult();
		cr.visit(visitor);
	}
	
	@Test
	public void testVisitRContain(){
		Map<String, String[]> propertyValues = new HashMap<String, String[]>();
		propertyValues.put(ATOMIC_VALUES_KEY, new String[]{});
		compareResult.setPropertyValues(propertyValues );
		List<String> allProperties = new ArrayList<String>();
		allProperties.add("noBeanNoArray");
		compareResult.setBeanResults(new HashMap<String,CompareResult>());
		compareResult.setArraysResults(new HashMap<String,CompareResult[]>());
		compareResult.setAllProperties(allProperties);
		compareResult.visit(visitor);
	}
	
	@Test
	public void testVisitR(){
		Map<String, String[]> propertyValues = new HashMap<String, String[]>();
		compareResult.setPropertyValues(propertyValues);
		List<String> allProperties = new ArrayList<String>();
		String bpkey = "beanProperty";
		String apkey = "arrayProperty";
		allProperties.add(bpkey);
		allProperties.add(apkey);
		
		Map<String, CompareResult> beanResults = new HashMap<String,CompareResult>();
		CompareResult bpCR = new CompareResult();	
		bpCR.setPropertyValues(new HashMap<String,String[]>());
		bpCR.setAllProperties(new ArrayList<String>());
		beanResults.put(bpkey, bpCR);
		
		Map<String, CompareResult[]> arraysResults = new HashMap<String, CompareResult[]>();
		CompareResult apCR1 = new CompareResult();
		apCR1.setPropertyValues(new HashMap<String,String[]>());
		apCR1.setAllProperties(new ArrayList<String>());
		
		CompareResult apCR2 = new CompareResult();
		apCR2.setPropertyValues(new HashMap<String,String[]>());
		apCR2.setAllProperties(new ArrayList<String>());
		arraysResults.put(apkey, new CompareResult[]{apCR1,apCR2});
		
		compareResult.setAllProperties(allProperties);
		compareResult.setBeanResults(beanResults);
		compareResult.setArraysResults(arraysResults);
		compareResult.visit(visitor);
	}
	
	@Test
	public void testGetSetEneities(){
		compareResult.setEntities(null);
		assertNull(compareResult.getEntities());
	}
	
	@Test
	public void testGetSetIds(){
		compareResult.setIds(null);
		assertNull(compareResult.getIds());
	}
	
	@Test
	public void testGetSetName(){
		String name = "test";
		compareResult.setName(name);
		assertEquals(name ,compareResult.getName());
	}
	
	@Test
	public void testGetSetJavaPropertyNames(){
		Map<String, String> javaPropertyNames = new HashMap<String,String>();
		javaPropertyNames.put("key", "value");
		compareResult.setJavaPropertyNames(javaPropertyNames );
		assertTrue(compareResult.getJavaPropertyNames().containsKey("key"));
	}
	
	@Test
	public void testIsBeanProperty(){
		Map<String, CompareResult> beanResults = new HashMap<String,CompareResult>();
		beanResults.put("key", new CompareResult());
		compareResult.setBeanResults(beanResults);
		assertNotNull(compareResult.getBeanResults());
		assertTrue(compareResult.isBeanProperty("key"));
		assertFalse(compareResult.isBeanProperty("another"));
	}
	
	@Test
	public void testIsArrayProperty(){
		Map<String, CompareResult[]> arraysResults = new HashMap<String,CompareResult[]>();
		CompareResult[] crs = {new CompareResult()};
		arraysResults.put("key", crs );
		compareResult.setArraysResults(arraysResults);
		assertNotNull(compareResult.getArraysResults());
		assertTrue(compareResult.isArrayProperty("key"));
		assertFalse(compareResult.isArrayProperty("another"));
	}
	@Test
	public void testGetSetAllProperties(){
		List<String> allProperties = new ArrayList<String>();
		allProperties.add("test");
		compareResult.setAllProperties(allProperties );
		assertNotNull(compareResult.getAllProperties());
		assertEquals(1,compareResult.getAllProperties().size());
	}
	
	@Test
	public void testSetMatchedProperties(){
		Set<String> matchedProperties = new HashSet<String>();
		compareResult.setMatchedProperties(matchedProperties );
	}
	
	@Test
	public void testGetSetUnmatchedProperties(){
		Set<String> unmatchedProperties = new HashSet<String>();
		unmatchedProperties.add("test1");
		unmatchedProperties.add("test2");
		compareResult.setUnmatchedProperties(unmatchedProperties);
		assertNotNull(compareResult.getUnmatchedProperties());
		assertEquals(2,compareResult.getUnmatchedProperties().size());
		
	}
	
	@Test
	public void testGetSetPropertyValues(){
		Map<String, String[]> propertyValues = new HashMap<String,String[]>();
		propertyValues.put("key", new String[]{"value1","value2"});
		compareResult.setPropertyValues(propertyValues);
		assertTrue(compareResult.getPropertyValues().containsKey("key"));
	}
	

	@Test
	public void testGetSetManuallyChangedProperties(){
		Set<String> manuallyChangedProperties = new HashSet<String>();
		manuallyChangedProperties.add("test");
		compareResult.setManuallyChangedProperties(manuallyChangedProperties );
		assertNotNull(compareResult.getManuallyChangedProperties());
	}
	
	@Test
	public void testGetSetParentUUID(){
		String parentUUID = "parentUUID";
		compareResult.setParentUUID(parentUUID);
		assertEquals(parentUUID,compareResult.getParentUUID());
	}
	
	private class InnerCompareResultVisitor implements CompareResultVisitor{

		@Override
		public void acceptProperty(String propertyName) {
			
		}

		@Override
		public void endBeanResult(String propertyName,
				CompareResult compareResult) {
			
		}

		@Override
		public void endCollectionResult(String propertyName,
				CompareResult[] compareResults) {
			
		}

		@Override
		public void startBeanResult(String propertyName,
				CompareResult compareResult) {
			
		}

		@Override
		public void startCollectionResult(String propertyName,
				CompareResult[] compareResults) {
			
		}
		
	}
	
}
