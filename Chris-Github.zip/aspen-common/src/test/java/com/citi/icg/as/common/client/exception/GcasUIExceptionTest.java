package com.citi.icg.as.common.client.exception;

import org.junit.Assert;
import org.junit.Test;

public class GcasUIExceptionTest {
	@Test
	public void testGcasUIException(){
		new GcasUIException();
		new GcasUIException("message", "stackDetails");
	}

	@Test
	public void testGetDetails(){
		Assert.assertNull(new GcasUIException().getDetails());
	}
	
	@Test
	public void testSetDetails(){
		new GcasUIException().setDetails("a");
	}
	
	@Test
	public void testGetMessage(){
		Assert.assertNull(new GcasUIException().getMessage());
	}
	
	@Test
	public void testSetMessage(){
		new GcasUIException().setMessage("a");
	}
	
	@Test
	public void testGetTrackingNo(){
		Assert.assertTrue(new GcasUIException().getTrackingNo() == 0);
	}
}
