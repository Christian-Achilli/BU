package com.citi.icg.as.common.client.compare;

import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.junit.Test;

public class SimpleCompareResultVisitorTest {
	InnerSimpleCompareResultVisitor iscv = new InnerSimpleCompareResultVisitor();

	@SuppressWarnings("serial")
	private class InnerSimpleCompareResultVisitor extends
			SimpleCompareResultVisitor {

	}

	@Test
	public void testGetCompareResultStack() {
		iscv.getCompareResultStack();
	}

	@Test
	public void testGetPropertyNameStack() {
		iscv.getPropertyNameStack();
	}

	@Test
	public void testGetPropertyNamePath() {
		iscv.getPropertyNamePath();
	}

	@Test
	public void testGetPropertyNamePathWithArg() throws Exception {
		List<String> propertyNameStack = new LinkedList<String>();
		propertyNameStack.add("");
		propertyNameStack.add("test");
		propertyNameStack.add(" ");
		resetPorpertyNameStack(propertyNameStack);
		iscv.getPropertyNamePath("test1");

	}

	private void resetPorpertyNameStack(List<String> propertyNameStack)
			throws NoSuchFieldException, IllegalAccessException {
		Field propertyNameStackField = SimpleCompareResultVisitor.class
				.getDeclaredField("propertyNameStack");
		propertyNameStackField.setAccessible(true);
		propertyNameStackField.set(iscv, propertyNameStack);
	}

	@Test
	public void testIsCompareResultFromCollection() throws Exception {
		setCompareResultOneValue();
		iscv.isCompareResultFromCollection();
	}

	private void setCompareResultOneValue() throws NoSuchFieldException,
			IllegalAccessException {
		List<CompareResult> compareResultStack = new ArrayList<CompareResult>();
		compareResultStack.add(new CompareResult());
		resetCompareResultStack(compareResultStack);
	}

	private void resetCompareResultStack(List<CompareResult> compareResultStack)
			throws NoSuchFieldException, IllegalAccessException {
		Field compareResultStackField = SimpleCompareResultVisitor.class
				.getDeclaredField("compareResultStack");
		compareResultStackField.setAccessible(true);
		compareResultStackField.set(iscv, compareResultStack);
	}

	@Test
	public void testStartBeanResult() throws Exception {
		// compareResultStack.isEmpty
		iscv.startBeanResult("propertyName", new CompareResult());
		setCompareResultOneValue();
		iscv.startBeanResult("propertyName", new CompareResult());
	}

	@Test
	public void testEndBeanResult() throws Exception {
		// compareResultStack not Empty
		List<CompareResult> compareResultStack = new ArrayList<CompareResult>();
		compareResultStack.add(new CompareResult());
		compareResultStack.add(new CompareResult());
		resetCompareResultStack(compareResultStack);

		List<String> propertyNameStack = new LinkedList<String>();
		propertyNameStack.add("test");
		resetPorpertyNameStack(propertyNameStack);
		iscv.endBeanResult("propertyName", new CompareResult());
	}

	@Test
	public void testEndBeanResultEmpty() throws Exception {
		setCompareResultOneValue();

		List<String> propertyNameStack = new LinkedList<String>();
		propertyNameStack.add("test");
		resetPorpertyNameStack(propertyNameStack);
		iscv.endBeanResult("propertyName", new CompareResult());
	}

	@Test
	public void testAcceptProperty() throws Exception {
		List<CompareResult> compareResultStack = new ArrayList<CompareResult>();
		CompareResult cr = new CompareResult();
		cr.setUnmatchedProperties(new HashSet<String>());
		cr.setPropertyValues(new HashMap<String, String[]>());
		compareResultStack.add(cr);
		resetCompareResultStack(compareResultStack);
		iscv.acceptProperty("propertyName");
	}

	@Test
	public void testStartEndCollectionResult() throws Exception {
		Field arrayResultMembersField = SimpleCompareResultVisitor.class
				.getDeclaredField("arrayResultMembers");
		arrayResultMembersField.setAccessible(true);
		CompareResult[] crs = new CompareResult[] { new CompareResult() };
		iscv.startCollectionResult("propertyName", crs);
		Set<CompareResult> arrayResultMembers = (Set<CompareResult>) arrayResultMembersField
				.get(iscv);
		assertEquals(crs.length, arrayResultMembers.size());
		
		iscv.endCollectionResult("propertyName",crs);
		assertEquals(0, arrayResultMembers.size());
	}

}
