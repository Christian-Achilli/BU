package com.citi.icg.as.config;

import org.junit.Test;

public class GcasConfigurationErrorTest {

	@Test
	public void testGcasConfigurationError(){
		new GcasConfigurationError("message");
		new GcasConfigurationError("message", new RuntimeException());
	}
}
