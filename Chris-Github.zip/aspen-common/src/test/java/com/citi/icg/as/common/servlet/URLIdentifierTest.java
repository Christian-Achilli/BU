package com.citi.icg.as.common.servlet;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by cd68076 on 23/02/2017.
 */
public class URLIdentifierTest {

    private final String regex = ".*(ASPEN-(\\w*)).*";

    @Test
    public void testNormalFilter() {
        String url = "/AssetServicing/CorporateActions.html";
        boolean isGwtRpcCall = false;
        UrlIdentifier identifier = new UrlIdentifier(regex);
        IndexTuple result = identifier.matchForUrlPattern(url, isGwtRpcCall);

        Assert.assertNull(result);
    }

    @Test
    public void testInvalidEnvironmentFilter() {
        String url = "/AssetServicing/UAT1/CorporateActions.html";
        boolean isGwtRpcCall = false;
        UrlIdentifier identifier = new UrlIdentifier(regex);
        IndexTuple result = identifier.matchForUrlPattern(url, isGwtRpcCall);
        // This should just be handled as a normal filter
        Assert.assertNull(result);
    }

    @Test
    public void testEnvironmentFilter() {
        String url = "/AssetServicing/ASPEN-UAT1/CorporateActions.html";
        boolean isGwtRpcCall = false;
        UrlIdentifier identifier = new UrlIdentifier(regex);
        IndexTuple result = identifier.matchForUrlPattern(url, isGwtRpcCall);

        Assert.assertNotNull(result);
    }
}
