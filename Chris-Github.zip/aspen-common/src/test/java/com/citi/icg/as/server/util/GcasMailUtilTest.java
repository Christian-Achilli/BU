package com.citi.icg.as.server.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.HashMap;
import java.util.logging.Level;

import org.apache.commons.lang.StringUtils;
import org.easymock.EasyMock;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.citi.icg.as.config.BaseDynamicPropertiesTest;
import com.citi.icg.as.config.EmailSupportConfiguration;

@RunWith(PowerMockRunner.class)
@PrepareForTest( {EmailSupportConfiguration.class, GcasMailUtil.class, StringUtils.class} )
public class GcasMailUtilTest extends BaseDynamicPropertiesTest {
	
	@Override
	protected void beforeInternal() {
		EmailSupportConfiguration.createInstance(new HashMap<String,String>());
		System.setProperty("icg.env", "local");		
	}	

	@Test
	public void testNotifySupportStringString() {
		GcasMailUtil.notifySupport(null, null);
	}

	@Test
	public void testNotifySupportStringStringThrowable() {
		GcasMailUtil.notifySupport(null, null, new Exception());
	}

	@Test
	public void testNotifySupportLevelStringString() {
		GcasMailUtil.notifySupport(null, null, "test");
	}

	@Test
	public void testNotifySupportLevelStringStringThrowableBranch1True() {
		GcasMailUtil.notifySupport(null, null, null, new Exception());
	}
	
	@Test
	public void testNotifySupportLevelStringStringThrowableBranch1False() {
		GcasMailUtil.notifySupport(null, null, null, null);
	}
	
	@Test
	public void testNotifySupportLevelStringStringThrowableBranch2True() {
		EmailSupportConfiguration configuration = PowerMock.createMock(EmailSupportConfiguration.class);
		PowerMock.mockStatic(EmailSupportConfiguration.class);
		EasyMock.expect(EmailSupportConfiguration.getInstance()).andReturn(configuration).anyTimes();
		EasyMock.expect(configuration.getSupportEmailDisabled()).andReturn(true).anyTimes();
		EasyMock.expect(configuration.getSupportEmail()).andReturn("test").anyTimes();
		EasyMock.expect(configuration.getApplicationName()).andReturn("test").anyTimes();
		PowerMock.replay(configuration, EmailSupportConfiguration.class);
		GcasMailUtil.notifySupport(null, null, null, new Exception());
	}
	
	@Test
	public void testNotifySupportLevelStringStringThrowableBranch2False() {
		EmailSupportConfiguration configuration = PowerMock.createMock(EmailSupportConfiguration.class);
		PowerMock.mockStatic(EmailSupportConfiguration.class);
		EasyMock.expect(EmailSupportConfiguration.getInstance()).andReturn(configuration).anyTimes();
		PowerMock.mockStaticPartial(GcasMailUtil.class, "sendMail");
		GcasMailUtil.sendMail(EasyMock.isA(String[].class), EasyMock.isA(String.class), EasyMock.isA(String.class), EasyMock.isA(String.class), EasyMock.anyBoolean());
		EasyMock.expectLastCall().anyTimes();
		EasyMock.expect(configuration.getSupportEmailDisabled()).andReturn(false).anyTimes();
		EasyMock.expect(configuration.getSupportEmail()).andReturn("test").anyTimes();
		EasyMock.expect(configuration.getApplicationName()).andReturn("test").anyTimes();
		PowerMock.replay(configuration, EmailSupportConfiguration.class, GcasMailUtil.class);
		GcasMailUtil.notifySupport(null, null, null, new Exception());
	}

	@Test
	public void testAddEnvInSubjectString() {
		GcasMailUtil.addEnvInSubject("test");
	}

	@Test
	public void testAddEnvInSubjectLevelString() {
		String result=GcasMailUtil.addEnvInSubject(Level.INFO, "test");
		assertTrue(result.matches("^CorporateActions:\\[LOCAL:INFO:(.)*\\]\\[null\\]test$"));
//		assertEquals("CorporateActions:[LOCAL:INFO:APACCNSHZJW1954][null]test", GcasMailUtil.addEnvInSubject(Level.INFO, "test"));
	}
	
	@Test
	public void testAddEnvInSubjectLevelStringException() {
		EmailSupportConfiguration configuration = PowerMock.createMock(EmailSupportConfiguration.class);
		PowerMock.mockStatic(EmailSupportConfiguration.class);
		EasyMock.expect(EmailSupportConfiguration.getInstance()).andReturn(configuration).anyTimes();
		EasyMock.expect(configuration.getApplicationName()).andReturn("test").anyTimes();
		PowerMock.mockStatic(StringUtils.class);
		EasyMock.expect(StringUtils.upperCase(EasyMock.isA(String.class))).andThrow(new RuntimeException()).anyTimes();
		PowerMock.replay(StringUtils.class, EmailSupportConfiguration.class, configuration);
		assertEquals("test:[null]test", GcasMailUtil.addEnvInSubject(Level.INFO, "test"));
	}

	@Test
	public void testSendMailStringArrayStringStringStringBooleanFileException() {
		GcasMailUtil.sendMail(new String[] {"a@a.com"}, "b@b.com", "ccc", "test", false, null);
	}
	
	@Test
	public void testSendMailStringArrayStringStringStringBooleanFileNullHost() {
		EmailSupportConfiguration configuration = PowerMock.createMock(EmailSupportConfiguration.class);
		PowerMock.mockStatic(EmailSupportConfiguration.class);
		EasyMock.expect(EmailSupportConfiguration.getInstance()).andReturn(configuration).anyTimes();
		EasyMock.expect(configuration.getEmailServer()).andReturn(null).anyTimes();
		PowerMock.replay(EmailSupportConfiguration.class, configuration);
		GcasMailUtil.sendMail(new String[] {"a@a.com"}, "b@b.com", "ccc", "test", false, null);
	}
	
	@Test
	public void testSendMailStringArrayStringStringStringBooleanFileHtmlTrue() {
		GcasMailUtil.sendMail(new String[] {"a@a.com"}, "b@b.com", "ccc", "test", true, null);
	}
	
	@Test
	public void testSendMailStringArrayStringStringStringBooleanFile() {
		GcasMailUtil.sendMail(new String[] {"a@a.com"}, "b@b.com", "ccc", "test", true, new File("test.xml"));
	}
	
	@Test
	public void testSendMailStringArrayStringStringStringBooleanFileMessageNull() {
		GcasMailUtil.sendMail(new String[] {"a@a.com"}, "b@b.com", "ccc", null, true, new File("test.xml"));
	}
	
	@Test
	public void testRemaining()
	{
		EmailSupportConfiguration configuration = PowerMock.createMock(EmailSupportConfiguration.class);
		PowerMock.mockStatic(EmailSupportConfiguration.class);
		EasyMock.expect(EmailSupportConfiguration.getInstance()).andReturn(configuration).anyTimes();
		EasyMock.expect(configuration.getEmailServer()).andReturn(null).anyTimes();
		EasyMock.expect(configuration.getSupportEmail()).andReturn(null).anyTimes();
		PowerMock.replay(EmailSupportConfiguration.class, configuration);
		GcasMailUtil.sendMailFromSupport(new String[]{}, null, null, false);
		GcasMailUtil.sendMailFromSupport(new String[]{}, null, null, null);
		GcasMailUtil.sendMail(new String[]{}, null, null, null);
		GcasMailUtil.sendMail(new String[]{}, null, null, null, false);
	}

	@Test
	public void testSoeIdToEmail() {
		assertEquals("000@imcnam.ssmb.com", GcasMailUtil.soeIdToEmail("000"));
	}



}
