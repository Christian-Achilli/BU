package com.citi;

/**
 * Created by ca85137 on 25/05/2016.
 *
 * This is used to mark unit tests that are specifics for the Custody stream.
 *
 */
public interface CustodySpecificTest {
}
