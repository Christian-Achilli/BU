package com.citi.icg.as.client.enums;

import java.util.LinkedHashMap;
import java.util.Map;

public enum DateCode {
	ONGO("On-Going"), UKWN("Unknown");

	private String displayName;

	private DateCode(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String toString() {
		return displayName;
	}

	public static Map<String, String> getValueMap() {
		Map<String, String> valueMap = new LinkedHashMap<String, String>();
		for (DateCode value : DateCode.values()) {
			valueMap.put(value.name(), value.getDisplayName());
		}
		return valueMap;
	}
}
