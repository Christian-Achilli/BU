package com.citi.icg.as.server.rest;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

/**
 * 
 * @author ap72338
 *
 */

@Configuration
public class RestfulServiceConfiguration extends WebMvcConfigurationSupport {

	private static final String DEFAULT_DATE_FORMAT_FOR_SERIALIZATION = "yyyy-MM-dd HH:mm:ss";
	
	@Override
	protected void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
		for (HttpMessageConverter<?> httpMessageConverter : converters) {
			if (httpMessageConverter instanceof AbstractJackson2HttpMessageConverter) {
				AbstractJackson2HttpMessageConverter jacksonConverter = (AbstractJackson2HttpMessageConverter) httpMessageConverter;

				jacksonConverter.getObjectMapper().configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
						.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true)						
						.setDateFormat(new SimpleDateFormat(DEFAULT_DATE_FORMAT_FOR_SERIALIZATION));
				if(!(jacksonConverter.getObjectMapper() instanceof XmlMapper)){
					jacksonConverter.getObjectMapper().configure(SerializationFeature.INDENT_OUTPUT,true);
				}
			}
		}
	}
	 
}
