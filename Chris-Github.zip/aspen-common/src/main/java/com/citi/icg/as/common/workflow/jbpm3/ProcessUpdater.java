package com.citi.icg.as.common.workflow.jbpm3;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public interface ProcessUpdater {

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	void updateProcessDefiniton();

}