package com.citi.icg.as.core.entities.constants;


public class UserConstant {
	public static final String SOE_ID = "soeId";
	public static final String DEBUG_STRING = "debugString";
	public static final String CLASS = "class";
	public static final String EMAIL_ADDRESS = "emailAddress";
	public static final String SYSTEM_USER = "systemUser";
	public static final String USER_NAME_FIRST = "userNameFirst";
	public static final String SYSTEM = "system";
	public static final String USER_ROLES = "userRoles";
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String USER_GROUP = "userGroup";
	public static final String USER_ID = "userId";
	public static final String VALUE = "value";
	public static final String ACTIVE_IND = "activeInd";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
	public static final String USER_ATTRIBUTES = "userAttributes";
	public static final String USER_NAME_LAST = "userNameLast";
}