package com.citi.icg.as.server.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.MDC;

import com.citi.icg.as.common.client.exception.EntitlementException;
import com.citi.icg.as.server.GcasRequestContext;
import com.citi.icg.as.server.util.ExceptionUtil;
import com.citi.icg.toolkit.web.client.IcgGwtUIException;
import com.google.gwt.user.client.rpc.IncompatibleRemoteServiceException;
import com.google.gwt.user.client.rpc.SerializationException;
import com.google.gwt.user.server.rpc.RPC;
import com.google.gwt.user.server.rpc.RPCRequest;
import com.google.gwt.user.server.rpc.RPCServletUtils;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.google.gwt.user.server.rpc.UnexpectedException;

public class BaseRemoteServletService extends RemoteServiceServlet {
	private static final long serialVersionUID = -8078221222446874063L;
	private static final Log LOG = LogFactory.getLog(BaseRemoteServletService.class);

	@Override
	protected void doUnexpectedFailure(Throwable e) {
		LOG.error(e);
		try {
			Throwable cause = e instanceof UnexpectedException ? e.getCause()
					: e;
			IcgGwtUIException uiException = ExceptionUtil.getUIException(cause);
			MDC.put("caseId", uiException.getTrackingNo());
			String responsePayload = RPC.encodeResponseForFailure(null, uiException);
			RPCServletUtils.writeResponse(getServletContext(),
					getThreadLocalResponse(), responsePayload, true);
		} catch (Exception e1) {
			LOG.error(e);
			super.doUnexpectedFailure(e1);
		}
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// HACK, ugly toolkit code. service() is invoked before GWT's
		// doPost() and does not properly initialize GWT framework.
		synchronized (this) {
			validateThreadLocalData();
			perThreadRequest.set(req);
			perThreadResponse.set(resp);
		}

		long start = System.currentTimeMillis();
		try {
//			RequestContext.set(req);
			GcasRequestContext.set(req);
			super.service(req, resp);

		} finally { 
			perThreadRequest.set(null);
			perThreadResponse.set(null);
//			RequestContext.clear();
			GcasRequestContext.clear();
			LOG.info(String.format("Service completed in %d ms", (System.currentTimeMillis() - start)));
		}
	}
	
	@Override
	public String processCall(String payload) throws SerializationException {
		MDC.remove("user");
		MDC.remove("method");
		MDC.remove("requestId");
		RPCRequest rpcRequest = null;
		try {
			LOG.debug("Unserialization started..." + (payload != null ? payload.length() : 0));
			// Decode request
			rpcRequest = RPC.decodeRequest(payload, this.getClass(), this);

			if (rpcRequest == null) {
				throw new NullPointerException("No rpc request");
			}

			Method method = rpcRequest.getMethod();
			MDC.put("user", GcasRequestContext.getUserId());
			MDC.put("requestId","req#"+GcasRequestContext.getRequestId()+"~");
			if (method != null) {
				MDC.put("method", getClass().getSimpleName() + "#" + method.getName());
			}
			GcasRpcContext.start(GcasRequestContext.getUserId(), this.getClass(), method, rpcRequest.getParameters());
			LOG.info("Starting RPC: " + GcasRpcContext.get());

			LOG.debug("Unserialization ended, Request User " + GcasRequestContext.getUserId());
			LOG.debug("Citi Velocity Request ID " + GcasRequestContext.getRequestId());
			LOG.debug("Method for permission started " + method.getName());

			EntitlementChecker.isAllowed(getEntitlement(), method.getName(), rpcRequest.getParameters(), method.getParameterTypes());
			Object returnValue = rpcRequest.getMethod().invoke(this, rpcRequest.getParameters());
			LOG.debug("Method actual end " + method.getName());

			LOG.debug("Serialization Started ");
			// Encode response
			String returnString = RPC.encodeResponseForSuccess(rpcRequest.getMethod(), returnValue, rpcRequest.getSerializationPolicy());
			LOG.debug("Serialization End  " + (returnString != null ? returnString.length() : 0));
			return returnString;
		} catch (IllegalArgumentException e) {
			GcasRpcContext.get().setFailed(true);
			LOG.error("RPC Failed. " + GcasRpcContext.get(), e);
			throw e;
		} catch (IllegalAccessException e) {
			GcasRpcContext.get().setFailed(true);
			LOG.error("RPC Failed. " + GcasRpcContext.get(), e);
			throw ExceptionUtil.wrapInRuntimeException(e);
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			GcasRpcContext.get().setFailed(true);
			Throwable cause = (Throwable) (e.getCause());
			// log only exception message. If the exception is unexpected (not a
			// checked
			// execption between client) the complete stack will be logged in
			// doUnexpected
			// and caseId generated.
			LOG.error("RPC Failed. " + GcasRpcContext.get() + "\n" + cause.getMessage());
			return RPC.encodeResponseForFailure(rpcRequest.getMethod(), cause, rpcRequest.getSerializationPolicy());
		} catch (IncompatibleRemoteServiceException e) {
			GcasRpcContext.get().setFailed(true);
			LOG.error("RPC Failed. " + GcasRpcContext.get(), e);
			return RPC.encodeResponseForFailure(null, e, rpcRequest.getSerializationPolicy());
		} catch (EntitlementException e) {
			LOG.error("RPC Failed. " + GcasRpcContext.get(), e);
			// don't setFailed()
			throw e;
		} catch (RuntimeException e) {
			LOG.error("RPC Failed. " + GcasRpcContext.get(), e);
			GcasRpcContext.get().setFailed(true);
			throw e;
		} finally {
			GcasRpcContext.finish();
		}
	}

	public Object getEntitlement() {
		return null;
	}

	private void validateThreadLocalData() {
		if (perThreadRequest == null) {
			perThreadRequest = new ThreadLocal<HttpServletRequest>();
		}
		if (perThreadResponse == null) {
			perThreadResponse = new ThreadLocal<HttpServletResponse>();
		}
	}
	
	public void declareException() throws IcgGwtUIException {
		
	}
}
