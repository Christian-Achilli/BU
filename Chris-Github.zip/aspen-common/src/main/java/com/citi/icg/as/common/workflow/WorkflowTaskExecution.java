package com.citi.icg.as.common.workflow;

import java.util.Arrays;


/**
 * JPBM task. 
 *
 */
public class WorkflowTaskExecution implements TaskExecution 
{

	private Long id;
	
	private String user;
		
	private String[] users;
	
	private State state;
	
	private String taskName;
	
	private boolean open;
	
	public boolean isOpen() {
		return open;
	}
		
	public WorkflowTaskExecution(Long id, String user, State state, String taskName, boolean open)
	{
		this.id = id;
		this.user = user;
		this.state = state;
		this.taskName = taskName;
		this.open = open;
	}
	
	public WorkflowTaskExecution(Long id, String[] users, State state, String taskName, boolean open)
	{
		this.id = id;
		this.users = users.clone();
		this.state = state;
		this.taskName = taskName;
		this.open = open;
	}

	public Long getId() {
		return id;
	}

	public String getUser() {
		return user;
	}

	public String[] getUsers() {
		return users.clone();
	}

	public State getState() {
		return state;
	}

	public String getTaskName()
	{
		return taskName;
	}

	@Override
	public String toString()
	{
		//CHECKSTYLE:OFF
		return "JbpmTaskExecution [id=" + id + ", state=" + state + ", taskName=" + taskName + ", user=" + user + ", users="
				+ Arrays.toString(users) + "]";
		//CHECKSTYLE:ON
	}
		
}
