package com.citi.icg.as.core.dao.entities.ext.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is entity class for FX_RATE table.
 * 
 * @author vg89846
 *
 */
@Entity
@Table(name = "FX_RATE")
public class FXRateDomain implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long pkFxRateId;
	private Date fxRateDate;
	private String rateType;
	private Long termCcy;
	private Long baseCcy;
	private String tenor;
	private BigDecimal fxRateBid;
	private BigDecimal fxRateAsk;
	private BigDecimal fxRateMid;
	private String instrumentLabel;
	
	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_FX_RATE", allocationSize = 1)
	@Column(name = "PK_FX_RATE_ID", unique = true, nullable = false)
	public Long getPkFxRateId() {
		return pkFxRateId;
	}

	public void setPkFxRateId(Long pkFxRateId) {
		this.pkFxRateId = pkFxRateId;
	}

	@Column(name = "FX_RATE_DATE")
	public Date getFxRateDate() {
		return fxRateDate;
	}

	public void setFxRateDate(Date fxRateDate) {
		this.fxRateDate = fxRateDate;
	}

	@Column(name = "RATE_TYPE")
	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	@Column(name = "FK_TERM_CCY")
	public Long getTermCcy() {
		return termCcy;
	}

	public void setTermCcy(Long termCcy) {
		this.termCcy = termCcy;
	}

	@Column(name = "FK_BASE_CCY")
	public Long getBaseCcy() {
		return baseCcy;
	}

	public void setBaseCcy(Long baseCcy) {
		this.baseCcy = baseCcy;
	}

	@Column(name = "TENOR")
	public String getTenor() {
		return tenor;
	}

	public void setTenor(String tenor) {
		this.tenor = tenor;
	}

	@Column(name = "FX_RATE_BID")
	public BigDecimal getFxRateBid() {
		return fxRateBid;
	}

	public void setFxRateBid(BigDecimal fxRateBid) {
		this.fxRateBid = fxRateBid;
	}

	@Column(name = "FX_RATE_ASK")
	public BigDecimal getFxRateAsk() {
		return fxRateAsk;
	}

	public void setFxRateAsk(BigDecimal fxRateAsk) {
		this.fxRateAsk = fxRateAsk;
	}

	@Column(name = "FX_RATE_MID")
	public BigDecimal getFxRateMid() {
		return fxRateMid;
	}

	public void setFxRateMid(BigDecimal fxRateMid) {
		this.fxRateMid = fxRateMid;
	}

	@Column(name = "INSTRUMENT_LABEL")
	public String getInstrumentLabel() {
		return instrumentLabel;
	}

	public void setInstrumentLabel(String instrumentLabel) {
		this.instrumentLabel = instrumentLabel;
	}

}
