package com.citi.icg.as.common.dao.impl;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.FetchMode;
import org.hibernate.FlushMode;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.type.Type;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;
import com.citi.icg.as.common.converter.Converter;
import com.citi.icg.as.common.converter.EntityConverter;
import com.citi.icg.as.common.dao.HibernateInteraction;
import com.citi.icg.as.common.util.CommonUtil;
import com.citi.icg.as.dao.DaoConstants;
import com.citi.icg.as.server.util.GcasConstants;

/**
 * Helper class for generic DAO queries. All of the operations are provided in HibernateTemplate.
 * 
 * @author am48050
 * 
 * @param <T>
 *            Domain object instance.
 * @param <I>
 *            Primary key type.
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public class HbmGenericTemplate extends HibernateTemplate {

	private static Log log = LogFactory.getLog(HbmGenericTemplate.class);

	private static final String AUDIT_TABLES = "AEventWorkflowAttributes,AAccount";
	
	private SessionFactory sessionFactory;

	@Override
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}

	public <T> T findSingleByExample(final T example) {
		return super.execute(new HibernateCallback<T>() {
			public T doInHibernate(Session session) {
				List<T> objects = (List<T>) getListByExample(example, null);
				if (objects != null && objects.size() > 0) {
					if (objects.size() == 1) {
						return objects.get(0);
					} else {
						throw new RuntimeException("Query returned more than 1 row.");
					}
				}
				return null;
			}
		});

	}

	public <T> T findSingleByCriteria(Class<T> returnClassType, DetachedCriteria criteria) {
		List<T> list = findByCriteria(returnClassType, criteria);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public <T> T findSingleByCriteria(Class<T> returnClassType, Criteria criteria) {
		List<T> list = findByCriteria(returnClassType, criteria);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public <T> T findUniqueByCriteria(Class<T> returnClassType, DetachedCriteria criteria) {
		List<T> list = findByCriteria(returnClassType, criteria);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public <T> List<T> findByCriteria(final Class<T> returnClassType, final DetachedCriteria detachedCriteria, final int startRow, final int pageSize) {
		return super.execute(new HibernateCallback<List<T>>() {
			public List<T> doInHibernate(Session session) {
				Criteria criteria = detachedCriteria.getExecutableCriteria(session);
				criteria.setFirstResult(startRow);
				criteria.setMaxResults(pageSize);
				return findByCriteria(returnClassType, criteria);

			}
		});
	}
	public <T> List<T> findByCriteria(final Class<T> returnClassType, final DetachedCriteria criteria) {
		return super.execute(new HibernateCallback<List<T>>() {
			public List<T> doInHibernate(Session session) {
				return findByCriteria(returnClassType, criteria.getExecutableCriteria(session));

			}
		});
	}

	public <T> List<T> findByCriteria(final Class<T> returnClassType, final Criteria criteria) {
		if (returnClassType.getName().contains("com.citi.icg.as.core.dao.entities.business")) {
			Class domClass = getDomainClass(returnClassType);
			Class busClass = getBusinessClass(returnClassType);
			EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
			if (converter == null) {
				return Converter.getDestinationList(criteria.list(), returnClassType);
			}
			List list = criteria.list();
			if (list.size() > 0) {
				return new ArrayList(converter.convertAllFrom(new HashSet(list)));
			}
		}
		return criteria.list();
	}

	public <T> T findUniqueWithEntity(final Class<T> returnType, final String queryString, final List<Object> entities, final Object... objs) {
		List list = findWithEntity(queryString, entities, objs);
		if (list.isEmpty()) {
			return null;
		}

		if (returnType.getName().contains("com.citi.icg.as.core.dao.entities.business")) {
			Class domClass = getDomainClass(returnType);
			Class busClass = getBusinessClass(returnType);
			EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
			return (T) converter.convertFrom(list.get(0));
		} else {
			return (T) list.get(0);
		}
	}

	public <T> T findUniqueWithEntity(final String queryString, final Object... objs) {
		List list = find(queryString, objs);
		if (list == null || list.size() == 0)
			return null;
		return (T) list.get(0);
	}

	public List findEntities(final String queryString, final List<Object> entities, final Object... objs) {
		List result = new ArrayList(0);
		List list = findWithEntity(queryString, entities, objs);
		if (list.isEmpty()) {
			return result;
		}
		for (Object obj : list) {

			if (obj.getClass().getName().contains("com.citi.icg.as.core.dao.entities.ext.beans") || obj.getClass().getName().contains("com.citi.icg.as.core.dao.entities.ext.beans.v2")) {
				Class domClass = getDomainClass(obj.getClass());
				Class busClass = getBusinessClass(obj.getClass());

				EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
				result.add(converter == null ? Converter.getDestinationClass(obj, busClass) : converter.convertFrom(obj));
			} else {
				result.add(obj);
			}
		}
		return result;
	}

	public List findWithEntity(final String queryString, final List<Object> entities, final Object... objs) {
		return super.execute(new HibernateCallback<List>() {
			public List doInHibernate(Session session) {
				Query query = session.createQuery(queryString);
				int i = 0;
				if (entities != null) {
					for (i = 0; i < entities.size(); i++) {
						if (entities.get(i) instanceof BaseBusinessEntity) {

							BaseBusinessEntity busObj = (BaseBusinessEntity) entities.get(i);
							Object domObj = getDomainObject(busObj);
							entities.set(i, domObj);
						}
						query.setEntity(i, entities.get(i));
					}
					i = entities.size();
				}
				if (objs != null) {
					for (int j = 0; j < objs.length; i++, j++) {
						query.setParameter(i, objs[j]);
					}
				}
				List list = query.list();
				return list;
			}
		});
	}

	public <T> List<T> saveOrUpdate(Class<T> clazz, Collection<T> obj) {
		return (List<T>) saveOrUpdate(obj.toArray());
	}

	public <T> T saveOrUpdate(Class<T> clazz, T obj) {
		return (T) saveOrUpdate(new Object[] { obj }).get(0);
	}

	public <T> T saveOrUpdateObject(T obj) {
		return (T) saveOrUpdate(new Object[] { obj }).get(0);
	}

	public List executeSQL(final String query) {
		return super.execute(new HibernateCallback<List>() {
			public List doInHibernate(Session session) {
				SQLQuery sql = session.createSQLQuery(query);
				return sql.list();
			}
		});
	}

	public List executeSQL(final String query, final List<String> params) {
		return super.execute(new HibernateCallback<List>() {
			public List doInHibernate(Session session) {
				SQLQuery sql = session.createSQLQuery(query);
				for(int i = 0; i < params.size(); i++){
					sql.setString(i, params.get(i));
				}
				return sql.list();
			}
		});
	}
	
	public List executeSQL(final String query, final Map<String, ? extends Object> params) {
		return super.execute(new HibernateCallback<List>() {
			public List doInHibernate(Session session) {
				SQLQuery sql = session.createSQLQuery(query);
				sql.setProperties(params);
				return sql.list();
			}
		});
	}

	public <T extends BaseBusinessEntity> List<T> findByExample(T example) {
		return getListByExample(example, null);
	}

	public <T> T getByExample(final T example, final String cacheRegion) {
		List<T> list = getListByExample(example, cacheRegion);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public <T> List<T> getListByExample(final T example, final String cacheRegion) {
		return getListByExample(example, cacheRegion, null);
	}

	public <T> List<T> getListByExample(final T example, final String cacheRegion, final Criterion dcriteria) {
		return super.execute(new HibernateCallback<List<T>>() {
			public List<T> doInHibernate(Session session) {
				Class domClass = getDomainClass(example.getClass());
				Class busClass = getBusinessClass(example.getClass());
				EntityConverter converter = CommonUtil.getConverter(busClass, domClass);

				Object obj = converter == null ? Converter.getDestinationClass(example, domClass) : CommonUtil.getConverter(busClass, domClass).convertTo(example);
				Criteria criteria = session.createCriteria(domClass).add(Example.create(obj));
				if (cacheRegion != null) {
					criteria.setCacheable(true).setCacheRegion(cacheRegion);
				}
				criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
				if (dcriteria != null) {
					criteria.add(dcriteria);
				}
				if (example.getClass().getName().contains("com.citi.icg.as.core.dao.entities.business")) {
					if (converter == null) {
						return Converter.getDestinationList(criteria.list(), example.getClass());
					}
					List list = criteria.list();
					if (list.size() > 0) {
						return new ArrayList(converter.convertAllFrom(new HashSet<BaseBusinessEntity>(list)));
					}

				}
				return criteria.list();

			}
		});
	}

	public <T> void deleteAll(final T... objs) {
		super.execute(new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session) throws HibernateException, SQLException {
				if (objs == null || objs.length == 0) {
					return null;
				}
				for (Object obj : objs) {
					if (obj instanceof BaseBusinessEntity) {
						Object domainObject = null;
						Object idObj = ((BaseBusinessEntity) obj).getId();
						Class domClass = getDomainClass(obj.getClass());
						Type type = getClassMetadata(domClass).getIdentifierType();
						if (type.getName().toLowerCase().contains("long") && idObj instanceof Integer) {
							domainObject = session.get(domClass, ((Integer) idObj).longValue());
						} else {
							domainObject = session.get(domClass, (Serializable) idObj);
						}
						if (domainObject != null) {
							session.delete(domainObject);
						}
					} else {
						session.delete(obj);
					}
				}
				return null;
			}
		});
	}

	public <T> Set<T> save(final T... objArray) {
		Set<T> set = new HashSet<T>(0);
		for (T obj : objArray) {
			set.add((T) saveOne(obj));
		}
		return set;
	}

	public ClassMetadata getClassMetadata(final Class<?> classType) {
		return super.execute(new HibernateCallback<ClassMetadata>() {
			@Override
			public ClassMetadata doInHibernate(Session session) throws HibernateException, SQLException {
				Class domClass = getDomainClass(classType);
				return sessionFactory.getClassMetadata(domClass);

			}
		});
	}

	public void clearSession() {
		sessionFactory.getCurrentSession().clear();
	}

	public <T> T merge(final T object) {

		return super.execute(new HibernateCallback<T>() {
			@Override
			public T doInHibernate(Session session) throws HibernateException, SQLException {
				if (object.getClass().getName().contains("com.citi.icg.as.core.dao.entities.business")) {
					Object bean = getDomainObject(object);
					Object mergedObject = merge(session, bean);
					return (T) getBusinessObject(mergedObject);
				}
				return (T) merge(session, object);
			}
		});

	}

	public void evict(final Object obj) {
		super.execute(new HibernateCallback<Void>() {
			public Void doInHibernate(Session session) {
				if (obj instanceof BaseBusinessEntity)
					session.evict(getDomainObject(obj));
				else
					session.evict(obj);
				return null;
			}
		});
	}

	public <T> List<T> find(final Class<T> returnClassType, final String cacheRegion, final String orderby) {
		return super.execute(new HibernateCallback<List<T>>() {
			public List<T> doInHibernate(Session session) {
				Class domClass = getDomainClass(returnClassType);
				Class busClass = getBusinessClass(returnClassType);
				if (returnClassType.getName().contains("com.citi.icg.as.core.dao.entities.business")) {

					Criteria criteria = session.createCriteria(domClass);
					if (cacheRegion != null) {
						criteria.setCacheable(true).setCacheRegion(cacheRegion);
					}
					if (orderby != null) {
						criteria.addOrder(Order.asc(orderby));
					}
					EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
					if (converter == null) {
						return Converter.getDestinationList(criteria.list(), returnClassType);
					}
					List list = criteria.list();
					if (list.size() > 0) {
						return new ArrayList(converter.convertAllFrom(new HashSet(list)));
					}
					return list;
				} else {
					Criteria criteria = session.createCriteria(domClass);
					if (cacheRegion != null) {
						criteria.setCacheable(true).setCacheRegion(cacheRegion);
					}
					if (orderby != null) {
						criteria.addOrder(Order.asc(orderby));
					}
					return criteria.list();
				}

			}
		});
	}

	public <T> List<T> executeNativeSQLQueryForEntity(final Class<T> entity, final String queryString, final Map<String, Object> params) {
		return super.execute(new HibernateCallback<List<T>>() {
			public List<T> doInHibernate(Session session) {
				session.clear();
				Class domClass = getDomainClass(entity);
				Class busClass = getBusinessClass(entity);
				SQLQuery query = session.createSQLQuery(queryString);
				query.addEntity(getDomainClass(entity));
				// start time
				long time_0 = System.currentTimeMillis();

				EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
				Map destMap = new HashMap(0);
				for (Map.Entry<String, Object> entry : params.entrySet()) {
					// start
					log.debug("Key in entry is: " + entry.getKey() + "Value in entry is: " + entry.getValue());
					if (entry.getValue().getClass().getName().contains("com.citi.icg.as.core.dao.entities.business")) {
						if (converter == null) {
							long time_2 = System.currentTimeMillis();
							destMap = Converter.getDestinationMap(params, getDomainClass(entity));
							long time_3 = System.currentTimeMillis();
							log.debug("Contain bussiness package name and Convert is null costs: " + (time_3 - time_2) + " ms");
						} else {
							long time_4 = System.currentTimeMillis();
							destMap.put(entry.getKey(), converter.convertTo(entry.getValue()));
							long time_5 = System.currentTimeMillis();
							log.debug("Contain bussiness package name and Convert is NOT null costs: " + (time_5 - time_4) + " ms");
						}
					} else {
						long time_6 = System.currentTimeMillis();
						destMap.put(entry.getKey(), entry.getValue());
						long time_7 = System.currentTimeMillis();
						log.debug("NOT Contain bussiness package name costs: " + (time_7 - time_6) + " ms");
					}
					// log.warn("PERFORMANCE_TIMING: HbmGenericTemplate.executeNativeSQLQueryForEntity::one dozer coversion took:(msec)" + (System.currentTimeMillis() - internalCurrentTime));
				}
				long time_8 = System.currentTimeMillis();

				query.setProperties(destMap);
				query.setFlushMode(FlushMode.MANUAL);
				query.setReadOnly(true);
				List list = query.list();

				long time_9 = System.currentTimeMillis();
				log.debug("query list costs: " + (time_9 - time_8) + " ms");

				if (entity.getName().contains("com.citi.icg.as.core.dao.entities.business")) {
					if (converter == null) {
						return Converter.getDestinationList(list, entity);
					}
					if (list.size() > 0) {
						return new ArrayList(converter.convertAllFrom(new HashSet(list)));
					}
				}
				// end time
				long time_1 = System.currentTimeMillis();
				log.debug("Name of entity is: " + entity.getName() + ", Converter is: " + converter + ", list size is: " + list.size() + ", segment costs: " + (time_1 - time_9) + " ms");
				log.debug("Convert cost totally: " + (time_1 - time_0) + " ms");
				return list;
			}
		});
	}

	public <T> T getByExample(final T example, final String cacheRegion, Criterion criteria) {

		List<T> list = getListByExample(example, cacheRegion, criteria);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;

	}

	public <T> T getById(final Class<T> entityType, final Serializable id) {
		return super.execute(new HibernateCallback<T>() {
			public T doInHibernate(Session session) {
				if (id == null)
					return null;
				Class domClass = getDomainClass(entityType);
				Class busClass = getBusinessClass(entityType);
				Type type = getClassMetadata(domClass).getIdentifierType();
				Object obj = null;
				if (type.getName().toLowerCase().contains("long") && id instanceof Integer) {
					obj = session.get(domClass, ((Integer) id).longValue());
				}  else {
					obj = session.get(domClass, id);
				}
				if (obj == null) {
					return null;
				}
				if (entityType.getName().contains("com.citi.icg.as.core.dao.entities.business")) {
					EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
					if (converter == null) {
						return Converter.getDestinationClass(obj, entityType);
					}
					return (T) converter.convertFrom(obj);
				}
				return (T) obj;
			}
		});
	}

	public <T> T persistObject(final T obj) {
		return super.execute(new HibernateCallback<T>() {
			public T doInHibernate(Session session) {
				Class domClass = getDomainClass(obj.getClass());
				Class busClass = getBusinessClass(obj.getClass());
				EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
				Object domObj = converter == null ? Converter.getDestinationClass(obj, domClass) : converter.convertTo(obj);
				session.persist(domObj);
				if (obj.getClass().getName().contains("com.citi.icg.as.core.dao.entities.business")) {
					if (converter == null) {
						return (T) Converter.getDestinationClass(domObj, obj.getClass());
					}
					return (T) converter.convertFrom(domObj);
				}
				return (T) domObj;
			}
		});
	}

	public <T> List<T> saveOrUpdate(final T... objs) {
		return super.execute(new HibernateCallback<List<T>>() {
			public List<T> doInHibernate(Session session) {
				// session.clear();
				List<T> savedObj = new ArrayList<T>(0);
				for (T obj : objs) {

					if (obj instanceof BaseBusinessEntity) {
						Class domClass = getDomainClass(obj.getClass());
						Class busClass = getBusinessClass(obj.getClass());
						EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
						Object domObj = converter == null ? Converter.getDestinationClass(obj, domClass) : converter.convertTo(obj);
						// session.saveOrUpdate(domObj);

						Object idObj = ((BaseBusinessEntity) obj).getId();
						if ((idObj instanceof Integer && (Integer) idObj > 0) || (idObj instanceof Long && (Long) idObj > 0) || (idObj instanceof String && idObj != null)) {
							domObj = merge(session, domObj);
						} else {
							session.save(domObj);
							domObj = merge(session, domObj);
							savedObj.add((T) getBusinessObject(domObj));
							continue;
						}

						if (converter == null) {
							savedObj.add((T) Converter.getDestinationClass(domObj, obj.getClass()));
						} else
							savedObj.add((T) converter.convertFrom(domObj));
					} else {

						if (getBusinessClass(obj.getClass()).getName().contains(".business.")) {
							Object idObj = null;
							try {
								idObj = ((BaseBusinessEntity) getBusinessObject(obj)).getId();
								if ((idObj instanceof Integer && (Integer) idObj > 0) || (idObj instanceof Long && (Long) idObj > 0) || (idObj instanceof String)) {
									obj = (T) merge(session, obj);
									savedObj.add((T) obj);
									continue;
								}
							} catch (RuntimeException ex) {
								if (ex == null || ex.getMessage() == null || !ex.getMessage().toLowerCase().contains("must have a primary key")) {
									throw ex;
								}
							}
						}
						session.saveOrUpdate(obj);
						savedObj.add((T) obj);
					}
				}
				return savedObj;
			}
		});
	}

	public <T> List<T> update(final T... objs) {

		return super.execute(new HibernateCallback<List<T>>() {
			public List<T> doInHibernate(Session session) {
				session.clear();
				List<T> savedObj = new ArrayList<T>(0);
				for (T obj : objs) {
					if (obj instanceof BaseBusinessEntity) {
						Class domClass = getDomainClass(obj.getClass());
						Class busClass = getBusinessClass(obj.getClass());
						EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
						Object domObj = converter == null ? Converter.getDestinationClass(obj, domClass) : converter.convertTo(obj);
						session.update(domObj);
						if (converter == null) {
							savedObj.add((T) Converter.getDestinationClass(domObj, obj.getClass()));
						} else
							savedObj.add((T) converter.convertFrom(domObj));
					} else {
						session.update(obj);
						savedObj.add((T) obj);
					}
				}
				return savedObj;
			}
		});
	}

	public <T> void assignIdProperty(Object domainObject, BaseBusinessEntity obj) {
		try {
			String idProperty = getClassMetadata(domainObject.getClass()).getIdentifierPropertyName();
			BeanUtils.setProperty(obj, idProperty, BeanUtils.getProperty(domainObject, idProperty));
		} catch (Exception e) {
		}

	}

	public <T> Serializable saveOne(final T obj) {
		Serializable id = super.execute(new HibernateCallback<Serializable>() {
			public Serializable doInHibernate(Session session) {
				Serializable ret = 0;
				if (obj instanceof BaseBusinessEntity) {
					BaseBusinessEntity busObj = (BaseBusinessEntity) obj;
					Object domainObject = getDomainObject(busObj);
					ret = session.save(domainObject);
					assignIdProperty(domainObject, (BaseBusinessEntity) obj);
				} else {
					ret = session.save(obj);
				}
				return ret;
			}
		});
		return id;
	}

	@Override
	public List find(final String queryString, final Object... objs) {
		return findEntities(queryString, null, objs);
	}

	@Override
	public List find(final String queryString, final Object obj) {
		return findEntities(queryString, null, obj);
	}

	public Class getDomainClass(Class objClass) {
		try {
			Class domClass = null;
			if (objClass != null && (objClass.getName().contains("com.citi.icg.as.core.dao.entities.ext.beans.v2.") || objClass.getName().contains("com.citi.icg.as.core.dao.entities.ext.beans"))){
				return objClass;
			}
			if (objClass !=null && Arrays.asList(AUDIT_TABLES.split(GcasConstants.COMMA)).contains(getClassName(objClass))) {
				domClass = Class.forName("com.citi.icg.as.core.dao.entities.audit." + getClassName(objClass));
			} else if(objClass !=null && !(Arrays.asList(AUDIT_TABLES.split(GcasConstants.COMMA)).contains(getClassName(objClass)))){
				domClass = Class.forName("com.citi.icg.as.core.dao.entities.ext.beans." + getClassName(objClass));
			}
			/*if (domClass == null) {
				return objClass;
			}*/
			return domClass;
		} catch (ClassNotFoundException e) {
			try {
				// Forcefully Sending the older model Object in case Class
				// doesn't exists in new data model
				objClass = Class.forName("com.citi.icg.as.core.dao.entities.ext.beans." + getClassName(objClass));
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
		}

		return objClass;
	}

	public Class getBusinessClass(Class objClass) {
		try {
			Class busClass = Class.forName("com.citi.icg.as.core.dao.entities.business." + getClassName(objClass));
			/*if (busClass == null)
				return objClass;*/
			return busClass;
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}

	}

	public String getClassName(Class objClass) {
		String fullClassName = objClass.getName();
		String className = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
		return className;
	}

	public <T> Object getDomainObject(T object) {
		Object bean = null;
		if (object == null || !object.getClass().getName().contains(".business."))
			return object;

		Class busClass = getBusinessClass(object.getClass());
		Class domClass = getDomainClass(object.getClass());
		EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
		bean = converter == null ? Converter.getDestinationClass(object, domClass) : converter.convertTo(object);
		return bean;

	}

	public <T extends Object> BaseBusinessEntity getBusinessObject(T object) {
		BaseBusinessEntity bean = null;

		if (object instanceof BaseBusinessEntity)
			return (BaseBusinessEntity) object;

		Class busClass = getBusinessClass(object.getClass());
		Class domClass = getDomainClass(object.getClass());
		EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
		bean = (BaseBusinessEntity) (converter == null ? Converter.getDestinationClass(object, busClass) : converter.convertFrom(object));
		return bean;

	}

	public Integer executeUpdateSQL(final String query, final Map<String, ? extends Object> params) {
		return super.execute(new HibernateCallback<Integer>() {
			public Integer doInHibernate(Session session) {
				SQLQuery sql = session.createSQLQuery(query);
				sql.setProperties(params);
				sql.setFlushMode(FlushMode.MANUAL);
				return sql.executeUpdate();
			}
		});
	}

	/**
	 * Returns Business or Domain Collection object that is converted based on the input If Business list is given and return class is expected as Domain, then domain collection is returned similarly
	 * vice-versa
	 * 
	 * @param <T>
	 * @param clazz
	 * @param list
	 * @return
	 */
	public <T> List<T> getEntityCollection(Class<T> clazz, Collection collection) {
		Class domClass = getDomainClass(clazz);
		Class busClass = getBusinessClass(clazz);
		if (collection == null){
			return new ArrayList<T>();
		}
		EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
		if (converter == null) {
			return Converter.getDestinationList(new ArrayList(collection), clazz);
		}
		if (collection.size() > 0) {
			if (clazz.getName().contains(".business.")) {
				return new ArrayList(converter.convertAllFrom(new HashSet(collection)));
			} else {
				return new ArrayList(converter.convertAllTo(new HashSet(collection)));
			}
		}
		return null;
	}

	public List getProjectionCriteriaList(final Class entityClass, final Map<String, FetchMode> joinMap, final Map<String, String> aliasMap, final Map<String, Object> eqRestrMap,
			final Map<String, Object> neRestrMap, final Map<String, Object[]> inMap, final Boolean distinctFlag, final String orderBy, final String orderByKey,
			final Map<String, DetachedCriteria> selfJoinMap, final String... projections) {
		return super.execute(new HibernateCallback<List>() {
			public List doInHibernate(Session session) {
				Criteria criteria = session.createCriteria(entityClass, DaoConstants.MAIN);
				if (orderByKey != null) {
					if (orderBy == null || orderBy.equalsIgnoreCase("asc")) {
						criteria.addOrder(Order.asc(orderByKey));
					} else {
						criteria.addOrder(Order.desc(orderByKey));
					}
				}
				if (joinMap != null) {
					for (Map.Entry<String, FetchMode> joinMapEntry: joinMap.entrySet()) {
						criteria.setFetchMode(joinMapEntry.getKey(), joinMapEntry.getValue());
					}
				}
				ProjectionList list = Projections.projectionList();
				for (String obj : projections) {
					if (distinctFlag) {
						list.add(Projections.distinct(Projections.property(obj)));
					} else {
						list.add(Projections.property(obj));
					}
				}
				criteria.setProjection(list);
				if (aliasMap != null) {
					for (Map.Entry<String, String> aliasMapEntry : aliasMap.entrySet()) {
						criteria.createAlias(aliasMapEntry.getKey(), aliasMapEntry.getValue());
					}
				}
				if (eqRestrMap != null) {
					for (Map.Entry<String, Object> eqRestrMapEntry : eqRestrMap.entrySet()) {
						criteria.add(Restrictions.eq(eqRestrMapEntry.getKey(), eqRestrMapEntry.getValue()));
					}
				}
				if (neRestrMap != null) {
					for (Map.Entry<String, Object> neRestrMapEntry: neRestrMap.entrySet()) {
						criteria.add(Restrictions.ne(neRestrMapEntry.getKey(), neRestrMapEntry.getValue()));
					}
				}
				if (inMap != null) {
					for (Map.Entry<String, Object[]> inMapEntry: inMap.entrySet()) {
						criteria.add(Restrictions.in(inMapEntry.getKey(), inMapEntry.getValue()));
					}
				}
				if (selfJoinMap != null) {
					for (Map.Entry<String, DetachedCriteria>  selfJoinMapEntry: selfJoinMap.entrySet()) {
						criteria.add(Property.forName(selfJoinMapEntry.getKey()).in(selfJoinMap.get(selfJoinMapEntry.getValue())));
					}
				}
				return criteria.list();
			}
		});

	}

	/**
	 * Application Hibernate Callback.
	 * 
	 */
	private static class HbmHibernateCallback<T> implements HibernateCallback<T> {
		private HibernateInteraction<T> dbInteraction;

		HbmHibernateCallback(HibernateInteraction<T> dbInteraction) {
			this.dbInteraction = dbInteraction;
		}

		public T doInHibernate(Session session) {
			try {
				return dbInteraction.execute();
			} catch (RuntimeException re) {
				throw re;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}

	protected <T> T merge(Session session, T entity) {
		// check if entity contains version
		ClassMetadata cmd = session.getSessionFactory().getClassMetadata(entity.getClass());
		boolean containsVersion = cmd.getVersion(entity, EntityMode.POJO) != null;

		T ret = (T) session.merge(entity);
		setBlobValueAfterMerge(ret, entity);
		if (containsVersion)
			session.flush();
		return ret;

	}

	private <T> void setBlobValueAfterMerge(T target, T entity) {
		for (Field field : target.getClass().getDeclaredFields()) {
			if (field.getType().equals(Blob.class)) {
				try {
					field.setAccessible(true);
					if (field.get(entity) != null) {
						field.set(target, Hibernate.createBlob(((Blob) field.get(entity)).getBinaryStream()));
					} else {
						field.set(target, null);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public <T> T executeTransaction(final HibernateInteraction<T> dbInteraction) {
		T value = execute(new HbmHibernateCallback<T>(dbInteraction));
		return value;
	}

	public <T> List<T> executeNativeQuery(final Class<T> returnClassType, Query query) {
		if (returnClassType.getName().contains("com.citi.icg.as.core.dao.entities.business")) {
			Class domClass = getDomainClass(returnClassType);
			Class busClass = getBusinessClass(returnClassType);
			EntityConverter converter = CommonUtil.getConverter(busClass, domClass);
			if (converter == null) {
				return Converter.getDestinationList(query.list(), returnClassType);
			}
			List list = query.list();
			if (list.size() > 0) {
				return new ArrayList(converter.convertAllFrom(new HashSet(list)));
			}
		}
		return query.list();
	}
}
