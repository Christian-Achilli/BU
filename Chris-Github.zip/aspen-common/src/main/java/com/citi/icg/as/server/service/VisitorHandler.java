package com.citi.icg.as.server.service;

import com.citi.icg.as.hessian.ResultWrapper;

public interface VisitorHandler {

	<T> T execute(Class<?> caller, ServiceVisitor<T> callBack);
	
	<T> T execute(Object caller, ServiceVisitor<T> callBack);

	/**
	 * Will invoke the callback's execute and return the Result wrapper even in case of exception in execution of callback
	 * @param caller
	 * @param callBack
	 * @return
	 */
	<T> ResultWrapper<T> executeSilently(Object caller, ServiceVisitor<ResultWrapper<T>> callBack);
}