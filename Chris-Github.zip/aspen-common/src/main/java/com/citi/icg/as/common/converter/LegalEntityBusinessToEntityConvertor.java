/**
 * 
 */
package com.citi.icg.as.common.converter;

import org.springframework.core.convert.converter.Converter;

import com.citi.icg.as.core.dao.entities.ext.beans.LegalEntity;

/**
 * @author sk21695
 *
 */
public class LegalEntityBusinessToEntityConvertor implements Converter<com.citi.icg.as.core.dao.entities.business.LegalEntity, LegalEntity>{

	@Override
	public LegalEntity convert(com.citi.icg.as.core.dao.entities.business.LegalEntity source) {

		LegalEntity target = new LegalEntity();
		target.setPkLegalEntityId(source.getPkLegalEntityId());
		target.setLastUpdatedBy(source.getLastUpdatedBy());
		target.setLastUpdatedDate(source.getLastUpdatedDate());
		target.setLegalEntityCode(source.getLegalEntityCode());
		target.setLegalEntityName(source.getLegalEntityName());
		target.setAliasName(source.getAliasName());
		target.setCairoFilterFlag(source.getCairoFilterFlag());
		target.setOnOffShore(source.getOnOffShore());
		target.setWithholdingAgentRole(source.getWithholdingAgentRole());
		target.setEntityLocationCountry(source.getEntityLocationCountry());
		target.setSwtEligibility(source.getSwtEligibility());

		return target;
	}

}
