package com.citi.icg.as.common.client.entities;

import java.io.Serializable;

import com.citi.icg.toolkit.web.client.grid.dataobjects.TransferObject;

//TODO: need to remove interface TransferObject after icg-toolkit retire
public interface BusinessEntity extends Serializable, TransferObject {

	String getTemporaryKey();

	void setTemporaryKey(String key);

	Serializable getId();
}