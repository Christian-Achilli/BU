/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.citi.icg.as.common.constants.CommonConstants;

/**
 * @author ap72338
 *         <p>
 *         Please see {@link ConditionalEMCAsyncModeEnabled}
 *         </p>
 */
public class OnEMCAsyncModeEnabledCondition implements Condition {

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		String systemConfigurationValue = System.getProperty(CommonConstants.EMC_ASYNC_MODE_ENABLED_PROPERTY, StringUtils.EMPTY);
		return systemConfigurationValue.equalsIgnoreCase(Boolean.TRUE.toString());
	}

}
