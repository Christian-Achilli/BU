package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

@MappedSuperclass
@Table(name = "PRIVILEGE", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BasePrivilege extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 825511140931985513L;

	private int pkPrivilegeId;
	private String privilegeName;
	private String resourceType;
	private String privilegeDescription;
	private Character actionType;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public BasePrivilege() {
	}

	public BasePrivilege(String privilegeName, String resourceType, Character actionType, Date lastUpdatedDate) {
		this.privilegeName = privilegeName;
		this.resourceType = resourceType;
		this.actionType = actionType;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BasePrivilege(String privilegeName, String resourceType, String privilegeDescription, Character actionType, String lastUpdatedBy, Date lastUpdatedDate) {
		this.privilegeName = privilegeName;
		this.resourceType = resourceType;
		this.privilegeDescription = privilegeDescription;
		this.actionType = actionType;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_PRIVILEGE", allocationSize = 1)
	@Column(name = "PK_PRIVILEGE_ID", unique = true, nullable = false)
	public int getPkPrivilegeId() {
		return this.pkPrivilegeId;
	}

	public void setPkPrivilegeId(int pkPrivilegeId) {
		this.pkPrivilegeId = pkPrivilegeId;
	}

	@Column(name = "PRIVILEGE_NAME", nullable = false, length = 50)
	public String getPrivilegeName() {
		return this.privilegeName;
	}

	public void setPrivilegeName(String privilegeName) {
		this.privilegeName = privilegeName;
	}

	@Column(name = "RESOURCE_TYPE", nullable = false, length = 50)
	public String getResourceType() {
		return this.resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	@Column(name = "PRIVILEGE_DESCRIPTION", length = 100)
	public String getPrivilegeDescription() {
		return this.privilegeDescription;
	}

	public void setPrivilegeDescription(String privilegeDescription) {
		this.privilegeDescription = privilegeDescription;
	}

	@Column(name = "ACTION_TYPE", nullable = false, length = 1)
	public Character getActionType() {
		return this.actionType;
	}

	public void setActionType(Character actionType) {
		this.actionType = actionType;
	}

	@Column(name = "LAST_UPDATED_BY", length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
