package com.citi.icg.as.common.workflow.jbpm3;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Restrictions;
import org.jbpm.JbpmContext;
import org.jbpm.command.Command;
import org.jbpm.command.CommandService;
import org.jbpm.graph.def.Action;
import org.jbpm.graph.def.Event;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.instantiation.Delegation;
import org.jbpm.taskmgmt.exe.PooledActor;
import org.jbpm.taskmgmt.exe.TaskInstance;

public class CommandServiceCallbackManager implements CallbackManager {

	private CommandService commandService;

	public CommandServiceCallbackManager(CommandService commandService) {
		super();
		this.commandService = commandService;
	}
	
	@SuppressWarnings("unchecked")
	public <T> T executeCallback(final JbpmCallback<T> cb)
	{
		// wrap in command for the command service (lazy)
		Command command = new Command(){

			/**
			 * 
			 */
			private static final long serialVersionUID = 8583350651028901617L;

			@Override
			public Object execute(JbpmContext context) throws Exception {
				return cb.doCallback(context);
			}};
			
		return (T) commandService.execute(command);
		
	}
	
	static class RetrieveDefinitionCallback implements JbpmCallback<ProcessDefinition> {
		String processName;
		public RetrieveDefinitionCallback(String processName) {
			super();
			this.processName = processName;
		}
		@Override
		public ProcessDefinition doCallback(JbpmContext context) {
			Criteria criteria = context.getSession().createCriteria(ProcessDefinition.class);
			criteria.add(Restrictions.eq("name", processName));
			return (ProcessDefinition) criteria.uniqueResult();
		}
		
	}
	
	static class NewProcessCallback implements JbpmCallback<ProcessInstance> {
		String processName;
		String key;
		Map<String, Object> variables;
		public NewProcessCallback(String processName, String key,
				Map<String, Object> variables) {
			super();
			this.processName = processName;
			this.key = key;
			this.variables = variables;
		}
		@Override
		public ProcessInstance doCallback(JbpmContext context) {
			ProcessInstance pi = context.newProcessInstance(processName);
			pi.getContextInstance().createVariable("key", key);
			pi.setKey(key);
			if (variables != null && variables.size() > 0) {
				pi.getContextInstance().addVariables(variables);
			}

			context.save(pi);
			return pi;
		}
		
	}
	
	static class GetProcessCallback implements JbpmCallback<ProcessInstance> {
		String processName;
		String key;
		public GetProcessCallback(String processName, String key) {
			super();
			this.processName = processName;
			this.key = key;
		}
		@Override
		public ProcessInstance doCallback(JbpmContext context) {
			Criteria criteria = context.getSession()
					.createCriteria(ProcessInstance.class);
			criteria.add(Restrictions.eq("key", key));
			criteria.createCriteria("processDefinition").add(
					Restrictions.eq("name", processName));
			criteria.add(Restrictions.isNull("end"));
			return (ProcessInstance) criteria.uniqueResult();
		}
		
	}
	
	static class DeployDefinitionCallback implements JbpmCallback<ProcessDefinition> {

		ProcessDefinition pd;
		
		public DeployDefinitionCallback(ProcessDefinition pd) {
			super();
			this.pd = pd;
		}

		@Override
		public ProcessDefinition doCallback(JbpmContext context) {
			context.deployProcessDefinition(pd);
			return pd;
		}
		
	}
	
	static class SetPooledActorsCallback implements JbpmCallback<Void> 
	{
		
		Set<String> groups; 
		TaskInstance instance;
		
		public SetPooledActorsCallback(Set<String> groups, TaskInstance instance) {
			super();
			this.groups = groups;
			this.instance = instance;
		}

		@SuppressWarnings("unchecked")
		@Override
		public Void doCallback(JbpmContext context) {
			// remove any current actors from the given instance
			if (instance.getPooledActors() != null)
			{
				Set<PooledActor> actors = (Set<PooledActor>) instance.getPooledActors();
				for (PooledActor actor : actors)
				{
					actor.getTaskInstances().remove(instance);
				}
				instance.getPooledActors().clear();
			}

			if (instance.getPooledActors() == null)
			{
				instance.setPooledActors(new HashSet());
			}


			// Get Existing Actors in the database
			List<PooledActor> pooledActors = getPooledActors(groups, context);

			// add existing actors to this instance
			for (PooledActor actor : pooledActors)
			{
				if (groups.remove(actor.getActorId()))
				{
					instance.getPooledActors().add(actor);
					actor.getTaskInstances().add(instance);
				}
			}
			// create new actors for any not already handled
			instance.getPooledActors().addAll(PooledActor.createPool(groups.toArray(new String[0]), null, instance));
			return null;
		}
		
		@SuppressWarnings("unchecked")
		private List<PooledActor> getPooledActors(final Set<String> actors, JbpmContext context) 
		{
			Criteria criteria = context.getSession().createCriteria(PooledActor.class);
			criteria.add(Restrictions.in("actorId", actors));
			criteria.setFetchMode("taskInstances", FetchMode.SELECT);
			return criteria.list();
		}
		
	}
	
	//TODO Unused method for workflow update.
	// Below method should be called only once during the deployment, it attaches the global event handler to the existing process definition.
	static class UpdateDefinitionCallback implements JbpmCallback<Void> {

		public UpdateDefinitionCallback() {
			super();
		}

		@Override
		public Void doCallback(JbpmContext context) {
			Criteria criteria = context.getSessionFactory().getCurrentSession().createCriteria(ProcessDefinition.class);
			boolean isGlobalActionHandlerAssociated=false;
			
			List<ProcessDefinition> processDefinitions= criteria.list();
			for (ProcessDefinition processDefinition : processDefinitions) {
				//logic to check if the actionhandler is already associated, if yes then skip to next processdefinition
				isGlobalActionHandlerAssociated=false;
				List<Action> actionsList = null;
				Event nodeEnter = processDefinition.getEvent(Event.EVENTTYPE_NODE_ENTER);
				if (nodeEnter != null)
				{
					actionsList = nodeEnter.getActions();
					for (Action attachedAction : actionsList) {
						if(attachedAction.getActionDelegation()!=null && attachedAction.getActionDelegation().getClassName().contains("ActionHandlerNodeEnter")){
							isGlobalActionHandlerAssociated=true;
						}
					}
				}
				
				//logic to check if the actionhandler is already associated - ends
				
				if(!isGlobalActionHandlerAssociated)
				{
					
//					WorkflowUtil.attachGlobalEventHandler(processDefinition, processDefinition.getName());				
					context.getSession().save(processDefinition);
					
				}
			}
			
			//clearing the second level cache.
			context.getSessionFactory().evict(ProcessDefinition.class);
			return null;
		}
		
	}
	
	
}
