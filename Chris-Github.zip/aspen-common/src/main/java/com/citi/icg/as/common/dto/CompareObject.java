package com.citi.icg.as.common.dto;

import java.io.Serializable;
import java.util.List;

public class CompareObject implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long puID = -1;
	private long puVersion = -1;
	private List<String> changedPropoertyNames;
	
	public long getPuID() {
		return puID;
	}
	public void setPuID(long puID) {
		this.puID = puID;
	}
	public long getPuVersion() {
		return puVersion;
	}
	public void setPuVersion(long puVersion) {
		this.puVersion = puVersion;
	}
	public List<String> getChangedPropoertyNames() {
		return changedPropoertyNames;
	}
	public void setChangedPropoertyNames(List<String> changedPropoertyNames) {
		this.changedPropoertyNames = changedPropoertyNames;
	}
	
	@Override
	public String toString() {
		return "CompareObject [puID="
				+ puID
				+ ", puVersion="
				+ puVersion
				+ ", "
				+ (changedPropoertyNames != null ? "changedPropoertyNames="
						+ changedPropoertyNames : "") + "]";
	}
	
}
