package com.citi.icg.as.server.service.compare;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.common.client.compare.CompareResult;
import com.citi.icg.as.common.client.compare.CompareResultVisitor;
import com.citi.icg.as.common.client.compare.SimpleCompareResultVisitor;

public class StringDescriptionCompareResultVisitor extends SimpleCompareResultVisitor
{
	private static final long serialVersionUID = -6338340481440236851L;

	protected static final Log LOG = LogFactory
			.getLog(StringDescriptionCompareResultVisitor.class);
	
	private StringBuilder stringBuilder;
	
	public StringDescriptionCompareResultVisitor()
	{
		
	}	
	
	public static void logToDebug(CompareResult compareResult)
	{
		logToDebug(LOG, compareResult);
	}
	
	public static void logToInfo(CompareResult compareResult)
	{
		logToInfo(LOG, compareResult);
	}
	
	public static void logToDebug(Log log, CompareResult compareResult)
	{
		if (log != null && log.isDebugEnabled() && compareResult != null)
		{
			CompareResultVisitor stringBuilder = new StringDescriptionCompareResultVisitor();
			compareResult.visit(stringBuilder);		
			log.debug(stringBuilder.toString());
		}
	}
	
	public static void logToInfo(Log log, CompareResult compareResult)
	{
		if (log != null && log.isInfoEnabled() && compareResult != null)
		{
			CompareResultVisitor stringBuilder = new StringDescriptionCompareResultVisitor();
			compareResult.visit(stringBuilder);		
			log.info(stringBuilder.toString());
		}
	}
	
	@Override
	public void startRootCompareResult()
	{
		stringBuilder = new StringBuilder();
	}

	@Override
	public void acceptCompareResult(String propertyName, CompareResult compareResult)
	{
		stringBuilder.append(getIndent() + "CompareResult<" + getPropertyNamePath() + ">\n");
	}
	
	@Override
	public void acceptProperty(String propertyName, CompareResult parent, boolean isMatched, String[] values)
	{
		String javaPropName = parent.getJavaPropertyNames() == null ? null : parent.getJavaPropertyNames().get(propertyName);
		stringBuilder.append(getIndent());
		stringBuilder.append("  ");
		stringBuilder.append(propertyName).append('(').append(javaPropName).append(')').append('\t');
		stringBuilder.append(values[0]).append(isMatched ? " == " : " != ").append(values[1]);
		stringBuilder.append("\n");
	}

	private String getIndent()
	{
		return StringUtils.leftPad(StringUtils.EMPTY, (getCompareResultStack().size() - 1) * 2);
	}
	
	@Override
	public String toString()
	{
		return stringBuilder.toString();
	}

}
