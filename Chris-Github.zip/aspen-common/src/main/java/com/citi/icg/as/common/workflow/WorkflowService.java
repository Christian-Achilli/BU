package com.citi.icg.as.common.workflow;

import java.util.Set;

import org.jbpm.taskmgmt.exe.TaskInstance;



/**
 * Entry point for all workflow related tasks.
 * @see WorkflowFactory
 */
public interface WorkflowService 
{

	/**
	 * 
	 * This method creates a proxy workflow instance.  The proxy is created from the input object type. The interface methods will 
	 * correspond to the transitions in the workflow.  Therefore, executing a workflow method on the returned object will cause 
	 * the method invocation handler to execute a named transition in the workflow process. 
	 * 
	 * @param <T> Proxy workflow object.
	 * @param objectType Interface stub that equates to a process definition.
	 * @param key Business Key for the workflow instance.
	 * @return Return stub
	 */
	<T extends Workflow> T getProxyWorkflowInstance(Class<T> objectType, WorkflowKey key);
		
	<T extends Workflow> void deployWorkflow(Class<T> objectType);
	
	<T extends Workflow> boolean isProcessInstanceExists(Class<T> objectType, WorkflowKey key);
	
	void setPooledActors(Set<String> groups, TaskInstance instance);
			
}