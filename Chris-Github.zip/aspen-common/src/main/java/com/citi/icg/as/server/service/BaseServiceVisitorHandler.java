package com.citi.icg.as.server.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.hessian.ResultWrapper;

public class BaseServiceVisitorHandler implements VisitorHandler
{
	private static final Log LOG = LogFactory.getLog(BaseServiceVisitorHandler.class);
	@Override
	public <T> T execute(Class<?> caller, ServiceVisitor<T> callBack)
	{
		try
		{
			return callBack.execute();
		}
		catch (Exception t)
		{
			LOG.error(t.getMessage(), t);
			throw new RuntimeException(t);
		}
	}

	@Override
	public <T> T execute(Object caller, ServiceVisitor<T> callBack)
	{
		return execute(caller.getClass(), callBack);
	}
	
	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.citi.icg.as.server.service.VisitorHandler#executeSilently(java.lang.Object, com.citi.icg.as.server.service.ServiceVisitor)
	 */
	@Override
	public <T> ResultWrapper<T> executeSilently(Object caller, ServiceVisitor<ResultWrapper<T>> callBack) {
		ResultWrapper<T> r = null;
		try {
			r = execute(caller.getClass(), callBack);
		} catch (RuntimeException t) {
			// Exception already logged properly from the try block so just passing back the resultWrapper object
			r = new ResultWrapper<T>(null, true, t.getMessage());
		}
		return r;
	}
	


}
