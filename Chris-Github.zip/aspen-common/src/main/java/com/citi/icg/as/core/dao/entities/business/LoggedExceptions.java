package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class LoggedExceptions extends BaseBusinessEntity {
	
	private int pkExceptionId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String isSent;
	private Date sentDate;
	private String toEmail;
	private String source;
	private long caseId;
	private String exceptionName;
	private String exceptionMessage;
	private String exceptionLevel;
	
	
	
	public int getPkExceptionId() {
		return pkExceptionId;
	}



	public void setPkExceptionId(int pkExceptionId) {
		this.pkExceptionId = pkExceptionId;
	}



	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}



	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}



	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}



	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}



	public String getIsSent() {
		return isSent;
	}



	public void setIsSent(String isSent) {
		this.isSent = isSent;
	}



	public Date getSentDate() {
		return sentDate;
	}



	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}



	public String getToEmail() {
		return toEmail;
	}



	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}



	public String getSource() {
		return source;
	}



	public void setSource(String source) {
		this.source = source;
	}



	public long getCaseId() {
		return caseId;
	}



	public void setCaseId(long caseId) {
		this.caseId = caseId;
	}



	public String getExceptionName() {
		return exceptionName;
	}



	public void setExceptionName(String exceptionName) {
		this.exceptionName = exceptionName;
	}



	public String getExceptionMessage() {
		return exceptionMessage;
	}



	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}



	public String getExceptionLevel() {
		return exceptionLevel;
	}



	public void setExceptionLevel(String exceptionLevel) {
		this.exceptionLevel = exceptionLevel;
	}



	@Override
	public Integer getId()
	{
		return getPkExceptionId();
	}

}
