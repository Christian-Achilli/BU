package com.citi.icg.as.common.client.util;

/**
 *
 * @author yy31798
 *
 */
class PdfPrintHandlerIE extends PdfPrintHandler {

	@Override
	public void print(String url) {
		doPrint(url);
	}

	public static native void doPrint(String url) /*-{
		var pw = $wnd.open();
		var pdfObj = pw.document.createElement("object");
		pdfObj.id = "pdfObj";
		pdfObj.classid = "CLSID:CA8A9780-280D-11CF-A24D-444553540000";
		pdfObj.src = url;
		pdfObj.width = "100%";
		pdfObj.height = "100%";
		pw.document.body.appendChild(pdfObj);
		 
		pdfObj.click();
		pdfObj.setActive();
		pdfObj.focus();
		pdfObj.printAll();
  	}-*/;
}
