package com.citi.icg.as.config.reader;

import java.io.InputStream;



public interface ConfigReader<T> {
	
	InputStream getConfigFileStream(Class<T> configurationClass);
	InputStream getConfigFileStream(String configFileName);
	/**
	 * @Description to be override in subClass to get config file name by className;
	 * @param configClass
	 * @return
	 */
	String getConfigName(Class<T> configClass);

}
