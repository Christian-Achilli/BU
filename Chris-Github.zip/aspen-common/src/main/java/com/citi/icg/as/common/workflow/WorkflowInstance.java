package com.citi.icg.as.common.workflow;

import java.util.List;
import java.util.Map;

/**
 * Equals a running instance of a JBPM workflow.
 *
 */
public class WorkflowInstance implements Workflow 
{
	
	private Map<String, Object> variables;
	
	private String processName;
	
	private String key;
			
	private State currentState;
		
	private List<TaskExecution> tasks;	

	public WorkflowInstance(String process, String key)
	{
		this.processName= process;
		this.key = key;
	}
	
	public String getProcessName() {
		return processName;
	}

	public String getKey() {
		return key;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> getVariables()
	{
		return variables;	
	}

	public State getCurrentState() {
		return currentState;
	}

	public void setCurrentState(State currentState) {
		this.currentState = currentState;
	}
	
	public List<TaskExecution> getTasks() {
		return tasks;
	}

	public void setTasks(List<TaskExecution> tasks) {
		this.tasks = tasks;
	}
	
	public void setVariables(Map<String, Object> variables) {
		this.variables = variables;
	}


}
