package com.citi.icg.as.server.service;


public interface ServiceVisitor<T> {

	T execute() throws Exception;
	
}
