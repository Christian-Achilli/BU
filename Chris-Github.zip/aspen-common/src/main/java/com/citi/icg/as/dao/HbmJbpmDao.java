package com.citi.icg.as.dao;

import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.orm.hibernate3.HibernateOperations;


public class HbmJbpmDao implements JbpmDao {

	private HibernateOperations template;
	
	public HbmJbpmDao(HibernateOperations template) {
		this.template = template;
	}
	
	public void setTemplate(HibernateOperations template) {
		this.template = template;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> findByNamedQuery(String querySql, Object... paramaters) {
		String[] paramNames = null;
		if (paramaters != null && paramaters[0] instanceof String[]
				&& ((String[]) paramaters[0]).length == paramaters.length - 1) {
			paramNames = (String[]) paramaters[0];
			paramaters = ArrayUtils.remove(paramaters, 0);
			return (List<Object>) template.findByNamedQueryAndNamedParam(querySql, paramNames,
					paramaters);
		} else {
			return (List<Object>) template.findByNamedQuery(querySql, paramaters);
		}
	}
}
