package com.citi.icg.as.common.client.compare;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.citi.icg.as.common.client.entities.BusinessEntity;
import com.citi.icg.as.common.client.util.StringUtilGwt;
import com.citi.icg.aspenlogger.Loggable;
import com.google.gwt.user.client.rpc.IsSerializable;

/**
 * The derived result of comparing two or more entities.
 */
public class CompareResult implements Serializable, IsSerializable, Loggable {
	public static final String ATOMIC_VALUES_KEY = "__ATOMIC_VALUES__";
	public static final String PROPERTY_PATH_DELIMITER = ".";

	private String name;
	private List<String> allProperties;
	private Set<String> matchedProperties;
	private Set<String> unmatchedProperties;
	private Set<String> manuallyChangedProperties;
	private Map<String, String[]> propertyValues;
	private Map<String, CompareResult[]> arraysResults;
	private Map<String, CompareResult> beanResults;
	private List<BusinessEntity> entities;
	
	private List<String> ids;
	private Map<String, String> javaPropertyNames;
	private String parentUUID = null;

	private boolean rawMessageAddFlag = false;
	// CMOT-27345
	private boolean optionManualUpdateFlag = false;
	private Set<String> optionUUID;
	private List<IsSerializable> serializableEntities;

	public void visitExtractPendingApprovalData(CompareResultVisitor visitor) {
		visitRExtractPendingApprovalData(this, visitor, StringUtilGwt.EMPTY);
	}

	private void visitRExtractPendingApprovalData(
			final CompareResult currentNode,
			final CompareResultVisitor visitor, final String name) {
		visitor.startBeanResult(name, currentNode);
		if (currentNode.getPropertyValues().containsKey(ATOMIC_VALUES_KEY)) {
			// atomic value is special, and is not included all properties
			visitor.acceptProperty(ATOMIC_VALUES_KEY);
		}
		for (String property : currentNode.getAllProperties()) {
			if (currentNode.isBeanProperty(property)) {
				// do nothing
			} else if (currentNode.isArrayProperty(property)) {
				CompareResult[] nextToVisit = currentNode.getArraysResults()
						.get(property);

				visitor.startCollectionResult(property, nextToVisit);
				for (CompareResult r : nextToVisit) {
					visitRExtractPendingApprovalData(r, visitor, property);
				}
				visitor.endCollectionResult(property, nextToVisit);
			} else {
				visitor.acceptProperty(property);
			}
		}
		visitor.endBeanResult(name, currentNode);
	}

	public void visit(CompareResultVisitor visitor) {
		visitR(this, visitor, StringUtilGwt.EMPTY);
	}

	private void visitR(final CompareResult currentNode,
			final CompareResultVisitor visitor, final String name) {
		visitor.startBeanResult(name, currentNode);
		if (currentNode.getPropertyValues().containsKey(ATOMIC_VALUES_KEY)) {
			// atomic value is special, and is not included all properties
			visitor.acceptProperty(ATOMIC_VALUES_KEY);
		}
		for (String property : currentNode.getAllProperties()) {
			if (currentNode.isBeanProperty(property)) {
				CompareResult nextToVisit = currentNode.getBeanResults().get(
						property);
				visitR(nextToVisit, visitor, property);
			} else if (currentNode.isArrayProperty(property)) {
				CompareResult[] nextToVisit = currentNode.getArraysResults()
						.get(property);

				visitor.startCollectionResult(property, nextToVisit);
				for (CompareResult r : nextToVisit) {
					visitR(r, visitor, property);
				}
				visitor.endCollectionResult(property, nextToVisit);
			} else {
				visitor.acceptProperty(property);
			}
		}
		visitor.endBeanResult(name, currentNode);
	}

	/*
	 * private static String appendToPath(String path, String suffix) { return
	 * IcgCommonUtil.isEmpty(path) ? suffix : (path + PROPERTY_PATH_DELIMITER +
	 * suffix); }
	 */

	/*
	 * The entities which are being described by the properties contained in
	 * this object.
	 */
	public BusinessEntity[] getEntities() {
		if (entities != null) {
			final BusinessEntity[] retArray = new BusinessEntity[entities.size()];
			return entities.toArray(retArray);
		}
		return null;
	}

	public void setEntities(BusinessEntity[] entities) {
		if (this.entities != null) {
			this.entities.clear();
		}
		if (entities != null) {
			this.entities = new ArrayList<BusinessEntity>();
			for (BusinessEntity businessEntity : entities) {
				this.entities.add(businessEntity);
			}
		}
	}

	/*
	 * Get the id (PK?) which describes the bean being compared. Typically id
	 * should be the same for all entities. (but it doesn't have to be, really
	 * depenends on comparators configured)
	 */
	public String[] getIds() {
		if (this.ids != null) {
			final String[] retArray = new String[ids.size()];
			return ids.toArray(retArray);
		}
		return null;
	}

	public void setIds(String[] ids) {
		if (this.ids != null) {
			this.ids.clear();
		}
		if (ids != null) {
			this.ids = new ArrayList<String>();
			for (String id : ids) {
				this.ids.add(id);
			}
		}
	}

	/*
	 * The name of generic name of entities compared in this result.
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, String> getJavaPropertyNames() {
		return javaPropertyNames;
	}

	public void setJavaPropertyNames(Map<String, String> javaPropertyNames) {
		this.javaPropertyNames = javaPropertyNames;
	}

	/*
	 * True if the specified properties type is itself another entity (bean).
	 */
	public boolean isBeanProperty(String property) {
		return beanResults.containsKey(property);
	}

	public boolean isArrayProperty(String property) {
		return arraysResults.containsKey(property);
	}

	/*
	 * The value of all properties which of the bean which this entity
	 * represents.
	 */
	public List<String> getAllProperties() {
		return allProperties;
	}

	public void setAllProperties(List<String> allProperties) {
		this.allProperties = allProperties;
	}

	public Set<String> getMatchedProperties() {
		return matchedProperties;
	}

	public void setMatchedProperties(Set<String> matchedProperties) {
		this.matchedProperties = matchedProperties;
	}

	public Set<String> getUnmatchedProperties() {
		return unmatchedProperties;
	}

	public void setUnmatchedProperties(Set<String> unmatchedProperties) {
		this.unmatchedProperties = unmatchedProperties;
	}

	public Map<String, String[]> getPropertyValues() {
		return propertyValues;
	}

	public void setPropertyValues(Map<String, String[]> propertyValues) {
		this.propertyValues = propertyValues;
	}

	public Map<String, CompareResult> getBeanResults() {
		return beanResults;
	}

	public void setBeanResults(Map<String, CompareResult> beanResults) {
		this.beanResults = beanResults;
	}

	public Map<String, CompareResult[]> getArraysResults() {
		return arraysResults;
	}

	public void setArraysResults(Map<String, CompareResult[]> arraysResults) {
		this.arraysResults = arraysResults;
	}

	public Set<String> getManuallyChangedProperties() {
		return manuallyChangedProperties;
	}

	public void setManuallyChangedProperties(
			Set<String> manuallyChangedProperties) {
		this.manuallyChangedProperties = manuallyChangedProperties;
	}

	public String getParentUUID() {
		return parentUUID;
	}

	public void setParentUUID(String parentUUID) {
		this.parentUUID = parentUUID;
	}

	public boolean isRawMessageAddFlag() {
		return rawMessageAddFlag;
	}

	public void setRawMessageAddFlag(boolean rawMessageAddFlag) {
		this.rawMessageAddFlag = rawMessageAddFlag;
	}

	public boolean isOptionManualUpdateFlag() {
		return optionManualUpdateFlag;
	}

	public void setOptionManualUpdateFlag(boolean optionManualUpdateFlag) {
		this.optionManualUpdateFlag = optionManualUpdateFlag;
	}

	public Set<String> getOptionUUID() {
		return optionUUID;
	}

	public void setOptionUUID(Set<String> optionUUID) {
		this.optionUUID = optionUUID;
	}

	public IsSerializable[] getSerializableEntities() {
		if (this.serializableEntities != null) {
			final IsSerializable[] retArray = new IsSerializable[serializableEntities.size()];
			return serializableEntities.toArray(retArray);
		}
		return null;
	}

	public void setSerializableEntities(IsSerializable[] serializableEntities) {
		if (this.serializableEntities != null) {
			this.serializableEntities.clear();
		}
		if (serializableEntities != null) {
			this.serializableEntities = new ArrayList<IsSerializable>();
			for (IsSerializable sEntity : serializableEntities) {
				this.serializableEntities.add(sEntity);
			}
		}
	}

	@Override
	public String toLogString() {
		return name;
	}
	
	
}
