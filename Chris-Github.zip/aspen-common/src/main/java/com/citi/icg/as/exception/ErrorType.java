package com.citi.icg.as.exception;

import com.google.gwt.user.client.rpc.IsSerializable;

public enum ErrorType implements IsSerializable {
	INSERT, UPDATE, DELETE, DATA_ERROR, UNKNOW, STALE_DATA, ERROR, WARNING, INFO
}