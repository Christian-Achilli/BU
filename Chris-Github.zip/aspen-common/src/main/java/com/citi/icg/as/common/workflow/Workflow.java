package com.citi.icg.as.common.workflow;

import java.util.List;
import java.util.Map;

/**
 *
 */
public interface Workflow
{
	
	Map<String, Object> getVariables();
	
	String getProcessName();
	
	String getKey();
	
	State getCurrentState();
	
	List<TaskExecution> getTasks();
		
}
