package com.citi.icg.as.config;

import java.util.Map;

import org.apache.commons.configuration.XMLConfiguration;

import com.citi.icg.as.common.util.CommonUtil;

public class GCASAppConfiguration extends XMLConfiguration {
	// CHECKSTYLE:OFF
	private static final String GCAS_APPCONFIG = "gcas.appconfigdir";
	private static final String GCAS_KEYFILE = "gcas.keyfile";
	private static final String GCAS_ICGENV = "gcas.icgenv";
	private static final String CLUSTER_NAME = "gcas.clusterName";
	private static final long serialVersionUID = 1L;	
	private static GCASAppConfiguration INSTANCE;
	static Object mutex = new Object();
	// CHECKSTYLE:ON

	public static GCASAppConfiguration getInstance() {
		synchronized (mutex) {
			if(INSTANCE==null){
				INSTANCE = GcasConfigUtil.getInstance(GCASAppConfiguration.class);
			}
		}
		return INSTANCE;
	}

	public static GCASAppConfiguration getDynamicInstance(Map<String,?> properties) {
		synchronized (mutex) {
			if(INSTANCE==null){
				INSTANCE = CommonUtil.createDynamicConfigurationInstance(GCASAppConfiguration.class, null, properties);
			}
		}		
		return INSTANCE;
	}
	
	public String getAppConfigDir() {
		return INSTANCE.getString(GCAS_APPCONFIG);
	}

	public String getKeyFilePath() {
		return INSTANCE.getString(GCAS_KEYFILE);
	}

	public String getIcgEnv() {
		return INSTANCE.getString(GCAS_ICGENV);
	}
	
	public String getClusterName() {
		return INSTANCE.getString(CLUSTER_NAME);
	}

	public GCASAppConfiguration() {
		setDelimiterParsingDisabled(true);
	}

}
