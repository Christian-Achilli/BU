package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlTransient;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class User extends BaseBusinessEntity {
	
	private static final long serialVersionUID = 8007526270281848248L;

	private String userId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String userNameFirst;
	private String userNameLast;
	private String userGroup;
	private String system;
	private String emailAddress;
	private char systemUser;
	private String soeId;
	private char activeInd;
    private Date dateOfDeletion;
	private Set<UserRole> userRoles = new HashSet<UserRole>(0);
	private Set<UserAttribute> userAttributes = new HashSet<UserAttribute>(0);
	private Set<UserProcessingUnit> userProcessingUnit = new HashSet<UserProcessingUnit>(0);
	private Set<UserRegion> userRegions = new HashSet<UserRegion>(0);
	private Set<UserPURegionMatrix> userPURegionMatrixSet = new HashSet<UserPURegionMatrix>(0);

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getUserNameFirst() {
		return userNameFirst;
	}

	public void setUserNameFirst(String userNameFirst) {
		this.userNameFirst = userNameFirst;
	}

	public String getUserNameLast() {
		return userNameLast;
	}

	public void setUserNameLast(String userNameLast) {
		this.userNameLast = userNameLast;
	}

	public String getUserGroup() {
		return userGroup;
	}

	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public char getSystemUser() {
		return systemUser;
	}

	public void setSystemUser(char systemUser) {
		this.systemUser = systemUser;
	}

	public String getSoeId() {
		return soeId;
	}

	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}

	public char getActiveInd() {
		return activeInd;
	}

	public void setActiveInd(char activeInd) {
		this.activeInd = activeInd;
	}

	public Date getDateOfDeletion()
	{
		return dateOfDeletion;
	}
	
	public void setDateOfDeletion(Date dateOfDeletion)
	{
		this.dateOfDeletion = dateOfDeletion;
	}
	
	@XmlElement(name = "userRole", type = UserRole.class)
	@XmlElementWrapper(name = "userRoles")
	public Set<UserRole> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(Set<UserRole> userRoles) {
		this.userRoles = userRoles;
	}

	@XmlElement(name = "userAttribute", type = UserAttribute.class)
	@XmlElementWrapper(name = "userAttributes")
	public Set<UserAttribute> getUserAttributes() {
		return userAttributes;
	}

	public void setUserAttributes(Set<UserAttribute> userAttributes) {
		this.userAttributes = userAttributes;
	}

	@XmlTransient
	public Set<UserProcessingUnit> getUserProcessingUnit() {
		return userProcessingUnit;
	}

	public void setUserProcessingUnit(Set<UserProcessingUnit> userProcessingUnit) {
		this.userProcessingUnit = userProcessingUnit;
	}

	@XmlTransient
	public Set<UserRegion> getUserRegions() {
		return userRegions;
	}

	public void setUserRegions(Set<UserRegion> userRegions) {
		this.userRegions = userRegions;
	}

	@XmlTransient
	public Set<UserPURegionMatrix> getUserPURegionMatrixSet() {
		return userPURegionMatrixSet;
	}

	public void setUserPURegionMatrixSet(Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.userPURegionMatrixSet = userPURegionMatrixSet;
	}

	@Override
	public String getId() {
		return getUserId();
	}

	@Override
	public String toString() {
		return "[userId=" + userId + ", soeId=" + soeId + "]";
	}
	
}
