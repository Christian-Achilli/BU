package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseAnnouncementCopyType;

@Entity
@Table(name = "ANNOUNCEMENT_COPY_TYPE")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class AnnouncementCopyType extends BaseAnnouncementCopyType {

	private static final long serialVersionUID = -4105275125636071083L;

}
