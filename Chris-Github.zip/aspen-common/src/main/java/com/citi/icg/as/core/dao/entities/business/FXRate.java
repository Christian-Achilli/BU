package com.citi.icg.as.core.dao.entities.business;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class FXRate extends BaseBusinessEntity {

	private Long pkFxRateId;
	private Date fxRateDate;
	private String rateType;
	private Long termCcy;
	private Long baseCcy;
	private String tenor;
	private BigDecimal fxRateBid;
	private BigDecimal fxRateAsk;
	private BigDecimal fxRateMid;
	private String instrumentLabel;

	public Long getPkFxRateId() {
		return pkFxRateId;
	}

	public void setPkFxRateId(Long pkFxRateId) {
		this.pkFxRateId = pkFxRateId;
	}

	public Date getFxRateDate() {
		return fxRateDate;
	}

	public void setFxRateDate(Date fxRateDate) {
		this.fxRateDate = fxRateDate;
	}

	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	public Long getTermCcy() {
		return termCcy;
	}

	public void setTermCcy(Long termCcy) {
		this.termCcy = termCcy;
	}

	public Long getBaseCcy() {
		return baseCcy;
	}

	public void setBaseCcy(Long baseCcy) {
		this.baseCcy = baseCcy;
	}

	public String getTenor() {
		return tenor;
	}

	public void setTenor(String tenor) {
		this.tenor = tenor;
	}

	public BigDecimal getFxRateBid() {
		return fxRateBid;
	}

	public void setFxRateBid(BigDecimal fxRateBid) {
		this.fxRateBid = fxRateBid;
	}

	public BigDecimal getFxRateAsk() {
		return fxRateAsk;
	}

	public void setFxRateAsk(BigDecimal fxRateAsk) {
		this.fxRateAsk = fxRateAsk;
	}

	public BigDecimal getFxRateMid() {
		return fxRateMid;
	}

	public void setFxRateMid(BigDecimal fxRateMid) {
		this.fxRateMid = fxRateMid;
	}

	public String getInstrumentLabel() {
		return instrumentLabel;
	}

	public void setInstrumentLabel(String instrumentLabel) {
		this.instrumentLabel = instrumentLabel;
	}

	@Override
	public Serializable getId() {
		return getPkFxRateId();
	}
}
