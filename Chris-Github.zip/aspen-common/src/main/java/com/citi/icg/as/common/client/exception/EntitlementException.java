package com.citi.icg.as.common.client.exception;

import com.citi.icg.toolkit.web.client.IcgGwtException;
import com.google.gwt.user.client.rpc.IsSerializable;

/**
 * RPC exception for GWT.
 */
@SuppressWarnings("serial")
public class EntitlementException extends IcgGwtException implements IsSerializable {
	public EntitlementException() {

	}

	public EntitlementException(String message) {
		super(message);
	}
}
