package com.citi.icg.as.common.service;

import java.util.List;
import java.util.Map;

import com.citi.icg.as.common.enums.AnnouncementCopyTypeEnum;
import com.citi.icg.as.core.dao.entities.business.AnnouncementCopyType;
import com.citi.icg.as.core.dao.entities.business.CountryCode;
import com.citi.icg.as.core.dao.entities.business.CurrencyCode;
import com.citi.icg.as.core.dao.entities.business.FXRate;
import com.citi.icg.as.core.dao.entities.business.LegalEntity;
import com.citi.icg.as.core.dao.entities.business.ProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.User;

public interface CommonDataService {

	User getCurrentUser();

	User getUser(String userId);

	Integer executeUpdateSQL(String query, Map<String, ? extends Object> params);

	List executeSQL(String query);

	List<String> getNodeNames(String clusterName);

	AnnouncementCopyType getQualifier(AnnouncementCopyTypeEnum item);

	List<CurrencyCode> getCurrencyCodesList();

	int countDataRows(Class<?> entityClass);

	<T> List<T> fetchData(Class<T> entityClass, int startRow, int pageSize);

	<T> List<T> fetchData(Class<T> entityClass);

	public List<FXRate> getCurrencyFxRate(String termCurrency, String baseCurrency);

	CountryCode getCountry(String alphaCode);

	/**
	 * Get the legal entity list for DEFAULT PUs (PB Equity, Main Firm Equity, Swaps, Fixed Income)
	 * @return 
	 */
	List<LegalEntity> getLegalEntities();

	/**
	 * Get the legal entity list only for CGMI Broadridge PU
	 * @return 
	 */
	List<LegalEntity> getLegalEntitiesForBR();

	/**
	 * Filter alias name within legal entities for DEFAULT PUs (PB Equity, Main Firm, Swaps, Fixed Income)
	 * @return 
	 */
	Map<String, LegalEntity> getAllLegalEntityFiterAliasName();

	LegalEntity getLegalEntity(int legalEntityId);

	LegalEntity getLegalEntityByCode(String code);

	List<ProcessingUnit> getProcessingUnits();

}