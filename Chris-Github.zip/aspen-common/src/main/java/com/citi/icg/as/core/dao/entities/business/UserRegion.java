package com.citi.icg.as.core.dao.entities.business;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class UserRegion extends BaseBusinessEntity {

	private static final long serialVersionUID = 7110628064611253418L;

	private int pkUserRegionId;
	private User user;
	private Region region;
	private String primaryRegion;
	private Date lastUpdatedDate;
	private Set<UserPURegionMatrix> userPURegionMatrixSet = new HashSet<UserPURegionMatrix>(0);

	public int getPkUserRegionId() {
		return this.pkUserRegionId;
	}

	public void setPkUserRegionId(int pkUserRegionId) {
		this.pkUserRegionId = pkUserRegionId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public String getPrimaryRegion() {
		return primaryRegion;
	}

	public void setPrimaryRegion(String primaryRegion) {
		this.primaryRegion = primaryRegion;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Serializable getId() {
		return getPkUserRegionId();
	}

	public Set<UserPURegionMatrix> getUserPURegionMatrixSet() {
		return userPURegionMatrixSet;
	}

	public void setUserPURegionMatrixSet(Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.userPURegionMatrixSet = userPURegionMatrixSet;
	}

}
