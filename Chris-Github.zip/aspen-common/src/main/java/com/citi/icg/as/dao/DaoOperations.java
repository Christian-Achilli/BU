package com.citi.icg.as.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.hibernate.criterion.Criterion;
import org.springframework.orm.hibernate3.HibernateCallback;

public interface DaoOperations<T, S> {

	T findSingleByCriteria(List<Criterion> criterion);
	
	T findSingleByExample(T example);

	List<T> findByCriteria(List<Criterion> criterion);

	T get(Serializable id);

	void saveOrUpdate(T entity);

	void saveOrUpdate(Collection<T> entities);

	<C> C execute(HibernateCallback<C> callback);
	
	T convertToBusinessEntity(S hibernateEntity);
	
	T convertToBusinessEntity(S hibernateEntity, T businessEntity);

	S convertToHibernateEntity(T businessEntity);
	
	S convertToHibernateEntity(T businessEntity, S hibernateEntity);
	
}