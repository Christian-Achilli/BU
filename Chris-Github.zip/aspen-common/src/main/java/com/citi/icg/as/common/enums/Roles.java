package com.citi.icg.as.common.enums;

/**
 * Provides the lists of User Role Names from Roles Table.
 */
public enum Roles {
	READ_ONLY, CA_ANALYST, INCOME_ANALYST, USER_ADMIN, SUPER, SUPPORT, CA_SUPERVISOR, INCOME_SUPERVISOR, TAX_SUPERVISOR, EC_SUPERVISOR, EC_ANALYST, CAEC_SUPERVISOR, REFDATA_SUPERVISOR

}
