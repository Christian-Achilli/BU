package com.citi.icg.as.common.workflow;


/**
 * Bean for a generic state object.
 *
 */
public class GenericState implements State {

	private Long id;
	
	private String name;
	
	private StateType stateType;
	
	public GenericState(Long id, String name, StateType stateType) 
	{
		this.id = id;
		this.name = name;
		this.stateType = stateType;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public StateType getStateType() {
		return stateType;
	}
	
}
