package com.citi.icg.as.server.service.comparator;

import java.util.Comparator;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class StringPropertyBeanComparator<T> implements Comparator<T>
{	
	protected static final Log LOG = LogFactory.getLog(NullSafeBeanPropertyComparator.class);
	
	private final String property;
	
	public StringPropertyBeanComparator(String property)
	{
		this.property = property;
	}

	public int compare(T arg0, T arg1)
	{
		try
		{
			Object val0 = arg0 == null ? null : BeanUtils.getProperty(arg0, property);
			Object val1 = arg1 == null ? null : BeanUtils.getProperty(arg1, property);
			
			if (val0 == null && val1 == null)
			{
				return 0;
			}
			if (val0 == null)
			{
				return 1;
			}
			else if (val1 == null)
			{
				return -1;
			}
			else
			{
				return val0.toString().trim().compareTo(val1.toString().trim());
			}
		}
		catch (Exception e)
		{
			LOG.error(e.toString(), e);
			throw new ClassCastException();
		}
	}
}
