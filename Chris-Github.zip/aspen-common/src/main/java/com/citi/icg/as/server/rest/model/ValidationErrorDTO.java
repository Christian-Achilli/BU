/**
 * 
 */
package com.citi.icg.as.server.rest.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ap72338
 *
 */
public class ValidationErrorDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1385496417751073019L;
	
	private List<FieldErrorDTO> fieldErrors = new ArrayList<>();
 
    public void addFieldError(String path, String message) {
        FieldErrorDTO error = new FieldErrorDTO(path, message);
        fieldErrors.add(error);
    }

	public List<FieldErrorDTO> getFieldErrors() {
		return fieldErrors;
	}
}
