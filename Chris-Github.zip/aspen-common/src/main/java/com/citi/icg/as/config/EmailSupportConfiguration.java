package com.citi.icg.as.config;

import java.util.Map;

import com.citi.icg.as.common.util.CommonUtil;

/**
 * 
 * replace IcgToolkitConfiguration.
 * 
 */
public class EmailSupportConfiguration extends GCASAppConfiguration
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7590756707740908794L;

	// private static EmailSupportConfiguration singleton = null;
	private static final String APPLICATION = "application";
	private static final String PERIOD = ".";
	private static final String APPLICATION_NAME = "name";
	private static final String EMAIL_SERVER = "email.server";
	private static final String EMAIL_SUPPORT = "email.support";
	private static final String EMAIL_SUPPORT_DISABLED = "email.supportDisabled";

	private static EmailSupportConfiguration INSTANCE;
	
	public static EmailSupportConfiguration getInstance()
	{
		return INSTANCE;
	}

	
	public static EmailSupportConfiguration createInstance(Map<String,String>properties){		
		if(INSTANCE==null){
			INSTANCE = CommonUtil.createDynamicConfigurationInstance(EmailSupportConfiguration.class, null,properties);
		}
		return INSTANCE;
	}
	
	public String getApplicationName()
	{
		return getString(APPLICATION + PERIOD + APPLICATION_NAME);
	}
	
	public String getEmailServer()
	{
		return getString(APPLICATION + PERIOD + EMAIL_SERVER);
	}

	public String getSupportEmail()
	{
		return getString(APPLICATION + PERIOD + EMAIL_SUPPORT);
	}

	public boolean getSupportEmailDisabled()
	{
		String flag = getString(APPLICATION + PERIOD + EMAIL_SUPPORT_DISABLED);
		return flag != null && flag.trim().equals("true");
	}
}
