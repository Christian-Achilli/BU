package com.citi.icg.as.server.service.compare;

import com.citi.icg.as.common.client.compare.CompareResult;
import com.citi.icg.as.exception.GcasException;

public interface CompareService {
	CompareResult compare(Object... entities) throws GcasException;
}
