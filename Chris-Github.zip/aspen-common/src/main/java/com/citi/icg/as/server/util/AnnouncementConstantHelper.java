package com.citi.icg.as.server.util;

import org.apache.commons.lang.time.DateUtils;

public final class AnnouncementConstantHelper {
	
	private AnnouncementConstantHelper() { }
	public static final String STOCK_PAYOUT = "SECMOVE";
	public static final String CASH_PAYOUT = "CASHMOVE";
	public static final String HIBERNATE_ROLE_NAME_SEP = ".";
	public static final String MSG_SOURCE_EVENT_IS_NOT_NULL = "SOURCE EVENT IS NOT NULL ";
	public static final String OPTION_TYPE_KEY = "optionCode";
	public static final String PAYOUT_TYPE_KEY = "payoutCode";
	public static final String OUT_KEY_UPDATED_BY = "by";
	public static final String OUT_KEY_UPDATED_AT = "at";
	public static final String OUT_KEY_VERSION = "ver";
	public static final String OUT_KEY_SUBMITTED_BY = "subm";
	public static final String OUT_KEY_APPROVED_BY = "appr";
	public static final String OUT_KEY_IS_MANUAL = "isManual";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String E = "E";
	public static final String SPACE_CHAR = " ";
	public static final String NEWLINE = "\n";
	public static final String NULL = "NULL";
	public static final String AGENT_DEADLINE = "agentDeadline";
	public static final String MARKET_DEADLINE = "marketDeadline";
	public static final String INTERNAL_DEADLINE = "internalDeadline";
	public static final String DOT_CHAR = ".";
	public static final String COLON_CHAR = ":";
	public static final String POSITION_TYPE_UNKNOWN = "UNKNOWN";
	public static final String POSITION_TYPE_LONG = "Long";
	public static final String POSITION_TYPE_BOTH = "Both";
	public static final char PROCESSED_INDICATOR_REJECTED = 'R';
	public static final char PROCESSED_INDICATOR_NOT_PROCESSED = 'N';
	public static final String OUT_KEY_VALUE = "value";
	public static final String OUT_KEY_ASSIGNED_AT = "assgnd";
	public static final String FIELD_VALUE = "Value";
	public static final String FIELD_UPDATED_BY = "Updated By";
	public static final String FIELD_UPDATED_ON = "Updated On";
	public static final String FIELD_VERSION = "Version";
	public static final String FIELD_SUBMITTED_BY = "Submitted By";
	public static final String FIELD_APPROVED_BY = "Approved By";
	public static final String AUDIT_FIELD_WINDOW_TITLE = " Audit";
	public static final String EMPTY_MESSSAGE = "Audit History not Found for this request";
	
	public static final long PROCESSED_MESSAGE_MAX_AGE_DEFAULT = DateUtils.MILLIS_PER_HOUR;
	public static final long EXPIRED_MESSAGE_MAX_AGE_DEFAULT = DateUtils.MILLIS_PER_DAY * 7L;
	public static final long FAILED_MESSAGES_MAX_AGE_DEFAULT = DateUtils.MILLIS_PER_DAY * 7L;
	
	public static final String OPT_MANUAL_IND = "MANUAL";
	public static final String OPT_HYPHEN = " - ";
	public static final String OPT_SPACE = " ";
	public static final String OPT_USCORE = "_";
	public static final String OPT_OPENBRACKET = "(";
	public static final String OPT_CLOSEBRACKET = ")";
	public static final String OPT_THREE_DOTS = "...";
	public static final String OPT_DOUBLE_QUOTES = "\"";
	
	public static final String MAND = "MAND";
	public static final String OPTIONLABEL = "Option";
	public static final String OPT_SEC_ID = "option_section_";
	public static final String OPTIONTEXT = "optionText";
	public static final String OPT_RPT_STACK_ID = "option_repeat_stack_";
	public static final String M = "M";
	public static final String NO = "No";
	public static final String ZERO = "0";
	public static final String RESTRICTED_STATUS_KEY = "statusCode";
	public static final String FTT_STATUS_KEY = "statusCode";
	public static final String IS_MANUAL = "Is Manual";
	public static final String RULE_ID = "ruleId";
}
