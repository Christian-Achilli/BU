package com.citi.icg.as.dao;

import java.util.TimeZone;

import org.apache.commons.lang.time.DateUtils;

public class DaoConstants {
	public static final String MESSAGE_TYPE_564 = "564";
	public static final String MESSAGE_TYPE_568 = "568";
	public static final String CA_MESSAGE_TYPE_564 = "I564";
	public static final String CA_MESSAGE_TYPE_568 = "I568";
	public static final String DEFAULT_HOLDING_TYPE = "UNKNOWN";
	public static final String DEFAULT_PROCESSING_UNIT_NAME = "Default PU";
	public static final int ZERO = 0;
	public static final String COL = "col";
	public static final String COL1 = "col1";
	public static final String COL2 = "col2";
	public static final String MAIN = "main";
	public static final String ACCOUNT_TYPE_UNKNOWN = "UNKNOWN";
	public static final String[] PK_ANNOUNCEMENT_ID_REGION_CODE = new String[] {
			"pkAnnouncementId",
			"region"};
	public static final int INITIAL_SEQUENCE_NUMBER = 1;
	public static final String SEQUENCE_NAME = "sequenceName";
	public static final String DOT_CHAR = ".";
	public static final String NEWLINE = "\n";
	public static final String NULL = "NULL";
	public static final String MANUAL_EVENT_SEQUENCE = "ManualEventSequence";
	
	public static final TimeZone TIMEZONENAM = TimeZone.getTimeZone("America/New_York");
	public static final TimeZone TIMEZONEEMEA = TimeZone.getTimeZone("Europe/London");
	public static final TimeZone TIMEZONEASPAC = TimeZone.getTimeZone("Asia/Hong_Kong");
	public static final TimeZone TIMEZONEAPAC = TimeZone.getTimeZone("Australia/Sydney");
	public static final TimeZone TIMEZONEUTC = DateUtils.UTC_TIME_ZONE;
	public static final String USER_SYSTEM = "SYSTEM";
	public static final int EVENT_TYPE_DEFAULT_ID = 68;
	
	public static final char PROCESSED_INDICATOR_NOT_PROCESSED = 'N';
	public static final char PROCESSED_INDICATOR_HOLD = 'H';
	public static final char PROCESSED_INDICATOR_PROCESSED = 'Y';
	public static final char PROCESSED_INDICATOR_EXPIRED = 'X';
	public static final char PROCESSED_INDICATOR_FAILED = 'F';
	public static final char PROCESSED_INDICATOR_REJECTED = 'R';
	public static final String MESSAGE_FUNCTION_XML= "XML";
	public static final String USER_UNASSIGNED = "unassigned";
	
	public static final String DATE_FORMAT_yyyyMMdd = "yyyyMMdd";
	public static final String DATE_TIME_FORMAT_yyyyMMdd = "yyyyMMddhhmmss";
	
	
	public static final String MASTER_IND_YES = "Y";
	public static final String PROPERTY_WEBLOGIC_NODE_NAME = "weblogic.Name";
	public static final String NODE_NAME_UNDEFINED = "undefined";
	public static final long DEFAULT_POLLING_INTERVAL = DateUtils.MILLIS_PER_MINUTE;
	
	public static final String UNKNOWN_HOLDING_TYPE = "UNKNOWN";
	
	public enum SwiftMessageFunction
	{
		//CHECKSTYLE:OFF
		IADD("Additional Business Process"),
		ICAN("Cancellation Request"),
		INEW("New"),
		IREP("Eligible Balance Notification"),
		IRPL("Replacement"),
		IRMD("Reminder"),
		IWIT("Withdrawal");
		//CHECKSTYLE:ON
		
		private String displayName;

		private SwiftMessageFunction(String displayName)
		{
			this.displayName = displayName;
		}

		public String getDisplayName()
		{
			return displayName;
		}	
	}
}
