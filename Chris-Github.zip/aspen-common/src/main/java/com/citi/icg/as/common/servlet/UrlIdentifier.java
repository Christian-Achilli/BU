package com.citi.icg.as.common.servlet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by cd68076 on 2/03/2017.
 */
public class UrlIdentifier {

    private final static Log LOG = LogFactory.getLog(UrlIdentifier.class);
    private Pattern pattern;

    public UrlIdentifier(String regex) {
        this.pattern = Pattern.compile(regex);
    }

    /**
     * For GWT rpc call remove only references to ASPEN-UAT1/UAT2 but not the context AssetServicing
     * for static resources remove the context AssetServicing and Aspen-UAT1/UAT2
     * @param payload
     * @param isGwtRpcCall
     * @return
     */
    public IndexTuple matchForUrlPattern(String payload, boolean isGwtRpcCall){
        if (pattern != null){
            Matcher matcher = pattern.matcher(payload);
            while (matcher.find()) {
                int firstIdx = 0;
                if (isGwtRpcCall){
                    firstIdx = matcher.start(1); // matches on the first group of the regex pattern .*(ASPEN-(\w*)).*
                    //group 1 pattern : (ASPEN-(\w*)) --> ASPEN-UAT1
                    //group 2 pattern : (\w*) --> UAT1
                }
                int lastIdx = matcher.end(1);
                LOG.debug(String.format("[Regex Group: %s, startIndex: %d endIndex: %d]", matcher.group(1), firstIdx, lastIdx));
                return new IndexTuple(firstIdx, lastIdx);
            }
        }
        return null;
    }
}


