package com.citi.icg.as.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

public class GcasException extends Exception
{
	private static final long serialVersionUID = 7295251232534630745L;

	protected ErrorType errorType;
	
	// --- Constructor(s) ---
	public GcasException(String message)
	{
		super(message);
	}

	public GcasException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public GcasException(String message, ErrorType errorType)
	{
		super(message);
		this.errorType = errorType;
	}

	// --- Static Methods ---

	public static String asString(Throwable throwable)
	{
		if (throwable == null) {
			return null;
		}

		StringWriter buffer = new StringWriter();
		PrintWriter writer = new PrintWriter(buffer);
		throwable.printStackTrace(writer);
		writer.flush();

		return buffer.toString();

	}
}
