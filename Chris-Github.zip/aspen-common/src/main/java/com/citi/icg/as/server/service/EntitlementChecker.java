package com.citi.icg.as.server.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.server.util.ExceptionUtil;
import com.citi.icg.toolkit.web.client.IcgGwtException;

public final class EntitlementChecker
{
	
	private static final String PERMISSION_DENIED_METHOD_NOT_FOUND = "Permission denied, possible security violation.";
	
	private static final Log LOG = LogFactory.getLog(EntitlementChecker.class);
	
	private EntitlementChecker() { }
	public static void isAllowed(Object obj, String name, Object[] parameters, Class<?>[] classes)
	{
		if (obj == null)
		{ 
			return;
		}
		try
		{
		   Method method = obj.getClass().getMethod(name, classes);
		   if (method == null)
		   {
			   throw ExceptionUtil.createEntitlementException(PERMISSION_DENIED_METHOD_NOT_FOUND);
		   }
		   method.invoke(obj, parameters);
		}
		catch (InvocationTargetException invoke) {
			if (invoke.getTargetException() instanceof IcgGwtException)
			{
				throw (IcgGwtException) invoke.getTargetException();
			}
			LOG.error("Exception while performing entitlement isAllowed");
			throw ExceptionUtil.createEntitlementException(PERMISSION_DENIED_METHOD_NOT_FOUND);
		}
		catch (IcgGwtException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			LOG.error("Exception while performing entitlement check");
			throw new IcgGwtException();
		}
	}
}