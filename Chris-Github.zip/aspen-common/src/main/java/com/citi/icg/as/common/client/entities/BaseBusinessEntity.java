package com.citi.icg.as.common.client.entities;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

import com.citi.icg.aspenlogger.Loggable;

@XmlType(namespace = "urn:com:citi:icg:as:core:dao:entities:business", name = "BusinessEntity")
public abstract class BaseBusinessEntity implements BusinessEntity, Loggable {

	private static final long serialVersionUID = 3120702114658316189L;
	
	private String temporaryKey;

	public String getTemporaryKey() {
		return temporaryKey;
	}

	public void setTemporaryKey(String key) {
		temporaryKey = key;
	}

	abstract public Serializable getId();

	@Override
	public String toLogString(){
		if (null != this.getId()){
			return this.getId().toString();
		}else {
			return "";
		}
		
	}
}
