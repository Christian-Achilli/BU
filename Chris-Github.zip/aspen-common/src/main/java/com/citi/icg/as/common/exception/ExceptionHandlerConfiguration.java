package com.citi.icg.as.common.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ExceptionHandlerConfiguration {

	@Value("$ex{exceptions.exception.name}")
	private String[] exceptionNames;
	@Value("$ex{exceptions.exception.ignoretime}")
	private String[] ignoreTimes;
	@Value("$ex{exceptions.email}")
	private String email;
	@Value("$ex{exceptions.log.level}")
	private String logLevel;
	@Value("$ex{exceptions.batch.number}")
	private String sBatchNumber;
	@Value("$ex{exceptions.max.unsent}")
	private String maxUnsent;
	@Value("$ex{exceptions.max.exist}")
	private String maxExist;
	@Value("$ex{exceptions.db.available}")
	private String dbAvail;
	@Value("$ex{exceptions.send.email}")
	private String sendEmailOut;
	@Value("$ex{exceptions.warning.exception.name}")
	private String[] warningExceptionNames;
	@Value("$ex{exceptions.warning.exception.string}")
	private String[] warningExceptionStrings;
	@Value("$ex{exceptions.info.exception.name}")
	private String[] infoExceptionNames;
	@Value("$ex{exceptions.info.exception.string}")
	private String[] infoExceptionStrings;

	public String[] getAllExceptions() {
		return this.exceptionNames;
	}

	public String[] getAllIgnoreTimes() {
		return this.ignoreTimes;
	}

	public String getMail() {
		return this.email;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public int getBatchNumber() {
		int batchNumber = 1;

		try {
			batchNumber = Integer.parseInt(sBatchNumber);
			if (batchNumber <= 0) {
				batchNumber = 1;
			}
		} catch (Exception e) {
			batchNumber = 1;
		}

		return batchNumber;
	}

	public int getMaximumUnsentExceptions() {
		int maximumunsentexceptions = 1;

		try {
			maximumunsentexceptions = Integer.parseInt(maxUnsent);
			if (maximumunsentexceptions <= 0) {
				maximumunsentexceptions = 1;
			}
		} catch (Exception e) {
			maximumunsentexceptions = 1;
		}

		return maximumunsentexceptions;
	}

	public int getMaximumExistsDays() {
		int days = 7;

		try {
			days = Integer.parseInt(maxExist);
			if (days <= 0) {
				days = 1;
			}
		} catch (Exception e) {
			days = 7;
		}

		return days;
	}

	public boolean isDBAvailable() {
		if ("true".equalsIgnoreCase(dbAvail)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isSendEmail() {
		if ("true".equalsIgnoreCase(sendEmailOut)) {
			return true;
		} else {
			return false;
		}
	}

	public String getIgnoreTimeOfException(String exceptionName) {
		String[] exceptionNames = getAllExceptions();
		for (int index = 0; index < exceptionNames.length; index++) {
			if (exceptionName.equals(exceptionNames[index])) {
				return getAllIgnoreTimes()[index];
			}
		}
		return null;
	}

	public String getDefaultIgnoreTime() {
		return getIgnoreTimeOfException("DEFAULT");
	}

	public String[] getAllInfoExceptions() {
		return infoExceptionNames;
	}

	public String[] getAllInfoStrings() {
		return infoExceptionStrings;
	}

	public String[] getAllWarningExceptions() {
		return warningExceptionNames;
	}

	public String[] getAllWarningStrings() {
		return warningExceptionStrings;
	}
}
