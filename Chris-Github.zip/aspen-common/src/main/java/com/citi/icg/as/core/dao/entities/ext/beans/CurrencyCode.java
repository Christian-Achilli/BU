package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.NamedNativeQueries;
import org.hibernate.annotations.NamedNativeQuery;

import com.citi.icg.as.core.dao.entities.base.beans.BaseCurrencyCode;

@Entity
@Table(name="CURRENCY_CODE")
@NamedNativeQueries({@NamedNativeQuery(name = "currencyIndexQuery", query = "select * from currency_code c where c.currency_code = :Code", resultClass = CurrencyCode.class)})
public class CurrencyCode extends BaseCurrencyCode
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8697517278775502718L;

}
