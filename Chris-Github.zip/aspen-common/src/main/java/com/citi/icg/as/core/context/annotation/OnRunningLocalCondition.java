package com.citi.icg.as.core.context.annotation;

import static com.citi.icg.as.common.constants.CommonConstants.SYSTEM_ENV_PROPERTY;
import static org.apache.commons.lang.StringUtils.EMPTY;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.citi.icg.as.common.constants.CommonConstants;

/**
 * 
 * @author ap72338
 *         <p>
 *         The class which can create conditional beans depending on whether env
 *         is local or jenkins.
 *         </p>
 */
public class OnRunningLocalCondition implements Condition {

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {

		Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalRunningLocally.class.getName());
		List<String> includedList = Arrays.asList((String[]) attributes.get("included"));
		String systemConfigurationValue = System.getProperty(SYSTEM_ENV_PROPERTY, EMPTY);
		return (CollectionUtils.isNotEmpty(includedList) && includedList.contains(systemConfigurationValue))
				|| CommonConstants.Y
						.equalsIgnoreCase(System.getProperty(CommonConstants.TEST_EXECUTION, StringUtils.EMPTY));
	}

}
