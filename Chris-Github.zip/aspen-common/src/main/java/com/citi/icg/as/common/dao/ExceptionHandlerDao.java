package com.citi.icg.as.common.dao;

import java.util.List;

import com.citi.icg.as.core.dao.entities.ext.beans.LoggedExceptions;

public interface ExceptionHandlerDao {

	void saveOrUpdateExceptions(LoggedExceptions exception);

	List<LoggedExceptions> getExceptionList(Integer[] pkIds);

	Integer getNextSequenceNumber(final String sequenceName);

	List<LoggedExceptions> getLoggedExpcetions();

	
}
