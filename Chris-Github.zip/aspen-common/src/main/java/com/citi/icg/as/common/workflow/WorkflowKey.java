package com.citi.icg.as.common.workflow;

public interface WorkflowKey<T> {

	public abstract Class<T> getEntityType();

	public abstract Long[] getEntityIds();

	public abstract String[] getEntityIdsWithBrackets();

}