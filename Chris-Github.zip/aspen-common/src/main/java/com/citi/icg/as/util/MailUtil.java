package com.citi.icg.as.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MailUtil {
	
	private static final Log LOG = LogFactory.getLog(MailUtil.class);
	
	private static final String SMTP_HOST = "mail.smtp.host";
	private static final String SMTP_PORT = "mail.smtp.port";

	/**
	 * Sends an email with the specified parameters.
	 * 
	 * @param to list of email like 'a@b.com;c@d.com'
	 * @param cc list of email like 'a@b.com;c@d.com'
	 * @param bcc list of email like 'a@b.com;c@d.com'
	 * @param from
	 * @param subject
	 * @param message
	 * @param host
	 * @param port
	 * @return <t>true</t> if successful, else <t>false</t>
	 */
	public static boolean sendMail(String to, String cc, String bcc,
			String from, String subject, String message, String host, int port) {
		try {
			if (StringUtils.isEmpty(from)){
				LOG.debug("Empty 'from' field");
				return false;
			}
			if (StringUtils.isEmpty(host)){
				LOG.debug("Empty 'host' field");
				return false;
			}
			
			LOG.info(String.format("Send email to[%s] msg[%s]", to, message));
			LOG.debug(String.format("Sending through %s:%d", host, port));
			
			Properties props = System.getProperties();
			props.put(SMTP_HOST, host);
			props.put(SMTP_PORT, port);
			Session session = Session.getInstance(props, null);
			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(from));
			
			if (StringUtils.isNotEmpty(to)) {
				msg.setRecipients(javax.mail.Message.RecipientType.TO, createAddresses(to));
			} else {
				LOG.debug("Empty 'to' field");
				return false;
			}
			if (StringUtils.isNotEmpty(cc)) {
				msg.setRecipients(javax.mail.Message.RecipientType.CC, createAddresses(cc));
			}
			if (StringUtils.isNotEmpty(bcc)) {
				msg.setRecipients(javax.mail.Message.RecipientType.BCC, createAddresses(bcc));
			}
			msg.setSubject(subject);
			// create and fill the first message part
			MimeBodyPart mbp1 = new MimeBodyPart();
			mbp1.setContent(message, "text/html");

			// create the Multipart and add its parts to it
			MimeMultipart mp = new MimeMultipart("mixed");
			mp.addBodyPart(mbp1);

			// add the Multipart to the message
			msg.setContent(mp);
			msg.setSentDate(new Date());

			// send the message
			Transport.send(msg);
			return true;
		} catch (Exception e) {
			LOG.error("Couldn't send email", e);
		}
		return false;
	}
	
	private static InternetAddress[] createAddresses(String address) throws AddressException {
		String[] toAddress = address.split(";");
		List<InternetAddress> iaddresses = new ArrayList<InternetAddress>();
		for (int i = 0; i < toAddress.length; i++) {
			InternetAddress addr = new InternetAddress(toAddress[i].trim());
			if (addr != null) {
				iaddresses.add(addr);
			}
		}
		return iaddresses.toArray(new InternetAddress[iaddresses.size()]);
	}
}

