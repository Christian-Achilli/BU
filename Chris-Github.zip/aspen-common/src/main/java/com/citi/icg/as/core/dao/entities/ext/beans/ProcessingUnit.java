package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseProcessingUnit;

@Entity
@Table(name = "PROCESSING_UNIT")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class ProcessingUnit extends BaseProcessingUnit {

	private static final long serialVersionUID = -4670697577510065669L;

	@Override
	public String toString() {
		return "ProcessingUnit [getLastUpdatedBy()=" + getLastUpdatedBy() + ", getLastUpdatedDate()=" + getLastUpdatedDate() + ", getPkProcessingUnitId()=" + getPkProcessingUnitId()
				+ ", getUnitAlternateName()=" + getUnitAlternateName() + ", getUnitLongName()=" + getUnitLongName() + ", getUnitName()=" + getUnitName() + ", getGroupEmailAddress()="
				+ getGroupEmailAddress() + ", getGroupTelephoneNumber()=" + getGroupTelephoneNumber() + "]";
	}

}
