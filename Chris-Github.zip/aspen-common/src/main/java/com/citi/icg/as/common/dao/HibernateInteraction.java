package com.citi.icg.as.common.dao;

/**
 * Hibernate interaction functor.
 *
 * @param <T>
 *            return type from execute.
 */
public interface HibernateInteraction<T> {
	T execute() throws Exception;
}
