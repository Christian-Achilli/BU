package com.citi.icg.as.core.entities.constants;


public class UserAttributeConstant {
	public static final String PK_USER_ATTRIBUTE_ID = "pkUserAttributeId";
	public static final String ATTRIBUTE_VALUE = "attributeValue";
	public static final String DEBUG_STRING = "debugString";
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String VALUE = "value";
	public static final String ATTRIBUTE = "attribute";
	public static final String CLASS = "class";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
	public static final String USER = "user";
}