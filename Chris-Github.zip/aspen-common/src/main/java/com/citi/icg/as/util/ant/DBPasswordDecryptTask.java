package com.citi.icg.as.util.ant;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import com.citi.icg.as.util.CommonTextEncryptUtils;

/**
 * This is a customized Ant task used to decrypt and override the old DB password.
 *
 */
public class DBPasswordDecryptTask extends Task {
	
	public static final String ENCODE_INDICATOR_START = "ENC(";
	
	private String property;
	private String value;
	
	
	public String getValue() {
	    return value;
	}
	
	public void setValue(String value) {
	    this.value = value;
	}
	
	public void setProperty(String property) {
	    this.property = property;
	}
	
	public void execute() throws BuildException {
	    System.out.println("Begin to execute customized ant task - DecryptDBPsdTask: property=" + property + ", value=" + value);
	    
	    if (value.startsWith(ENCODE_INDICATOR_START)) {
	    	String passwordDecrypted = CommonTextEncryptUtils.decryptIfEncrypted(value);
		    getProject().setProperty(property, passwordDecrypted);
	    }
	    
	}
}
