package com.citi.icg.as.common.service;

import javax.annotation.Resource;

public class CommonServiceFactory {

	private static CommonServiceFactory instance = new CommonServiceFactory();
	
	@Resource private CommonDataService commonDataService;
	
	private CommonServiceFactory(){}
	
	public static CommonServiceFactory getInstance() {
		return instance;
	}
	
	public CommonDataService getCommonDataService() {
		return commonDataService;
	}
}
