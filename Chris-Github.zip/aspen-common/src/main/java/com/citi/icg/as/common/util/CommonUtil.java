package com.citi.icg.as.common.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;
import com.citi.icg.as.common.constants.CommonConstants;
import com.citi.icg.as.common.converter.ConversionSession;
import com.citi.icg.as.common.converter.Converter;
import com.citi.icg.as.common.converter.EntityConverter;
import com.citi.icg.as.config.reader.ConfigReader;
import com.citi.icg.as.config.reader.DefaultConfigReader;
import com.citi.icg.as.server.common.config.AspenPropertyPlaceHolderConfigurer;
import com.citi.icg.as.server.common.template.engine.FreeMarkerTemplateUtility;

@SuppressWarnings({"rawtypes", "unchecked"})
public class CommonUtil {

	private static final String UTC = "UTC";
	public static final String DELIMETER = "-";
	
	private static final Log LOG = LogFactory.getLog(CommonUtil.class);

	public static <S, T> EntityConverter<S, T> getConverter(Class<S> busClass, Class<T> domClass) {
		return ConversionSession.newSession().getConverter(busClass, domClass);
	}

	public static <S, T> Set<S> getCollection(EntityConverter<S, T> converter, List<T> list) {
		return converter.convertAllFrom(new HashSet<T>(list == null ? new ArrayList<T>(0) : list));
	}

	public static Date convertDate(Date date, TimeZone toTimeZone) {
		Calendar localCalendar = Calendar.getInstance(toTimeZone);
		localCalendar.setTime(date);
		Calendar utcCalendar = Calendar.getInstance(TimeZone.getTimeZone(UTC));

		int[] fieldsToUpdate = { Calendar.YEAR, Calendar.MONTH, Calendar.DAY_OF_MONTH, Calendar.HOUR_OF_DAY, Calendar.MINUTE, Calendar.SECOND, Calendar.MILLISECOND };

		for (int field : fieldsToUpdate) {
			utcCalendar.set(field, localCalendar.get(field));
		}

		return utcCalendar.getTime();
	}

	public static java.util.Date getDate(String strDate, String pattern) {
		try {
			if (StringUtils.isBlank(strDate) || StringUtils.isBlank(pattern)) {
				return null;
			}
			SimpleDateFormat sdf = new SimpleDateFormat(pattern);
			return sdf.parse(strDate);
		} catch (ParseException e) {
			throw new RuntimeException();
		}
	}

	public static String formatDate(java.util.Date dt, String pattern) {
		if (null == dt) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(dt);
	}
	
	public static int getDateIntValue(java.util.Date dt) {
		String dateStr = formatDate(dt, CommonConstants.FORMAT_STR);
		return Integer.parseInt(dateStr);
	}

	public static String removeLeadingZeros(String eventId) {
		return StringUtils.trim(eventId).replaceFirst("^0*", "");
	}

	public static <T extends Object> BaseBusinessEntity getBusinessObject(T object) {
		BaseBusinessEntity bean = null;

		if (object instanceof BaseBusinessEntity)
			return (BaseBusinessEntity) object;

		Class busClass = getBusinessClass(object.getClass());
		Class domClass = getDomainClass(object.getClass());
		EntityConverter converter = getConverter(busClass, domClass);
		bean = (BaseBusinessEntity) (converter == null ? Converter.getDestinationClass(object, busClass) : converter.convertFrom(object));
		return bean;

	}
	
	public static <T extends XMLConfiguration> T createConfigurationInstance(Class<T> clazz, ConfigReader<T> configReaderImpl) {
		try {
			T instance = CommonUtil.newInstance(clazz);

			ConfigReader<T> configReader = configReaderImpl;
			if(configReader == null){
				configReader = new DefaultConfigReader<T>();
			}
			InputStream configStream =  configReader.getConfigFileStream(clazz);
			instance.setDelimiterParsingDisabled(true);
			
			//Get the Bean here
			
			instance.load(configStream);
			return instance;
		} catch (ConfigurationException e) {
			LOG.error(e);
			throw new RuntimeException();
		}
	}
	
	/**
	 * @param clazz
	 * @param configReaderImpl
	 * @param model
	 * @return
	 * <p>This method returns the configuration by loading property file values using FreeMarker template Engine.
	 * The model parameter should contain all the property files, preferably obtained using {@link AspenPropertyPlaceHolderConfigurer}
	 */
	public static <T extends XMLConfiguration> T createDynamicConfigurationInstance(Class<T> clazz,
			ConfigReader<T> configReaderImpl, Map<String, ?> model) {
		try {
			T instance = CommonUtil.newInstance(clazz);

			ConfigReader<T> configReader = configReaderImpl;
			if (configReader == null) {
				configReader = new DefaultConfigReader<T>();
			}
			String configFile = configReader.getConfigName(clazz);

			String xmlWithPopulatedprops = FreeMarkerTemplateUtility.getInstance().processTemplateIntoString(configFile,
					model);

			instance.setDelimiterParsingDisabled(true);
			instance.load(new ByteArrayInputStream(xmlWithPopulatedprops.getBytes()));
			return instance;
		} catch (ConfigurationException e) {
			LOG.error(e);
			throw new RuntimeException(e);
		}
	}

	public static <T> T newInstance(Class<?> className){
		try {
			return  (T)className.newInstance();
		} catch (InstantiationException | IllegalAccessException e) {
			LOG.warn("Class :"+ className+ " can't be instantiated");
			throw new RuntimeException("Class :"+ className+ " can't be instantiated");
		}
	}
	

	private static Class getDomainClass(Class objClass) {
		try {
			Class domClass = null;
			if (objClass != null && (objClass.getName().contains("com.citi.icg.as.core.dao.entities.ext.beans.v2.") || objClass.getName().contains("com.citi.icg.as.core.dao.entities.ext.beans"))) {
				return objClass;
			}
			
			if(objClass!=null){
				domClass = Class.forName("com.citi.icg.as.core.dao.entities.ext.beans." + getClassName(objClass));
			}
			/*if (domClass == null) {
				return objClass;
			}*/
			return domClass;
		} catch (ClassNotFoundException e) {
			try {
				objClass = Class.forName("com.citi.icg.as.core.dao.entities.ext.beans." + getClassName(objClass));
			} catch (ClassNotFoundException e1) {
			}
		}

		return objClass;
	}

	private static Class getBusinessClass(Class objClass) {
		try {
			Class busClass=null;
			if(objClass!=null){
				 busClass = Class.forName("com.citi.icg.as.core.dao.entities.business." + getClassName(objClass));
			}
			/*if (busClass == null) {
				return objClass;
			}*/
			return busClass;
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	private static String getClassName(Class objClass) {
		String fullClassName = objClass.getName();
		String className = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
		return className;
	}
	
	public static boolean checkTwoDateEquals(Date date1, Date date2) {
		if (date1 == null && date2 == null) {
			return true;
		} else if (date1 != null && date2 != null) {
			int intValue1 = Integer.parseInt(formatDate(date1, CommonConstants.FORMAT_STR));
			int intValue2 = Integer.parseInt(formatDate(date2, CommonConstants.FORMAT_STR));
			return intValue1 == intValue2;
		} else {
			return false;
		}
	}
	
	public static boolean createFile(String destFileName) {
		File file = new File(destFileName);  
        if(file.exists()) {  
            LOG.error("create file " + destFileName + " error, file already exists");  
            return false;  
        }  
        if (destFileName.endsWith(File.separator)) {  
        	LOG.error("create file " + destFileName + " error. file name can't be a folder");  
            return false;  
        }  
        if(!file.getParentFile().exists()) {  
        	LOG.info("target folder does not exist. create the folder");  
            if(!file.getParentFile().mkdirs()) {  
            	LOG.error("error in creating folder");  
                return false;  
            }  
        }  
        try {  
            if (file.createNewFile()) {  
            	LOG.info("create file " + destFileName + "successfully");  
                return true;  
            } else {  
            	LOG.error("fail to create " + destFileName);  
                return false;  
            }  
        } catch (IOException e) {  
        	LOG.error("fail to create " + destFileName);
            return false;  
        }  
	}
}
