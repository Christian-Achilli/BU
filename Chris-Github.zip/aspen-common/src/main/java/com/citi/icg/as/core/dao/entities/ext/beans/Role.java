package com.citi.icg.as.core.dao.entities.ext.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseRole;

@Entity
@Table(name = "ROLES")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "hibernate.USER_PROFILE")
public class Role extends BaseRole {
	
	private static final long serialVersionUID = 4481082753132449510L;

	@Transient
	public RoleEntitlement addRoleEntitlement(Privilege privilege) {
		return addRoleEntitlement(privilege, null, null);
	}

	@Transient
	public RoleEntitlement addRoleEntitlement(Privilege privilege, String lastUpdatedBy, Date lastUpdatedDate) {
		if (privilege == null) {
			return null;
		}
		RoleEntitlement roleEntitlement = new RoleEntitlement();
		roleEntitlement.setPrivilege(privilege);
		lastUpdatedBy = (lastUpdatedBy == null ? "SYSTEM" : lastUpdatedBy);
		roleEntitlement.setLastUpdatedBy(lastUpdatedBy);
		lastUpdatedDate = (lastUpdatedDate == null ? new Date() : lastUpdatedDate);
		roleEntitlement.setLastUpdatedDate(lastUpdatedDate);
		roleEntitlement.setRole(this);
		this.getRoleEntitlements().add(roleEntitlement);
		return roleEntitlement;
	}
}
