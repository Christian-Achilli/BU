package com.citi.icg.as.server.service;

/**
 * @author ca85137
 *
 *Execute a service that returns T or any Exception.
 *
 * @param <T>
 */
public interface ServiceExecutor<T> {

	T execute() throws Exception;

}