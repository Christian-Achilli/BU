package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseFieldQualifier;

@Entity
@Table(name = "FIELD_QUALIFIER")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class FieldQualifier extends BaseFieldQualifier {

	private static final long serialVersionUID = -4949154329333234359L;

	@Override
	public String toString() {
		return "FieldQualifier [getFieldCode()=" + getFieldCode() + ", getFieldDesc()=" + getFieldDesc() + ", getFieldDisplayLabel()=" + getFieldDisplayLabel() + ", getLastUpdatedBy()="
				+ getLastUpdatedBy() + ", getLastUpdatedDate()=" + getLastUpdatedDate() + ", getIsoCode()=" + getIsoCode() + "]";
	}

}
