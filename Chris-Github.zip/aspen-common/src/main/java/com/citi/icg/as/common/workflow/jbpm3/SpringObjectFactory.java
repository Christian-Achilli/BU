package com.citi.icg.as.common.workflow.jbpm3;

import org.jbpm.configuration.ObjectFactory;
import org.jbpm.configuration.ObjectFactoryParser;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SpringObjectFactory  implements ObjectFactory, ApplicationContextAware  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4683319989793426099L;

	/** Spring container */
	private ApplicationContext applicationContext;
	
	/** Default jBPM object factory */
	private ObjectFactory jbpmObjectFactory;
	
	public SpringObjectFactory(String jbpmConfigFile) {
		this.jbpmObjectFactory = ObjectFactoryParser.parseResource(jbpmConfigFile);		
	}

	public Object createObject(String objectName) {
		if (applicationContext.containsBean(objectName)) {
			return applicationContext.getBean(objectName);
		} else if (jbpmObjectFactory.hasObject(objectName)) {
			return jbpmObjectFactory.createObject(objectName);
		} else {
			return null;
		}
	}

	public boolean hasObject(String objectName) {
		return applicationContext.containsBean(objectName) || jbpmObjectFactory.hasObject(objectName);
	}

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}
	
}
