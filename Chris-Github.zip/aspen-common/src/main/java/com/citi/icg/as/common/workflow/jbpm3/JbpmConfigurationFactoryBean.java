package com.citi.icg.as.common.workflow.jbpm3;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.jbpm.JbpmConfiguration;
import org.jbpm.JbpmContext;
import org.jbpm.configuration.ObjectFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

public class JbpmConfigurationFactoryBean implements FactoryBean<JbpmConfiguration>, InitializingBean, ApplicationListener<ContextClosedEvent> {

	/** Logger for this class. */
	private static final Log LOG = LogFactory.getLog(JbpmConfigurationFactoryBean.class);
	
	/** The singleton object that this factory produces */
	private JbpmConfiguration jbpmConfiguration;
	
	/** The jBPM object factory */
	private ObjectFactory objectFactory;
	
	/** Indicates whether the job executor must be started */
	private boolean startJobExecutor;
	
	/** The Hibernate session factory used by jBPM and the application */
	private SessionFactory sessionFactory;
	
	private static final String JBPM_CFG_XML = "jbpm.cfg.xml";
	
	/**
	 * Default constructor.
	 */
	public JbpmConfigurationFactoryBean() {
		
	}
	
	public JbpmConfiguration getObject() throws Exception {
		return jbpmConfiguration;
	}

	public Class getObjectType() {
		return JbpmConfiguration.class;
	}

	public boolean isSingleton() {
		return true;
	}

	public void afterPropertiesSet() throws Exception {
		
		LOG.info("All properties set. Initializing the jBPM configuration");
		
		// Create jbpm Config object
		JbpmConfiguration.Configs.setDefaultObjectFactory(objectFactory);
		jbpmConfiguration = JbpmConfiguration.parseResource(JBPM_CFG_XML);
				
		// Inject session factory
		JbpmContext ctx = null;
		try {
			 ctx = jbpmConfiguration.createJbpmContext();
			 ctx.setSessionFactory(sessionFactory);
			 LOG.info("SessionFactory injected in the jBPM config. jBPM will now use this session factory "
					 + "to create its Hibernate sessions");
		} finally {
			if (ctx != null) {
				ctx.close();
			}
		}
		
		// Start job executor if needed
		if (startJobExecutor) {
			LOG.info("Starting job executor ...");
			jbpmConfiguration.startJobExecutor();
			LOG.info("Job executor started.");
		}
	}
	
	@Override
	public void onApplicationEvent(ContextClosedEvent arg0) {
		jbpmConfiguration.getJobExecutor().stop();
	}
	
	public void setObjectFactory(ObjectFactory objectFactory) {
		this.objectFactory = objectFactory;
	}


	public void setStartJobExecutor(boolean startJobExecutor) {
		this.startJobExecutor = startJobExecutor;
	}
	
	public void setSessionfactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	
}
