package com.citi.icg.as.map;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.hibernate.collection.PersistentSet;

/**
 * Implementation of BeanMapper that will look for custom converters first, then will fall back to Dozer if no custom converters are found.
 *
 */
public class AspenBeanMapper implements BeanMapper {

	private DozerBeanMapper dozerMap;
		
	public AspenBeanMapper(){
		List<String> files= new ArrayList<String>();
//		files.add("dozer-custom-maps.xml");
		files.add("dozerBeanMapping.xml");
		dozerMap = new DozerBeanMapper(files);
	}
	
	@Override
	public <T> T map(Object entity, Class<T> targetClass) {
		if (entity != null) {
			return dozerMap.map(entity, targetClass);
		} else {
			return null;
		}
	}

	@Override
	public <T> Collection<T> mapAll(Collection<?> entities, Class<T> targetClass) {
		Collection<T> targetCol = null;
		try {
			if (entities instanceof PersistentSet) {
				targetCol = new HashSet();
			} else {
				targetCol = entities.getClass().newInstance();
			}
			for (Object e : entities) {
				targetCol.add(map(e, targetClass));
			}
		} catch (InstantiationException e1) {
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			e1.printStackTrace();
		}
		
		return targetCol;
	}

	
	
}
