package com.citi.icg.as.common.converter;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import com.citi.icg.toolkit.logger.IcgAppLogger;


public class Converter
{
	private static final GcasBeanMapper staticMapper = new GcasBeanMapper();
	private final Mapper instanceMapper;
	
	/**
	 * Create a new instance of converter. Each instance maintains a context
	 * of any objects (instances) already converted by this Converter. It should
	 * be reused when converting a collection of objects to prevent deep clones
	 * that would occur with the static implementation.
	 */
	public Converter()
	{
		instanceMapper = staticMapper.getMappingProcessor();
	}
	
	/**
	 * Convert the given source object to target instance. The conversion occurs
	 * with its own context and always results in a complete clone of the source
	 * object. When performing multiple transformations within a single RPC method
	 * this is almost certainly NOT what you want to do.
	 *
	 * @param <S>
	 * @param <D>
	 * @param source
	 * @param destType
	 * @return
	 */
	public static <S, D> D getDestinationClass(S source, Class<D> destType)
	{
		IcgAppLogger.debug(Converter.class, "Source class: " + source.getClass().getName());
		IcgAppLogger.debug(Converter.class, "Destination class: " + destType.getName());
	    return staticMapper.map(source, destType);
	}
	
	public static <S, D> void getDestinationEntity(S source, D destType)
	{
		IcgAppLogger.debug(Converter.class, "Source class: " + source.getClass().getName());
		IcgAppLogger.debug(Converter.class, "Destination class: " + destType.getClass().getName());
	    staticMapper.map(source, destType);
	}
	
	/**
	 * Convert the given source object to target. If method is invoked multiple
	 * times with the same instance, previous result is returned (regardless of
	 * if the object has been mutated). Additionally any objects referenced by
	 * this object will be checked in cache first.
	 * 
	 * The instance should be discarded after a complete unit of work.
	 * 
	 * @param <S>
	 * @param <D>
	 * @param source
	 * @param destType
	 * @return
	 */
	public <S, D> D getDestinationInstance(S source, Class<D> destType)
	{
		IcgAppLogger.debug(Converter.class, "Source class: " + source.getClass().getName());
		IcgAppLogger.debug(Converter.class, "Destination class: " + destType.getName());
	    return instanceMapper.map(source, destType);
	}

	/**
	 * Perform a conversion of the given map from. Conversion is done in a single
	 * scope, and will not result in a deep copy of each element where elements
	 * cross reference each-other.
	 * 
	 * @param <S>
	 * @param <D>
	 * @param map
	 * @param destType
	 * @return
	 */
	public static <S, D> Map<String, D> getDestinationMap(Map<String, S> map, Class<D> destType)
	{
		Converter conv = new Converter();
		Map<String, D> convertedMap = new LinkedHashMap<String, D>();
		
		for (Map.Entry<String, S> entry : map.entrySet())
		{
			convertedMap.put(entry.getKey(), conv.getDestinationInstance(entry.getValue(), destType));
		}

		return convertedMap;
	}

	/**
	 * Same as getDestinationMap, but for list see above.
	 * 
	 * @param <S>
	 * @param <D>
	 * @param srcList
	 * @param destType
	 * @return
	 */
	public static <S, D> List<D> getDestinationList(List<S> srcList, Class<D> destType)
	{
		Converter conv = new Converter();
		List<D> destList = new LinkedList<D>();

		for (S src : srcList)
		{
			destList.add(conv.getDestinationInstance(src, destType));
		}

		return (List<D>) destList;
	}

	/**
	 * Increase visibility on getMappingProcessor() - the instance
	 * level mapper implemented by Dozer.
	 *
	 */
	public static class GcasBeanMapper extends DozerBeanMapper
	{
		public GcasBeanMapper()
		{
			super(Arrays.asList("dozerBeanMapping.xml"));
		}
	
		@Override
		public Mapper getMappingProcessor()
		{
			return super.getMappingProcessor();
		}
	}
	
}
