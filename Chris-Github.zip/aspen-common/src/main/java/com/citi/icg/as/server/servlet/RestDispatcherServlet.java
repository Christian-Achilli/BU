/**
 * 
 */
package com.citi.icg.as.server.servlet;

import static com.citi.icg.as.server.common.config.AspenPropertyPlaceHolderConfigurer.ASPEN_ENV;
import static com.citi.icg.as.server.common.config.AspenPropertyPlaceHolderConfigurer.PROD_ENV;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * @author ap72338
 *         <p>
 *         This servlet should be configured in web.xml in all components
 *         wherever {@link RestController} is used. This will prevent servicing
 *         of Rest requests in production environment.
 *         </p>
 *
 */
public class RestDispatcherServlet extends DispatcherServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4166363311364695360L;

	@Override
	protected void doDispatch(HttpServletRequest request, HttpServletResponse response) throws Exception {

		//change to support different stream's prod
		if (System.getProperty(ASPEN_ENV, StringUtils.EMPTY).endsWith(PROD_ENV)) {
			response.sendError(HttpStatus.FORBIDDEN.value(), "Rest services are not available in this environment");
			return;
		}
		super.doDispatch(request, response);
	}

}
