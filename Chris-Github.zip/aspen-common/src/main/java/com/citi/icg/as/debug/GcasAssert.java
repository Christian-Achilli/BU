package com.citi.icg.as.debug;

import com.citi.icg.as.exception.GcasAssertError;

/**
 * This class provides convenience methods for performing assertions to ensure code validity.
 */
public final class GcasAssert
{
	// --- Constructor(s) ---

	/**
	 * Constructs an GcasAssert.
	 */
	private GcasAssert()
	{
	}

	// --- Static Methods ---

	/**
	 * Checks that the specified value is not null.
	 */
	public static void notNull(Object value, String name) throws GcasAssertError
	{
		if (value == null) {
			throw new GcasAssertError(name + " can not be specified as null.");
		}
	}

	/**
	 * Checks that the specified value is not null or blank.
	 */
	public static void notNullOrBlank(String value, String name) throws GcasAssertError
	{
		notNull(value, name);

		if (value.trim().length() == 0) {
			throw new GcasAssertError(name + " can not be specified as blank.");
		}
	}

	/**
	 * Checks that the specified array is not null or empty.
	 */
	public static void notNullOrEmpty(Object[] array, String name) throws GcasAssertError
	{
		notNull(array, name);

		if (array.length == 0) {
			throw new GcasAssertError(name + " can not be specified as an empty array.");
		}
	}

	/**
	 * Checks that the specified array is not null or empty.
	 */
	public static void notNullOrEmpty(byte[] array, String name) throws GcasAssertError
	{
		notNull(array, name);

		if (array.length == 0) {
			throw new GcasAssertError(name + " can not be specified as an empty array.");
		}
	}

	/**
	 * Checks that the specified array is not null or empty.
	 */
	public static void notNullOrEmpty(short[] array, String name) throws GcasAssertError
	{
		notNull(array, name);

		if (array.length == 0) {
			throw new GcasAssertError(name + " can not be specified as an empty array.");
		}
	}

	/**
	 * Checks that the specified array is not null or empty.
	 */
	public static void notNullOrEmpty(int[] array, String name) throws GcasAssertError
	{
		notNull(array, name);

		if (array.length == 0) {
			throw new GcasAssertError(name + " can not be specified as an empty array.");
		}
	}

	/**
	 * Checks that the specified array is not null or empty.
	 */
	public static void notNullOrEmpty(long[] array, String name) throws GcasAssertError
	{
		notNull(array, name);

		if (array.length == 0) {
			throw new GcasAssertError(name + " can not be specified as an empty array.");
		}
	}

	/**
	 * Checks that the specified array is not null or empty.
	 */
	public static void notNullOrEmpty(float[] array, String name) throws GcasAssertError
	{
		notNull(array, name);

		if (array.length == 0) {
			throw new GcasAssertError(name + " can not be specified as an empty array.");
		}
	}

	/**
	 * Checks that the specified array is not null or empty.
	 */
	public static void notNullOrEmpty(double[] array, String name) throws GcasAssertError
	{
		notNull(array, name);

		if (array.length == 0) {
			throw new GcasAssertError(name + " can not be specified as an empty array.");
		}
	}

	/**
	 * Checks that the specified value is a positive integer.
	 */
	public static void positiveInteger(Integer value, String name) throws GcasAssertError
	{
		notNull(value, name);
		positiveInteger(value.intValue(), name);
	}

	/**
	 * Checks that the specified value is a positive integer.
	 */
	public static void positiveInteger(int value, String name) throws GcasAssertError
	{
		if (value <= 0) {
			throw new GcasAssertError(name + " must be a positive integer (i.e. greater than zero).");
		}
	}

	/**
	 * Checks that the specified value is a non-negative integer.
	 */
	public static void nonNegativeInteger(Integer value, String name) throws GcasAssertError
	{
		notNull(value, name);
		nonNegativeInteger(value.intValue(), name);
	}

	/**
	 * Checks that the specified value is a non-negative integer.
	 */
	public static void nonNegativeInteger(int value, String name) throws GcasAssertError
	{
		if (value < 0) {
			throw new GcasAssertError(name + " must be an integer greater than or equal to zero.");
		}
	}

	/**
	 * Checks that the specified value is a positive number.
	 */
	public static void positiveNumber(Number value, String name) throws GcasAssertError
	{
		notNull(value, name);

		if (value.doubleValue() <= 0) {
			throw new GcasAssertError(name + " must be a positive long number (i.e. greater than zero).");
		}
	}

	/**
	 * Checks that the specified value is a positive number.
	 */
	public static void positiveNumber(double value, String name) throws GcasAssertError
	{
		if (value <= 0) {
			throw new GcasAssertError(name + " must be a positive long number (i.e. greater than zero).");
		}
	}

	/**
	 * Checks that the specified value is within the specified range.
	 */
	public static void inRange(long value, long start, long end, String name) throws GcasAssertError
	{
		if (value < start || value > end) {
			throw new GcasAssertError(name + " must be between " + start + " and " + end + ".");
		}
	}

	/**
	 * Checks that the specified value is within the specified range.
	 */
	public static void inRange(Integer value, int start, int end, String name) throws GcasAssertError
	{
		notNull(value, name);

		if (value.intValue() < start || value.intValue() > end) {
			throw new GcasAssertError(name + " must be between " + start + " and " + end + ".");
		}
	}

	/**
	 * Checks that the specified value is within the specified array's bounds.
	 */
	public static void withinBounds(int value, byte[] array, String name) throws GcasAssertError
	{
		GcasAssert.notNull(array, name);

		if (value < 0 || value >= array.length) {
			throw new GcasAssertError(name + " is out of array bounds.");
		}
	}

	/**
	 * Checks that the specified value is within the specified array's bounds.
	 */
	public static void withinBounds(int value, short[] array, String name) throws GcasAssertError
	{
		GcasAssert.notNull(array, name);

		if (value < 0 || value >= array.length) {
			throw new GcasAssertError(name + " is out of array bounds.");
		}
	}

	/**
	 * Checks that the specified value is within the specified array's bounds.
	 */
	public static void withinBounds(int value, int[] array, String name) throws GcasAssertError
	{
		GcasAssert.notNull(array, name);

		if (value < 0 || value >= array.length) {
			throw new GcasAssertError(name + " is out of array bounds.");
		}
	}

	/**
	 * Checks that the specified value is within the specified array's bounds.
	 */
	public static void withinBounds(int value, long[] array, String name) throws GcasAssertError
	{
		GcasAssert.notNull(array, name);

		if (value < 0 || value >= array.length) {
			throw new GcasAssertError(name + " is out of array bounds.");
		}
	}

	/**
	 * Checks that the specified value is within the specified array's bounds.
	 */
	public static void withinBounds(int value, float[] array, String name) throws GcasAssertError
	{
		GcasAssert.notNull(array, name);

		if (value < 0 || value >= array.length) {
			throw new GcasAssertError(name + " is out of array bounds.");
		}
	}

	/**
	 * Checks that the specified value is within the specified array's bounds.
	 */
	public static void withinBounds(int value, double[] array, String name) throws GcasAssertError
	{
		GcasAssert.notNull(array, name);

		if (value < 0 || value >= array.length) {
			throw new GcasAssertError(name + " is out of array bounds.");
		}
	}

	/**
	 * Checks that the specified value is within the specified array's bounds.
	 */
	public static void withinBounds(int value, Object[] array, String name) throws GcasAssertError
	{
		GcasAssert.notNullOrEmpty(array, "Array referenced by " + name);

		if (value < 0 || value >= array.length) {
			throw new GcasAssertError(name + " is out of array bounds.");
		}
	}

	/**
	 * Checks that the specified value is an instance of the given class.
	 */
	public static void instanceOf(Object value, Class<?> cls, String name) throws GcasAssertError
	{
		notNull(value, name);
		notNull(cls, "Class To Check For Instance-Of");
		if (!cls.isAssignableFrom(value.getClass())) {
			throw new GcasAssertError(name + " is not an instance of " + cls.getName());
		}
	}

}
