package com.citi.icg.as.common.client.util;

import com.google.gwt.core.client.GWT;

/**
 * more printing functionality can implement in future.
 * 
 * @author yy31798
 *
 */
abstract class PdfPrintHandler {
	static final PdfPrintHandler impl = GWT.create(PdfPrintHandler.class);

	public abstract void print(String url);

}
