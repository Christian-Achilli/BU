package com.citi.icg.as.common.workflow.jbpm3;

import org.jbpm.JbpmContext;

public interface JbpmCallback<T> {
	T doCallback(JbpmContext context);
}
