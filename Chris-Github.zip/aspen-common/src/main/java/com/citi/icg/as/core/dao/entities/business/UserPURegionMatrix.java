package com.citi.icg.as.core.dao.entities.business;

import java.io.Serializable;
import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class UserPURegionMatrix extends BaseBusinessEntity {

	private static final long serialVersionUID = -3000262786408897521L;
	
	private int userPURegionMatrixId;
	private User user;
	private UserProcessingUnit userProcessingUnit;
	private UserRegion userRegion;
	private Date lastUpdatedDate;
	private String updatedBy;
	


	public int getUserPURegionMatrixId() {
		return userPURegionMatrixId;
	}



	public void setUserPURegionMatrixId(int userPURegionMatrixId) {
		this.userPURegionMatrixId = userPURegionMatrixId;
	}



	public User getUser() {
		return user;
	}



	public void setUser(User user) {
		this.user = user;
	}


	public UserProcessingUnit getUserProcessingUnit() {
		return userProcessingUnit;
	}



	public void setUserProcessingUnit(UserProcessingUnit userProcessingUnit) {
		this.userProcessingUnit = userProcessingUnit;
	}



	public UserRegion getUserRegion() {
		return userRegion;
	}



	public void setUserRegion(UserRegion userRegion) {
		this.userRegion = userRegion;
	}



	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}



	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}



	public String getUpdatedBy() {
		return updatedBy;
	}



	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	@Override
	public Serializable getId() {
		return getUserPURegionMatrixId();
	}

}
