package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

@MappedSuperclass
@Table(name = "FIELD_QUALIFIER", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseFieldQualifier extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = -5631213042295911827L;
	private String fieldCode;
	private String fieldDisplayLabel;
	private String fieldDesc;
	private String fieldType;
	private Integer fieldUsageCode;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String isoCode;

	public BaseFieldQualifier() {
	}

	public BaseFieldQualifier(String fieldCode, String fieldName, String fieldDisplayLabel, String swiftCode, String isoCode, String lastUpdatedBy, Date lastUpdatedDate) {
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BaseFieldQualifier(String fieldCode, String fieldName, String fieldDisplayLabel, String fieldDesc, String swiftCode, String isoCode, Integer fieldUsageCode, String lastUpdatedBy,
			Date lastUpdatedDate) {
		this.fieldCode = fieldCode;
		this.fieldDisplayLabel = fieldDisplayLabel;
		this.fieldDesc = fieldDesc;
		this.isoCode = isoCode;
		this.fieldUsageCode = fieldUsageCode;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.isoCode = isoCode;

	}

	@Id
	@Column(name = "FIELD_CODE", unique = true, length = 50, nullable = false)
	public String getFieldCode() {
		return this.fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	@Column(name = "FIELD_DISPLAY_LABEL", length = 100, nullable = false)
	public String getFieldDisplayLabel() {
		return this.fieldDisplayLabel;
	}

	public void setFieldDisplayLabel(String fieldDisplayLabel) {
		this.fieldDisplayLabel = fieldDisplayLabel;
	}

	@Column(name = "FIELD_DESC", length = 500)
	public String getFieldDesc() {
		return this.fieldDesc;
	}

	public void setFieldDesc(String fieldDesc) {
		this.fieldDesc = fieldDesc;
	}

	@Column(name = "FIELD_TYPE", length = 100, nullable = false)
	public String getFieldType() {
		return this.fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	@Column(name = "ISO_CODE", length = 4)
	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	@Column(name = "LAST_UPDATED_BY", nullable = false, length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Column(name = "FIELD_USAGE_CODE", nullable = false, length = 1)
	public Integer getFieldUsageCode() {
		return fieldUsageCode;
	}

	public void setFieldUsageCode(Integer fieldUsageCode) {
		this.fieldUsageCode = fieldUsageCode;
	}
}