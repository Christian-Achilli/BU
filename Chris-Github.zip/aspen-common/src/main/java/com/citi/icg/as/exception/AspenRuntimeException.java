package com.citi.icg.as.exception;

import com.google.gwt.user.client.rpc.IsSerializable;


@SuppressWarnings("serial")
public class AspenRuntimeException extends RuntimeException implements IsSerializable {

	protected ErrorType errorLevel;
	protected String details;

	public AspenRuntimeException() {
		super();
	}

	public AspenRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}
	public AspenRuntimeException(String message,ErrorType errorLevel) {
		super(message);
		this.errorLevel = errorLevel;
	}
	public AspenRuntimeException(String message) {
		super(message);
	}

	public AspenRuntimeException(String message, Throwable cause, ErrorType errorLevel) {
		super(message, cause);
		this.errorLevel = errorLevel;
	}

	public AspenRuntimeException(String message, String stackDetails, ErrorType errorLevel) {
		super(message);
		this.details = stackDetails;
		this.errorLevel = errorLevel;
	}

	public ErrorType getErrorLevel() {
		return errorLevel;
	}

	public void setErrorLevel(ErrorType errorLevel) {
		this.errorLevel = errorLevel;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getDetails() {
		return details;
	}
}
