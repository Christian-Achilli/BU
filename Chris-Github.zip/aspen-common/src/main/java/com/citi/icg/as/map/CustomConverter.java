package com.citi.icg.as.map;

public interface CustomConverter<T, S> {

	T convert(S entity);
	
}
