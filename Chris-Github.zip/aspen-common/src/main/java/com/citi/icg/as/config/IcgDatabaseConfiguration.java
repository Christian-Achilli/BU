package com.citi.icg.as.config;

import java.util.Map;

import com.citi.icg.as.common.util.CommonUtil;
import com.citi.icg.toolkit.config.IcgConfigUtil;
import com.citi.icg.toolkit.config.IcgConfiguration;
import com.citi.icg.toolkit.config.IcgConfigurationError;
import com.citi.icg.toolkit.debug.IcgAssert;
import com.citi.icg.toolkit.exception.IcgException;

/**
 * This class represents the configuration for the database(s). The
 * configuration data for setting up database connections is organized by
 * defining an optional set of driver wrappers using {@link IcgDriver} and a set
 * of database connection datasources.
 * 
 * @see IcgDriver
 * @see IcgConnection
 */
public class IcgDatabaseConfiguration extends IcgConfiguration
{
	// --- Static Variables ---

	/** Singleton instance of this class. */
	private static IcgDatabaseConfiguration singleton;

	/** Configuration name. */
	private static final String CONFIGURATION_NAME = "database";

	/** List of driver wrappers. */
	public static final String DRIVERS = "driver-wrappers.driver-wrapper";

	/** Driver wrapper name. */
	public static final String DRIVER_NAME = "name";

	/** Driver wrapper name. */
	public static final String DRIVER_TYPE_NAME = "driver-name";

	/** Driver class. */
	public static final String DRIVER_CLASS = "driver-class";

	/** List of database datasources. */
	public static final String datasources = "datasources.datasource";

	/** Database datasource name. */
	public static final String DATASOURCE_NAME = "name";

	/** Database URL. */
	public static final String URL = "url";

	/** Database username. */
	public static final String USERNAME = "username";

	/** Database password. */
	public static final String PASSWORD = "password";

	/** Prefix for pool configuration. */
	public static final String POOL_CONFIG_PREFIX = "pool-config.";

	/** Max size of pool. */
	public static final String MAX_SIZE = "max-size";

	/** Min number of idle connections to maintain in pool. */
	public static final String MIN_IDLE = "min-idle";

	/** Max number of idle connections to allow in pool. */
	public static final String MAX_IDLE = "max-idle";

	/** Action when borrowing from exhausted pool. */
	public static final String WHEN_EXHAUSTED_ACTION = "when-exhausted-action";

	/** Action: Fail when borrowing from exhausted pool. */
	public static final String EXHAUSTED_ACTION_FAIL = "fail";

	/** Action: Block when borrowing from exhausted pool. */
	public static final String EXHAUSTED_ACTION_BLOCK = "block";

	/** Action: Grow when borrowing from exhausted pool. */
	public static final String EXHAUSTED_ACTION_GROW = "grow";

	/** Max time to block when borrowing from exhausted pool. */
	public static final String MAX_BLOCK_WAIT_TIME = "max-block-wait-time";

	/** Validation query to test connections. */
	public static final String VALIDATION_QUERY = "validation-query";
	
	/** Validation to be done on startup time. */
	public static final String VALIDATION_ON_STARTUP = "validate-on-startup";

	/** Flag indicating if connections should be tested when borrowed. */
	public static final String TEST_ON_BORROW = "test-on-borrow";

	/** Flag indicating if connections should be tested when returned. */
	public static final String TEST_ON_RETURN = "test-on-return";

	/** Flag indicating if idle connections are tested. */
	public static final String TEST_IDLE = "test-idle";

	/** Time between checks of idle connections. */
	public static final String IDLE_CHECK_RUN_INTERVAL = "idle-check-run-interval";

	/**
	 * Number of items from pool to check during idle checks. Negative number
	 * means fraction of idle objects (1/x).
	 */
	public static final String IDLE_CHECK_NUMBER_ITEMS = "idle-check-number-items";

	/** Max time a connection can remain idle. */
	public static final String MAX_IDLE_TIME = "max-idle-time";

	// --- Static Methods ---
	/**
	 * Retrieves an instance of this configuration.
	 */
	public static IcgDatabaseConfiguration getInstance() throws IcgException
	{
		return singleton;
	}
	
	public static IcgDatabaseConfiguration createInstance(Map<String,String>properties){		
		if(singleton == null){
			singleton = CommonUtil.createDynamicConfigurationInstance(IcgDatabaseConfiguration.class, null,properties);
		}
		return singleton;
	}

	// --- Instance Methods ---

	@Override
	public String getConfigurationName()
	{
		return CONFIGURATION_NAME;
	}

	@Override
	public String[] getRequiredEntries()
	{
		return new String[] {};
	}

	/**
	 * Retrieves the driver wrapper names.
	 */
	public String[] getDriverNames()
	{
		return getStringArray(DRIVERS + "." + DRIVER_NAME);
	}

	/**
	 * Retrieves the index of the driver specified.
	 */
	private int getDriverIndex(String name)
	{
		IcgAssert.notNullOrBlank(name, "Driver Name");

		String[] drivers = getDriverNames();
		for (int ctr = 0; ctr < drivers.length; ctr++)
		{
			if (name.equals(drivers[ctr]))
				return ctr;
		}

		return -1;
	}

	/**
	 * Retrieves the driver for the specified datasource.
	 */
	public String getDriverClass(String name) throws IcgConfigurationError
	{
		int index = getDriverIndex(name);
		if (index == -1)
			throw new IcgConfigurationError("Failed to find driver with name: " + name);

		return getString(DRIVERS + "(" + index + ")." + DRIVER_CLASS);
	}

	/**
	 * Retrieves the list of datasource names;
	 */
	public String[] getDataSourceNames()
	{
		return getStringArray(datasources + "." + DATASOURCE_NAME);
	}

	/**
	 * Retrieves the index of the datasource specified.
	 */
	private int getDataSourceIndex(String datasource)
	{
		IcgAssert.notNullOrBlank(datasource, "DataSource Name");

		String[] datasources = getDataSourceNames();
		for (int ctr = 0; ctr < datasources.length; ctr++)
		{
			if (datasource.equals(datasources[ctr]))
				return ctr;
		}

		return -1;
	}

	/**
	 * Retrieves the driver for the specified datasource.
	 */
	public String getDataSourceDriverClass(String name) throws IcgConfigurationError
	{
		int index = getDataSourceIndex(name);
		if (index == -1)
			throw new IcgConfigurationError("DataSource configuration is missing required entry for driver class: " + name);

		return getString(datasources + "(" + index + ")." + DRIVER_CLASS);
	}

	/**
	 * Retrieves the database URL for the specified DataSource.
	 */
	public String getDataSourceUrl(String name) throws IcgConfigurationError
	{
		int index = getDataSourceIndex(name);
		if (index == -1)
			throw new IcgConfigurationError("DataSource configuration is missing required entry for URL: " + name);

		return getString(datasources + "(" + index + ")." + URL);
	}

	/**
	 * Retrieves the database username for the specified DataSource.
	 */
	public String getDataSourceUsername(String dataSource)
	{
		int index = getDataSourceIndex(dataSource);
		if (index == -1)
			return null;

		return getString(datasources + "(" + index + ")." + USERNAME);
	}

	/**
	 * Retrieves the database password for the specified pool.
	 */
	public String getDataSourcePassword(String datasource)
	{
		int index = getDataSourceIndex(datasource);
		if (index == -1)
			return null;

		return getString(datasources + "(" + index + ")." + PASSWORD);
	}

	/**
	 * Retrieves the pool configuration key.
	 */
	private String getPoolConfigKey(String datasource, String setting)
	{
		String key = null;
		int index = getDataSourceIndex(datasource);
		if (index != -1)
		{
			key = datasources + "(" + index + ")." + POOL_CONFIG_PREFIX + setting;
			if (this.containsKey(key) == false)
				key = null;
		}

		return key;
	}

	/**
	 * Retrieves the max size of the connection pool.
	 */
	public int getMaxSize(String pool)
	{
		String key = getPoolConfigKey(pool, MAX_SIZE);
		if (key == null)
			return -1;

		return getInteger(key, new Integer(0)).intValue();
	}

	/**
	 * Retrieves the min number of idle connections to maintain in pool.
	 */
	public int getMinIdle(String pool)
	{
		String key = getPoolConfigKey(pool, MIN_IDLE);
		if (key == null)
			return 0;

		return getInteger(key, new Integer(0)).intValue();
	}

	/**
	 * Retrieves the max number of idle connections to allow in pool.
	 */
	public int getMaxIdle(String pool)
	{
		String key = getPoolConfigKey(pool, MAX_IDLE);
		if (key == null)
			return 0;

		return getInteger(key, new Integer(0)).intValue();
	}

	/**
	 * Retrieves the action to take when borrowing from exhausted pool.
	 */
	public String getWhenExhaustedAction(String pool)
	{
		String key = getPoolConfigKey(pool, WHEN_EXHAUSTED_ACTION);
		if (key == null)
			return EXHAUSTED_ACTION_BLOCK;

		return getString(key, EXHAUSTED_ACTION_BLOCK);
	}

	/**
	 * Retrieves the max time to block when borrowing from exhausted pool.
	 */
	public int getMaxBlockWaitTime(String pool)
	{
		String key = getPoolConfigKey(pool, MAX_BLOCK_WAIT_TIME);
		if (key == null)
			return 10 * 1000;

		return getInteger(key, new Integer(0)).intValue();
	}

	/**
	 * Retrieves the validation query to test connections.
	 */
	public String getValidationQuery(String pool)
	{
		String key = getPoolConfigKey(pool, VALIDATION_QUERY);
		if (key == null)
			return null;

		return getString(key);
	}
	
	/**
	 * Retrieves the value for validation on startup to test connections.
	 */
	public boolean getValidationOnStartup(String pool)
	{
		String key = getPoolConfigKey(pool, VALIDATION_ON_STARTUP);
		if (key == null)
			return false;

		return getBoolean(key);
	}

	/**
	 * Indicates if connections should be tested when borrowed.
	 */
	public boolean shouldTestOnBorrow(String pool)
	{
		String key = getPoolConfigKey(pool, TEST_ON_BORROW);
		if (key == null)
			return false;

		return getBoolean(key, false);
	}

	/**
	 * Indicates if connections should be tested when returned.
	 */
	public boolean shouldTestOnReturn(String pool)
	{
		String key = getPoolConfigKey(pool, TEST_ON_RETURN);
		if (key == null)
			return false;

		return getBoolean(key, false);
	}

	/**
	 * Indicates if if idle connections are tested.
	 */
	public boolean shouldTestIdle(String pool)
	{
		String key = getPoolConfigKey(pool, TEST_IDLE);
		if (key == null)
			return true;

		return getBoolean(key, true);
	}

	/**
	 * Retrieves the time between checks of idle connections (in milliseconds).
	 */
	public long getIdleCheckRunInterval(String pool)
	{
		String key = getPoolConfigKey(pool, IDLE_CHECK_RUN_INTERVAL);
		if (key == null)
			return 60 * 1000;

		return getLong(key, new Long(60 * 1000)).intValue();
	}

	/**
	 * Retrieves the number of items from pool to check during idle checks.
	 * Negative number means fraction of idle objects (1/x).
	 */
	public int getIdleCheckNumberItems(String pool)
	{
		String key = getPoolConfigKey(pool, IDLE_CHECK_NUMBER_ITEMS);
		if (key == null)
			return -1;

		return getInteger(key, new Integer(-1)).intValue();
	}

	/**
	 * Retrieves the max time a connection can remain idle.
	 */
	public long getMaxIdleTime(String pool)
	{
		String key = getPoolConfigKey(pool, MAX_IDLE_TIME);
		if (key == null)
			return -1;

		return getLong(key, new Long(-1)).intValue();
	}

}
