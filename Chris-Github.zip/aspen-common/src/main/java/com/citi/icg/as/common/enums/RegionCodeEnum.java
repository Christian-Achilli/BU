package com.citi.icg.as.common.enums;

/**
 * Region Codes display names.
 */
public enum RegionCodeEnum {
	// CHECKSTYLE:OFF

	NAM("North America"), EMEA("Europe, Middle-East & Africa"), ASPAC("Asia-Pacific: Hong Kong"), APAC("Asia-Pacific: Australia"), UTC("Universal Time"), UNKNOWN("Unknown");

	// CHECKSTYLE:ON

	private String displayName;

	private RegionCodeEnum(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String toString() {
		return this.displayName;
	}
}
