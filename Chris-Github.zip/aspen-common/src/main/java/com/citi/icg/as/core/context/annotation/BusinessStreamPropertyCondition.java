/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import static com.citi.icg.as.common.constants.CommonConstants.SYSTEM_BUSINESS_STREAM_PROPERTY;
import static org.apache.commons.lang.StringUtils.EMPTY;
import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.trimToEmpty;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * @author AP72338 This class implements {@link Condition} to match a value as
 *         given in {@link Conditional}. The class checks the business stream
 *         property of the application against the System property "stream". The
 *         application can provide system property using
 *         -Dstream=custody/markets etc
 */
public class BusinessStreamPropertyCondition implements Condition {

	private final static Logger logger = Logger.getLogger(BusinessStreamPropertyCondition.class);

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalSystemStream.class.getName());
		String systemPropertyValue = trimToEmpty((String) attributes.get("value"));

		String systemConfigurationValue = System.getProperty(SYSTEM_BUSINESS_STREAM_PROPERTY, EMPTY);

		if (isBlank(systemConfigurationValue)) {
			logger.warn("######### System property " + SYSTEM_BUSINESS_STREAM_PROPERTY
					+ " has not been provided. This may have undesirable results, as spring dependencies will fail #########");
		}
		return systemConfigurationValue.equalsIgnoreCase(systemPropertyValue);
	}

}
