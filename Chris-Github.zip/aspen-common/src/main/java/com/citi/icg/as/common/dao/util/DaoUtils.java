package com.citi.icg.as.common.dao.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;
import com.citi.icg.as.common.converter.ConversionSession;
import com.citi.icg.as.common.converter.Converter;
import com.citi.icg.as.common.converter.EntityConverter;

@SuppressWarnings({"rawtypes", "unchecked"})
public final class DaoUtils {
	private static final String UTC = "UTC";

	public static <S, T> EntityConverter<S, T> getConverter(Class<S> busClass, Class<T> domClass) {
		return ConversionSession.newSession().getConverter(busClass, domClass);
	}

	public static <S, T> Set<S> getCollection(EntityConverter<S, T> converter, List<T> list) {
		return converter.convertAllFrom(new HashSet<T>(list == null ? new ArrayList<T>(0) : list));
	}

	public static Date convertDate(Date date, TimeZone toTimeZone) {
		Calendar localCalendar = Calendar.getInstance(toTimeZone);
		localCalendar.setTime(date);
		Calendar utcCalendar = Calendar.getInstance(TimeZone.getTimeZone(UTC));

		int[] fieldsToUpdate = { Calendar.YEAR, Calendar.MONTH, Calendar.DAY_OF_MONTH, Calendar.HOUR_OF_DAY, Calendar.MINUTE, Calendar.SECOND, Calendar.MILLISECOND };

		for (int field : fieldsToUpdate) {
			utcCalendar.set(field, localCalendar.get(field));
		}

		return utcCalendar.getTime();
	}

	public static java.util.Date getDate(String strDate, String pattern) throws ParseException {
		if (StringUtils.isBlank(strDate) || StringUtils.isBlank(pattern)) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.parse(strDate);
	}

	public static String formatDate(java.util.Date dt, String pattern) {
		if (null == dt) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(dt);
	}

	public static String removeLeadingZeros(String eventId) {
		return StringUtils.trim(eventId).replaceFirst("^0*", "");
	}

	public static <T extends Object> BaseBusinessEntity getBusinessObject(T object) {
		BaseBusinessEntity bean = null;

		if (object instanceof BaseBusinessEntity)
			return (BaseBusinessEntity) object;

		Class busClass = getBusinessClass(object.getClass());
		Class domClass = getDomainClass(object.getClass());
		EntityConverter converter = DaoUtils.getConverter(busClass, domClass);
		bean = (BaseBusinessEntity) (converter == null ? Converter.getDestinationClass(object, busClass) : converter.convertFrom(object));
		return bean;

	}

	private static Class getDomainClass(Class objClass) {
		try {
			Class domClass = null;
			if (objClass != null && (objClass.getName().contains("com.citi.icg.as.core.dao.entities.ext.beans.v2.") || objClass.getName().contains("com.citi.icg.as.core.dao.entities.ext.beans"))) {
				return objClass;
			}
			if(objClass!=null){
				domClass = Class.forName("com.citi.icg.as.core.dao.entities.ext.beans." + getClassName(objClass));
			}
			/*if (domClass == null) {
				return objClass;
			}*/
			return domClass;
		} catch (ClassNotFoundException e) {
			try {
				objClass = Class.forName("com.citi.icg.as.core.dao.entities.ext.beans." + getClassName(objClass));
			} catch (ClassNotFoundException e1) {
			}
		}

		return objClass;
	}

	private static Class getBusinessClass(Class objClass) {
		try {
			Class busClass = Class.forName("com.citi.icg.as.core.dao.entities.business." + getClassName(objClass));
			/*if (busClass == null) {
				return objClass;
			}*/
			return busClass;
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	private static String getClassName(Class objClass) {
		String fullClassName = objClass.getName();
		String className = fullClassName.substring(fullClassName.lastIndexOf(".") + 1);
		return className;
	}
}
