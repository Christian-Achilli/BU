package com.citi.icg.as.server.util;

import java.io.File;
import java.net.InetAddress;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.config.EmailSupportConfiguration;
import com.citi.icg.as.server.GcasRequestContext;
import com.citi.icg.as.util.GcasEnvironment;

/**
 * Utility class to send email notifications.
 */
public final class GcasMailUtil
{
	private static final Log LOG = LogFactory.getLog(GcasMailUtil.class);
	private static final String MIME_TEXT_PLAIN = "text/plain";
	private static final String MIME_TEXT_HTML = "text/html";
	private static final String MIME_BINARY_MULTIPART = "application/octet-stream";

	/** Port. */
	private static final Integer PORT = Integer.valueOf(25);

	/** SMTP host. */
	private static final String SMTP_HOST = "mail.smtp.host";

	/** SMTP host. */
	private static final String SMTP_PORT = "mail.smtp.port";

	private GcasMailUtil()
	{

	}

	@Deprecated
	/** @deprecated as of 1.6. Use version with java.util.loggin.Level */
	public static void notifySupport(String subject, String message)
	{
		notifySupport(Level.INFO, subject, message, null);
	}

	@Deprecated
	/** @deprecated as of 1.6. Use version with java.util.loggin.Level */
	public static void notifySupport(String subject, String message, Throwable ex)
	{
		notifySupport(Level.INFO, subject, message, ex);
	}

	public static void notifySupport(Level level, String subject, String message)
	{
		notifySupport(level, subject, message, null);
	}

	public static void notifySupport(Level level, String subject, String message, Throwable ex)
	{

		String[] recipents = new String[] { EmailSupportConfiguration.getInstance().getSupportEmail() };

		String envSubStr = addEnvInSubject(level, subject);

		StringBuilder envMessage = new StringBuilder();
		envMessage.append(message);
		if (ex != null)
		{
			envMessage.append("\nCause: " + ex.getCause());
			envMessage.append("\nMessage: " + ex.getLocalizedMessage());
			envMessage.append("\nStack Trace: " + ExceptionUtil.getStackTrace(ex));
		}
		if (!EmailSupportConfiguration.getInstance().getSupportEmailDisabled())
		{
			sendMail(recipents, EmailSupportConfiguration.getInstance().getSupportEmail(), envSubStr, envMessage.toString(), false);
		}
		else
		{
			LOG.error("Support Notification: " + envSubStr + envMessage.toString());
		}
	}

	@Deprecated
	/** @deprecated as of 1.6. Use version with java.util.loggin.Level */
	public static String addEnvInSubject(String subject)
	{
		return addEnvInSubject(Level.INFO, subject);
	}

	public static String addEnvInSubject(Level level, String subject)
	{
		StringBuilder envSubject = new StringBuilder();
		envSubject.append(EmailSupportConfiguration.getInstance().getApplicationName() + ':');
		try
		{
			envSubject.append('[' + StringUtils.upperCase(GcasEnvironment.getEnvironment()) + ':' + level + ':'
					+ InetAddress.getLocalHost().getHostName() + ']');
		}
		catch (Exception e)
		{
			LOG.debug(e.getMessage());
		}
		envSubject.append('[' + GcasRequestContext.getUserId() + ']');
		envSubject.append(subject);
		return envSubject.toString();
	}

	public static void sendMailFromSupport(String[] recipents, String subject, String message, boolean htmlFormat)
	{
		sendMail(recipents, EmailSupportConfiguration.getInstance().getSupportEmail(), subject, message, htmlFormat);
	}

	public static void sendMail(String[] recipents, String from, String subject, String message)
	{
		sendMail(recipents, from, subject, message, false);
	}

	public static void sendMailFromSupport(String[] recipents, String subject, String message, File attachment)
	{
		sendMail(recipents, EmailSupportConfiguration.getInstance().getSupportEmail(), subject, message, false, attachment);
	}

	public static void sendMail(String[] recipents, String from, String subject, String message, boolean htmlFormat)
	{
		if (StringUtils.isBlank(from)) {
			sendMail(recipents, EmailSupportConfiguration.getInstance()
					.getSupportEmail(), subject, message, htmlFormat, null);
		} else {
			sendMail(recipents, from, subject, message, htmlFormat, null);
		}
		

	}
	
	public static void sendMail(String[] recipents, String from, String subject, String message, boolean htmlFormat, File attachment)
	{
		InternetAddress[] address = new InternetAddress[recipents.length];
		Properties props = new Properties();
		String host = EmailSupportConfiguration.getInstance().getEmailServer();
		//temp hack to send emails locally
		//String host = "soe-vip.nam.nsroot.net";
		
		if (host == null || PORT == null)
		{
			LOG.error("Mail host not configured.");
			return;
		}
		props.put(SMTP_HOST, host);
		props.put(SMTP_PORT, PORT);

		Session session = Session.getInstance(props);

		try
		{
			for (int i = 0; i < address.length; i++)
			{
				address[i] = new InternetAddress(recipents[i]);
			}

			Message msg = new MimeMessage(session);

			msg.setFrom(new InternetAddress(from));
			msg.setRecipients(Message.RecipientType.TO, address);
			msg.setSubject(subject);
			msg.setSentDate(new Date());

			String messageMime = htmlFormat ? MIME_TEXT_HTML : MIME_TEXT_PLAIN;
			if (attachment != null)
			{
				Multipart multipart = new MimeMultipart();
				if (message != null)
				{
					MimeBodyPart messageBodyPart = new MimeBodyPart();
					msg.setContent(message, messageMime);
					messageBodyPart.setText(message);
					multipart.addBodyPart(messageBodyPart);
				}
				FileDataSource source = new FileDataSource(attachment)
				{
					@Override
					public String getContentType()
					{
						return MIME_BINARY_MULTIPART;
					}
				};
				MimeBodyPart attachmentBodyPart = new MimeBodyPart();
				attachmentBodyPart.setFileName(attachment.getName());
				attachmentBodyPart.setDataHandler(new DataHandler(source));
				multipart.addBodyPart(attachmentBodyPart);
				msg.setContent(multipart);
			}
			else
			{
				msg.setContent(message, messageMime);
			}

			Transport.send(msg);
		}
		catch (MessagingException mex)
		{
			LOG.error(mex.getMessage(), mex);
		}
	}

	public static String soeIdToEmail(String soeID)
	{
		return soeID.trim() + "@imcnam.ssmb.com";
	}
}
