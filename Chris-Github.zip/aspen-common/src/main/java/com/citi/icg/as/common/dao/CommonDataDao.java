package com.citi.icg.as.common.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.citi.icg.as.common.enums.AnnouncementCopyTypeEnum;
import com.citi.icg.as.core.dao.entities.business.AnnouncementCopyType;
import com.citi.icg.as.core.dao.entities.business.CountryCode;
import com.citi.icg.as.core.dao.entities.business.CurrencyCode;
import com.citi.icg.as.core.dao.entities.business.FXRate;
import com.citi.icg.as.core.dao.entities.business.FieldQualifier;
import com.citi.icg.as.core.dao.entities.business.LegalEntity;
import com.citi.icg.as.core.dao.entities.business.ProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.Region;
import com.citi.icg.as.core.dao.entities.business.SourceSystem;
import com.citi.icg.as.core.dao.entities.ext.beans.CountryCodeMapping;

public interface CommonDataDao {

	Set<CountryCode> getCountryCodes();

	Set<Region> getRegions();

	List<SourceSystem> getSourceSystems();

	Set<ProcessingUnit> getProcessingUnits();

	CountryCode getCountryCode(String alpha3Code);

	Set<CountryCodeMapping> getCountryCodeMapping();

	Region getRegion(String regionCode);

	@SuppressWarnings("rawtypes")
	List executeSQL(String query);

	Integer executeUpdateSQL(final String query);

	Integer executeUpdateSQL(final String query, final Map<String, ? extends Object> params);

	AnnouncementCopyType getQualifier(String qualifierName);

	AnnouncementCopyType getQualifier(AnnouncementCopyTypeEnum item);

	AnnouncementCopyType getQualifier(int qualifierId);

	Set<FieldQualifier> getFieldQualifiers();

	List<String> getNodeNames(String clusterName);

	List<CurrencyCode> getCurrencyCodesList();

	<T> List<T> fetchData(final Class<T> entityClass, int startRow, int pageSize);

	int countDataRows(final Class<?> entityClass);

	<T> List<T> fetchData(Class<T> entityClass);

	public List<FXRate> getCurrencyFxRate(String termCurrency, String baseCurrency);

	CountryCode getCountry(String alphaCode);

	/**
	 * Get the legal entities used for PB Equity, Swaps, Main Firm Equity and Fixed Income processing units
	 * aspen-3203 move legal entity to common
	 */
	List<LegalEntity> getAllDefaultLegalEntities();

	/**
	 * Get the legal entities only for CGMI Broadridge processing unit
	 * 
	 * @return legalEntityList the legalEntityList
	 */
	List<LegalEntity> getAllLegalEntitiesForBR();

	List<String> getCairoLegalEntitiesFilter();
}
