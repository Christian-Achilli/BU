package com.citi.icg.as.common.converter;

import java.util.List;
import java.util.Set;

public interface EntityConverter<F, T> {

	T convertTo(F source);

	F convertFrom(T entity);

	Set<T> convertAllTo(Set<F> source);

	Set<F> convertAllFrom(Set<T> source);

	List<F> convertAllFrom(List<T> source);

	Class<T> getTargetClass();

	Class<F> getSourceClass();

	void setConversionSession(ConversionSession session);

}
