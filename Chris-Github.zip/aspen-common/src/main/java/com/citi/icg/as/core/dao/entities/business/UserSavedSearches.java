package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class UserSavedSearches extends BaseBusinessEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2697642002004686839L;
	
	private int pkSearchId;
	private String queueType;
	private String fkUserId;
	private String searchName;
	private String searchData;
	private String gridLayoutData;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public int getPkSearchId() {
		return pkSearchId;
	}

	public void setPkSearchId(int pkSearchId) {
		this.pkSearchId = pkSearchId;
	}

	public String getQueueType() {
		return queueType;
	}

	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}

	public String getFkUserId() {
		return fkUserId;
	}

	public void setFkUserId(String fkUserId) {
		this.fkUserId = fkUserId;
	}

	public String getSearchName() {
		return searchName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}

	public String getSearchData() {
		return searchData;
	}

	public void setSearchData(String searchData) {
		this.searchData = searchData;
	}

	public String getGridLayoutData() {
		return gridLayoutData;
	}

	public void setGridLayoutData(String gridLayoutData) {
		this.gridLayoutData = gridLayoutData;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Integer getId() {
		return getPkSearchId();
	}
}
