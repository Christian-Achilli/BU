package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class Region extends BaseBusinessEntity {
	
	private static final long serialVersionUID = 4055711162333919724L;

	private int pkRegionCodeId;
	private String regionCode;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String timezoneId;
	private String regionLocale;

	public String getRegionLocale() {
		return regionLocale;
	}

	public void setRegionLocale(String regionLocale) {
		this.regionLocale = regionLocale;
	}



	public String getTimezoneId() {
		return timezoneId;
	}

	public void setTimezoneId(String timezoneId) {
		this.timezoneId = timezoneId;
	}

	public int getPkRegionCodeId() {
		return pkRegionCodeId;
	}

	public void setPkRegionCodeId(int pkRegionCodeId) {
		this.pkRegionCodeId = pkRegionCodeId;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Integer getId() {
		return getPkRegionCodeId();
	}
	
	@Override
	public String toString() {
		return "Region [pkRegionCodeId=" + pkRegionCodeId + ", regionCode="
				+ regionCode + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedDate=" + lastUpdatedDate + ", timezoneId="
				+ timezoneId + ", regionLocale=" + regionLocale + "]";
	}
	// public Set<UserRegion> getUserRegions() {
	// return userRegions;
	// }
	//
	//
	// public void setUserRegions(Set<UserRegion> userRegions) {
	// this.userRegions = userRegions;
	// }

}
