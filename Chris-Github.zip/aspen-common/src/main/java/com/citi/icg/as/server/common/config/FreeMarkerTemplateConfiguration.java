package com.citi.icg.as.server.common.config;

import java.io.Writer;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;

import com.citi.icg.as.server.common.template.engine.FreeMarkerTemplateUtility;

import freemarker.core.Environment;
import freemarker.template.Configuration;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

@org.springframework.context.annotation.Configuration
public class FreeMarkerTemplateConfiguration {

	private final static Logger logger = Logger.getLogger(FreeMarkerTemplateConfiguration.class);

	@Bean
	public Configuration configuration() {
		FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
		bean.setTemplateLoaderPath("classpath:/");
		bean.setPreferFileSystemAccess(false);
		try {
			bean.afterPropertiesSet();
			Configuration config = bean.getObject();
			config.setTemplateExceptionHandler(new TemplateExceptionHandler() {
				public void handleTemplateException(TemplateException te, Environment env, Writer out)
						throws TemplateException {
					logger.warn(te);
				}
			});
			return config;

		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}

	@Bean
	public FreeMarkerTemplateUtility freeMarkerTemplateUtility() {
		FreeMarkerTemplateUtility utility = FreeMarkerTemplateUtility.getInstance();
		utility.setConfiguration(configuration());
		return utility;
	}
}
