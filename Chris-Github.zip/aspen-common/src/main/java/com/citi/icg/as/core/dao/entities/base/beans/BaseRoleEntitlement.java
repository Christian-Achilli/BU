package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.ext.beans.Privilege;
import com.citi.icg.as.core.dao.entities.ext.beans.Role;

@MappedSuperclass
@Table(name = "ROLE_ENTITLEMENT", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseRoleEntitlement extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 7648184276722249884L;

	private Integer pkEntitlementId;
	private Role role;
	private Privilege privilege;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public BaseRoleEntitlement() {
	}

	public BaseRoleEntitlement(Role role, Privilege privilege, Date lastUpdatedDate) {
		this.role = role;
		this.privilege = privilege;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BaseRoleEntitlement(Role role, Privilege privilege, String lastUpdatedBy, Date lastUpdatedDate) {
		this.role = role;
		this.privilege = privilege;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_ROLE_ENTITLEMENT", allocationSize = 1)
	@Column(name = "PK_ENTITLEMENT_ID", unique = true, nullable = false)
	public Integer getPkEntitlementId() {
		return this.pkEntitlementId;
	}

	public void setPkEntitlementId(Integer pkEntitlementId) {
		this.pkEntitlementId = pkEntitlementId;
	}

	@ManyToOne()
	@JoinColumn(name = "FK_ROLE_ID", nullable = false)
	public Role getRole() {

		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_PRIVILEGE_ID", nullable = false)
	public Privilege getPrivilege() {
		return this.privilege;
	}

	public void setPrivilege(Privilege privilege) {
		this.privilege = privilege;
	}

	@Column(name = "LAST_UPDATED_BY", length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
