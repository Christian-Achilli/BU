package com.citi.icg.as.dao;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateOperations;
import org.springframework.util.Assert;

import com.citi.icg.as.common.util.ClassUtils;
import com.citi.icg.as.map.AspenBeanMapper;
import com.citi.icg.as.map.BeanMapper;

/**
 * This class should be used as the basis for a DAO implementation. There should
 * be a DAO implementation per business entity.
 * 
 */
public abstract class BaseEntityDaoComponent<T, S> implements DaoOperations<T, S>, ConversionOperations<T, S> {

	private Class<T> targetBusinessEntity;

	private Class<S> targetHibernateEntity;

	private HibernateOperations template;

	private BeanMapper beanMapper;
	
	public BaseEntityDaoComponent(HibernateOperations hibernateOperations) {
		this(hibernateOperations, new AspenBeanMapper());
	}

	public BaseEntityDaoComponent(HibernateOperations hibernateOperations, BeanMapper mapper) {
		super();
		this.targetBusinessEntity = (Class<T>)ClassUtils.getTypeArguments(BaseEntityDaoComponent.class, this.getClass()).get(0);
		this.targetHibernateEntity = (Class<S>)ClassUtils.getTypeArguments(BaseEntityDaoComponent.class, this.getClass()).get(1);
		this.template = hibernateOperations;
		this.beanMapper = mapper;
	}

	@Override
	public T getNewBusinessEntity(S source) throws InstantiationException, IllegalAccessException
	{
		return targetBusinessEntity.newInstance();
	}
	
	@Override
	public S getNewHibernateEntity(T target) throws InstantiationException, IllegalAccessException
	{
		return targetHibernateEntity.newInstance();
	}
	
	@Override
	public T convertToBusinessEntity(S hibernateEntity) {
		try {
			return this.convertToBusinessEntity(hibernateEntity, getNewBusinessEntity(hibernateEntity));
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 
	}
	
	@Override
	public T convertToBusinessEntity(S hibernateEntity, T businessEntity) {
		if (hibernateEntity != null) {
			return (T) beanMapper.map(hibernateEntity, businessEntity.getClass());
		}

		return null;
	}

	public S convertToHibernateEntity(T businessEntity) {
		try {
			return this.convertToHibernateEntity(businessEntity, getNewHibernateEntity(businessEntity));
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 
	}
	
	public S convertToHibernateEntity(T businessEntity, S hibernateEntity) {
		
		if (businessEntity != null) {
			return (S) beanMapper.map(businessEntity, hibernateEntity.getClass());
		}

		return null;
	}
	public <B> B convertOne(Object sourceEntity, Class<B> targetClass) {
		if (sourceEntity != null) {
			return (B) beanMapper.map(sourceEntity, targetClass);
		}
		return null;
	}
	@SuppressWarnings("unchecked")
	public <C> Collection<C> convertAll(Collection<?> items, Class<C> target) {
		if (items == null) {
			return null;
		}

		if (target.equals(targetBusinessEntity)
				|| target.equals(targetHibernateEntity)) {
			Collection<C> newArray;
			if (items.isEmpty()) return (Collection<C>)items;
			try {
				newArray = items.getClass().newInstance();
				if (target.equals(targetHibernateEntity)) {

					for (Object item : items) {
						newArray.add((C) convertToHibernateEntity((T) item));
					}

				} else if (target.equals(targetBusinessEntity)) {

					for (Object item : items) {
						newArray.add((C) convertToBusinessEntity((S) item));
					}

				} else {
					throw new IllegalArgumentException("Target class ["
							+ target
							+ "] is not a business or hibernate entity.");
				}
				return newArray;
			} catch (InstantiationException e) {
				throw new RuntimeException(e);
			} catch (IllegalAccessException e) {
				throw new RuntimeException(e);
			}
		} else {
			return beanMapper.mapAll(items, target);
		}

	}

	private Criteria createCriteria(Session session, List<Criterion> criterion) {
		Criteria criteria = session.createCriteria(targetHibernateEntity);
		if (CollectionUtils.isNotEmpty(criterion)) {
			for (Criterion c : criterion) {
				criteria.add(c);
			}
		}
		return criteria;
	}

	@Override
	public T findSingleByExample(final T example) {
		HibernateCallback<T> cb = new HibernateCallback<T>() {

			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {
				S hbm = convertToHibernateEntity(example);
				Criteria criteria = session.createCriteria(hbm.getClass());
				criteria.add(Example.create(hbm));
				return convertToBusinessEntity((S) criteria.uniqueResult());
			}
		};

		return execute(cb);
	}

	public T findSingleByCriteria(final List<Criterion> criterion) {
		HibernateCallback<T> cb = new HibernateCallback<T>() {

			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {

				Criteria criteria = createCriteria(session, criterion);
				return convertToBusinessEntity((S) criteria.uniqueResult());
			}
		};

		return execute(cb);
	}

	public List<T> findByCriteria(final List<Criterion> criterion) {
		HibernateCallback<List<T>> cb = new HibernateCallback<List<T>>() {

			@Override
			public List<T> doInHibernate(Session session)
					throws HibernateException, SQLException {
				Criteria criteria = createCriteria(session, criterion);
				List<S> items = criteria.list();
				return (List<T>) convertAll(items, targetBusinessEntity);
			}
		};

		return execute(cb);
	}

	public T get(final Serializable id) {

		HibernateCallback<T> cb = new HibernateCallback<T>() {

			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {

				S hbm = (S) session.get(targetHibernateEntity, id);
				return convertToBusinessEntity(hbm);

			}
		};

		return execute(cb);

	}

	private void saveOrUpdate(T entity, Session session) {
		// convert to hibernate entity
		S hibernateEntity = convertToHibernateEntity(entity);

		// execute
		session.saveOrUpdate(hibernateEntity);
	}

	public void saveOrUpdate(final T entity) {

		HibernateCallback<Void> cb = new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session)
					throws HibernateException, SQLException {
				saveOrUpdate(entity, session);
				return null;
			}
		};

		execute(cb);

	}

	public void saveOrUpdate(final Collection<T> entities) {

		HibernateCallback<Void> cb = new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session)
					throws HibernateException, SQLException {
				for (T entity : entities) {
					saveOrUpdate(entity, session);
				}
				return null;
			}
		};

		execute(cb);

	}

	private T merge(T entity, Session session) {
		// convert to hibernate entity
		S hibernateEntity = convertToHibernateEntity(entity);

		// execute
		S hibernateEntityMerged = (S) session.merge(hibernateEntity);

		return convertToBusinessEntity(hibernateEntityMerged);
	}

	public T merge(final T entity) {

		HibernateCallback<T> cb = new HibernateCallback<T>() {
			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {
				return merge(entity, session);
			}
		};

		return execute(cb);

	}

	public Collection<T> merge(final Collection<T> entities) {
		HibernateCallback<Collection<T>> cb = new HibernateCallback<Collection<T>>() {
			@Override
			public Collection<T> doInHibernate(Session session)
					throws HibernateException, SQLException {
				Set<T> businessEntitiesMerged = new HashSet<T>();
				for (T entity : entities) {
					businessEntitiesMerged.add(merge(entity, session));
				}
				return businessEntitiesMerged;
			}
		};

		return execute(cb);
	}

	public <C> C execute(HibernateCallback<C> callback) {
		return template.execute(callback);
	}

	public Class<T> getTargetBusinessEntity() {
		return targetBusinessEntity;
	}

	public Class<S> getTargetHibernateEntity() {
		return targetHibernateEntity;
	}

	public HibernateOperations getTemplate() {
		return template;
	}

	public void setTargetHibernateEntity(Class<S> targetHibernateEntity) {
		this.targetHibernateEntity = targetHibernateEntity;
	}

}
