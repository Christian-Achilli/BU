/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import static com.citi.icg.as.common.constants.CommonConstants.SYSTEM_ENV_PROPERTY;
import static com.citi.icg.as.common.constants.CommonConstants.WEBLOGIC_NODE_NAME;
import static org.apache.commons.lang.StringUtils.EMPTY;

import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.citi.icg.as.config.ConfigurationUtility;

/**
 * @author ap72338
 *         <p>
 *         The condition looks up aspen-config's asyncModeExclusionNodes
 *         property as in config.json
 *         </p>
 */
public class OnNodeAllowedForAsyncCondition implements Condition {

	private static final Logger logger = LoggerFactory.getLogger(OnNodeAllowedForAsyncCondition.class);

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalAsyncListener.class.getName());
		String nodeName = (String) attributes.get("nodeName");
		nodeName = StringUtils.defaultIfBlank(nodeName, System.getProperty(WEBLOGIC_NODE_NAME, StringUtils.EMPTY));

		ConfigurationUtility configUtility = getBean(context);
		if (configUtility == null) {
			configUtility = new ConfigurationUtility(System.getProperty(SYSTEM_ENV_PROPERTY, EMPTY));
		}

		boolean nodeAllowed = true;
		String exclusionList = configUtility.getAsyncModeExclusionNodes();
		if (StringUtils.isNotBlank(exclusionList)) {
			nodeAllowed = !Pattern.matches(exclusionList, nodeName);
		}
		return nodeAllowed;
	}

	/**
	 * @param context
	 * @return
	 */
	private ConfigurationUtility getBean(ConditionContext context) {
		try {
			return context.getBeanFactory().getBean(ConfigurationUtility.class);
		} catch (BeansException e) {
			logger.info("ConfigurationUtility bean not present in context. No need to worry.");
			return null;
		}
	}
}