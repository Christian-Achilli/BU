package com.citi.icg.as.util;

public class GcasExecutionTimer 
{
	private static final String TIME_ELAPSED = "TimeElapsed: ";

	private static final String HYPEN = " - ";

	private static final String SEPARATOR_CLASS_METHOD = "::";

	private static final String END_BRACKET_HYPEN = " ] - ";

	private static final String START_BRACKET = "[ ";

	private static final long MILL_SEC_1000 = 1000L;
	private static final long SEC_IN_ONE_HOUR = 3600L;
	private static final long SEC_60 = 60L;
	
	private long start;
	private long end;

	public GcasExecutionTimer()
	{
		reset();
	}

	public void start()
	{
		start = System.currentTimeMillis();
	}

	public void end()
	{
		end = System.currentTimeMillis();
	}

	public long duration()
	{
		return (end - start);
	}

	public void reset()
	{
		start = 0;
		end = 0;
	}

	public String getPerformanceMessage(String className, String methodName)
	{
		StringBuilder hms = new StringBuilder(START_BRACKET);
		hms.append(className).append(SEPARATOR_CLASS_METHOD).append(methodName).append(END_BRACKET_HYPEN);
		hms.append(TIME_ELAPSED).append(getHourMinuteSeconds(duration()));

		return hms.toString();
	}

	public String getPerformanceMessage(String className, String methodName, String prefix)
	{
		StringBuilder hms = new StringBuilder(START_BRACKET);
		hms.append(className).append(SEPARATOR_CLASS_METHOD).append(methodName).append(END_BRACKET_HYPEN);
		hms.append(prefix).append(HYPEN).append(TIME_ELAPSED).append(getHourMinuteSeconds(duration()));

		return hms.toString();
	}

	private String getHourMinuteSeconds(long elapsedTimeMillis)
	{
		long hours;
		long minutes;
		long seconds;
		StringBuilder hms = new StringBuilder();

		long timeInSeconds = elapsedTimeMillis / MILL_SEC_1000; // total # of seconds
		long millisLeft = elapsedTimeMillis % MILL_SEC_1000; // total number of millis
														// left

		hours = timeInSeconds / SEC_IN_ONE_HOUR;
		timeInSeconds = timeInSeconds - (hours * SEC_IN_ONE_HOUR);
		minutes = timeInSeconds / SEC_60;
		timeInSeconds = timeInSeconds - (minutes * SEC_60);
		seconds = timeInSeconds;
		if (hours == 0 && minutes == 0 && seconds == 0 && millisLeft == 0)
		{
			hms.append("0");
		}
		else
		{
			hms.append(hours).append(" hour(s) ").append(minutes).append(" minute(s) ").append(seconds).append(" second(s) ").append(
					millisLeft).append(" millisecond(s) ");
		}

		// hms.append("TimeElapsed: ").append(hours).append(":").append(minutes).append(":").append(seconds).append(",").append(millisLeft);

		return hms.toString();
	}// End method
}
