package com.citi.icg.as.config;

public final class ConfigEvnHelper {
	public static final String ICG_ENV = "gcas.env";

	/** Runtime: Local Development. */
	public static final String RUNTIME_VM = "vm";
	
	/** Runtime: Local Development. */
	public static final String RUNTIME_LOCAL = "local";

	/** Runtime: Development. */
	public static final String RUNTIME_DEV = "dev";

	/** Runtime: INTEGRATION (QA). */
	public static final String RUNTIME_INT = "int";

	/** Runtime: UAT (STAGE). */
	public static final String RUNTIME_UAT = "uat";

	/** Runtime: Production. */
	public static final String RUNTIME_PROD = "prod";

	/** Runtime: auto test . */
	public static final String RUNTIME_AUTO_TEST = "autotest";

	private ConfigEvnHelper() { }
	
	public static void set(String env)
	{
		System.setProperty(ICG_ENV, env);
	}

	/**
	 * Set environment environment to auto test.
	 */
	public static void setRuntimeToAutoTest()
	{
		set(RUNTIME_AUTO_TEST);
	}

	/**
	 * Set environment environment to local.
	 */
	public static void setRuntimeToLocal()
	{
		set(RUNTIME_LOCAL);
	}

	/**
	 * Set environment environment to dev.
	 */
	public static void setRuntimeToDev()
	{
		set(RUNTIME_DEV);
	}

	/**
	 * Set environment environment to int.
	 */
	public static void setRuntimeToInt()
	{
		set(RUNTIME_INT);
	}

	/**
	 * Set environment environment to uat.
	 */
	public static void setRuntimeToUat()
	{
		set(RUNTIME_UAT);
	}

	/**
	 * Set environment environment to prod.
	 */
	public static void setRuntimeToProd()
	{
		set(RUNTIME_PROD);
	}
	
	/**
	 * Set environment environment to prod.
	 */
	public static void setRuntimeToBelfast()
	{
		set(RUNTIME_VM);
	}
}
