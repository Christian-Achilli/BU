package com.citi.icg.as.common.util;

public interface IProxyHelper {

	public abstract <T> T getTransactionalInstance(T target);

}