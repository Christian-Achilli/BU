/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Conditional;

/**
 * @author ap72338
 * <p>The annotation which helps to distinguish a server env from a local one. Except local and jenkins everything is considered a server env</p>
 */

@Target({ ElementType.TYPE, ElementType.METHOD })
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Conditional(OnRunningInServerCondition.class)
public @interface ConditionalRunningOnServer {

	String[] excluded() default {"local","jenkins"};
}
