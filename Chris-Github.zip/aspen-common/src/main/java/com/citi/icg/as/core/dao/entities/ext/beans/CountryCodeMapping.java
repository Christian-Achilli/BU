package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseCountryCodeMapping;

@Entity
@Table(name = "COUNTRY_CODE_MAPPING")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class CountryCodeMapping extends BaseCountryCodeMapping{
	
	private static final long serialVersionUID = 5412491516569859543L;
}
