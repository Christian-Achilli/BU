package com.citi.icg.as.server.service;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.exception.GcasException;

/**
 * Reflection utilities.
 * 
 */

public final class GcasBeanUtils
{
	private static final Log LOG = LogFactory.getLog(GcasBeanUtils.class);
	
	private GcasBeanUtils()
	{

	}

	public static void setProperty(Object obj, String attributeName, Object excelValue) throws GcasException
	{
		try
		{
			BeanUtils.setProperty(obj, attributeName, excelValue); 
		}
		catch (IllegalAccessException e)
		{
			throw new GcasException(e.getMessage(), e);
		}
		catch (InvocationTargetException e)
		{
			throw new GcasException(e.getMessage(), e);
		}
	}

	/**
	 * Get property value from the object with bean convention.
	 */
	public static Object getProperty(Object object, String propertyName, Object defaultValue)
	{
		Object value = null;
		try
		{
			value = getProperty(object, propertyName);
		}
		catch (GcasException e)
		{
			LOG.error("Error getting property " + propertyName + e.getMessage());
		}
		return value == null ? defaultValue : value;
	}

	public static Object getProperty(Object object, String propertyName) throws GcasException
	{
		try
		{
			return PropertyUtils.getProperty(object, propertyName);
		}
		catch (Exception ex)
		{
			throw new GcasException("Error getting property:" + propertyName, ex);
		}
	}

	public static Object convert(String nodeValue, Class<?> type)
	{
		if (type == null || type == String.class)
		{
			return nodeValue;
		}
		Object converted = ConvertUtils.convert(nodeValue, type);
		return converted;
	}

	@SuppressWarnings("unchecked")
	public static Map<String, String> getProperties(Object objectInstance)
	{
		try
		{
			return BeanUtils.describe(objectInstance);
		}
		catch (Exception e)
		{
			throw new RuntimeException("Failed to read object properties", e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public static Map describe(Object obj)
	{
		try
		{
			return BeanUtils.describe(obj);
		}
		catch (Exception excp)
		{
			throw new RuntimeException("describe failed", excp);
		}
	}
}
