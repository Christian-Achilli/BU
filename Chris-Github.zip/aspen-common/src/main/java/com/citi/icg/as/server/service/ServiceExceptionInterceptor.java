package com.citi.icg.as.server.service;

import com.citi.icg.as.hessian.ResultWrapper;

/**
 * @author ca85137
 * Intercepts the execution of a {@link ServiceExecutor} and wraps its result or exception in a ResultWrapper.
 * <br>
 * Do not implement this interface, subclass {@link BaseExceptionInterceptor} instead
 *
 */
public interface ServiceExceptionInterceptor {

	<T> ResultWrapper<T> execute(Class<?> caller, ServiceExecutor<T> callBack);

	/**
	 * Added so as callers does not have to always do object.getClass() as they can now call this method now.
	 * 
	 * @param caller
	 * @param callBack
	 * @return
	 */
	<T> ResultWrapper<T> execute(Object caller, ServiceExecutor<T> callBack);

}