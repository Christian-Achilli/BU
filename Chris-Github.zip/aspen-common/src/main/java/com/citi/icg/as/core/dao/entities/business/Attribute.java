package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class Attribute extends BaseBusinessEntity {
	
	private static final long serialVersionUID = -5213006217283484314L;
	
	private int pkAttributeId;
	private String attributeCode;
	private String attributeDescription;
	private Character attributeType;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private boolean dataModel;

	public boolean isDataModel() {
		return dataModel;
	}

	public void setDataModel(boolean dataModel) {
		this.dataModel = dataModel;
	}

	public int getPkAttributeId() {
		return pkAttributeId;
	}

	public void setPkAttributeId(int pkAttributeId) {
		this.pkAttributeId = pkAttributeId;
	}

	public String getAttributeCode() {
		return attributeCode;
	}

	public void setAttributeCode(String attributeCode) {
		this.attributeCode = attributeCode;
	}

	public String getAttributeDescription() {
		return attributeDescription;
	}

	public void setAttributeDescription(String attributeDescription) {
		this.attributeDescription = attributeDescription;
	}

	public Character getAttributeType() {
		return attributeType;
	}

	public void setAttributeType(Character attributeType) {
		this.attributeType = attributeType;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Integer getId() {
		return getPkAttributeId();
	}
}
