package com.citi.icg.as.common.workflow;

/**
 * 
 *
 */
public final class WorkflowConstants
{	
	//new add for generic
	public static final String ENTITIES = "entities";
	public static final String ENTITY_TYPE = "entityType";
	public static final String TRANSITION_NAME = "transition";
	public static final String HAS_TAX_CHANGES = "hasTaxChanges";
	public static final String HAS_ANN_CHANGES = "hasEventChagnes";
	
	//old
	public static final String TASK_DONE_BY = "doTaskUser";
	public static final String TASK_NAME = "taskName";
	public static final String EDIT_USER_VAR = "editUser";
	public static final String SUBMIT_USER_VAR = "submitUser";
	public static final String REASSIGN_USER_VAR = "reassignUser";
	public static final String REASSIGN_NOTES_VAR = "reassignNotes";
	public static final String ANNOUNCEMENT_VAR = "annoucement";
	public static final String REJECTION_REASONS_VAR = "rejectionReasons";
	public static final String PROCESSING_UNIT_VAR = "processingUnit";
	public static final String NOTIFICATION_TYPE_VAR = "notificationType";
	public static final String NOTIFICATION_ID_VAR = "notificationId";
	public static final String NOTIFICATION = "notification";
	public static final String EVENT_STATUS_VAR = "eventStatus";
	
	public static final String AUTO_NOTIFICATION_RULES = "AUTO_NOTIFICATIONS";
	public static final String AUTO_APPROVE_NOTIFICATIONS = "AUTO_APPROVE_NOTIFICATIONS";
	public static final String ENTITY_ID = "entityId";
	public static final String WORKFLOW_TYPE = "workflowType";
	public static final String CHECKOUT_PU_LIST = "checkedOutPUList";
	public static final String WORKFLOW_ATTR = "workflowAttr";
	
	//alert
	public static final String ALERT_CLOSE_TYPE = "alertCloseType";
	public static final String ALERT_OWNER = "alertOwner";
	public static final String ALERT_REGION = "alertRegion";
	public static final String ALERT_PU = "alertPu";
	public static final String ALERT_APPROVAL = "alertApproval";
	public static final String AUTO_CLOSE = "auto-close";
	public static final String MANUAL_CLOSE = "manual-close";
	public static final String AUTO = "auto";
	public static final String MANUAL = "manual";
	public static final String ALERT = "alert";
	
	public static final String UUID = "uuid";

	
	private WorkflowConstants() { }
	
}
