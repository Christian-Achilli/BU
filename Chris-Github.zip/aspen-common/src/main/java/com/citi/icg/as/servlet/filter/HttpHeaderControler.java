package com.citi.icg.as.servlet.filter;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 
 * @author yy31798
 *
 */
public class HttpHeaderControler implements Filter {
	private static Log log = LogFactory.getLog(HttpHeaderControler.class);
	private Map<String, String> attributesMap;
	private Pattern URL_PATTERN;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		if (response instanceof HttpServletResponse) {
			HttpServletRequest httpRequest = (HttpServletRequest) request;
			HttpServletResponse httpResponse = (HttpServletResponse)response;
			Matcher matcher = URL_PATTERN.matcher(httpRequest.getRequestURL());
			if (matcher.matches()) {
				setHeaderAttributes(httpResponse);
			}
		}
		chain.doFilter(request, response);
	}

	private void setHeaderAttributes(HttpServletResponse httpResponse ) {
		Iterator<Entry<String, String>> iterator = attributesMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String, String> entry = iterator.next();
			httpResponse.setHeader(entry.getKey(), entry.getValue());
		}
	}
	@Override
	public void init(FilterConfig config) throws ServletException {
		attributesMap = new HashMap<String, String>();
		@SuppressWarnings("unchecked")
		Enumeration<String> names = config.getInitParameterNames();
		while (names.hasMoreElements()) {
			String name = names.nextElement();
			String value = config.getInitParameter(name);
			if ("url-pattern".equals(name.toLowerCase())) {
				 value = value.replaceAll("\\s", "").replace(".", "\\.")
				 		.replace(",", "|").replace("*", ".*");
				 URL_PATTERN = Pattern.compile(value);
				 log.info(value);
			} else {
				attributesMap.put(name, value);
			}
		}
		log.info("CacheControler has initialized");
	}

	@Override
	public void destroy() {
		log.info("CacheControler has destroy");
	}
}
