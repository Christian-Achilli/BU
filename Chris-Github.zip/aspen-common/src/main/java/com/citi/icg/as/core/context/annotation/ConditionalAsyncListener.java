/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Conditional;

/**
 * @author ap72338
 *         <p>
 *         This annotation creates conditional beans based on whether the node
 *         is enabled for async communication i.e. can it listen to a JMS queue
 *         for example. It checks based on asyncModeExclusionNodes key as in
 *         aspen-config/config.json
 *         </p>
 */

@Target({ ElementType.TYPE, ElementType.METHOD })
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Conditional(OnNodeAllowedForAsyncCondition.class)
public @interface ConditionalAsyncListener {

}