/**
 * 
 */
package com.citi.icg.as.server.rest;

import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.citi.icg.as.server.rest.model.ValidationErrorDTO;

/**
 * @author ap72338
 *         <p>
 *         The central error handler for all {@link RestController}'s
 *         </p>
 */

@ControllerAdvice(annotations = RestController.class)
public class RestErrorHandler {

	@ExceptionHandler({ MethodArgumentNotValidException.class, MethodArgumentTypeMismatchException.class })
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public ValidationErrorDTO processValidationError(MethodArgumentNotValidException ex) {
		BindingResult result = ex.getBindingResult();
		List<FieldError> fieldErrors = result.getFieldErrors();

		return processFieldErrors(fieldErrors);
	}

	private ValidationErrorDTO processFieldErrors(List<FieldError> fieldErrors) {
		ValidationErrorDTO dto = new ValidationErrorDTO();

		for (FieldError fieldError : fieldErrors) {
			String localizedErrorMessage = fieldError.getDefaultMessage();
			dto.addFieldError(fieldError.getField(), localizedErrorMessage);
		}

		return dto;
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public ValidationErrorDTO handleAllErrors(Exception ex) {
		ValidationErrorDTO dto = new ValidationErrorDTO();
		dto.addFieldError("IN_REQUEST", ExceptionUtils.getFullStackTrace(ex));
		return dto;
	}
}
