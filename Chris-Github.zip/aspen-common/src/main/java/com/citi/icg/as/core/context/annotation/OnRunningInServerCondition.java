package com.citi.icg.as.core.context.annotation;

import static com.citi.icg.as.common.constants.CommonConstants.SYSTEM_ENV_PROPERTY;
import static org.apache.commons.lang.StringUtils.EMPTY;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.citi.icg.as.common.constants.CommonConstants;

/**
 * 
 * @author ap72338
 *         <p>
 *         Please check {@link ConditionalRunningOnServer}
 *         </p>
 */
public class OnRunningInServerCondition implements Condition {

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {

		Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalRunningOnServer.class.getName());
		List<String> excludedList = Arrays.asList((String[]) attributes.get("excluded"));
		String systemConfigurationValue = System.getProperty(SYSTEM_ENV_PROPERTY, EMPTY);
		return (CollectionUtils.isNotEmpty(excludedList) && !excludedList.contains(systemConfigurationValue))
				&& CommonConstants.N
						.equalsIgnoreCase(System.getProperty(CommonConstants.TEST_EXECUTION, CommonConstants.N));
	}

}
