package com.citi.icg.as.config;


/**
 * This class is used to throw exceptions resulting from configuration problems.
 */
@SuppressWarnings("serial")
public class GcasConfigurationError extends RuntimeException
{
	// --- Constructor(s) ---

	/**
	 * Constructs an GcasConfigurationException with a detail message.
	 * 
	 * @param message the detail message.
	 */
	public GcasConfigurationError(String message)
	{
		super(message);
	}

	/**
	 * Constructs an GcasConfigurationException with a root cause of the error.
	 * 
	 * @param message the detail message.
	 * @param cause the root cause of the error.
	 */
	public GcasConfigurationError(String message, Throwable cause)
	{
		super(message, cause);
	}

}
