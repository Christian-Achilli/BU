/**
 * 
 */
package com.citi.icg.as.common.dao;

import java.util.HashSet;
import java.util.Set;

/**
 * @author ap72338
 *         <p>
 *         This class can be used to specify which entities we need to load in
 *         manual converters, mainly in positions component, to decide which
 *         entity we should load. The client/callee just need to set the
 *         appropriate class and check it accordingly in the mapping code, which
 *         is DOZER in our case.
 *         </p>
 *         <p>
 *         To tell dont load entity for example Region use
 *         <code>EntityLoadDeterminator.dontLoadEntity(Region.class);</code>.
 *         </p>
 *         Once the client is done with the loading part, one should always
 *         clear using
 *         <p>
 *         <code>EntityLoadDeterminator.clearEntity(Region.class);</code> or
 *         <code>EntityLoadDeterminator.clearAll();</code>
 *         </p>
 */
public class EntityLoadDeterminator {

	private final static ThreadLocal<Set<Class<?>>> entityNamesNotToBeLoaded = new ThreadLocal<Set<Class<?>>>();

	private static void init() {
		entityNamesNotToBeLoaded.set(currentThreadNullSafeExcludedEntitySet());
	}

	public static void dontLoadEntity(Class<?>... classes) {
		init();
		if (classes.length > 0) {
			for (Class<?> clazz : classes) {
				entityNamesNotToBeLoaded.get().add(clazz);
			}
		}
	}
	
	public static boolean isEntityToBeLoaded(Class<?> clazz) {
		return !currentThreadNullSafeExcludedEntitySet().contains(clazz);
	}

	public static void clearAll() {
		currentThreadNullSafeExcludedEntitySet().clear();
	}

	public static void clearEntity(Class<?> clazz) {
		currentThreadNullSafeExcludedEntitySet().remove(clazz);
	}

	private static Set<Class<?>> currentThreadNullSafeExcludedEntitySet() {
		Set<Class<?>> entitySet = entityNamesNotToBeLoaded.get();
		if (entitySet == null) {
			entitySet = new HashSet<Class<?>>();
		}
		return entitySet;
	}
}
