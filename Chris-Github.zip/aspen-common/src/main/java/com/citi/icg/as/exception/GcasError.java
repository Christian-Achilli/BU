package com.citi.icg.as.exception;

/**
 * This is the base class for all runtime (unchecked) errors in the system.
 */
@SuppressWarnings("serial")
public class GcasError extends Error
{
	// --- Constructor(s) ---

	/**
	 * Constructs an GcasError with a detail message.
	 * 
	 * @param message the detail message.
	 */
	public GcasError(String message)
	{
		super(message);
	}

	/**
	 * Constructs an GcasError with a root cause of the error.
	 * 
	 * @param message the detail message.
	 * @param cause the root cause of the error.
	 */
	public GcasError(String message, Throwable cause)
	{
		super(message, cause);
	}

}
