/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Conditional;

/**
 * @author ap72338
 *         <p>
 *         The annotation that can be used in components to enable/disable the
 *         ASYNC mode i.e if WC can send messages via queues to other components
 *         and they can then have the queue listeners configured.
 *         The conditional annotation works by checking system property "<b>aspen.wc.async.flow.enabled</b>"
 *         </p>
 */

@Target({ ElementType.TYPE, ElementType.METHOD })
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Conditional(OnAsyncModeEnabledCondition.class)
public @interface ConditionalAsyncModeEnabled {

}
