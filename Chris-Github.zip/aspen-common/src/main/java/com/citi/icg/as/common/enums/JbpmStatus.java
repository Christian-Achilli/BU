package com.citi.icg.as.common.enums;

/**
 * Status to be saved as part of JPBM_ANNOUNCEMENT_ATTRIBUTES.
 *
 */
public enum JbpmStatus {
	// CHECKSTYLE:OFF
	LOCKED("Locked"), IN_PROGRESS("In Progress"), PENDING_APPROVAL("Pending Approval"), APPROVED("Approved"), REJECTED("Rejected"), PENDING_TAX_APPROVAL("Pending Tax Approval");

	// CHECKSTYLE:ON
	private String displayName;

	private JbpmStatus(String displayName) {
		this.displayName = displayName;
	}

	public static JbpmStatus getStatus(String strStatus) {
		for (JbpmStatus status : JbpmStatus.values()) {
			if (status.name().equalsIgnoreCase(strStatus)) {
				return status;
			}
		}
		return null;
	}

	public static JbpmStatus getStatusByName(String displayName) {

		for (JbpmStatus status : JbpmStatus.values()) {
			if (status.displayName.equalsIgnoreCase(displayName)) {
				return status;
			}
		}
		return null;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String toString() {
		return this.displayName;
	}

}
