package com.citi.icg.as.core.dao.entities.base.beans;

/*import net.sf.gilead.pojo.gwt.LightEntity;*/

import com.citi.icg.toolkit.web.client.grid.dataobjects.TransferObject;

/**
 * ICG hibernate mapped entities which use {@link JPAGridServiceImpl} must extend this base class. It adds properties to the object which allow hibernate store to be saved by gilead.
 */
public class JPATransferObject implements TransferObject {

	private static final long serialVersionUID = -6265272027772545559L;

}
