package com.citi.icg.as.server.service.compare;

import java.beans.PropertyEditor;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.comparators.ComparableComparator;
import org.apache.commons.collections.functors.TruePredicate;
import org.apache.commons.collections.map.DefaultedMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.citi.icg.as.common.client.compare.CompareResult;
import com.citi.icg.as.common.client.entities.BusinessEntity;
import com.citi.icg.as.common.client.util.PlaceHolder;
import com.citi.icg.as.exception.GcasError;
import com.citi.icg.as.exception.GcasException;
import com.google.gwt.user.client.rpc.IsSerializable;
import com.sybase.jdbc4.tds.SybTimestamp;

/**
 * Base class for calculating entity comparison / difference.
 * This class uses PropertyUtils and inspects all properties of
 * the given object graph. It is meant to be a suitable base
 * class for implementations which are domain aware. (e.g.
 * use TranferObjectInfo. 
 */
@SuppressWarnings("unchecked")
public class BeanCompareService implements CompareService
{
	public static final String ROOT = "ROOT";
	protected static final String PROPERTY_PATH_DELIMETER = ".";
	protected static final String NEW_LINE = "\n";
	protected static final String NULL = "null";
	protected static final String CLASS_PROPERTY = "class";
	protected static final String PROPERTY_PLACEHOLDER = "__PROPERTY_PLACEHOLDER__";
	
	// object types which represent leafs in our object graph
	// we won't perform deep introspection of these objects.
	public static final Set<Class<?>> ATOMIC_PROPERTIES;
	static
	{
		ATOMIC_PROPERTIES = new HashSet<Class<?>>();
		ATOMIC_PROPERTIES.addAll(Arrays.asList(new Class<?>[] {
				String.class,
				Long.class,
				Integer.class,
				Float.class,
				Double.class,
				Character.class,
				Byte.class,
				BigDecimal.class,
				BigInteger.class,
				Boolean.class,
				Short.class,
				Date.class,
				Timestamp.class,
				SybTimestamp.class,
				java.sql.Date.class,
		}));
	}

	/*
	 * A convienence comparator, which uses the string values returned
	 * from property editors registerd with this instance.
	 * TODO, maybe this should be the deafult comparator instead of
	 *       ComparableComparator?
	 */
	public final Comparator<?> StringRepresentationComparator = new Comparator()
	{
		public int compare(Object arg0, Object arg1)
		{
			if (arg0 == null && arg1 == null)
			{
				return 0;
			}
			else if (arg0 == null)
			{
				return 1;
			}
			else if (arg1 == null)
			{
				return -1;
			}
			// we don't provide a property path, if one is required, this comparator is
			// not suitable, and client needs t implement there own
			String str0 = stringRepresenation(arg0, valuePropertyEditors, null);
			String str1 = stringRepresenation(arg1, valuePropertyEditors, null);
			return str0.compareTo(str1);
		}
	};
	
	/** all possible types of a property of bean being inspected. **/
	protected static enum PropertyType
	{
		ATOMIC, BEAN, COLLECTION, MAP, ARRAY
	}
	
	private Comparator defaultEquivalenceComparator = new ComparableComparator(); 
	
	// the comparator used to determine if two leafs are equal
	// if leafs are not comparable, you must register a custom comparator.
	private Map<Class, Comparator> equivalenceComparators = new DefaultedMap(defaultEquivalenceComparator);
	
	// the comparator used to merge join collection properties
	// if collection members are not comparable, you must register a custom comparator.
	private Map<Class, Comparator> listMergeComparators = new DefaultedMap(defaultEquivalenceComparator);
	
	// register a predicate for excluding elements from list comparisons
	private Map<Class, Predicate> listFilterPredicates = new DefaultedMap(TruePredicate.INSTANCE);
	
	// get a property editor which should be used to convert a bean
	// to its string representation, lookup is done based on type heirachy
	// e.g., Object.class could be used to  match all entities.
	// we DO NOT gaurentee the most specific editor is used and you should
	// not register different editors for classes in the same heirachy,
	// e.g. Registering java.util.Date and java.sql.Date(which extends Date)
	// would not provide any deterministic guarentees that java.sql.Date is
	// handled by the editor registered for java.sql.Date / java.util.Date
	protected Map<Class, PropertyEditor> valuePropertyEditors = new HashMap<Class, PropertyEditor>();
	protected Map<Class, PropertyEditor> namePropertyEditors = new HashMap<Class, PropertyEditor>();
	
	private Set<String> excludedProperties = new HashSet<String>();
	
	/*
	 * Register a custom comparator which should be used for
	 * testing if two objects are equivalent. This Comparator
	 * is used only when comparing leaf nodes (atomic properties).
	 */
	public <T> void registerEquivalenceComparator(Class<? extends T> clazz, Comparator<T> comparator)
	{
		equivalenceComparators.put(clazz, comparator);
	}
	
	public void unregisterEquivalenceComparator(Class<?> clazz)
	{
		equivalenceComparators.remove(clazz);
	}
	
	/*
	 * Register comparator used for merge join of collections.
	 * The default behavior of comparing two collection properties
	 * is to perform a merge join of the two list. This comparator
	 * will sort the result. Any objects which are "equal" as defined
	 * by the registered comparator will have properties individually inspected
	 */
	public <T> void registerListMergeComparator(Class<? extends T> clazz, Comparator<T> comparator)
	{
		listMergeComparators.put(clazz, comparator);
	}
	
	/*
	 * Register an editor which know how to turn the specfied class to
	 * a string representing its value.
	 */
	public void registerValuePropertyEditor(Class clazz, PropertyEditor editor)
	{
		valuePropertyEditors.put(clazz, editor);
	}
	
	public void registerNamePropertyEditor(Class clazz, PropertyEditor editor)
	{
		namePropertyEditors.put(clazz, editor);
	}
	
	public void unregisterListMergeComparator(Class<?> clazz)
	{
		listMergeComparators.remove(clazz);
	}
	
	public void addExcludedProperties(Collection<String> excludedProperties)
	{
		this.excludedProperties.addAll(excludedProperties);
	}
	
	public void addExcludedProperty(String property)
	{
		this.excludedProperties.add(property);
	}
	                                                                         
	public void registerListPredicate(Class clazz, Predicate predicate)
	{
		this.listFilterPredicates.put(clazz, predicate);
	}
	
	public void unregisterListPredicate(Class clazz)
	{
		this.listFilterPredicates.remove(clazz);
	}
	
	/*
	 * Compare two or more entities.
	 * Assumes that the given root entity is NOT a Collection or Map
	 *
	 * THREAD SAFETY, this method is meant to be thread-safe / re-entrant
	 * but, registering new editors, comparators is not safe while comparison
	 * is running.
	 */
	public CompareResult compare(Object... entities) throws GcasException
	{
		CompareResult result = null;
		CompareResult[] results = rCompare(entities, null, false);
		if(null != results){
			result = results[0];
		}
		if( null != result ) {
			result.setName(ROOT);
		}
		return result;
		
	}
	
	/*
	 * Recursive entry point for comparison of object graph.
	 * We continue to follow graph (re-call this method)
	 * until we reach a data-type which is atomic.
	 * NOTE: sub-classes may need to override typeOf() to create
	 *       a more rational base case than ATOMIC_PROPERTIES defined above.
	 */
	protected CompareResult[] rCompare(Object[] entities, String propertyPath, boolean isListMember) throws GcasException
	{
		PropertyType type = getConsistentType(entities, propertyPath);
		CompareResult[] result = null;
		
		if (!StringUtils.isEmpty(propertyPath) && excludedProperties.contains(propertyPath))
		{
			return null;
		}
		
		if (type != null)
		{
			switch (type)
			{
				case BEAN:					
					result = new CompareResult[] {compareBean(entities, propertyPath, isListMember)};
					break;
				case MAP:
					result = compareMap(entities, propertyPath);
					break;
				case COLLECTION:
					result = compareCollection(entities, propertyPath);
					break;
				case ATOMIC:
					result = new CompareResult[] {compareAtomic(entities, propertyPath)};
					break;
				case ARRAY:
					Object[] collectionArr = new Object[entities.length];
					for (int n = 0; n < entities.length; n++)
					{
						Object[] arr = (Object[]) entities[n];
						collectionArr[n] = Arrays.asList(arr);
					}
					result = compareCollection(collectionArr, propertyPath);					
					break;
				default:
			}
		}
		
		return result;
	}	

	/*
	 * Compare the given array of atomic entities.
	 * This method is never recursive.
	 * In this case entities is an array of primitive
	 * values which are being compared to one-another
	 */
	protected CompareResult compareAtomic(Object[] entities, String propertyPath) throws GcasException
	{
		CompareResult result = new CompareResult();
		result.setAllProperties(new ArrayList<String>(0));
		result.setBeanResults(new HashMap<String, CompareResult>(0));
		result.setArraysResults(new HashMap<String, CompareResult[]>(0));
		result.setPropertyValues(new HashMap<String, String[]>(0));
		result.setMatchedProperties(new HashSet<String>(0));
		result.setUnmatchedProperties(new HashSet<String>(0));
		String[] atomicValues = stringRepresentationForArray(entities, valuePropertyEditors, propertyPath);
		result.getPropertyValues().put(CompareResult.ATOMIC_VALUES_KEY, atomicValues);
		
		result.setName(propertyPath); // FIXME
		
		boolean isMatched = true;
		
		if (entities!=null && entities.length > 1)
		{
			// get the comparator for this leaf.
			// we're assuming all atomics must be comparable with
			// one another, if not we'll throw run-time exception.
			Class<?> clazz = null;
			Comparator<Object> comparator = null;
			for (int n = 0; n < entities.length - 1 && isMatched; n++)
			{
				if (entities[n] == null && entities[n + 1] == null)
				{
					isMatched = true;
				}
				else if (entities[n] == null || entities[n + 1] == null)
				{
					isMatched = false;
				}
				else 
				{
					if (comparator == null)
					{
						clazz = entities[n].getClass();
						comparator = getEquivalenceComparator(clazz, propertyPath); 
					}
					try
					{
						Date left = null;
						Date right = null;
						if(entities[n] instanceof java.sql.Timestamp)
						{
							left = new Date(((Timestamp)entities[n]).getTime());
						}
						else if(entities[n] instanceof Date)
						{
							left = (Date)entities[n];
						}
						
						if(left != null){
							if(entities[n+1] instanceof java.sql.Timestamp)
								right = new Date(((Timestamp)entities[n+1]).getTime());
							else
								right = (Date)entities[n+1];
							
							Calendar cal1 = Calendar.getInstance();
							Calendar cal2 = Calendar.getInstance();
													
							cal1.setTime(left);
							cal1.set(Calendar.MILLISECOND, 0);
							cal1.set(Calendar.SECOND, 0);
							
							cal2.setTime(right);
							cal2.set(Calendar.MILLISECOND, 0);
							cal2.set(Calendar.SECOND, 0);

							isMatched = cal1.compareTo(cal2) == 0 ? true : false ;
						}else
							isMatched = comparator.compare(entities[n], entities[n + 1]) == 0;
					}
					catch (ClassCastException e)
					{
						throw new GcasException("Property of type \"" + clazz + "\" is not comparable. "
								+ "Maybe you need to registerEquivalenceComparator()?");
					}
				}
			}		
		}
		
		if (isMatched)
		{
			result.getMatchedProperties().add(CompareResult.ATOMIC_VALUES_KEY);
		}
		else
		{
			result.getUnmatchedProperties().add(CompareResult.ATOMIC_VALUES_KEY);
		}
		
		populateEntityAndId(entities, propertyPath, result);
		return result;
	}

	/*
	 * Compare the properties of two or more beans, following graph as
	 * necessary into child properties.
	 */
	protected CompareResult compareBean(Object[] beans, String propertyPath, boolean isListMember) throws GcasException
	{
		Set<String> allProperties = new LinkedHashSet<String>();
		Set<String> allPropertyNames = new LinkedHashSet<String>();
		List<Map<String, Object>> beanPropertyMaps = new ArrayList<Map<String, Object>>(beans.length);
		for (Object entity : beans)
		{
			try
			{
				List<String> propNames = new LinkedList<String>();
				Map<String, Object> props = describe(entity, propertyPath, propNames);
				beanPropertyMaps.add(props);
				allProperties.addAll(props.keySet());
				allPropertyNames.addAll(propNames);
			}
			catch (Exception e)
			{
				throw new GcasException("Failed while accessing bean properties at property \"" 
						+ propertyPath + "\".", e);
			}
		}
		
		boolean blnSystemDatePropertyFlag = false;
		List<CompareResult> lArrSystemDateCompareResult = null;
		CompareResult result = new CompareResult();
		result.setAllProperties(new ArrayList<String>(allProperties.size()));
		result.setMatchedProperties(new HashSet<String>(allProperties.size()));
		result.setUnmatchedProperties(new HashSet<String>(allProperties.size()));
		result.setPropertyValues(new HashMap<String, String[]>(allProperties.size()));
		result.setArraysResults(new HashMap<String, CompareResult[]>());
		result.setBeanResults(new HashMap<String, CompareResult>(allProperties.size()));
		result.setJavaPropertyNames(new HashMap<String, String>());
		
		// true if this bean is being compared as a member of a list
		if (isListMember)
		{
			// list member beans can have values assoicated with thier node
			// in the result graph. e.g. values that appear to the right of 
			// their name in the gui window.
			
			// check if this bean has any string represenations that should
			// appear to its right.
			String[] values = stringRepresentationForArray(beans, valuePropertyEditors, propertyPath);
			
			// attach the values a bean level (under no specific bean attribute)
			result.getPropertyValues().put(CompareResult.ATOMIC_VALUES_KEY, values);
			
			// make sure to flag as either matched or unmatched
			if (arrayAllEqual(values))
			{
				result.getMatchedProperties().add(CompareResult.ATOMIC_VALUES_KEY);
			}
			else
			{
				result.getUnmatchedProperties().add(CompareResult.ATOMIC_VALUES_KEY);
			}
			
		}
				
		Iterator<String> allPropertiesIter = allProperties.iterator();
		Iterator<String> namesIter = allPropertyNames.isEmpty() ? allProperties.iterator() : allPropertyNames.iterator();
		
		while (allPropertiesIter.hasNext())
		{
			String property = allPropertiesIter.next();
			String name = namesIter.next();
			
			// save the mapping between printable 'name' and the java property which created it
			result.getJavaPropertyNames().put(name, property);
			
			Object[] values = getValues(beanPropertyMaps, property);
			String fullPath = propertyPath == null ? property : propertyPath + PROPERTY_PATH_DELIMETER + property;
			PropertyType type = getConsistentType(values, fullPath);
			CompareResult[] propResult = rCompare(values, fullPath, false);
			
			if (propResult != null){
				
				if(name != null && name.equalsIgnoreCase("Dates")){
					lArrSystemDateCompareResult = new ArrayList<CompareResult>();
				}
				
				blnSystemDatePropertyFlag = false;
				for (CompareResult r : propResult){
					if (r.getName() == null){
						r.setName(name); // FIXME, custom naming
					}else if(checkSystemDatesExtraction(name, r)){
						blnSystemDatePropertyFlag = true;
						lArrSystemDateCompareResult.add(r);
						propResult = (CompareResult[]) ArrayUtils.removeElement(propResult, r);
					}// EP Phase - I Traded date and Settled Date Audit comparison code changes
				}
			}
			
			// EP Phase - I Traded date and Settled Date Audit comparison code changes
			if(blnSystemDatePropertyFlag){
				String strSystemFlagPropertyName = "System Dates";
				result.getAllProperties().add(strSystemFlagPropertyName);
				CompareResult[] systemDatesResults = lArrSystemDateCompareResult.toArray(new CompareResult[lArrSystemDateCompareResult.size()]);
				if(lArrSystemDateCompareResult == null || isAllMatched(systemDatesResults)){
					result.getMatchedProperties().add(strSystemFlagPropertyName);
				}else{
					result.getUnmatchedProperties().add(strSystemFlagPropertyName);
				}
				result.getArraysResults().put(strSystemFlagPropertyName, systemDatesResults);
				blnSystemDatePropertyFlag = false;
			}
			
			if (propResult == null || isAllMatched(propResult)){
				result.getMatchedProperties().add(name);
			}else{
				result.getUnmatchedProperties().add(name);
			}
			
			result.getAllProperties().add(name);
			
			if (type == null) // FIXME, want better type handling of null
			{                 // can't tell if its bean or atomic
				result.getPropertyValues().put(name, new String[values.length]);
			} else if(propResult == null){
				// do nothing
			}
			else if (type == PropertyType.ATOMIC)
			{
				// the property is atomic and not a collection, reduce it into our result set
				result.getPropertyValues().put(name, propResult[0].getPropertyValues().get(CompareResult.ATOMIC_VALUES_KEY));
			}
			else if (type == PropertyType.COLLECTION || type == PropertyType.ARRAY)
			{
				result.getArraysResults().put(name, propResult);
			}
			else if (type == PropertyType.BEAN)
			{
				result.getBeanResults().put(name, propResult[0]);
			}
		}
		
		populateEntityAndId(beans, propertyPath, result);		
		return result;
	}

	/* Method to check system dates field available for extraction from datevalues */
	private boolean checkSystemDatesExtraction(String name, CompareResult r) {
		return name != null
				&& name.equalsIgnoreCase("Dates")
				&& r.getName() != null
				&& (r.getName().equalsIgnoreCase("Settled Date")
						|| r.getName().equalsIgnoreCase(
								"Position Pull End Date") || r.getName()
						.equalsIgnoreCase("Traded Date"));
	}

	/*
	 * Override this method to assign the id property in result
	 */
	protected String getIdForBean(Object bean, String propertyPath)
	{
		return null;
	}
	
	protected void populateEntityAndId(Object[] beans, String propertyPath, CompareResult result)
	{
		String[] ids = new String[beans.length];
		BusinessEntity[] tobjs = new BusinessEntity[beans.length];
		
		IsSerializable[] sOb = new IsSerializable[beans.length];
		for (int n = 0; n < beans.length; n++) {
			if (beans[n] != null) {
				
				if (beans[n] instanceof BusinessEntity) 
				{
					tobjs[n] = (BusinessEntity) beans[n];
				} else if (beans[n] instanceof IsSerializable) {
					sOb[n] = (IsSerializable) beans[n];
				}
				
			}
			ids[n] = getIdForBean(beans[n], propertyPath);
		}
		// save the object which were compared in the object
		result.setEntities(tobjs);
		result.setSerializableEntities(sOb);
		result.setIds(ids);
	}
	
	private <T> List<? extends T> sortAndFilterCollection(Collection<T> collection, Comparator<T> comparator, Predicate predicate)
	{
		if (collection == null)
		{
			return new ArrayList<T>(0);
		}
		List<T> result = new ArrayList<T>(collection);
		Collections.sort(result, comparator);
		CollectionUtils.filter(result, predicate);
		return result;
	}
	
	/*
	 * Compare the given Collection[]. It is assumed that
	 * all objects are comparable to one another.
	 */
	private CompareResult[] compareCollection(Object[] entities, String propertyPath) throws GcasException
	{
		// FIXME:
		// merge-joining N sets is more complexity than I want
		// to support, this method needs to be changed if we
		// want to compare N beans with collection properties.
		// For now, this works only with exactly 2 beans.
		if (entities.length < 2 || entities.length > 2)
		{
			throw new GcasException("Comparison beans with collection properties supportes exactly two beans only." + " must be between " + 2 + " and " + 2 + ".");
		}
//		IcgAssert.inRange(entities.length, 2, 2, 
//				"Comparison beans with collection properties supportes exactly two beans only.");
		
		Class clazz = classOf(entities);
		Comparator comparator = getListMergeComparator(clazz, propertyPath);
		Predicate predicate = getListFilter(clazz, propertyPath);
		
		List left = null;
		List right = null;
		try
		{
			left = sortAndFilterCollection((Collection) entities[0], comparator, predicate);
			right = sortAndFilterCollection((Collection) entities[1], comparator, predicate);
		}
		catch (ClassCastException cce)
		{
			throw new GcasException("Property of type \"" + clazz + "\" is not comparable. "
					+ "Maybe you need to registerListMergeComparator()?");
		}
		
		
		ListIterator rightIter = right.listIterator();
		ListIterator leftIter = left.listIterator();
		
		List<CompareResult> result = new ArrayList<CompareResult>(left.size() + right.size());
		
		while (leftIter.hasNext() && rightIter.hasNext())
		{
			Object l = leftIter.next();
			Object r = rightIter.next();
			int comp = comparator.compare(l, r);
			if (comp < 0)
			{
				// left pointer points to a values smaller than right
				// don't advance the right pointer and only process
				// object on left
				rightIter.previous();
				CompareResult c = rCompare(new Object[] {l, null}, propertyPath, true)[0];
				c.setName(stringRepresenation(l, namePropertyEditors, propertyPath));
				result.add(c);
			}
			else if (comp > 0)
			{
				leftIter.previous();
				CompareResult c = rCompare(new Object[] {null, r}, propertyPath, true)[0];
				c.setName(stringRepresenation(r, namePropertyEditors, propertyPath));
				result.add(c);
			}
			else
			{
				// both pointers point to an equivalent value, do deep inspection
				CompareResult c = rCompare(new Object[] {l, r}, propertyPath, true)[0];
				// note that the name used describes both left and right object
				// so it should not disagree with the list merge comparator.
				c.setName(stringRepresenation(r, namePropertyEditors, propertyPath));
				result.add(c);
			}
		}
		
		while (leftIter.hasNext())
		{
			Object next = leftIter.next();
			CompareResult c = rCompare(new Object[] {next, null}, propertyPath, true)[0];
			c.setName(stringRepresenation(next, namePropertyEditors, propertyPath));
			result.add(c);
		}
		
		while (rightIter.hasNext())
		{
			Object next = rightIter.next();
			CompareResult c = rCompare(new Object[] {null, next}, propertyPath, true)[0];
			c.setName(stringRepresenation(next, namePropertyEditors, propertyPath));
			result.add(c);
		}
		
		return result.toArray(new CompareResult[0]);
	}
	
	protected Predicate getListFilter(Class clazz, String propertyPath)
	{
		return listFilterPredicates.get(clazz);
	}

	private CompareResult[] compareMap(Object[] entities, String propertyPath)
	{
		throw new Error("Map properties are not supported.");
	}
	
	private Object[] getValues(List<Map<String, Object>> beanPropertyMaps, String property)
	{
		Object[] result = new Object[beanPropertyMaps.size()];
		for (int n = 0; n < beanPropertyMaps.size(); n++)
		{
			result[n] = beanPropertyMaps.get(n).get(property);
		}
		return result;
	}
	
	private boolean isAllMatched(CompareResult[] results)
	{
		for (CompareResult result : results)
		{
			if (!result.getUnmatchedProperties().isEmpty())
			{
				return false;
			}
		}
		return true;
	}
	
	private String[] stringRepresentationForArray(Object[] objs, Map<Class, PropertyEditor> editors, String propertyPath)
	{
		if (objs == null)
		{
			return null;
		}
		String[] result = new String[objs.length];
		for (int n = 0; n < objs.length; n++)
		{
			result[n] = stringRepresenation(objs[n], editors, propertyPath);
		}
		return result;
	}
	
	/*
	 * Implemenations can override this method
	 * with more specific presentation logic.
	 */
	protected String stringRepresenation(Object obj, Map<Class, PropertyEditor> editors, String propertyPath)
	{
		if (obj == null)
		{
			return StringUtils.EMPTY;
		}
		PropertyEditor editor = getPropertyEditor(obj.getClass(), editors);
		if (editor == null)
		{
			return obj.toString();
		}
		else
		{
			synchronized (editor)
			{
				editor.setValue(obj);
				return editor.getAsText();
			}
		}
	}
	
	/*
	 * Assert that the given entity beans are of a consistent type
	 * and return that type.  I don't care about class hierarchy I'll
	 * duck-type any beans, but if one entity is a collection, map, 
	 * or array, they must all be collection, map, array respectively
	 */
	private PropertyType getConsistentType(Object[] entities, String propertyPath)
	{
		PropertyType type = null;
		boolean containsPlaceHolder = false;
		for (Object obj : entities)
		{
			if (obj != null)
			{
				// UGLY HACK, PlaceHolder may be returned as the value
				// of a bean property where describe() is used. This is
				// done so that recursive compare will not stop at null
				// property. A PlaceHolder does not have a datatype of
				// its own, and should be coerced into to whatever type
				// its being compared with.
				if (obj instanceof PlaceHolder)
				{
					containsPlaceHolder = true;
				}
				else if (type == null)
				{
					type = typeOf(obj, propertyPath);
				}
				else if (type != typeOf(obj, propertyPath))
				{
					throw new GcasError("Object graph types are not consistent.");
				}
			}
		}
		return type == null && containsPlaceHolder ? PropertyType.BEAN : type;
	}
	
	/*
	 * Retutn the comparator which should be used for object
	 * of type clazz. Note this method does not understand
	 * class hierance, and class must exactly match.
	 */
	public Comparator getListMergeComparator(Class clazz, String propertyPath)
	{
		return listMergeComparators.get(clazz);
	}
	
	/*
	 * Retutn the comparator which should be used for object
	 * of type clazz. Note this method does not understand
	 * class hierance, and class must exactly match.
	 */
	protected Comparator getEquivalenceComparator(Class clazz, String propertyPath)
	{
		return equivalenceComparators.get(clazz);
	}
	
	/*
	 * Get the property editor used
	 * TODO check util-concurrent for a thread safe map.
	 *      I really don't need to synch here?
	 */
	protected PropertyEditor getPropertyEditor(Class clazz, Map<Class, PropertyEditor> editors)
	{
		PropertyEditor result;
		synchronized (editors)
		{
			result = editors.get(clazz);
			if (result == null)
			{
				for (Entry<Class, PropertyEditor> entry : editors.entrySet())
				{
					if (entry.getKey().isAssignableFrom(clazz))
					{
						result = entry.getValue();
						break;
					}
				}
				editors.put(clazz, result);
			}
		}
		return result;
	}
	
	/*
	 * Given an array of collections retutn the class
	 * type of its elements. This method assumes that
	 * all elements are the same type (no inhertance).
	 * If type heirarchy, becomse more complicated, it
	 * may need to return greatest-common-class.
	 */
	protected Class<?> classOf(Object[] collections)
	{
		for (Object o : collections) 
		{
			Collection<?> c = (Collection<?>) o;
			if (CollectionUtils.isNotEmpty(c)) {
				return c.iterator().next().getClass();
			}
		}
		return null;
	}
	
	/*
	 * Get the type of the specified object.
	 * 
	 * This method can be extended to control
	 * how deep into the object graph we will
	 * traverse.
	 */
	protected PropertyType typeOf(Object o, String propertyPath)
	{
		PropertyType result;
		if (o == null)
		{
			result = null;
		}
		else if (o.getClass().isArray())
		{
			result = PropertyType.ARRAY;
		}
		else if (Map.class.isAssignableFrom(o.getClass()))
		{
			result = PropertyType.MAP;
		}
		else if (Collection.class.isAssignableFrom(o.getClass()))
		{
			result = PropertyType.COLLECTION;
		}
		else if (ATOMIC_PROPERTIES.contains(o.getClass()))
		{
			result = PropertyType.ATOMIC;
		}
		else
		{
			result = PropertyType.BEAN;
		}
		return result;
	}
	
	/*
	 * Return a map containing property name -> propert value
	 * for all readable properties of the sepecifed object. 
	 * 
	 * This method may be extended to provide more meaningful
	 * property names, or to limit the set of properties included
	 * in the comparison.
	 */
	protected Map<String, Object> describe(Object o, String propertyPath, List<String> names) throws Exception
	{
		if (o == null)
		{
			return new HashMap<String, Object>();
		}
		Map<String, Object> result = PropertyUtils.describe(o);
		result.remove(CLASS_PROPERTY); // exclude .getClass()
		// in the base implemenation "property name" is always the java property.
		// simply copy resutlt, to map key -> key
		return result;
	}
	
	/*
	 * True if ever element of ths given array is equal.
	 */
	private boolean arrayAllEqual(String[] values)
	{
		if (values == null)
		{
			return true;
		}
		
		String lastValue = null;
		for (String str : values)
		{
			if (lastValue == null)
			{
				lastValue = str;
			}
			else if (!lastValue.equals(str))
			{
				return false;
			}
		}
		return true;
	}
	
}