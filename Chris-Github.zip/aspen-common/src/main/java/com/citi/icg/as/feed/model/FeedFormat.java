/**
 * 
 */
package com.citi.icg.as.feed.model;

/**
 * Enum class for various feeds from ASPEN to downstream system
 * @author ap72338
 *
 */
public enum FeedFormat {

	DBS, 
	FLEXCUBE, 
	S2DBS, 
	S2FLEXCUBE,
	QUICKREC,
	QUICKREC_OK,
	SONOF,
	TACS,
	IPS,
	ADVI,
	TEFRA,
	DAID,	
	A2SP,
	GCSDVF48009,
	GCSDVF4800A,
	VCF81252,
	RTI;
	
}
