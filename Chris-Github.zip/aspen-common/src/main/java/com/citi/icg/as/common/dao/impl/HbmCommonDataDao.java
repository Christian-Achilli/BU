package com.citi.icg.as.common.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.DateType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Repository;

import com.citi.icg.as.common.constants.LegalEntityConstant;
import com.citi.icg.as.common.dao.CommonDataDao;
import com.citi.icg.as.common.enums.AnnouncementCopyTypeEnum;
import com.citi.icg.as.common.enums.ProcessingUnitType;
import com.citi.icg.as.core.dao.entities.business.AnnouncementCopyType;
import com.citi.icg.as.core.dao.entities.business.CountryCode;
import com.citi.icg.as.core.dao.entities.business.CurrencyCode;
import com.citi.icg.as.core.dao.entities.business.FXRate;
import com.citi.icg.as.core.dao.entities.business.FieldQualifier;
import com.citi.icg.as.core.dao.entities.business.LegalEntity;
import com.citi.icg.as.core.dao.entities.business.ProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.Region;
import com.citi.icg.as.core.dao.entities.business.SourceSystem;
import com.citi.icg.as.core.dao.entities.ext.beans.CountryCodeMapping;
import com.citi.icg.as.server.util.GcasConstants;

@Repository
public class HbmCommonDataDao implements CommonDataDao {

	@Resource(name = "hibernateTemplate")
	private HbmGenericTemplate template;

	@Override
	public Region getRegion(final String regionCode) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.Region.class);
		criteria.add(Restrictions.eq("regionCode", regionCode));
		return template.findSingleByCriteria(Region.class, criteria);
	}

	@Override
	public Set<Region> getRegions() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.Region.class);
		return new HashSet<>(template.findByCriteria(Region.class, criteria));
	}

	@Override
	public List<SourceSystem> getSourceSystems() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.SourceSystem.class);
		return template.findByCriteria(SourceSystem.class, criteria);
	}

	@Override
	public CountryCode getCountryCode(final String alpha3Code) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.CountryCode.class);
		criteria.add(Restrictions.eq("alpha3Code", alpha3Code));
		return (CountryCode) template.findSingleByCriteria(CountryCode.class,
				criteria);
	}

	@Override
	public Set<CountryCode> getCountryCodes() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.CountryCode.class);
		return new HashSet<CountryCode>(template.findByCriteria(
				CountryCode.class, criteria));

	}

	@Override
	public Set<CountryCodeMapping> getCountryCodeMapping() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(CountryCodeMapping.class);
		return new HashSet<CountryCodeMapping>(template.findByCriteria(
				CountryCodeMapping.class, criteria));

	}

	public Integer executeUpdateSQL(final String query) {
		return template.execute(new HibernateCallback<Integer>() {
			public Integer doInHibernate(Session session) {
				SQLQuery sql = session.createSQLQuery(query);
				return sql.executeUpdate();
			}
		});
	}

	public Integer executeUpdateSQL(final String query,
			final Map<String, ? extends Object> params) {
		return template.executeUpdateSQL(query, params);
	}

	@SuppressWarnings("rawtypes")
	public List executeSQL(final String query) {
		return template.executeSQL(query);
	}

	@Override
	public Set<ProcessingUnit> getProcessingUnits() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.ProcessingUnit.class);
		return new HashSet<ProcessingUnit>(template.findByCriteria(
				ProcessingUnit.class, criteria));
	}

	@Override
	public AnnouncementCopyType getQualifier(final String qualifierName) {

		HibernateCallback<AnnouncementCopyType> callback = new HibernateCallback<AnnouncementCopyType>() {
			@Override
			public AnnouncementCopyType doInHibernate(Session arg0)
					throws HibernateException, SQLException {
				Criteria criteria = arg0
						.createCriteria(com.citi.icg.as.core.dao.entities.ext.beans.AnnouncementCopyType.class);
				criteria.add(Restrictions.eq("qualifierName", qualifierName));
				return template.findSingleByCriteria(
						AnnouncementCopyType.class, criteria);
			}
		};
		return template.execute(callback);
	}

	@Override
	public AnnouncementCopyType getQualifier(AnnouncementCopyTypeEnum item) {
		return getQualifier(item.getPkQualifierId());
	}

	@Override
	public AnnouncementCopyType getQualifier(final int qualifierId) {
		HibernateCallback<AnnouncementCopyType> callback = new HibernateCallback<AnnouncementCopyType>() {
			@Override
			public AnnouncementCopyType doInHibernate(Session arg0)
					throws HibernateException, SQLException {
				Criteria criteria = arg0
						.createCriteria(com.citi.icg.as.core.dao.entities.ext.beans.AnnouncementCopyType.class);
				criteria.add(Restrictions.eq("pkQualifierId", qualifierId));
				return template.findSingleByCriteria(
						AnnouncementCopyType.class, criteria);
			}
		};
		return template.execute(callback);
	}

	@Override
	public Set<FieldQualifier> getFieldQualifiers() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.FieldQualifier.class);
		return new HashSet<FieldQualifier>(template.findByCriteria(
				FieldQualifier.class, criteria));
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<String> getNodeNames(final String clusterName) {
		return template.execute(new HibernateCallback<List<String>>() {

			@Override
			public List<String> doInHibernate(Session session)
					throws HibernateException, SQLException {
				String sql = "SELECT NODE_NAME FROM CLUSTER_MASTER WHERE CLUSTER_NAME=:clusterName";
				SQLQuery query = session.createSQLQuery(sql);
				query.addScalar("NODE_NAME", Hibernate.STRING).setParameter(
						"clusterName", clusterName);
				return query.list();
			}
		});
	}

	@Override
	public List<CurrencyCode> getCurrencyCodesList() {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.CurrencyCode.class);
		return new ArrayList<CurrencyCode>(template.findByCriteria(
				CurrencyCode.class, criteria));
	}

	@Override
	public <T> List<T> fetchData(Class<T> entityClass, int startRow,
			int pageSize) {
		DetachedCriteria criteria = DetachedCriteria.forClass(template
				.getDomainClass(entityClass));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return template.findByCriteria(entityClass, criteria, startRow,
				pageSize);
	}

	@Override
	public <T> List<T> fetchData(Class<T> entityClass) {
		DetachedCriteria criteria = DetachedCriteria.forClass(template
				.getDomainClass(entityClass));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return template.findByCriteria(entityClass, criteria);
	}

	@Override
	public int countDataRows(Class<?> entityClass) {
		DetachedCriteria criteria = DetachedCriteria.forClass(template
				.getDomainClass(entityClass));
		criteria.setProjection(Projections.rowCount());
		List<Long> rowCountList = (List<Long>) template
				.findByCriteria(criteria);
		return rowCountList.get(0).intValue();
	}

	@Override
	public List<FXRate> getCurrencyFxRate(final String termCurrency,
			final String baseCurrency) {
		return template.execute(new HibernateCallback<List<FXRate>>() {
			@Override
			public List<FXRate> doInHibernate(Session session)
					throws HibernateException, SQLException {
				String sql = "select PK_FX_RATE_ID as \"pkFxRateId\",FX_RATE_DATE as \"fxRateDate\", RATE_TYPE as \"rateType\" ,FK_TERM_CCY as \"termCcy\","
						+ "FK_BASE_CCY as \"baseCcy\",TENOR as \"tenor\",FX_RATE_BID as \"fxRateBid\",FX_RATE_ASK as \"fxRateAsk\" ,FX_RATE_MID as \"fxRateMid\","
						+ "INSTRUMENT_LABEL as \"instrumentLabel\"  from FX_RATE where FK_TERM_CCY in (select PK_CURRENCY_CODE_ID from CURRENCY_CODE where CURRENCY_CODE=:TERMCCY)"
						+ "and FK_BASE_CCY in (select PK_CURRENCY_CODE_ID from CURRENCY_CODE where CURRENCY_CODE=:BASECCY)";
				SQLQuery query = session.createSQLQuery(sql);
				query.setResultTransformer(Transformers
						.aliasToBean(FXRate.class));
				query.setParameter("TERMCCY", termCurrency);
				query.setParameter("BASECCY", baseCurrency);
				query.addScalar("pkFxRateId", LongType.INSTANCE);
				query.addScalar("fxRateDate", DateType.INSTANCE);
				query.addScalar("rateType", StringType.INSTANCE);
				query.addScalar("termCcy", LongType.INSTANCE);
				query.addScalar("baseCcy", LongType.INSTANCE);
				query.addScalar("tenor", StringType.INSTANCE);
				query.addScalar("fxRateBid", BigDecimalType.INSTANCE);
				query.addScalar("fxRateAsk", BigDecimalType.INSTANCE);
				query.addScalar("fxRateMid", BigDecimalType.INSTANCE);
				query.addScalar("instrumentLabel", StringType.INSTANCE);
				List<FXRate> list = (List<FXRate>) query.list();
				return list;
			}
		});

	}

	/**
	 * Method to fetch Country Code either for AlphaCode2 or AlphaCode3
	 */
	@Override
	public CountryCode getCountry(final String alphaCode) {
		DetachedCriteria criteria = DetachedCriteria
				.forClass(com.citi.icg.as.core.dao.entities.ext.beans.CountryCode.class);
		criteria.add(Restrictions.disjunction().add(Restrictions.eq("alpha3Code", alphaCode)).add(Restrictions.eq("alpha2Code", alphaCode)));
		return (CountryCode) template.findSingleByCriteria(CountryCode.class,
				criteria);
	}

	@Override
	public List<LegalEntity> getAllDefaultLegalEntities() {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.LegalEntity.class);
		criteria.add(Restrictions.isNull(LegalEntityConstant.PROCESSING_UNIT));
		criteria.addOrder(Order.asc(LegalEntityConstant.LEGAL_ENTITY_NAME));
		return template.findByCriteria(LegalEntity.class, criteria);
	}
	
	@Override
	public List<LegalEntity> getAllLegalEntitiesForBR() {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.LegalEntity.class);
		criteria.add(Restrictions.eq(LegalEntityConstant.PROCESSING_UNIT, ProcessingUnitType.CGMI_BROADRIDGE.getDisplayName()));
		criteria.addOrder(Order.asc(LegalEntityConstant.LEGAL_ENTITY_NAME));
		return template.findByCriteria(LegalEntity.class, criteria);
	}

	@Override
	public List<String> getCairoLegalEntitiesFilter() {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.LegalEntity.class);
		criteria.add(Restrictions.eq(LegalEntityConstant.CAIRO_FILTER_FLAG, GcasConstants.Y));
		com.citi.icg.as.core.dao.entities.ext.beans.LegalEntity example = new com.citi.icg.as.core.dao.entities.ext.beans.LegalEntity();
		example.setCairoFilterFlag(GcasConstants.Y);
		List<LegalEntity> legEntities = template.findByCriteria(LegalEntity.class, criteria);
		List<String> cairoFilterCriteriaValues = new ArrayList<String>();
		for (LegalEntity legEntity : legEntities) {
			cairoFilterCriteriaValues.add(legEntity.getLegalEntityName());
		}
		return cairoFilterCriteriaValues;
	}

}
