package com.citi.icg.as.common.client.compare;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.citi.icg.as.common.client.util.ClientConstants;
import com.citi.icg.as.common.client.util.StringUtilGwt;

@SuppressWarnings("serial")
public abstract class SimpleCompareResultVisitor implements CompareResultVisitor {
	private static final String PROPERTY_NAME_PATH_DELIMETER = ClientConstants.DOT_CHAR;
	private List<CompareResult> compareResultStack = new LinkedList<CompareResult>();
	private List<String> propertyNameStack = new LinkedList<String>();
	private Set<CompareResult> arrayResultMembers = new HashSet<CompareResult>();

	// override this method
	public void acceptProperty(String propertyName, CompareResult compareResult, boolean isMatched, String[] values) {

	}

	// override this method
	public void acceptCompareResult(String propertyName, CompareResult compareResult) {

	}

	public void startRootCompareResult() {

	}

	public void endRootCompareResult() {

	}

	public final List<CompareResult> getCompareResultStack() {
		return Collections.unmodifiableList(compareResultStack);
	}

	public final List<String> getPropertyNameStack() {
		return Collections.unmodifiableList(propertyNameStack);
	}

	public final String getPropertyNamePath() {
		return getPropertyNamePath(null);
	}

	public final String getPropertyNamePath(String currentProperty) {
		List<String> path = new ArrayList<String>(propertyNameStack);
		Collections.reverse(path);
		for (Iterator<String> iter = path.iterator(); iter.hasNext();) {
			if (StringUtilGwt.isNullOrEmpty(iter.next())) {
				iter.remove();
			} else {
				break;
			}
		}
		if (currentProperty != null) {
			path.add(currentProperty);
		}
		return StringUtilGwt.joinWithDelimeter(PROPERTY_NAME_PATH_DELIMETER, path.toArray(new String[0]));
	}

	public final boolean isCompareResultFromCollection(CompareResult result) {
		return arrayResultMembers.contains(result);
	}

	public final boolean isCompareResultFromCollection() {
		return isCompareResultFromCollection(compareResultStack.get(0));
	}

	public final void startBeanResult(String propertyName, CompareResult compareResult) {
		if (compareResultStack.isEmpty()) {
			startRootCompareResult();
		}

		compareResultStack.add(0, compareResult);
		propertyNameStack.add(0, propertyName);
		acceptCompareResult(propertyName, compareResult);
	}

	public final void endBeanResult(String propertyName, CompareResult compareResult) {
		compareResultStack.remove(0);
		propertyNameStack.remove(0);

		if (compareResultStack.isEmpty()) {
			endRootCompareResult();
		}
	}

	public final void acceptProperty(String propertyName) {
		CompareResult parent = compareResultStack.get(0);
		boolean isMatched = !parent.getUnmatchedProperties().contains(propertyName);
		String[] values = parent.getPropertyValues().get(propertyName);
		acceptProperty(propertyName, parent, isMatched, values);
	}

	public final void startCollectionResult(String propertyName, CompareResult[] compareResults) {
		arrayResultMembers.addAll(Arrays.asList(compareResults));
	}

	public final void endCollectionResult(String propertyName, CompareResult[] compareResults) {
		arrayResultMembers.removeAll(Arrays.asList(compareResults));
	}

}
