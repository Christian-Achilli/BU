package com.citi.icg.as.config;

public class GacsConfigurationException extends RuntimeException
{
	private static final long serialVersionUID = 4851178621145401471L;

	public GacsConfigurationException(String message)
	{
		super(message);
	}

	public GacsConfigurationException(String message, Throwable cause)
	{
		super(message, cause);
	}
}
