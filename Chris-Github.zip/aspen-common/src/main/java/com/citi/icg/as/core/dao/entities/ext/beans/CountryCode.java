package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseCountryCode;

@Entity
@Table(name = "COUNTRY_CODE")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class CountryCode extends BaseCountryCode {

	private static final long serialVersionUID = -4807799083057584632L;

}
