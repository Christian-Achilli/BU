/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Conditional;

/**
 * @author ap72338
 *         <p>
 *         The annotation which can create conditional beans depending on
 *         whether env is local or jenkins. By default the
 *         {@link ConditionalRunningLocally#included()} is local and jenkins
 *         only. rest all are considered to be running in an actual server
 *         environment.
 *         </p>
 */

@Target({ ElementType.TYPE, ElementType.METHOD })
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Conditional(OnRunningLocalCondition.class)
public @interface ConditionalRunningLocally {

	String[] included() default { "local", "jenkins" };
}
