
package com.citi.icg.as.server.service;

import javax.annotation.Resource;

import org.springframework.context.ApplicationContext;


/**
 * Simple facade to shield the caller from Spring IOC.
 *
 */
public final class ServiceLookupFactory
{

	private static ServiceLookupFactory INSTANCE = null;
		
	@Resource private ApplicationContext context;

	private ServiceLookupFactory()
	{
		
		
	}
	
	public static synchronized ServiceLookupFactory getInstance()
	{
		if(INSTANCE == null)
		{
			 
			INSTANCE = new ServiceLookupFactory();	
			
		}
		
		return INSTANCE;
	}
	
	public <T> T getServiceLocator(Class<T> locatorBeanClass)
	{
		return context.getBean(locatorBeanClass);
	}
	
	public <T> T getBean(String name,Class<T> locatorBeanClass)
	{
		return context.getBean(name,locatorBeanClass);
	}
	
	public void setContext(ApplicationContext context) {
		this.context = context;
	}
		
	
}
