package com.citi.icg.as.core.dao.entities.ext.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;

import com.citi.icg.as.core.dao.entities.base.beans.JPATransferObject;

@Entity
@Table(name = "USER_REGION")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "hibernate.USER_PROFILE")
public class UserRegion extends JPATransferObject implements Serializable {

	private static final long serialVersionUID = 217513296018444992L;

	public UserRegion() {
	}

	private long pkUserRegionId;
	private User user;
	private Region region;
	private String primaryRegion;
	private Date lastUpdatedDate;
	private Set<UserPURegionMatrix> userPURegionMatrixSet;

	// bi-directional many-to-one association to User
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_USER_ID")
	@org.hibernate.annotations.Fetch(org.hibernate.annotations.FetchMode.SELECT)
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	// bi-directional many-to-one association to Region
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_REGION_CODE_ID")
	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	@Column(name = "IS_PRIMARY")
	public String getPrimaryRegion() {
		return primaryRegion;
	}

	public void setPrimaryRegion(String primaryRegion) {
		this.primaryRegion = primaryRegion;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_USER_REGION", allocationSize = 1)
	@Column(name = "PK_USER_REGION_ID")
	public long getPkUserRegionId() {
		return pkUserRegionId;
	}

	public void setPkUserRegionId(long userRegionId) {
		this.pkUserRegionId = userRegionId;
	}

	@Column(name = "LAST_UPDATED_DATE")
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	// bi-directional many-to-one association to UserPURegionMatrix
	@OneToMany(/* cascade = CascadeType.ALL, */fetch = FetchType.EAGER, mappedBy = "userRegion")
	@Cascade({ org.hibernate.annotations.CascadeType.DELETE })
	public Set<UserPURegionMatrix> getUserPURegionMatrixSet() {
		return userPURegionMatrixSet;
	}

	public void setUserPURegionMatrixSet(Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.userPURegionMatrixSet = userPURegionMatrixSet;
	}
}
