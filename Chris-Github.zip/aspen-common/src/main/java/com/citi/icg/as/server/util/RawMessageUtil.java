package com.citi.icg.as.server.util;

public final class RawMessageUtil {
	private RawMessageUtil() { } 
	// message was processed, updated an announcement, nothing left to do
	public static final char PROCESSED_INDICATOR_PROCESSED = 'Y';
	// message has not been processed yet
	public static final char PROCESSED_INDICATOR_NOT_PROCESSED = 'N';
	// message has expired (has been in 'N' too long)
	public static final char PROCESSED_INDICATOR_EXPIRED = 'X';
	// message has transitioned to failed state (was not processed)
	public static final char PROCESSED_INDICATOR_FAILED = 'F';
	// message has been picked up for processing but was held due do a workflow
	// in progress
	public static final char PROCESSED_INDICATOR_HOLD = 'H';
	// message has processed but was part of a work-flow which was rejected
	// (will not be processed again)
	public static final char PROCESSED_INDICATOR_REJECTED = 'R';
	
	// message failed with Pagination validation will be ignored
	public static final char PROCESSED_INDICATOR_IGNORE = 'I';
	
	public static final String USER_UNASSIGNED = "unassigned";
}
