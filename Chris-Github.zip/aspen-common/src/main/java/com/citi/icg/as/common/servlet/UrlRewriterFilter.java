package com.citi.icg.as.common.servlet;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gwt.user.server.rpc.RPCServletUtils;

/**
 * @author vm47101
 *
 */
public class UrlRewriterFilter implements Filter
{
	private final static Log LOG = LogFactory.getLog(UrlRewriterFilter.class);
	private final static String GWT_RPC_CONTENT_TYPE = "text/x-gwt-rpc";
	private final static String BLANK="";
	private UrlIdentifier identifier;

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy()
	{

	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException
	{
		HttpServletRequest  request =(HttpServletRequest)req;
		String requestURI = request.getRequestURI();
		/**
		* check for url tokens (ASPEN-*)
		*/
		IndexTuple requestUriIdx =  identifier.matchForUrlPattern(requestURI, false);
		if (requestUriIdx != null) {
			/**
			* intercept GWT RPC calls and process the GWT payload to strip of
			* url tokens. Any references to ASPEN https- is stripped off
			*/
			if (isGwtRpcCall(request)) {
				HttpServletRequest filteredRequest = processGwtPayload(request, requestUriIdx);
				filteredRequest.getRequestDispatcher(filteredRequest.getRequestURI())
					.forward(filteredRequest, res);
			} else {
				/**
				* intercept calls for static/dynamic resources and strip of
				* url tokens of request uri
				* url after stripping should refer /CorpAction.html directly without the context amd
				* ASPEN-
				*/
				String newRequestUri = replaceTokensWithBlank(requestURI, requestUriIdx);
				req.getRequestDispatcher(newRequestUri).forward(req, res);
			}
		}
		else {
			chain.doFilter(req, res);
		}
	}
	
	private String replaceTokensWithBlank(String str, IndexTuple index){
		String toReplace = str.substring(index.getStartIndex(), index.getEndIndex());
		return str.replace(toReplace, BLANK);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException
	{
		String regexPattern = filterConfig.getInitParameter("regexPattern");
		if (regexPattern != null){
			identifier = new UrlIdentifier(regexPattern);
		}
	}
	
	private boolean isGwtRpcCall(HttpServletRequest  request){
		String contentType = request.getContentType();
		if (null != contentType && contentType.contains(GWT_RPC_CONTENT_TYPE)){
			return true;
		}
		return false;
	}
	
	/**
	 * for GWT rpc content, intercept the payload and check for urlTokens (ASPEN-*)
	 * if payload contains these urlTokens then strip them off the payload and then wrap the request 
	 * and override requestUri, inputstream to reflect the updated uri and payloads
	 * @param request
	 * @param requestUriIdxs
	 * @return
	 * @throws IOException
	 * @throws ServletException
	 */
	private HttpServletRequest processGwtPayload(final HttpServletRequest request, final IndexTuple requestUriIdxs) throws IOException, ServletException {
		String requestPayload = RPCServletUtils.readContent(request, GWT_RPC_CONTENT_TYPE, RPCServletUtils.CHARSET_UTF8_NAME);
		final IndexTuple requestPayLoadIdxs = identifier.matchForUrlPattern(requestPayload, true);

		if (requestPayLoadIdxs != null){
			requestPayload = replaceTokensWithBlank(requestPayload, new IndexTuple(requestPayLoadIdxs.getStartIndex(), requestPayLoadIdxs.getEndIndex()+1));

			final byte[] requestPayloadBytes = requestPayload.getBytes();
			final ByteArrayInputStream requestPayloadBytesInputStream = new ByteArrayInputStream(requestPayloadBytes);

			// Create a wrapper because you can't modify the GWT HTTP request object
			HttpServletRequestWrapper requestWrapper = new HttpServletRequestWrapper(request){
			@Override
				public String getRequestURI(){
					 String requestURI = request.getRequestURI();
					 return replaceTokensWithBlank(requestURI, requestUriIdxs);
				}
				
				@Override
				public int getContentLength(){
					return requestPayloadBytes.length;
				}
				
				@Override
				public ServletInputStream getInputStream() throws IOException{
					return new ServletInputStream(){

						@Override
						public int read() throws IOException
						{
							return requestPayloadBytesInputStream.read();
						}
						
						@Override
						public int available() throws IOException
						{
							return requestPayloadBytesInputStream.available();
						}
						
						@Override
						public int read(byte[] b, int off, int len) throws IOException
						{
							return requestPayloadBytesInputStream.read(b, off, len);
						}
						
					};
				}
			};
			return requestWrapper;
		}
		return request;
	}

}
