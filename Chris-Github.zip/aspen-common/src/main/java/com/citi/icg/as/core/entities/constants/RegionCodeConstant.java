package com.citi.icg.as.core.entities.constants;

public class RegionCodeConstant {
	public static final String REGION_CODE = "regionCode";
	public static final String DEBUG_STRING = "debugString";
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String VALUE = "value";
	public static final String CLASS = "class";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
	public static final String PK_REGION_CODE_ID = "pkRegionCodeId";
}