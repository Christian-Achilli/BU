/**
 * 
 */
package com.citi.icg.as.common.converter;

import org.springframework.core.convert.converter.Converter;

import com.citi.icg.as.core.dao.entities.business.ProcessingUnit;


/**
 * @author sk21695
 *
 */
public class ProcessingUnitEntityToBusinessConverter implements Converter<com.citi.icg.as.core.dao.entities.ext.beans.ProcessingUnit, ProcessingUnit> {

	@Override
	public ProcessingUnit convert(com.citi.icg.as.core.dao.entities.ext.beans.ProcessingUnit source) {
		
		ProcessingUnit target = new ProcessingUnit();
		target.setGroupEmailAddress(source.getGroupEmailAddress());
		target.setGroupTelephoneNumber(source.getGroupTelephoneNumber());
		target.setLastUpdatedBy(source.getLastUpdatedBy());
		target.setLastUpdatedDate(source.getLastUpdatedDate());
		target.setPkProcessingUnitId(source.getPkProcessingUnitId());
		target.setUnitName(source.getUnitName());
		target.setUnitAlternateName(source.getUnitAlternateName());
		target.setUnitLongName(source.getUnitLongName());
		target.setUnitName(source.getUnitName());
		
		return target;
	}



}
