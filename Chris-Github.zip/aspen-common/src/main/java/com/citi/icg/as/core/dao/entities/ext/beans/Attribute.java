package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseAttribute;

@Entity
@Table(name = "ATTRIBUTE")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "hibernate.USER_PROFILE")
public class Attribute extends BaseAttribute {

	private static final long serialVersionUID = 8789534459874300869L;

}
