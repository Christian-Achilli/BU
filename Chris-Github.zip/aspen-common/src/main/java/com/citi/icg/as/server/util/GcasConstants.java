package com.citi.icg.as.server.util;

import org.apache.commons.lang.StringUtils;

public final class GcasConstants {
	private GcasConstants() { }
	public static final String NEWLINE = "\n";
	public static final char NEWLINE_CHAR = '\n';
	public static final char ENTER_CHAR = '\r';
	public static final String ENTER = "\r";
	public static final char TAB_CHAR = '\t';
	public static final String TAB = "\t";
	public static final String COMMA = ",";
	public static final String DOT = ".";
	public static final String DOT_CHAR = "\\.";
	public static final String EMPTY = StringUtils.EMPTY;
	public static final String UNERSCORE = "_";
	public static final String COLON = ":";
	public static final String SEMICOLON = ";";
	// same as below but kept for backward compatibility
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String E = "E";
	
	public static final String SPACE = " ";
	public static final char SPACE_CHAR = ' ';
	public static final String LEGAL_ENTITY_UNKNOWN = "UNKNOWN";
	public static final String POSITION_TYPE_UNKNOWN = "UNKNOWN";
	
	public static final char Y_CHAR = 'Y';
	public static final char N_CHAR = 'N';
	public static final char R_CHAR = 'R';
	
	public static final String HOLDING_TYPE_DELIMITER = "\\.";
	
	public static final String NULL = "NULL";
	public static final String CLIENT = "Client";
	
	public static final String ERR_MESSAGE = "error occur when invoke %s, %s is \"%s\"";
	
	public static final String OPT_MANUAL_IND = "MANUAL";
	
	public static final String POUND_SIGN = "#";
	
	public static final String PARENTHESIS_LEFT = "(";
	public static final String PARENTHESIS_RIGHT = ")";
	
	public static final String BRACKET_LEFT = "[";
	public static final String BRACKET_RIGHT = "]";
	
	public static final String EQUALS_SIGN = "=";
	public static final String HTML_NEWLINE = " <BR>";
	
	public static final int NUMBER_0 = 0;
	public static final int NUMBER_1 = 1;
	public static final int NUMBER_2 = 2;
	public static final int NUMBER_3 = 3;
	public static final int NUMBER_4 = 4;
	public static final int NUMBER_5 = 5;
	public static final int NUMBER_6 = 6;
	public static final int NUMBER_7 = 7;
	public static final int NUMBER_8 = 8;
	public static final int NUMBER_9 = 9;
	public static final int NUMBER_10 = 10;
	public static final int NUMBER_11 = 11;
	public static final int NUMBER_12 = 12;
	public static final int NUMBER_13 = 13;
	public static final int NUMBER_14 = 14;
	public static final int NUMBER_15 = 15;
	public static final int NUMBER_16 = 16;
	public static final int NUMBER_17 = 17;
	public static final int NUMBER_18 = 18;
	public static final int NUMBER_19 = 19;
	public static final int NUMBER_20 = 20;
	public static final int NUMBER_21 = 21;
	public static final int NUMBER_22 = 22;
	
	public static final int NEGATIVE_NUMBER_1 = -1;
	public static final int NEGATIVE_NUMBER_2 = -2;
	public static final int NEGATIVE_NUMBER_3 = -3;
	
}
