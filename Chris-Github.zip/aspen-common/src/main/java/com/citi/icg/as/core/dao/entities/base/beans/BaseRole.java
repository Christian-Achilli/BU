package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.ext.beans.RoleEntitlement;

@MappedSuperclass
@Table(name = "ROLES", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseRole extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 2770696729183277767L;
	
	private int pkRoleId;
	private String roleName;
	private String roleDescription;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private Set<RoleEntitlement> roleEntitlements = new HashSet<RoleEntitlement>(0);

	public BaseRole() {
	}

	public BaseRole(String roleName, Date lastUpdatedDate) {
		this.roleName = roleName;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BaseRole(String roleName, String roleDescription, String lastUpdatedBy, Date lastUpdatedDate, Set<RoleEntitlement> roleEntitlements) {
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.roleEntitlements = roleEntitlements;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_ROLES", allocationSize = 1)
	@Column(name = "PK_ROLE_ID", unique = true, nullable = false)
	public int getPkRoleId() {
		return this.pkRoleId;
	}

	public void setPkRoleId(int pkRoleId) {
		this.pkRoleId = pkRoleId;
	}

	@Column(name = "ROLE_NAME", nullable = false, length = 50)
	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Column(name = "ROLE_DESCRIPTION", length = 100)
	public String getRoleDescription() {
		return this.roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	@Column(name = "LAST_UPDATED_BY", length = 50, nullable = false)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "role")
	public Set<RoleEntitlement> getRoleEntitlements() {
		return this.roleEntitlements;
	}

	public void setRoleEntitlements(Set<RoleEntitlement> roleEntitlements) {
		this.roleEntitlements = roleEntitlements;
	}

}
