package com.citi.icg.as.exception;

/**
 * This is the base class for all assert violations.
 */
@SuppressWarnings("serial")
public class GcasAssertError extends GcasError
{
	// --- Constructor(s) ---

	/**
	 * Constructs an IcgAssertError with a detail message.
	 * 
	 * @param message the detail message.
	 */
	public GcasAssertError(String message)
	{
		super(message);
	}

}