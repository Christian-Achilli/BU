package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

@MappedSuperclass
@Table(name = "ATTRIBUTE", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseAttribute extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = -6025869731590582955L;

	private int pkAttributeId;
	private String attributeCode;
	private String attributeDescription;
	private Character attributeType;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public BaseAttribute() {
	}

	public BaseAttribute(String attributeCode, Date lastUpdatedDate) {
		this.attributeCode = attributeCode;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BaseAttribute(String attributeCode, String attributeDescription, Character attributeType, String lastUpdatedBy, Date lastUpdatedDate) {
		this.attributeCode = attributeCode;
		this.attributeDescription = attributeDescription;
		this.attributeType = attributeType;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_ATTRIBUTE", allocationSize = 1)
	@Column(name = "PK_ATTRIBUTE_ID", unique = true, nullable = false)
	public int getPkAttributeId() {
		return this.pkAttributeId;
	}

	public void setPkAttributeId(int pkAttributeId) {
		this.pkAttributeId = pkAttributeId;
	}

	@Column(name = "ATTRIBUTE_CODE", nullable = false, length = 50)
	public String getAttributeCode() {
		return this.attributeCode;
	}

	public void setAttributeCode(String attributeCode) {
		this.attributeCode = attributeCode;
	}

	@Column(name = "ATTRIBUTE_DESCRIPTION", length = 100)
	public String getAttributeDescription() {
		return this.attributeDescription;
	}

	public void setAttributeDescription(String attributeDescription) {
		this.attributeDescription = attributeDescription;
	}

	@Column(name = "ATTRIBUTE_TYPE", length = 1)
	public Character getAttributeType() {
		return this.attributeType;
	}

	public void setAttributeType(Character attributeType) {
		this.attributeType = attributeType;
	}

	@Column(name = "LAST_UPDATED_BY", length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
