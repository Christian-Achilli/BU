package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class CountryCode extends BaseBusinessEntity{
	
	private int pkCountryCodeId;
	private Region fkRegionCode;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String numericCode;
	private String alpha2Code;
	private String alpha3Code;
	private String countryName;
	private String tdSdMarketType;
	private String isdAsdMarketType;
	
	private String atRisk;
	
	
	
	public int getPkCountryCodeId() {
		return pkCountryCodeId;
	}



	public void setPkCountryCodeId(int pkCountryCodeId) {
		this.pkCountryCodeId = pkCountryCodeId;
	}



	public Region getFkRegionCode() {
		return fkRegionCode;
	}



	public void setFkRegionCode(Region fkRegionCode) {
		this.fkRegionCode = fkRegionCode;
	}



	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}



	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}



	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}



	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}



	public String getNumericCode() {
		return numericCode;
	}



	public void setNumericCode(String numericCode) {
		this.numericCode = numericCode;
	}



	public String getAlpha2Code() {
		return alpha2Code;
	}



	public void setAlpha2Code(String alpha2Code) {
		this.alpha2Code = alpha2Code;
	}



	public String getAlpha3Code() {
		return alpha3Code;
	}



	public void setAlpha3Code(String alpha3Code) {
		this.alpha3Code = alpha3Code;
	}



	public String getCountryName() {
		return countryName;
	}



	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}


	public String getTdSdMarketType() {
		return tdSdMarketType;
	}



	public void setTdSdMarketType(String tdSdMarketType) {
		this.tdSdMarketType = tdSdMarketType;
	}



	public String getIsdAsdMarketType() {
		return isdAsdMarketType;
	}



	public void setIsdAsdMarketType(String isdAsdMarketType) {
		this.isdAsdMarketType = isdAsdMarketType;
	}

	
	
	@Override
	public Integer getId()
	{
		return getPkCountryCodeId();
	}



	public String getAtRisk() {
		return atRisk;
	}



	public void setAtRisk(String atRisk) {
		this.atRisk = atRisk;
	}


}
