package com.citi.icg.as.common.client.util;

public class PrinterUtil {

	/**
	 * 
	 * @param url
	 *            represents the resource need to print
	 * @param type
	 *            represent the medium type, currently only support PDF
	 */
	public static void print(String url, MediumType type) {
		switch (type) {
		case PDF:
			PdfPrintHandler.impl.print(url);
			break;
		default: // other medium types yet to implements in future if need.
			break;
		}
	}

	public static enum MediumType {
		PDF, WORD, EXCEL, HTML, TEXT;
	}
}
