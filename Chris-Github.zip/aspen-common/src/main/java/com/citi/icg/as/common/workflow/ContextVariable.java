package com.citi.icg.as.common.workflow;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Allows the specification of variables that are inserted 
 * into an execution context.
 *
 */
@Retention(value = RetentionPolicy.RUNTIME)
public @interface ContextVariable
{
	String name();
	boolean transientVar() default false;
}
