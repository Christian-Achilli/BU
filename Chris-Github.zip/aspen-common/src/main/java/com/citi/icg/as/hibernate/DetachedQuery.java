package com.citi.icg.as.hibernate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class DetachedQuery {
	private StringBuilder hql;
	private List<Object> positionalParameters = new ArrayList<Object>(3);
	private Integer firstResutl;
	private Integer maxResults;
	
	public DetachedQuery() {
		this("");
	}
	
	public DetachedQuery(String hql) {
		this.hql = new StringBuilder(hql);
	}
	
	public Query getExecutableQuery(Session session) {
		Query query = session.createQuery(hql.toString());
		
		for (int position = 0 ; position < positionalParameters.size(); position++) {
			query.setParameter(position, positionalParameters.get(position));
		}
		
		if (firstResutl != null) {
			query.setFirstResult(firstResutl);
		}
		if (maxResults != null) {
			query.setMaxResults(maxResults);
		}
		
		return query;
	}
	
	public void setHQL(String queryString) {
		hql = new StringBuilder(queryString);
	}
	
	public void setParameter(int position, Object val) {
		positionalParameters.set(position, val);
	}
	
	public void addParameters(List<?> parameters) {
		positionalParameters.addAll(parameters);
	}
	
	public DetachedQuery setFirstResult(Integer firstResutl) {
		this.firstResutl = firstResutl;
		return this;
	}
	
	public DetachedQuery setMaxResults(Integer maxResults) {
		this.maxResults = maxResults;
		return this;
	}
	
	public String getQueryString () {
		return hql.toString();
	}

	
	public List<Object> getPositionalParameters() {
		return positionalParameters;
	}

	public void setPositionalParameters(List<Object> positionalParameters) {
		this.positionalParameters = positionalParameters;
	}

	public Integer getFirstResutl() {
		return firstResutl;
	}

	public void setFirstResutl(Integer firstResutl) {
		this.firstResutl = firstResutl;
	}

	public Integer getMaxResults() {
		return maxResults;
	}

	@Override
	public String toString() {
		return "DetachedQuery [hql=" + hql + ", positionalParameters="
				+ positionalParameters + ", firstResutl=" + firstResutl + ", "
				+ "maxResults=" + maxResults + "]";
	}
}
