package com.citi.icg.as.server.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.hibernate.Hibernate;

public class ObjectBlobConverter {

	//Convert objec to blob
    public static java.sql.Blob ObjectToBlob(Object obj){
        try {
           ByteArrayOutputStream out = new ByteArrayOutputStream();
           ObjectOutputStream outputStream = new ObjectOutputStream(out);
           outputStream.writeObject(obj);
           byte [] bytes = out.toByteArray();
           outputStream.close();
           return Hibernate.createBlob(bytes);
       } catch (Exception e) {
    	   e.printStackTrace();
           return null ;
       } 
  
    }
    
    //Convert blob to object
    public static Object BlobToObject(java.sql.Blob desblob){
        try {
           Object obj = null;
           ObjectInputStream in = new ObjectInputStream(desblob.getBinaryStream());
           obj = in.readObject();
           in.close(); 
           return obj;
        } catch (Exception e) {
           e.printStackTrace();
           return null;
        } 
    }
}
