package com.citi.icg.as.common.converter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.hibernate.proxy.HibernateProxyHelper;

import com.citi.icg.as.common.client.entities.BusinessEntity;

@SuppressWarnings({ "unchecked", "hiding", "rawtypes" })
public abstract class BaseEntityConverter<S extends BusinessEntity, T> implements EntityConverter<S, T> {

	private ConversionSession conversionSession;

	protected ConversionSession getConversionSession() {
		return conversionSession;
	}

	public final Set<S> convertAllFrom(Set<T> source) {
		if (source != null && source.size() > 0) {
			Set<S> target = new HashSet<S>();
			for (T entity : source) {
				target.add(convertFrom(entity));
			}
			return target;
		}
		return null;
	}

	public final List<S> convertAllFrom(List<T> source) {
		if (source != null && source.size() > 0) {
			List<S> target = new ArrayList<S>();
			for (T entity : source) {
				target.add(convertFrom(entity));
			}
			return target;
		}
		return null;
	}

	public final Set<T> convertAllTo(Set<S> source) {

		if (source != null && source.size() > 0) {
			Set<T> target = new HashSet<T>();
			for (S entity : source) {
				target.add(convertTo(entity));
			}
			return target;
		}

		return null;
	}

	public final S convertFrom(T entity) {

		Object source = null;
		if (entity != null) {

			// must have an id otherwise error
			if (getTargetEntityId(entity) == null) {
				throw new RuntimeException("Target entity [" + entity + "] must have a primary key associated with it.");
			} else if (getTargetEntityId(entity) instanceof Integer && ((Integer) getTargetEntityId(entity)) == 0) {
				throw new RuntimeException("Target entity [" + entity + "] must have a primary key associated with it.");
			} else if (getTargetEntityId(entity) instanceof Long && ((Long) getTargetEntityId(entity)) == 0) {
				throw new RuntimeException("Target entity [" + entity + "] must have a primary key associated with it.");
			} else if (getTargetEntityId(entity) instanceof String && ((String) getTargetEntityId(entity)) == null) {
				throw new RuntimeException("Target entity [" + entity + "] must have a primary key associated with it.");
			}

			String targetId = String.valueOf(getTargetEntityId(entity));

			source = conversionSession.checkCacheFromObject(entity, targetId);
			if (source == null) {
				try {

					// create new instance and put in the cache
					source = createNewSourceObject(entity);

					addTargetToCache(entity, source, targetId);

					// copy values
					doConvertFromTarget(entity, (S) source);

				} catch (RuntimeException e) {

					// TODO remove from cache
					throw new RuntimeException(e);
				}

			}

		}

		return (S) source;

	}

	protected Object createNewSourceObject(T entity) {

		try {
			return getSourceClass().newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	protected Object createNewTargetObject(S entity) {
		try {
			return getTargetClass().newInstance();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public abstract void doConvertFromTarget(T entity, S target);

	public abstract Serializable getTargetEntityId(T entity);

	public final T convertTo(S entity) {

		Object target = null;
		if (entity != null) {

			// check if we have converted this before - always check id first
			target = conversionSession.checkCacheFromBusinessEntity(entity);

			if (target == null) {

				try {
					target = createNewTargetObject(entity);
				} catch (Exception e) {
					throw new RuntimeException(e);
				}

				addTargetToCache(entity, target);
				doConvertToTarget((T) target, entity);

			}

		}

		if (target != null) {
			return (T) target;
		}

		return null;

	}

	private void addTargetToCache(BusinessEntity from, Object to) {
		if ((from.getId() == null || (from.getId() instanceof Long && ((Long) from.getId()) == 0) || (from.getId() instanceof Integer && ((Integer) from.getId()) == 0) || (from.getId() instanceof String && ((String) from
				.getId()) == null)) && from.getTemporaryKey() == null) {
			from.setTemporaryKey(UUID.randomUUID().toString());
			addTargetToCache(from, to, from.getTemporaryKey());
		} else {

			addTargetToCache(from, to, String.valueOf(from.getId()));

		}

	}

	private void addTargetToCache(Object from, Object to, String key) {

		if (from != null && to != null) {

			conversionSession.addItemToCache(from, to, key);

		}

	}

	protected <S, T> Set<T> convertAll(Set<S> source, Class<S> sourceClass, Class<T> targetClass) {

		if (BusinessEntity.class.isAssignableFrom(sourceClass)) {

			Class<? extends BusinessEntity> businessEntity = (Class<? extends BusinessEntity>) sourceClass;
			EntityConverter converter = conversionSession.getConverter(businessEntity, targetClass);

			Set<T> set = converter.convertAllTo(source);
			if (set == null)
				return new HashSet<T>();
			return set;

		} else if (BusinessEntity.class.isAssignableFrom(targetClass)) {

			Class<? extends BusinessEntity> businessEntity = (Class<? extends BusinessEntity>) targetClass;
			EntityConverter converter = this.conversionSession.getConverter(businessEntity, sourceClass);

			Set<T> set = converter.convertAllFrom(source);
			if (set == null)
				return new HashSet<T>();
			return set;
		}

		return null;

	}

	protected <S extends BusinessEntity, T> S convert(T target, Class<S> source) {

		if (target != null) {

//			EntityConverter<S, T> converter = (EntityConverter<S, T>) this.conversionSession.getConverter(source, target.getClass());
			EntityConverter<S, T> converter = (EntityConverter<S, T>) this.conversionSession.getConverter(source, HibernateProxyHelper.getClassWithoutInitializingProxy(target));
			if (converter != null) {

				return converter.convertFrom(target);

			}

		}

		return null;

	}

	protected <S extends BusinessEntity, T> T convert(S source, Class<T> target) {

		if (source != null) {

			EntityConverter<S, T> converter = (EntityConverter<S, T>) this.conversionSession.getConverter(source.getClass(), target);
			if (converter != null) {

				return converter.convertTo(source);

			}

		}

		return null;

	}

	public abstract void doConvertToTarget(T target, S entity);

	@Override
	public void setConversionSession(ConversionSession session) {
		this.conversionSession = session;
	}

	public void addConverterSessionParam(String paramName, Object value) {
		conversionSession.addConverterParam(paramName, value);
	}

	public Object getConverterSessionParam(String paramName) {
		return conversionSession.getConverterParam(paramName);
	}

}
