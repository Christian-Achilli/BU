package com.citi.icg.as.common.client.util;

import java.util.ArrayList;

import com.citi.icg.toolkit.web.client.grid.dataobjects.TransferObject;

/**
 * UGLY HACK, this class should probably be deleted.
 * When CompareService is asked to compare to two beans,
 * and their nested paths recursion would normally terminate
 * where null values are encountered, to prevent this, where
 * null properties (or collections) are found we return instances
 * of PlaceHolder. The code should really be updated to be null
 * safe, and continue to traverse graph event where nulls are found.
 */
@SuppressWarnings("serial")
public class PlaceHolder<E> extends ArrayList<E> implements TransferObject
{

	public PlaceHolder()
	{
		super(0);
	}
	
}
