package com.citi.icg.as.common.util;

import java.io.File;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.UnhandledException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

/**
 * Helps encrypt and decrypt text.
 * Doesn't depend on GCAS.
 */
public final class PasswordEncryptUtils {

	private static final String DEFAULT_ENCRYPTION_ALGORITHM = "PBEWithMD5AndTripleDES";
	private static final String ENCRYPTION_ALGORITHM = getEncryptionAlgorithm();
	public static final String ENCODE_INDICATOR_START = "ENC(";
	public static final String ENCODE_INDICATOR_END = ")";
	public static final int INTERATION = 15;
	private static final byte[] SALT = { (byte) 0xd7, (byte) 0x73, (byte) 0x21, (byte) 0x8c, (byte) 0x7e,
			(byte) 0xc8, (byte) 0xee, (byte) 0x99 };

	private Cipher encrypter;
	private transient final Base64 base64 = new Base64();
	private transient String key;
	private Resource keyDat;

	private transient static final int KEYLENGTH = 256;
	public static final String ERROR_KEY_GENERATION = "Encryption key generation failed. Please verify the logs.";

	private static final Log LOGGER = LogFactory.getLog(PasswordEncryptUtils.class);

	private PasswordEncryptUtils instance;

	public PasswordEncryptUtils(Resource keyDat) {
		this.keyDat = keyDat;
		try {
			final String key = IOUtils.toString(keyDat.getInputStream()).trim();
			if (key != null) {				
				this.key = key;
				try {
					encrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.ENCRYPT_MODE);
				} catch (Exception e) {
					// CHECKSTYLE:OFF
					throw new RuntimeException(
							"Unable to Initialize Ciphers"
									+ "\nJAVA_HOME="
									+ System.getProperty("java.home")
									+ "\nSee https://teamforge.nam.nsroot.net/sf/wiki/do/viewPage/projects.153106_1/wiki/UnableToInitializeCiphers for posible solution",
							e);
					// CHECKSTYLE:ON
				}
				instance = this;
				LOGGER.debug("Application ciphers initialized from file.");
			}else{
				LOGGER.warn("Resource for key is null:" + keyDat);
			}
		} catch (Exception e) {
			LOGGER.error("Encryption initialization failed from file ", e);
		}

	}

	public String encrypt(String plainText) {
		try {
			return new String(base64.encode(encrypter.doFinal(plainText.getBytes())));
		} catch (Exception e) {
			throw new RuntimeException("failed to encrypt text=[" + plainText + "]", e);
		}
	}

	public String decrypt(String encryptedText) {
		// log.info("call to decrypt with encryptedText = " + encryptedText);
		try {
			final Cipher decrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.DECRYPT_MODE);
			// log.info("key = " + key);
			return new String(decrypter.doFinal(base64.decode(encryptedText.getBytes())));
		} catch (Exception e) {
			throw new RuntimeException("failed to decrypt text=[" + encryptedText + "]", e);
		}
	}

	public String encryptFormatted(String textToEncrypt) {
		if (instance != null) {
			return ENCODE_INDICATOR_START + instance.encrypt(textToEncrypt) + ENCODE_INDICATOR_END;
		}

		LOGGER.error("The Application Cypers were not initialized for encrypting.");

		return textToEncrypt;
	}

	public String decryptIfEncrypted(String encryptedString) {
		String decryptedString = encryptedString;
		// log.info("call to decryptIfEncrypted with encryptedString = " +
		// encryptedString);

		try {
			if (instance != null) {
				if (encryptedString != null && encryptedString.startsWith(ENCODE_INDICATOR_START)) {
					// log.info("It has to be decrypted!");
					decryptedString = encryptedString.substring(ENCODE_INDICATOR_START.length(),
							encryptedString.length() - 1);
					// log.info("decryptedString = " + decryptedString);
					return instance.decrypt(decryptedString);
				}
			} else {
				LOGGER.error("The Application Cypers were not initialized.");
			}

			return decryptedString;
		} catch (Exception ex) {
			throw new RuntimeException("failed to decrypt text", ex);
		}
	}
	
	
	/**
	 * @param encryptedString
	 * @return
	 * @deprecated
	 * Dont use this method in any component, as this has been made static only for the purpose of using it in Jetty-env.xml
	 */
	public static String decryptEncrypted(String encryptedString) {
		String decryptedString = encryptedString;
		Resource keyDat = new ClassPathResource("key.dat");
		String key = null;
		try {
			key = IOUtils.toString(keyDat.getInputStream()).trim();
			if (key != null) {

				try {
					Cipher encrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.ENCRYPT_MODE);
				} catch (Exception e) {
					// CHECKSTYLE:OFF
					throw new RuntimeException(
							"Unable to Initialize Ciphers" + "\nJAVA_HOME=" + System.getProperty("java.home")
									+ "\nSee https://teamforge.nam.nsroot.net/sf/wiki/do/viewPage/projects.153106_1/wiki/UnableToInitializeCiphers for posible solution",
							e);
					// CHECKSTYLE:ON
				}
				LOGGER.error("Application Cypers initialized from file.");
			} else {
				LOGGER.warn("Resource for key is null:" + keyDat);
			}

			decryptedString = encryptedString.substring(ENCODE_INDICATOR_START.length(), encryptedString.length() - 1);
			final Cipher decrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.DECRYPT_MODE);
			return new String(decrypter.doFinal(new Base64().decode(decryptedString.getBytes())));

		} catch (Exception e) {
			throw new UnhandledException(e);
		}
	}

	private static Cipher createCipher(char[] password, byte[] salt, int noIterations, int encryptionMode)
			throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException {
		final SecretKeyFactory keyfactory = SecretKeyFactory.getInstance(ENCRYPTION_ALGORITHM);
		final PBEKeySpec keySpec = new PBEKeySpec(password);
		final SecretKey key = keyfactory.generateSecret(keySpec);
		final Cipher ciph = Cipher.getInstance(ENCRYPTION_ALGORITHM);

		final PBEParameterSpec params = new PBEParameterSpec(salt, noIterations);
		ciph.init(encryptionMode, key, params);
		return ciph;
	}

	public boolean isKeyFileExists() {
		if (StringUtils.isEmpty(keyDat.getFilename())) {
			return false;
		}

		final File file = new File(keyDat.getFilename());
		if (!file.exists()) {
			return false;
		}
		return true;
	}

	/**
	 * Create the application key.
	 * 
	 * @return If the operation was successful.
	 */
	public boolean createAndStoreApplicaitonKey() {
		try {
			Assert.hasText(keyDat.getFilename(), "Encryption Key File Name");
			final String randomString = RandomStringUtils.randomAlphanumeric(KEYLENGTH);
			Assert.hasText(randomString, "Error while generating the Encryption Key : " + keyDat.getFilename());
			FileUtils.writeStringToFile(keyDat.getFile(), randomString);
			instance = new PasswordEncryptUtils(keyDat);
		} catch (Exception e) {
			LOGGER.error(ERROR_KEY_GENERATION, e);
			LOGGER.error("Could not generate Application Ciphers from file-" + keyDat.getFilename());
			return false;
		}

		return true;
	}

	public PasswordEncryptUtils getInstance() {
		return instance;
	}

	private static String getEncryptionAlgorithm() {
		String encryptionAlgorithm = ""; // FIXME
		if (StringUtils.isEmpty(encryptionAlgorithm)) {
			encryptionAlgorithm = DEFAULT_ENCRYPTION_ALGORITHM;
		}
		return encryptionAlgorithm;
	}
}


