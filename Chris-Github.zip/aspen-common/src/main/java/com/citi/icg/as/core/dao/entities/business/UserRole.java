package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import javax.xml.bind.annotation.XmlTransient;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class UserRole extends BaseBusinessEntity {
	
	private static final long serialVersionUID = -8596035022176402601L;

	private int pkUserRoleId;
	private Region regionCode;
	private Role role;
	private User user;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public int getPkUserRoleId() {
		return pkUserRoleId;
	}

	public void setPkUserRoleId(int pkUserRoleId) {
		this.pkUserRoleId = pkUserRoleId;
	}

	public Region getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(Region regionCode) {
		this.regionCode = regionCode;
	}

	@XmlTransient
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	@XmlTransient
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Integer getId() {
		return getPkUserRoleId();
	}
}
