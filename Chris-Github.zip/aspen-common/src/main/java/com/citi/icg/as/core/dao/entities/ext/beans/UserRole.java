package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseUserRole;


@Entity
@Table(name="USER_ROLE")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="hibernate.USER_PROFILE")
public class UserRole extends BaseUserRole
{

	private static final long serialVersionUID = 8932445826307138800L;

}
