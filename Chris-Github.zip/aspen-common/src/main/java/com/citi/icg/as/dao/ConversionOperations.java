package com.citi.icg.as.dao;

import java.util.Collection;

public interface ConversionOperations<T , S> {

	<C> Collection<C> convertAll(Collection<?> items, Class<C> target);
	
	T getNewBusinessEntity(S source) throws InstantiationException, IllegalAccessException;
	
	S getNewHibernateEntity(T target) throws InstantiationException, IllegalAccessException;
	
	public T convertToBusinessEntity(S hibernateEntity) ;
	
	public T convertToBusinessEntity(S hibernateEntity, T businessEntity) ;

	public S convertToHibernateEntity(T businessEntity);
	
	public S convertToHibernateEntity(T businessEntity, S hibernateEntity);
	
}
