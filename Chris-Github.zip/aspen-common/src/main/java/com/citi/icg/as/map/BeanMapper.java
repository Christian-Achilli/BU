package com.citi.icg.as.map;

import java.util.Collection;

public interface BeanMapper {

	<T> T map(Object entity, Class<T> targetClass);
	<T> Collection<T> mapAll(Collection<?> entities, Class<T> targetClass);
}
