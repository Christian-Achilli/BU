package com.citi.icg.as.common.client.service;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface BaseRemoteServiceAsync {
	void declareException(AsyncCallback<Void> asyncCallback);
}
