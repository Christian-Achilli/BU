package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.base.beans.BaseUserSavedSearches;

@Entity
@Table(name = "USER_SAVED_SEARCHES")
public class UserSavedSearches extends BaseUserSavedSearches {

	private static final long serialVersionUID = -1567974453144964934L;
}
