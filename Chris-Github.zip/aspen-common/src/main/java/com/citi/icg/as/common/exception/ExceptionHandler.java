package com.citi.icg.as.common.exception;

import java.util.Date;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.spi.LocationInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citi.icg.as.common.dao.ExceptionHandlerDao;
import com.citi.icg.as.core.dao.entities.ext.beans.LoggedExceptions;
import com.citi.icg.as.exception.AspenRuntimeException;
import com.citi.icg.as.exception.AspenServiceException;
import com.citi.icg.as.exception.ErrorType;
import com.citi.icg.as.server.GcasRequestContext;
import com.citi.icg.as.server.service.GcasRpcContext;
import com.citi.icg.toolkit.logger.IcgAppLogger;
import com.citi.icg.toolkit.util.IcgMailUtil;
import com.citi.icg.toolkit.web.client.IcgGwtUIException;
import com.citi.icg.toolkit.web.server.GwtServiceUtil;

@Component
public class ExceptionHandler {

	private HashMap<String, Long> occuredExceptions = new HashMap<String, Long>();

	@Resource
	private ExceptionHandlerConfiguration exceptionConfiguration;

	@Autowired(required=false)
	private ServletContext servletContext;

	private static Log log = LogFactory.getLog(ExceptionHandler.class);

	@Resource
	private ExceptionHandlerDao exceptionHandlerDao;

	private static final String ERROR_MSG_FMT = "#%d RPC Failed. %s";

	public void handleException(final String level, final Throwable t, LocationInfo locationInfo) {
		try {
			final String exceptionName = t.getClass().getSimpleName();
			String exceptionKey = exceptionName;
			if (locationInfo != null) {
				exceptionKey = exceptionKey + locationInfo.getClassName() + locationInfo.getLineNumber();
			}
			// generate a caseId which will be recorded to log file, DB, email
			final long caseId = (new Date().getTime() / 1000);

			// for each exception, check its last time, if within ignoretime,
			// then ignore it
			// otherwise, record it; if no ignoretime, always record it
			Long lastTime = occuredExceptions.get(exceptionKey);
			long currentTime = System.currentTimeMillis();
			String ignoreTime = exceptionConfiguration.getIgnoreTimeOfException(exceptionName);

			long ignoreTimeLong = 0;
			if (ignoreTime != null) {
				ignoreTimeLong = Long.parseLong(ignoreTime);
			}

			// default ignoreTime
			if (ignoreTimeLong == 0) {
				String defaultIgnoreTime = exceptionConfiguration.getDefaultIgnoreTime();
				ignoreTimeLong = Long.parseLong(defaultIgnoreTime);
			}

			if (lastTime == null || (currentTime - lastTime.longValue() > ignoreTimeLong)) {
				occuredExceptions.put(exceptionKey, currentTime);
				final String email = exceptionConfiguration.getMail();

				String msg = GwtServiceUtil.getStackTrace(t);
				// log file
				// check if is IcgGwtUIException, no need log again
				if (!(t instanceof IcgGwtUIException)) {
					IcgAppLogger.error(this, "Error in service. #" + caseId + "\n" + msg);
				}

				// if DB is ok, record to DB
				if (exceptionConfiguration.isDBAvailable()) {
					// FIXME: DB only allows up to 6000 characters.
					int max = 6000;
					if (msg.length() > max) {
						msg = msg.substring(0, max - 5) + " ...";
					}

					final LoggedExceptions oneException = new LoggedExceptions();
					if (t instanceof IcgGwtUIException) {
						// if is IcgGwtUIException, use its own trackNo
						oneException.setCaseId(((IcgGwtUIException) t).getTrackingNo());
					} else {
						oneException.setCaseId(caseId);
					}
					oneException.setExceptionMessage(msg);
					oneException.setExceptionName(exceptionName);
					oneException.setIsSent("N");
					oneException.setLastUpdatedBy(GcasRequestContext.getUserId());
					oneException.setLastUpdatedDate(new Date());
					String contextPath;
					if (servletContext != null && servletContext.getContextPath() != null) {
						contextPath = servletContext.getContextPath().substring(1);
					} else if (GcasRequestContext.getSession() != null && GcasRequestContext.getSession().getServletContext() != null
							&& GcasRequestContext.getSession().getServletContext().getContextPath() != null) {
						contextPath = GcasRequestContext.getSession().getServletContext().getContextPath().substring(1);
					} else {
						contextPath = StringUtils.EMPTY;
					}
					String source;
					if (GcasRequestContext.getUserId() != null) {
						source = "ASPEN:" + contextPath + ":" + GcasRequestContext.getUserId();
					} else {
						source = "ASPEN:" + contextPath;
					}
					oneException.setSource(source);
					oneException.setToEmail(email);
					oneException.setExceptionLevel(level);

					// use a separate thread to save, to avoid deadlock
					// new Thread(){
					// public void run()
					// {
					exceptionHandlerDao.saveOrUpdateExceptions(oneException);
					// }
					// }.start();
				} else {
					// sent mail directly
					IcgMailUtil.sendMail(new String[] { email }, "ASPEN", "An exception occured #" + caseId, GwtServiceUtil.getStackTrace(t));
				}
			} else {
				// ignore it
			}
		} catch (Exception e) {
			// e.printStackTrace();
			if (log.isDebugEnabled()) {
				log.debug(e);
			}
		}
	}

	public void handleException(final Throwable t) {
		ErrorType errorLevel = null;
		if (t instanceof AspenRuntimeException) {
			errorLevel = ((AspenRuntimeException) t).getErrorLevel();
		} else if (t instanceof AspenServiceException) {
			errorLevel = ((AspenServiceException) t).getErrorLevel();
		}
		// if ((errorLevel != null && errorLevel.equals(ErrorType.WARNING)) || isWarningConfigured(t)) {
		if (isWarningConfigured(t) || (errorLevel != null && errorLevel.equals(ErrorType.WARNING))) {
			handleException("WARNING", t, null);
		} else if ((errorLevel != null && errorLevel.equals(ErrorType.INFO)) || isInfoConfigured(t)) {
			handleException("INFO", t, null);
		} else
			handleException("ERROR", t, null);
	}

	public void handleException(String level, final Throwable t, LocationInfo locationInfo, GcasRpcContext ctx, Long caseId) {
		try {
			// generate a caseId which will be recorded to log file, DB, email
			String errorMsg = String.format(ERROR_MSG_FMT, caseId, ctx);
			if (isWarningConfigured(t))
				level = "WARNING";
			else if (isInfoConfigured(t))
				level = "INFO";
			if (!isExceptionRateLimited(t, locationInfo)) {
				// exception is not ignored or rate limited, log or email
				String email = exceptionConfiguration.getMail();
				if (exceptionConfiguration.isDBAvailable()) {
					String contextPath;
					if (servletContext != null && servletContext.getContextPath() != null) {
						contextPath = servletContext.getContextPath().substring(1);
					} else {
						contextPath = StringUtils.EMPTY;
					}
					String source;
					if (GcasRequestContext.getUserId() != null) {
						source = "ASPEN:" + contextPath + ":" + GcasRequestContext.getUserId();
					} else {
						source = "ASPEN:" + contextPath;
					}
					if (ctx != null) {
						source = StringUtils.abbreviate(ctx.getRemoteUser() + "@" + StringUtils.substringAfterLast(ctx.getTargetName(), ".") + "#" + ctx.getMethodName(), 50);
					}
					String stackTrace = StringUtils.abbreviate(errorMsg + "\n" + ExceptionUtils.getFullStackTrace(t), 6000);
					LoggedExceptions loggedExcepion = new LoggedExceptions();
					loggedExcepion.setCaseId(caseId == null ? System.currentTimeMillis() / 1000 : caseId);
					loggedExcepion.setExceptionMessage(stackTrace);
					loggedExcepion.setExceptionName(t.getClass().getSimpleName());
					loggedExcepion.setIsSent("N");
					loggedExcepion.setLastUpdatedBy(GcasRequestContext.getUserId());
					loggedExcepion.setLastUpdatedDate(new Date());

					loggedExcepion.setSource(source);
					loggedExcepion.setToEmail(email);
					loggedExcepion.setExceptionLevel(level);
					exceptionHandlerDao.saveOrUpdateExceptions(loggedExcepion);
				} else {
					IcgMailUtil.sendMail(new String[] { email }, "ASPEN", errorMsg, ExceptionUtils.getFullStackTrace(t));
				}
			}
		} catch (Exception e) {
			// handleException() is invoked by the GCAS log4j appender.
			// Trying to log to log4j here will cause this method to be
			// re-invoked from the appender. If something's broken this
			// could result in endless loop. Instead we have to just
			// dump the STDERR. FIXME: maybe appender should be configured
			// to filter this classes logger?
			System.err.println("An error occured while trying to record exception.");
			e.printStackTrace(System.err);
		}
	}

	private boolean isWarningConfigured(Throwable t) {
		try {
			String[] allWarningExceptions = exceptionConfiguration.getAllWarningExceptions();
			for (String exceptionName : allWarningExceptions) {
				if (exceptionName.equalsIgnoreCase(t.getClass().getSimpleName())) {
					return true;
				}
			}
			String[] allWarningStrings = exceptionConfiguration.getAllWarningStrings();
			for (String exceptionString : allWarningStrings) {
				if (ExceptionUtils.getStackTrace(t).contains(exceptionString)) {
					return true;
				}
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	private boolean isInfoConfigured(Throwable t) {
		try {
			String[] allInfoExceptions = exceptionConfiguration.getAllInfoExceptions();
			for (String exceptionName : allInfoExceptions) {
				if (exceptionName.equalsIgnoreCase(t.getClass().getSimpleName())) {
					return true;
				}
			}
			String[] allInfoStrings = exceptionConfiguration.getAllInfoStrings();
			for (String exceptionString : allInfoStrings) {
				if (ExceptionUtils.getStackTrace(t).contains(exceptionString)) {
					return true;
				}
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	private boolean isExceptionRateLimited(Throwable t, LocationInfo loc) {
		String exceptionKey = t.getClass().getSimpleName();
		if (loc != null) {
			exceptionKey = exceptionKey + loc.getClassName() + loc.getLineNumber();
		}

		// for each exception, check its last time, if within ignoretime, then ignore it
		// otherwise, record it; if no ignoretime, always record it
		Long lastTime = occuredExceptions.get(exceptionKey);
		long currentTime = System.currentTimeMillis();
		long rateLimit = getRateLimit(t);
		boolean isExceptionRateLimited = lastTime != null && currentTime - lastTime < rateLimit;

		if (!isExceptionRateLimited) {
			occuredExceptions.put(exceptionKey, currentTime);
		}

		return isExceptionRateLimited;
	}

	private long getRateLimit(Throwable t) {
		long result = -1;
		String ignoreTimeString = exceptionConfiguration.getIgnoreTimeOfException(t.getClass().getSimpleName());
		String defaultIgnoreTimeString = exceptionConfiguration.getDefaultIgnoreTime();

		if (ignoreTimeString != null) {
			result = Long.parseLong(ignoreTimeString);
		}
		if (result < 0) {
			result = Long.parseLong(defaultIgnoreTimeString);
		}

		return result;
	}

	public ExceptionHandlerConfiguration getExceptionConfiguration() {
		return exceptionConfiguration;
	}

	public void setExceptionConfiguration(ExceptionHandlerConfiguration exceptionConfiguration) {
		this.exceptionConfiguration = exceptionConfiguration;
	}

}
