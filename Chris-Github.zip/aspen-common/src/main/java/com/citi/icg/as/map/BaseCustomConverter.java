package com.citi.icg.as.map;

public abstract class BaseCustomConverter<T, S> implements CustomConverter<T, S> {

	
	@Override
	public T convert(S entity) {
		
		return null;
	}

	
	
}
