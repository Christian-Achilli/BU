package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseLegalEntity;

@Entity
@Table(name = "LEGAL_ENTITY", uniqueConstraints = @UniqueConstraint(columnNames = "LEGAL_ENTITY_NAME"))
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class LegalEntity extends BaseLegalEntity {

	private static final long serialVersionUID = 5824954610632231467L;

}
