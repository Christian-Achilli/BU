package com.citi.icg.as.server;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.toolkit.web.client.event.DataEvent;
import com.citi.icg.toolkit.web.client.event.EventType;
import com.citi.icg.toolkit.web.server.event.ServerDataEventManager;

public final class GcasRequestContext {
	private static final Log LOG = LogFactory.getLog(GcasRequestContext.class);
	private static final ThreadLocal<GcasRequestContext> THREAD_LOCAL_REQ_CONTEXT = new ThreadLocal<GcasRequestContext>();
	public static final String SM_USER_HEADER = "sm_user";
	public static final String HEADER_PORTAL_LOGIN = "x-citiportal-loginid";
	public static final String HEADER_PORTAL_REQUEST_ID = "x-citiportal-requestid";
	public static final String SYS_USER_NAME = System.getProperty("user.name");
	private final String userId;
	private final boolean isInPortal;
	private final HttpSession session;
	private final String requestId;
	private static String PORTAL_USERID_PARAM = "PORTAL_USERID";

	public static void clear()
	{
		THREAD_LOCAL_REQ_CONTEXT.set(null);
	}

	public static void set(String userId)
	{
		set(userId, false, null,null);
	}

	public static void set(String userId, boolean isInPortal, HttpSession sess, String requestId)
	{
		THREAD_LOCAL_REQ_CONTEXT.set(new GcasRequestContext(userId == null ? SYS_USER_NAME : userId, isInPortal, sess, requestId));
	}

	public static GcasRequestContext getRequestContext()
	{
		return THREAD_LOCAL_REQ_CONTEXT.get();
	}

	private GcasRequestContext(String userId, boolean isInPortal, HttpSession sess, String requestId)
	{
		this.userId = userId == null ? null : userId.toLowerCase();
		this.isInPortal = isInPortal;
		this.session = sess;
		this.requestId = requestId;
	}

	public static String getUserId()
	{
		GcasRequestContext requestContext = THREAD_LOCAL_REQ_CONTEXT.get();
		if (requestContext != null)
		{
			return requestContext.userId;
		}
		return null;
	}

	public static boolean isInPortal()
	{
		GcasRequestContext requestContext = THREAD_LOCAL_REQ_CONTEXT.get();
		if (requestContext != null)
		{
			return requestContext.isInPortal;
		}
		return false;
	}

	public static HttpSession getSession()
	{
		GcasRequestContext requestContext = THREAD_LOCAL_REQ_CONTEXT.get();
		if (requestContext != null)
		{
			return requestContext.session;
		}
		return null;
	}

	public static void set(HttpServletRequest req)
	{
		EventType eventType = EventType.UPDATE;

		HttpSession session = req.getSession(false);
		if (session == null)
		{
			eventType = EventType.ADD;
			session = req.getSession(true);
		}
		String requestId = "";
		if(req.getHeader(HEADER_PORTAL_REQUEST_ID)!=null){
			requestId = req.getHeader(HEADER_PORTAL_REQUEST_ID);
		}
		else{
			requestId = UUID.randomUUID().toString();
		}
		String userId = req.getRemoteUser();
		if (userId == null)
		{
			userId = req.getHeader(SM_USER_HEADER);
		}
		if (userId == null)
		{
			userId = req.getHeader(HEADER_PORTAL_LOGIN);
		}
		if (userId == null)
		{
			try
			{
				userId = (String) session.getAttribute(SM_USER_HEADER);
			}
			catch (Exception e)
			{
				LOG.warn(e.getCause());
			}
		}

		boolean isInPortal = false;
		if (null != req.getHeader(HEADER_PORTAL_LOGIN))
		{
			isInPortal = true;
		}

		if (userId == null && null != req.getParameter(PORTAL_USERID_PARAM))
		{
			userId = req.getParameter(PORTAL_USERID_PARAM);
		}

		session.setAttribute(SM_USER_HEADER, userId);
		ServerDataEventManager.getInstance().raiseEvent(DataEvent.create(HttpSession.class, eventType, session));
		set(userId, isInPortal, session,requestId);
	}

	public static boolean isSystemUser()
	{
		String userID = getUserId();
		return userID != null && userID.equals(SYS_USER_NAME);
	}
	
	public static String getRequestId()
	{
		GcasRequestContext requestContext = THREAD_LOCAL_REQ_CONTEXT.get();
		if (requestContext != null)
		{
			return requestContext.requestId;
		}
		return null;
	}

}
