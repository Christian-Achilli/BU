package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseRegion;

@Entity
@Table(name = "REGION")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class Region extends BaseRegion {
	
	private static final long serialVersionUID = 8552835975462484721L;

	@Override
	public String toString() {
		return "pkRegionCodeId=" + getPkRegionCodeId() + ", regionCode=" + getRegionCode() + ", lastUpdatedBy=" + getLastUpdatedBy() + ", lastUpdatedDate=" + getLastUpdatedDate() +",timezoneId=" + getTimezoneId()+",regionLocale=" + getRegionLocale();
	}

}
