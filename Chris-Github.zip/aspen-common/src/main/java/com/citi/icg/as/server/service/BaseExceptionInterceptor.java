package com.citi.icg.as.server.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.hessian.ResultWrapper;

/**
 * @author ca85137
 *
 * Intercepts a method and always return a ResultWrapper for it, also when an exception occurs.
 *
 * It is advisable to subclass this class and provide and implementation for getBusinessErrorMessage that a business readable description for the exception.
 *
 */
public class BaseExceptionInterceptor implements ServiceExceptionInterceptor {

	private static final Log LOG = LogFactory.getLog(BaseExceptionInterceptor.class);
	
	@Override
	public <T> ResultWrapper<T> execute(Class<?> caller, ServiceExecutor<T> callBack) {
		ResultWrapper<T> r = null;
		try {
			r = new ResultWrapper<T>(callBack.execute(), false, null);
		} catch (Exception e) {
			LOG.error(e);
			r = new ResultWrapper<T>(null, true, getBusinessErrorMessage(e));
		} 
		return r;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.citi.icg.as.server.service.ServiceExceptionInterceptor#execute(java.lang.Object, com.citi.icg.as.server.service.ServiceVisitor)
	 */
	@Override
	public <T> ResultWrapper<T> execute(Object caller, ServiceExecutor<T> callBack)
	{
		return execute(caller.getClass(), callBack);
	}
	
	/**
	 * @param e
	 * @return A description of this exception that the business User can understand.
	 * This message will be displayed on the applicaiton UI.
	 */
	protected String getBusinessErrorMessage(Exception e) {
		return "##"+System.currentTimeMillis()+"## "+e.getMessage();
	}

}