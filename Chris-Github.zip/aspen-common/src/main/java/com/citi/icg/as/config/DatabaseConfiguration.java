package com.citi.icg.as.config;

import java.util.Map;

import com.citi.icg.as.common.util.CommonUtil;
import com.citi.icg.as.exception.GcasError;
import com.citi.icg.as.exception.GcasRuntimeException;

/**
 * 
 * replace IcgDatabaseConfiguration.
 * 
 */

public class DatabaseConfiguration extends GCASAppConfiguration {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8655478364293109291L;

	public static final String DATA_SOURCES = "datasources.datasource";
	public static final String USERNAME = "username";
	public static final String DATASOURCE_NAME = "name";
	public static final String PASSWORD = "password";
	public static final String DRIVER_CLASS = "driver-class";
	public static final String URL = "url";
	private static DatabaseConfiguration INSTANCE;

	public static DatabaseConfiguration createInstance(Map<String, String> properties) {
		if (null == INSTANCE) {
			INSTANCE = CommonUtil.createDynamicConfigurationInstance(DatabaseConfiguration.class, null, properties);
		}
		return INSTANCE;
	}
	
	public static DatabaseConfiguration getInstance() {
		return DatabaseConfigurationHolder.holder;
	}

	private static class DatabaseConfigurationHolder {
		private DatabaseConfigurationHolder() { }
		public static DatabaseConfiguration holder = GcasConfigUtil
				.getInstance(DatabaseConfiguration.class);
	}

	/**
	 * Retrieves the database username for the specified DataSource.
	 */
	public String getDataSourceUsername(String dataSource) {
		int index = getDataSourceIndex(dataSource);
		if (index == -1) {
			return null;
		}

		return getString(DATA_SOURCES + "(" + index + ")." + USERNAME);
	}

	/**
	 * Retrieves the index of the datasource specified.
	 */
	private int getDataSourceIndex(String datasource) {
		if (null == datasource || datasource.trim().length() == 0) {
			throw new GcasError(
					"DataSource Name can not be specified as null or blank.");
		}

		String[] datasources = getDataSourceNames();
		for (int ctr = 0; ctr < datasources.length; ctr++) {
			if (datasource.equals(datasources[ctr])) {
				return ctr;
			}
		}

		return -1;
	}

	/**
	 * Retrieves the list of datasource names.
	 */
	public String[] getDataSourceNames() {
		return getStringArray(DATA_SOURCES + "." + DATASOURCE_NAME);
	}

	/**
	 * Retrieves the database password for the specified pool.
	 */
	public String getDataSourcePassword(String datasource) {
		int index = getDataSourceIndex(datasource);
		if (index == -1) {
			return null;
		}

		return getString(DATA_SOURCES + "(" + index + ")." + PASSWORD);
	}

	/**
	 * Retrieves the driver for the specified datasource.
	 */
	public String getDataSourceDriverClass(String name)
			throws GcasRuntimeException {
		int index = getDataSourceIndex(name);
		if (index == -1) {
			throw new GcasRuntimeException(
					"DataSource configuration is missing required entry for driver class: "
					+ name);
		}

		return getString(DATA_SOURCES + "(" + index + ")." + DRIVER_CLASS);
	}

	/**
	 * Retrieves the database URL for the specified DataSource.
	 */
	public String getDataSourceUrl(String name) throws GcasRuntimeException {
		int index = getDataSourceIndex(name);
		if (index == -1) {
			throw new GcasRuntimeException(
					"DataSource configuration is missing required entry for URL: "
					+ name);
		}

		return getString(DATA_SOURCES + "(" + index + ")." + URL);
	}
}
