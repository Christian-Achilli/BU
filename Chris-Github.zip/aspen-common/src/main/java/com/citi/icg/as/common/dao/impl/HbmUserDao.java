package com.citi.icg.as.common.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.citi.icg.as.common.constants.DaoConstants;
import com.citi.icg.as.common.dao.UserDao;
import com.citi.icg.as.core.dao.entities.business.User;
import com.citi.icg.as.core.dao.entities.business.UserAttribute;
import com.citi.icg.as.core.dao.entities.business.UserProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.UserRegion;
import com.citi.icg.as.core.dao.entities.business.UserSavedSearches;
import com.citi.icg.as.core.entities.constants.AttributeConstant;
import com.citi.icg.as.core.entities.constants.UserAttributeConstant;
import com.citi.icg.as.core.entities.constants.UserConstant;
import com.citi.icg.as.core.entities.constants.UserSavedSearchesConstant;

@Repository("userDao")
public class HbmUserDao implements UserDao {

	@Resource(name="hibernateTemplate")
	private HbmGenericTemplate template;

	public User getUser(String userId) {
		return template.getById(User.class, userId);
	}

	public List<UserAttribute> getAttributesForUserId(final String id) {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.UserAttribute.class);
		criteria.createAlias(UserAttributeConstant.USER, UserAttributeConstant.USER).add(Restrictions.eq(UserAttributeConstant.USER + DaoConstants.DOT_CHAR + UserConstant.USER_ID, id))
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return template.findByCriteria(UserAttribute.class, criteria);
	}

	@Override
	public List<User> addUsers(final List<User> userList) {
		if (userList == null || userList.size() < 1) {
			return null;
		}
		Set savedSet = template.save(userList.toArray());
		List<User> list = new ArrayList<User>();
		list.addAll(savedSet);
		return list;
	}

	@Override
	public void removeUsers(final List<User> userList) {
		if (userList == null || userList.size() < 1) {
			return;
		}
		template.deleteAll(userList.toArray());
	}

	@Override
	public User mergeUser(final User usr) {
		return template.merge(usr);
	}

	@Override
	public List<UserAttribute> getUserAttributes(final String attributeCode) {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.UserAttribute.class);
		criteria.createAlias(UserAttributeConstant.ATTRIBUTE, UserAttributeConstant.ATTRIBUTE).add(
				Restrictions.eq(UserAttributeConstant.ATTRIBUTE + DaoConstants.DOT_CHAR + AttributeConstant.ATTRIBUTE_CODE, attributeCode));
		return template.findByCriteria(UserAttribute.class, criteria);
	}

	@Override
	public List<User> getUsers() {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.User.class);
		return template.findByCriteria(User.class, criteria);
	}

	@Override
	public List<UserSavedSearches> getUserSavedSearchesByExample(final UserSavedSearches bean) {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.UserSavedSearches.class);
		criteria.add(Example.create(template.getDomainObject(bean)));
		return template.findByCriteria(UserSavedSearches.class, criteria);
	}

	public void saveOrUpdateUserSavedSearches(final UserSavedSearches example) {
		template.saveOrUpdateObject(example);
	}

	@Override
	public List<UserSavedSearches> getDateSaveSearchData(final String queueType, final String userSearchId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.UserSavedSearches.class);
		criteria.add(Restrictions.eq(UserSavedSearchesConstant.QUEUE_TYPE, queueType));
		criteria.add(Restrictions.eq(UserSavedSearchesConstant.FK_USER_ID, userSearchId));

		return template.findByCriteria(UserSavedSearches.class, criteria);
	}

	@Override
	public UserSavedSearches getDateSaveSearchLayout(final String queueType, final String userId, final String searchName, final String searchId) {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.UserSavedSearches.class);
		criteria.add(Restrictions.eq(UserSavedSearchesConstant.QUEUE_TYPE, queueType));
		criteria.add(Restrictions.eq(UserSavedSearchesConstant.SEARCH_NAME, searchName));
		criteria.add(Restrictions.eq(UserSavedSearchesConstant.FK_USER_ID, userId));

		return template.findSingleByCriteria(UserSavedSearches.class, criteria);
	}

	@Override
	public void removeDateSearchLayout(String queueType, String userId, String gridName) {
		UserSavedSearches userSavedSearches = getDateSaveSearchLayout(queueType, userId, gridName, null);
		template.deleteAll(userSavedSearches);
	}

	@Override
	public UserProcessingUnit getUserProcessingUnitFromDb(final UserProcessingUnit pu) {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.UserProcessingUnit.class, DaoConstants.MAIN);
		criteria.add(Restrictions.eq("isDefault", pu.getIsDefault())).createAlias(DaoConstants.MAIN + DaoConstants.DOT_CHAR + "processingUnit", DaoConstants.COL, Criteria.LEFT_JOIN)
				.add(Restrictions.eq(DaoConstants.COL + DaoConstants.DOT_CHAR + "unitName", pu.getProcessingUnit().getUnitName()))
				.createAlias(DaoConstants.MAIN + DaoConstants.DOT_CHAR + "user", DaoConstants.COL1, Criteria.LEFT_JOIN)
				.add(Restrictions.eq(DaoConstants.COL1 + DaoConstants.DOT_CHAR + "userId", pu.getUser().getUserId()));

		return template.findSingleByCriteria(UserProcessingUnit.class, criteria);

	}

	@Override
	public UserRegion getUserRegionFromDb(final UserRegion userRegion) {
		DetachedCriteria criteria = DetachedCriteria.forClass(com.citi.icg.as.core.dao.entities.ext.beans.UserRegion.class, DaoConstants.MAIN);
		criteria.add(Restrictions.eq("primaryRegion", userRegion.getPrimaryRegion())).createAlias(DaoConstants.MAIN + DaoConstants.DOT_CHAR + "region", DaoConstants.COL, Criteria.LEFT_JOIN)
				.add(Restrictions.eq(DaoConstants.COL + DaoConstants.DOT_CHAR + "regionCode", userRegion.getRegion().getRegionCode()))
				.createAlias(DaoConstants.MAIN + DaoConstants.DOT_CHAR + "user", DaoConstants.COL1, Criteria.LEFT_JOIN)
				.add(Restrictions.eq(DaoConstants.COL1 + DaoConstants.DOT_CHAR + "userId", userRegion.getUser().getUserId()));

		return template.findSingleByCriteria(UserRegion.class, criteria);
	}
}
