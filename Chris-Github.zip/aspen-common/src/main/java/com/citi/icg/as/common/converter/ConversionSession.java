package com.citi.icg.as.common.converter;

import java.util.HashMap;
import java.util.Map;

import com.citi.icg.as.common.client.entities.BusinessEntity;

@SuppressWarnings({ "unchecked", "rawtypes" })
public final class ConversionSession {

	private ConversionSession() {
	}

	/**
	 * Map items are held on a source class to target basis.
	 */
	private Map<Class<?>, Map<String, Object>> convertedObjectMap = new HashMap<Class<?>, Map<String, Object>>();

	/**
	 * Map param items that maybe useful during a conversion session.
	 */
	private Map<String, Object> paramObjectMap = new HashMap<String, Object>();

	/**
	 * This makes this class imuttable and threadsafe.
	 * 
	 * @return new ConversionSession
	 */
	public static synchronized ConversionSession newSession() {
		return new ConversionSession();
	}

	public void addItemToCache(Object from, Object to, String key) {

		if (!convertedObjectMap.containsKey(from.getClass())) {

			convertedObjectMap.put(from.getClass(), new HashMap<String, Object>());

		}

		convertedObjectMap.get(from.getClass()).put(key, to);

	}

	public Object checkCacheFromObject(Object source, String id) {
		if (convertedObjectMap.containsKey(source.getClass())) {

			Object cachedTarget = convertedObjectMap.get(source.getClass()).get(id);
			return cachedTarget;

		}

		return null;
	}

	public Object checkCacheFromBusinessEntity(BusinessEntity source) {

		Object cachedObject = null;
		if ((source.getId() instanceof Integer && ((Integer) source.getId()) > 0) || (source.getId() instanceof Long && ((Long) source.getId()) > 0)
				|| (source.getId() instanceof String && ((String) source.getId()) != null)) {
			String id = String.valueOf(source.getId());
			cachedObject = checkCacheFromObject(source, id);

		}

		if (cachedObject == null && source.getTemporaryKey() != null) {

			cachedObject = checkCacheFromObject(source, source.getTemporaryKey());

		}

		return cachedObject;

	}

	public <S, T> T convert(S source, Class<T> target) {

		Object targetObject = null;

		EntityConverter converter = getConverter(source.getClass(), target);
		if (converter != null) {

			// target focused
			if (converter.getTargetClass().equals(target)) {

				targetObject = converter.convertTo(source);

			} else {

				targetObject = converter.convertFrom(source);

			}

		}

		return (T) targetObject;

	}

	public synchronized <S, T> EntityConverter getConverter(Class<S> source, Class<T> target) {
		return ConverterFactory.getConverter(source, target, this);
	}

	public void addConverterParam(String paramName, Object value) {
		paramObjectMap.put(paramName, value);
	}

	public Object getConverterParam(String paramName) {
		return paramObjectMap.get(paramName);
	}

}
