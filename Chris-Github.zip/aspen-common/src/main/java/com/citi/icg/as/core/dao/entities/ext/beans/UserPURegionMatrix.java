package com.citi.icg.as.core.dao.entities.ext.beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.JPATransferObject;

@Entity
@Table(name = "USER_PU_REGION_MATRIX")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "hibernate.USER_PROFILE")
public class UserPURegionMatrix extends JPATransferObject implements Serializable {

	private static final long serialVersionUID = 555717066923756929L;

	public UserPURegionMatrix() {
	}

	private int userPURegionMatrixId;

	private UserProcessingUnit userProcessingUnit;

	private User user;

	private UserRegion userRegion;

	private Date lastUpdatedDate;

	private String updatedBy;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_USER_PROCESSING_UNIT_ID")
	public UserProcessingUnit getUserProcessingUnit() {
		return userProcessingUnit;
	}

	public void setUserProcessingUnit(UserProcessingUnit userProcessingUnit) {
		this.userProcessingUnit = userProcessingUnit;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FK_USER_ID")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_USER_REGION_ID")
	public UserRegion getUserRegion() {
		return userRegion;
	}

	public void setUserRegion(UserRegion userRegion) {
		this.userRegion = userRegion;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_USER_PU_REGION_MATRIX", allocationSize = 1)
	@Column(name = "PK_USER_PU_REGION_MATRIX_ID")
	public int getUserPURegionMatrixId() {
		return userPURegionMatrixId;
	}

	public void setUserPURegionMatrixId(int userPURegionMatrixId) {
		this.userPURegionMatrixId = userPURegionMatrixId;
	}

	@Column(name = "LAST_UPDATED_DATE")
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Column(name = "UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
}