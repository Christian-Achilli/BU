package com.citi.icg.as.common.enums;


/**
 * List of qualifiers(event copy names) for an event.
 */
public enum AnnouncementCopyTypeEnum
{
	SRCC
	{
		public Integer getPkQualifierId()
		{
			return Integer.valueOf(1);
		}

		public String getQualifierName()
		{
			return "SOURCE COPY";
		}

		public String getQueueType()
		{
			return "";
		}
	},

	APPC
	{
		public Integer getPkQualifierId()
		{
			return Integer.valueOf(2);
		}

		public String getQualifierName()
		{
			return "APPROVED COPY";
		}

		public String getQueueType()
		{
			return QueueType.Approval.name();
		}

	},

	USRC
	{
		public Integer getPkQualifierId()
		{
			return Integer.valueOf(3);
		}

		public String getQualifierName()
		{
			return "USER - WORKING COPY";
		}

		public String getQueueType()
		{
			return QueueType.WorkingItems.name();
		}
	},

	USRSRCC
	{
		public Integer getPkQualifierId()
		{
			return Integer.valueOf(4);
		}

		public String getQualifierName()
		{
			return "USER - SOURCE COPY";
		}

		public String getQueueType()
		{
			return "";
		}
	},
	
	REJECTC
	{
		public Integer getPkQualifierId()
		{
			return Integer.valueOf(5);
		}

		public String getQualifierName()
		{
			return "REJECTED COPY";
		}

		public String getQueueType()
		{
			return "";
		}
	};
	
	public static AnnouncementCopyTypeEnum getQualifierType(String strQualifierType)
	{
		for (AnnouncementCopyTypeEnum qualifierType : AnnouncementCopyTypeEnum.values()) {
			if (qualifierType.getQualifierName().equalsIgnoreCase(strQualifierType)) {
				return qualifierType;
			}
		}
		return null;
	}
	
	public static AnnouncementCopyTypeEnum getQualifierType(Integer pkQualifierId)
	{
		for (AnnouncementCopyTypeEnum qualifierType : AnnouncementCopyTypeEnum.values()) {
			if (pkQualifierId != null && qualifierType.getPkQualifierId().intValue() == pkQualifierId.intValue()) {
				return qualifierType;
			}
		}
		return null;
	}

	public static AnnouncementCopyTypeEnum getQualifierType(QueueType queueType)
	{
		for (AnnouncementCopyTypeEnum qualifierType : AnnouncementCopyTypeEnum.values()) {
			if (queueType != null && qualifierType.getQueueType().equals(queueType.name())) {
				return qualifierType;
			}
		}
		return null;
	}

	public abstract Integer getPkQualifierId();

	public abstract String getQualifierName();

	public abstract String getQueueType();
}
