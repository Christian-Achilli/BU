package com.citi.icg.as.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;

import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DriverManagerConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.pool.impl.GenericObjectPool;

import com.citi.icg.toolkit.debug.IcgAssert;
import com.citi.icg.toolkit.exception.IcgException;
import com.citi.icg.toolkit.logger.IcgAppLogger;
import com.citi.icg.toolkit.sql.IcgDataSourcePoolConfig;
import com.citi.icg.toolkit.sql.IcgDriver;
import com.citi.icg.toolkit.stats.IcgStatsEvent;
import com.citi.icg.toolkit.stats.sql.IcgSqlEventType;
import com.citi.icg.toolkit.stats.sql.IcgSqlStats;
import com.citi.icg.toolkit.util.IcgEnvironment;
import com.citi.icg.toolkit.util.IcgTextEncryptUtils;

/**
 * This class tracks all ICG JDBC drivers registered.
 */
public class IcgCommonDriverManager
{
	// --- Static Variables ---

	private static final int SECONDS_10 = 10000;

	/** Log. */
	private static Log log = LogFactory.getLog(IcgCommonDriverManager.class);

	/** Singleton instance. */
	private static IcgCommonDriverManager singleton = null;

	/** Name of default datasource in database configuration. */
	public static final String DEFAULT_DATASOURCE_NAME = "default";

	// --- Instance Variables ---

	/** Map of datasource factories being tracked. */
	private HashMap<String, PoolableConnectionFactory> dataSourceConnectionFactories = new HashMap<String, PoolableConnectionFactory>();

	/** Default connection factory. */
	private PoolableConnectionFactory defaultFactory = null;

	/** Holds the mapping between datasource URLs and names **/
	private HashMap<String, IcgDataSourcePoolConfig> dataSourcesUrlToConfig = new HashMap<String, IcgDataSourcePoolConfig>();

	// --- Constructor(s) ---

	/**
	 * Constructs an IcgDriverManager.
	 */
	private IcgCommonDriverManager()
	{
	}

	// --- Static Methods ---

	/**
	 * Retrieves the singleton instance of this class. The first time this
	 * method is invoked, it loads and configures all ICG JDBC drivers as
	 * defined in its configuration.
	 */
	public static IcgCommonDriverManager getInstance() throws IcgException
	{
		if (singleton == null)
		{
			synchronized (IcgCommonDriverManager.class)
			{
				if (singleton == null)
				{
					IcgCommonDriverManager manager = new IcgCommonDriverManager();

					// register driver classes
					manager.init();

					singleton = manager;

					// Bootstrap the SQL stats and tabulator
					IcgSqlStats.getInstance();

					// configure datasources
					singleton.configureDataSources();
				}
			}
		}
		return singleton;
	}

	// --- Instance Methods ---

	/**
	 * Retrieves data source name for specified db url.
	 */
	public String getDataSourceNames(String dataSourceUrl)
	{
		if (dataSourcesUrlToConfig != null && dataSourcesUrlToConfig.size() > 0)
		{
			IcgDataSourcePoolConfig poolconfig = dataSourcesUrlToConfig.get(dataSourceUrl);
			if(poolconfig != null){
				return dataSourcesUrlToConfig.get(dataSourceUrl).name;	
			}
		}
		return null;
	}

	/**
	 * Retrieves the default connection factory.
	 */
	public PoolableConnectionFactory getDefaultConnectionDataSource()
	{
		return defaultFactory;
	}

	/**
	 * Retrieves a database connection from the default connection factory.
	 */
	public Connection getConnection() throws IcgException
	{
		if (defaultFactory == null)
			throw new IcgException("There is no default connection DataSource defined.");

		Connection icgConn = null;
		try
		{
			IcgStatsEvent event = new IcgStatsEvent("Default DataSource", IcgSqlEventType.CREATE_CONNECTION);

			icgConn = (Connection) defaultFactory.getPool().borrowObject();

			event.end();
		}
		catch (Exception ex)
		{
			DbUtils.closeQuietly(icgConn);
			throw new IcgException("Failed to get database connection from default connection DataSource.");
		}
		return icgConn;
	}

	/**
	 * Retrieves a database connection from the named connection DataSource.
	 */
	public Connection getConnection(String dataSource) throws IcgException
	{
		IcgAssert.notNullOrBlank(dataSource, "Connection DataSource Name");
		Connection icgConn = null;

		try
		{
			IcgStatsEvent event = new IcgStatsEvent(dataSource, IcgSqlEventType.CREATE_CONNECTION);
			PoolableConnectionFactory factory = dataSourceConnectionFactories.get(dataSource);
			if (factory == null)
				throw new IcgException("There is no connection DataSource named: " + dataSource);

			icgConn = (Connection) factory.getPool().borrowObject();

			event.end();
		}
		catch (Exception ex)
		{
			DbUtils.closeQuietly(icgConn);
			throw new IcgException("Failed to get database connection from the connection DataSource." + dataSource, ex);
		}
		return icgConn;
	}

	/**
	 * Initializes the data sources.
	 */
	private void init() throws IcgException
	{
		configureDrivers();
	}

	/**
	 * Configures driver wrappers.
	 */
	private void configureDrivers() throws IcgException
	{
		// initialize ICG toolkit specified drivers, only when env settings is
		// set
		if (System.getProperty(IcgEnvironment.ICG_ENV) != null)
		{
			IcgDatabaseConfiguration configuration = IcgDatabaseConfiguration.getInstance();

			String[] driverNames = configuration.getDriverNames();
			if (driverNames == null)
			{
				log.debug("No database driver wrappers have been specified for setup.");
				return;
			}

			log.debug("Database driver wrappers to setup: " + Arrays.asList(driverNames));
			for (int ctr = 0; ctr < driverNames.length; ctr++)
			{
				String driverClassName = configuration.getDriverClass(driverNames[ctr]);
				log.debug("Loading driver class: " + driverClassName);

				registerDriver(driverClassName);
			}
		}

		// load ICG driver
		registerDriver(IcgDriver.class.getName());
	}

	/**
	 * Registers the driver.
	 * 
	 * @param driverName
	 *            the driver name
	 * @param driverClass
	 *            the driver class
	 */
	public void registerDriver(String driverClassName) throws IcgException
	{
		// Register driver.
		try
		{
			Class.forName(driverClassName);
		}
		catch (Throwable ex)
		{
			throw new IcgException("Failed to load driver class: " + driverClassName, ex);
		}
	}

	/**
	 * Configures connection datasources.
	 */
	private void configureDataSources() throws IcgException
	{
		IcgDatabaseConfiguration configuration = IcgDatabaseConfiguration.getInstance();

		String[] datasources = configuration.getDataSourceNames();
		if (datasources == null)
		{
			log.debug("No connection datasources have been specified for setup.");
			return;
		}

		log.debug("Connection datasources to setup: " + Arrays.asList(datasources));
		for (int ctr = 0; ctr < datasources.length; ctr++)
		{
			configureDataSource(getPoolConfig(configuration, datasources[ctr]));
		}
	}

	public void configureDataSource(String dataSourceName, String driver, String url, String username, String password,
			boolean validateOnStartUp) throws IcgException
	{
		// configure single connection pool - that only holds connections in
		// pool for 10 seconds.
		IcgDataSourcePoolConfig dataSourcePoolConfig = new IcgDataSourcePoolConfig();
		dataSourcePoolConfig.maxIdle = 0;
		dataSourcePoolConfig.maxActive = -1;
		dataSourcePoolConfig.testOnBorrow = false;
		dataSourcePoolConfig.timeBetweenEvictionRunsMillis = SECONDS_10;
		dataSourcePoolConfig.driver = driver;
		dataSourcePoolConfig.url = url;
		dataSourcePoolConfig.username = username;
		dataSourcePoolConfig.password = password;
		dataSourcePoolConfig.name = dataSourceName;
		dataSourcePoolConfig.validateOnStartUp = validateOnStartUp;

		configureDataSource(dataSourcePoolConfig);
	}

	public void configureDataSource(String dataSourceName, String driver, String url, String username, String password) throws IcgException
	{
		configureDataSource(dataSourceName, driver, url, username, password, false);
	}

	private void configureDataSource(IcgDataSourcePoolConfig config) throws IcgException
	{
		String driver = config.driver;

		if (IcgDriver.class.getName().equals(driver))
		{
			driver = IcgDriver.getNativeDriverNameFromIcgDriverUrl(config.url);
		}

		// add mapping between URLs and datasource names
		dataSourcesUrlToConfig.put(config.url, config);

		// Create a connection to test the parameters.
		Connection connection = null;
		try
		{
			IcgCommonDriverManager.getInstance().registerDriver(driver);
			if (config.validateOnStartUp)
			{
				connection = DriverManager.getConnection(IcgDriver.getNativeUrlFromIcgDriverUrl(config.url), config.username,
						IcgTextEncryptUtils.decryptIfEncrypted(config.password));
			}
		}
		catch (Exception ex)
		{
			IcgAppLogger.warn(this, "Failed to test connection for connection datasource: " + config.name, ex);
		}
		finally
		{
			DbUtils.closeQuietly(connection);
		}

		// Create connection pool.
		GenericObjectPool pool = new GenericObjectPool();
		pool.setConfig(config);
		
		ConnectionFactory factory = new DriverManagerConnectionFactory(config.url, config.username, IcgTextEncryptUtils
				.decryptIfEncrypted(config.password));
		// by default settings: readOnly=false, autoCommit=true
		// TODO: may be made configurable
		PoolableConnectionFactory poolFactory = new PoolableConnectionFactory(factory, pool, null, config.validationQuery, false, true);

		/*
		 * Add to map of pool factories, and set as default if this pool is
		 * named as such.
		 */
		dataSourceConnectionFactories.put(config.name, poolFactory);
		log.debug("Configured connection pool for datasource: " + config.name);

		if (DEFAULT_DATASOURCE_NAME.equals(config.name))
		{
			defaultFactory = poolFactory;
		}
	}

	/**
	 * Retrieves connection pool configuration.
	 */
	private IcgDataSourcePoolConfig getPoolConfig(IcgDatabaseConfiguration configuration, String dataSourceName)
	{
		IcgDataSourcePoolConfig config = new IcgDataSourcePoolConfig();
		config.maxActive = configuration.getMaxSize(dataSourceName);
		config.minIdle = configuration.getMinIdle(dataSourceName);
		config.maxIdle = configuration.getMaxIdle(dataSourceName);
		config.maxWait = configuration.getMaxBlockWaitTime(dataSourceName);
		config.testOnBorrow = configuration.shouldTestOnBorrow(dataSourceName);
		config.testOnReturn = configuration.shouldTestOnReturn(dataSourceName);
		config.testWhileIdle = configuration.shouldTestIdle(dataSourceName);
		config.timeBetweenEvictionRunsMillis = configuration.getIdleCheckRunInterval(dataSourceName);
		config.numTestsPerEvictionRun = configuration.getIdleCheckNumberItems(dataSourceName);
		config.minEvictableIdleTimeMillis = configuration.getMaxIdleTime(dataSourceName);

		config.driver = configuration.getDataSourceDriverClass(dataSourceName);
		config.url = configuration.getDataSourceUrl(dataSourceName);
		config.username = configuration.getDataSourceUsername(dataSourceName);
		config.password = configuration.getDataSourcePassword(dataSourceName);
		config.validationQuery = configuration.getValidationQuery(dataSourceName);
		config.validateOnStartUp = configuration.getValidationOnStartup(dataSourceName);
		config.name = dataSourceName;

		return config;
	}

	/**
	 * Get list of datasource loaded from configuration.
	 * 
	 * @return list of configured datasource names
	 */
	public Collection<String> getDataSourceNamesConfigured()
	{
		ArrayList<String> names = new ArrayList<String>();

		for (IcgDataSourcePoolConfig config : dataSourcesUrlToConfig.values())
		{
			names.add(config.name);
		}

		return names;
	}

	/**
	 * Get list of datasource loaded from configuration.
	 * 
	 * @param dataSourceName
	 *            data source name
	 * @return list of configured datasource names
	 */
	public IcgDataSourcePoolConfig getDataSourceConfigInfo(String dataSourceName)
	{
		for (IcgDataSourcePoolConfig config : dataSourcesUrlToConfig.values())
		{
			if (dataSourceName.equals(config.name))
			{
				return config;
			}
		}

		return null;
	}
}
