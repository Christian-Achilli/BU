package com.citi.icg.as.util;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public final class NumberFormatUtil {
	private static final String NUMBER_FORMAT = "000";
	
	private NumberFormatUtil() { } 
	
	public static final ThreadLocal<NumberFormat> OPTION_REPEAT_NUMBER_FORMAT = new ThreadLocal<NumberFormat>()
	{
		@Override
		protected NumberFormat initialValue()
		{
			return new DecimalFormat(NUMBER_FORMAT);
		}
	};
}
