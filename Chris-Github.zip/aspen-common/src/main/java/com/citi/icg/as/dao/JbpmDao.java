package com.citi.icg.as.dao;

import java.util.List;

public interface JbpmDao {
	List<Object> findByNamedQuery(String querySql, Object... objects);
}
