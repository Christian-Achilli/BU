package com.citi.icg.as.server.common.config.ui;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.UnhandledException;
import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.citi.icg.as.server.common.config.AspenPropertyPlaceHolderConfigurer;

/**
 * 
 * @author ap72338
 *         <p>
 *         The app.properties file is created during build process, using
 *         maven-properties-plugin. So will never change, hence instance
 *         variable and also to not load each time request comes to view config
 * 
 *         <pre>
 * &lt;execution&gt;
 * 	&lt;phase>generate-resources</phase>
 * 	&lt;goals>
 * 	&lt;goal>write-project-properties</goal>
 * 	&lt;/goals>
 * 		&lt;configuration>
 * 			&lt;outputFile>
 * 			src/main/resources/app.properties
 * 			&lt;/outputFile>
 * 		&lt;/configuration>
 * 	&lt;/execution>
 *         </pre>
 * 
 *         </p>
 */
@Controller
public abstract class BaseViewConfigController implements ApplicationContextAware {

	private final static Logger logger = Logger.getLogger(BaseViewConfigController.class);
	private ApplicationContext context;
	private Properties appProperties;

	@RequestMapping(value = "/viewConfig")
	public String showConfiguration(Model model) throws Exception {
		model.addAttribute("dataSources", getDataSourceInfo());
		model.addAttribute("releaseInfo", getReleaseInfo());
		model.addAttribute("aspenEnv", System.getProperty(AspenPropertyPlaceHolderConfigurer.ASPEN_ENV));

		for (Entry<Object, Object> entry : appProperties.entrySet()) {
			model.addAttribute(entry.getKey().toString().replaceAll("\\.", StringUtils.EMPTY), entry.getValue());
		}
		executeInternal(model.asMap());
		return "config";
	}

	/**
	 * 
	 * @param valueMap
	 *            The child classes can override this method to add any
	 *            additional information
	 */
	protected abstract void executeInternal(final Map<String, Object> valueMap);

	private List<DatasourceInfo> getDataSourceInfo() throws Exception {
		List<DatasourceInfo> dbList = new ArrayList<DatasourceInfo>();

		Map<String, DataSource> dataSources = context.getBeansOfType(DataSource.class);

		if (MapUtils.isEmpty(dataSources) && context.getParent() != null) {
			dataSources = context.getParent().getBeansOfType(DataSource.class);
		}

		for (Entry<String, DataSource> entry : dataSources.entrySet()) {
			Connection conn = null;
			try {
				conn = entry.getValue().getConnection();
				dbList.add(new DatasourceInfo(conn.getMetaData(), entry.getKey()));
			} finally {
				if (conn != null) {
					conn.close();
				}
			}
		}
		return dbList;

	}

	public String getReleaseInfo() {
		String releaseInfo = "Not Available";
		try {
			ClassPathResource res = new ClassPathResource("releaseInfo.html");
			releaseInfo = IOUtils.toString(res.getInputStream());
			IOUtils.closeQuietly(res.getInputStream());
		} catch (Exception e) {
			logger.error(e);
		}
		return releaseInfo;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context = applicationContext;
	}

	public ApplicationContext getApplicationContext() {
		return this.context;
	}

	@PostConstruct
	public void postConstruct() {
		appProperties = new Properties();
		try {
			appProperties.load(new ClassPathResource("app.properties").getInputStream());
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public class DatasourceInfo {
		private String dbURL, dbDriver, dsName;
		private int maxConnections;

		public DatasourceInfo(DatabaseMetaData metaData, String dsName) {			
			try {
				dbURL = metaData.getURL();
				dbDriver = metaData.getDriverName();
				this.dsName = dsName;
				maxConnections = metaData.getMaxConnections();
			} catch (SQLException e) {
				throw new UnhandledException(e);
			}
		}

		public String getDbURL() {
			return dbURL;
		}

		public String getDbDriver() {
			return dbDriver;
		}

		public String getDsName() {
			return dsName;
		}

		public int getMaxConnections() {
			return maxConnections;
		}

		public String toString(){
			return dbURL + dbDriver;
		}
	}
}
