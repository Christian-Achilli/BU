package com.citi.icg.as.common.constants;

public class CommonConstants {

	public static final String HYPHEN = "-";
	public static final String COMMA = ",";
	public static final String DOT = ".";
	public static final String CAIRO = "CAIRO";
	public static final String CSL = "CSL";
	public static final String GPDW = "GPDW";
	public static final String GPDW_CGMA = "GPDW_CGMA";
	public static final String GPDW_BR = "GPDW_BR";
	public static final String GPDW_NONE_CGMA = "GPDW_NONE_CGMA";
	public static final String SECORE = "SECORE";
	public static final String US_DCC = "US DCC";
	public static final String EMC = "EMC";
	public static final String FORMAT_STR = "yyyyMMdd";
	public static final String CLIENT_FIRM_POSITION = "Client/Firm";
	public static final String OTHER_POSITION = "Other position";
	public static final String TRADE = "trade";
	public static final String SYSTEM_USER = "SYSTEM";
	public static final String REGION_EMEA = "EMEA";
	public static final String REGION_ASPAC = "ASPAC";
	public static final String REGION_NAM = "NAM";
	public static final String REGION_CUSTODY = "US Custody Region";
	public static final String UNDER_LINE = "_"; 
	
	public static final String SYSTEM_BUSINESS_STREAM_PROPERTY = "aspen.stream";
	public static final String SYSTEM_ENV_PROPERTY = "aspen.env";
	public static final String CUSTODY_STREAM="custody";
	public static final String MARKETS_STREAM="markets";
	
	public static final String N = "N";
	public static final String Y = "Y";
	
	public static final String SPACE = " ";
	public static final String WEBLOGIC_CLASS_TO_BE_SCANNED_FOR_SPRING_BOOT = "weblogic.kernel.WorkManagerWrapper";
	public static final String WEBLOGIC_NODE_NAME = "weblogic.name";
	public static final String TEST_EXECUTION = "tests.execution";
	public static final String WC_ASYNC_MODE_ENABLED_PROPERTY = "aspen.wc.async.flow.enabled";

	public static final String EMC_ASYNC_MODE_ENABLED_PROPERTY = "aspen.emc.async.flow.enabled";
	
	public static final String OPERATION_EQUALS = "EQUALS";
	public static final String OPERATION_NOT_EQUALS = "NOT_EQUALS";
	
	
}
