package com.citi.icg.as.common.quartz.job;

import org.apache.commons.lang.StringUtils;
import org.springframework.scheduling.SchedulingException;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

public class AspenSchedulerFactoryBean extends SchedulerFactoryBean {
	
	private static final String NODE3 = "Node3";
	
	@Override
	public void start() throws SchedulingException {
		if (isNode3()) {
			return;
		}
		super.start();
	}
	
	
	private boolean isNode3() {
		String nodeName = System.getProperty("weblogic.Name");
		return StringUtils.isNotEmpty(nodeName) && nodeName.endsWith(NODE3);
	}
}
