package com.citi.icg.as.server.service;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.MDC;
import org.apache.log4j.spi.LoggingEvent;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.core.ParameterNameDiscoverer;

import com.citi.icg.as.server.GcasRequestContext;
import com.citi.icg.as.server.util.GcasConstants;

public class GcasRpcContext
{	
	private static final int INT_20 = 20;
	private static final Log LOG = LogFactory.getLog(GcasRpcContext.class);
	private static final ParameterNameDiscoverer PARAM_NAME_DISCONVER = new LocalVariableTableParameterNameDiscoverer();	
	private static final ThreadLocal<DateFormat> DF = new ThreadLocal<DateFormat>()
	{
		@Override
		protected DateFormat initialValue()
		{
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		}
	};
	
	private final long startTimeMs;
	private final String remoteUser;
	private final String targetName;
	private final String methodName;
	private final Map<String, String> args = new LinkedHashMap<String, String>();
	private long stopTimeMs;
	private boolean isFailed = false;
	
	public static GcasRpcContext get()
	{
		
		GcasRpcContext ctx = (GcasRpcContext) MDC.get(GcasRpcContext.class.getName());
		if (ctx == null)
		{
			ctx = start(GcasRequestContext.getUserId(), null, null, new Object[0]);
		}
		return ctx;
	}
	
	public static GcasRpcContext get(LoggingEvent loggingEvent)
	{
		return (GcasRpcContext) loggingEvent.getMDC(GcasRpcContext.class.getName());
	}
	
	public static GcasRpcContext start(String requestUser, Class<?> target, Method method, Object ...args)
	{
		GcasRpcContext ctx = new GcasRpcContext(requestUser, target, method, args);
		MDC.put(GcasRpcContext.class.getName(), ctx);
		return ctx;
	}
	
	public static GcasRpcContext start(String requestUser, String target, String method, Map<String, String> argMap) {
		GcasRpcContext ctx = new GcasRpcContext(requestUser, target, method, argMap);
		MDC.put(GcasRpcContext.class.getName(), ctx);
		return ctx;
	}
	
	public static void finish()
	{
		GcasRpcContext ctx = get();
		if (ctx != null)
		{
			ctx.stopTimeMs = System.currentTimeMillis();
			try
			{
				LOG.info(ctx.toRpcLogEntry());				
			}
			catch (Exception e)			
			{
				// don't raise exception to caller. should not
				// fail when unable to write transaction log.
				LOG.info(GcasConstants.POUND_SIGN + GcasConstants.SPACE + e.toString());
			}
		}
	}

	public GcasRpcContext(String remoteUser, String target, String method, Map<String, String> argMap)
	{
		this.remoteUser = remoteUser;
		this.startTimeMs = System.currentTimeMillis();
		this.stopTimeMs = -1;
		this.targetName = target;
		this.methodName = method;
		for (Entry<String, String> e : argMap.entrySet())
		{
			this.args.put(e.getKey(), describeParameter(e.getValue()));
		}
	}
	
	public GcasRpcContext(String remoteUser, Class<?> target, Method method, Object ...args)
	{
		this.remoteUser = remoteUser;
		this.startTimeMs = System.currentTimeMillis();
		this.stopTimeMs = -1;
		this.targetName = target == null ? null : target.getName();
		this.methodName = method == null ? null : method.getName();
		String[] argNames = PARAM_NAME_DISCONVER.getParameterNames(method);
		for (int n = 0; n < args.length; n++)
		{
			String argName = argNames == null ? "arg" + n : argNames[n];
			String argValue = describeParameter(args[n]);
			this.args.put(argName, argValue);
		}
	}
	
	public long getStartTimeMs()
	{
		return startTimeMs;
	}

	public String getRemoteUser()
	{
		return remoteUser;
	}

	public String getTargetName()
	{
		return targetName;
	}

	public String getMethodName()
	{
		return methodName;
	}

	public Map<String, String> getArgs()
	{
		return Collections.unmodifiableMap(args);
	}

	public boolean isFailed()
	{
		return isFailed;
	}

	public void setFailed(boolean isFailed)
	{
		this.isFailed = isFailed;
	}

	public long getStopTimeMs()
	{
		return stopTimeMs;
	}

	@Override
	public String toString()
	{
		try
		{
			StringBuffer result = new StringBuffer();
			result.append(this.targetName);
			result.append(GcasConstants.POUND_SIGN);
			result.append(this.methodName);
			result.append(GcasConstants.PARENTHESIS_LEFT);
			for (Map.Entry<String, String> arg : this.args.entrySet())
			{
				result.append(arg.getKey());
				result.append(GcasConstants.EQUALS_SIGN);
				result.append(StringUtils.abbreviate(arg.getValue(), INT_20));
				result.append(GcasConstants.COMMA + GcasConstants.SPACE);
			}
			if (!this.args.isEmpty())
			{
				result.delete(result.length() - 2, result.length());
			}
			result.append(GcasConstants.PARENTHESIS_RIGHT + GcasConstants.SPACE + GcasConstants.BRACKET_LEFT);
			result.append(this.remoteUser);
			result.append(", ");
			if (this.stopTimeMs >= 0)
			{
				result.append(this.stopTimeMs - this.startTimeMs);
			}
			else
			{
				result.append(System.currentTimeMillis() - this.startTimeMs);
			}
			result.append("ms" + GcasConstants.BRACKET_RIGHT);		
			return result.toString();
		}
		catch (Exception e)
		{
			return "GcasRpcContext#toString(): " + e.toString();
		}
	}

	public String toRpcLogEntry()
	{
		StringBuffer result = new StringBuffer();
		result.append(this.isFailed ? "ERR\t" : "OK\t");
		result.append(this.startTimeMs);
		result.append(GcasConstants.TAB);
		result.append(this.stopTimeMs - this.startTimeMs);
		result.append(GcasConstants.TAB);
		result.append(this.remoteUser);
		result.append(GcasConstants.TAB);
		result.append(this.targetName);
		result.append(GcasConstants.TAB);
		result.append(this.methodName);
		result.append(GcasConstants.TAB);
		for (Map.Entry<String, String> arg : this.args.entrySet()) {
			result.append(arg.getValue());
			result.append(GcasConstants.TAB);
		}
		return result.toString();
	}
	
	private String describeParameter(Object object)
	{
		StringBuffer result = new StringBuffer();
		if (object == null)
		{
			result.append("null");
		}
		else if (object.getClass().isPrimitive()
				|| object instanceof Number
				|| object instanceof Character
				|| object instanceof Boolean)
		{
			result.append(object);
		}
		else if (object instanceof CharSequence)
		{
			String str = object.toString();
			result.append(str.replace(GcasConstants.NEWLINE_CHAR,
					GcasConstants.SPACE_CHAR).replace(GcasConstants.ENTER_CHAR,
					GcasConstants.SPACE_CHAR).replace(GcasConstants.TAB_CHAR,
					GcasConstants.SPACE_CHAR));			
		}
		else if (object instanceof Date)
		{
			result.append(DF.get().format(object));
		}
//		else if (object instanceof Announcement)
//		{
//			Announcement ann = (Announcement) object;
//			result.append("Announcement(pk=");
//			result.append(ann.getPkAnnouncementId());
//			result.append(")");
//		}
//		else if (object instanceof Holding)
//		{
//			Holding holding = (Holding) object;
//			result.append("Holding(pk=");
//			result.append(holding.getPkHoldingId());
//			result.append(")");
//		}
		else if (object instanceof Collection<?>)
		{
			Collection<?> c = (Collection<?>) object;
			result.append("Collection(size=");
			result.append(c.size());
			result.append(")");
		}
		else if (object instanceof Map<?, ?>)
		{
			Map<?, ?> m = (Map<?, ?>) object;
			result.append("Map(size=");
			result.append(m.size());
			result.append(")");
		}
		else
		{
			result.append(StringUtils.substringAfterLast(object.getClass().getName(), GcasConstants.DOT));
		}
		return result.toString();
	}
	
}
