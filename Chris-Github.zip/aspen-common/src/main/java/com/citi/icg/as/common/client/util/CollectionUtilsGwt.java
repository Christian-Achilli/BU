package com.citi.icg.as.common.client.util;

import java.util.Collection;

public final class CollectionUtilsGwt {
	private CollectionUtilsGwt() {
	}

	public static boolean isEmpty(Collection<?> coll) {
		return (coll == null || coll.isEmpty());
	}

	public static boolean isNotEmpty(Collection<?> coll) {
		return !isEmpty(coll);
	}

	public static <T> boolean isExistIntersection(Collection<T> aCol, Collection<T> bCol) {
		for (T bItem : bCol) {
			if (aCol.contains(bItem)) {
				return true;
			}
		}

		return false;
	}

}
