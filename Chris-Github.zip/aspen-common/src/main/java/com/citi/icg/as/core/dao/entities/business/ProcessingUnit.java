package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;
import java.util.Set;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;
import com.citi.icg.as.common.enums.ProcessingUnitType;

public class ProcessingUnit extends BaseBusinessEntity {
	
	private static final long serialVersionUID = -7445665416174842965L;

	private int pkProcessingUnitId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String unitName;
	private String unitAlternateName;
	private String unitLongName;
	private String createdBy;
	private Date createdDate;
	private String groupEmailAddress;
	private String groupTelephoneNumber;
	private Set<UserProcessingUnit> userProcessingUnit; // related to user permissioning table

	public int getPkProcessingUnitId() {
		return pkProcessingUnitId;
	}

	public void setPkProcessingUnitId(int pkProcessingUnitId) {
		this.pkProcessingUnitId = pkProcessingUnitId;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getUnitAlternateName() {
		return unitAlternateName;
	}

	public void setUnitAlternateName(String unitAlternateName) {
		this.unitAlternateName = unitAlternateName;
	}

	public String getUnitLongName() {
		return unitLongName;
	}

	public void setUnitLongName(String unitLongName) {
		this.unitLongName = unitLongName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getGroupEmailAddress() {
		return groupEmailAddress;
	}

	public void setGroupEmailAddress(String groupEmailAddress) {
		this.groupEmailAddress = groupEmailAddress;
	}

	public String getGroupTelephoneNumber() {
		return groupTelephoneNumber;
	}

	public void setGroupTelephoneNumber(String groupTelephoneNumber) {
		this.groupTelephoneNumber = groupTelephoneNumber;
	}

	public Set<UserProcessingUnit> getUserProcessingUnit() {
		return userProcessingUnit;
	}

	public void setUserProcessingUnit(Set<UserProcessingUnit> userProcessingUnit) {
		this.userProcessingUnit = userProcessingUnit;
	}

	@Override
	public Integer getId() {
		return getPkProcessingUnitId();
	}

	@Override
	public String toString() {
		return this.unitName;
	}
	
	/**
	 * Calculates the type on the fly.
	 * A better design would be to replace unitName with processingUnitType,
	 * and avoid unnecessary conversion.
	 * 
	 * @return
	 */
	public ProcessingUnitType getProcessingUnitType() {
		if (getUnitName() == null) {
			return null;
		}
		return ProcessingUnitType.getPUType(getUnitName());
	}

}
