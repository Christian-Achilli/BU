package com.citi.icg.as.common.client.util;

/**
 *
 * @author yy31798
 *
 */
class PdfPrintHandlerStandard extends PdfPrintHandler {

	@Override
	public void print(String url) {
		doPrint(url);
	}

	public static native void doPrint(String url) /*-{
		var pw = $wnd.open(url);
    	pw.print();
  	}-*/;
}
