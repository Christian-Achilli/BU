package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class FieldQualifier extends BaseBusinessEntity {
	
	private static final long serialVersionUID = 8625496638595745906L;
	private String fieldCode;
	private String fieldName;
	private String fieldDisplayLabel;
	private String fieldDesc;
	private String fieldType;
	private Integer fieldUsageCode;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String isoCode;

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldDisplayLabel() {
		return fieldDisplayLabel;
	}

	public void setFieldDisplayLabel(String fieldDisplayLabel) {
		this.fieldDisplayLabel = fieldDisplayLabel;
	}

	public String getFieldDesc() {
		return fieldDesc;
	}

	public void setFieldDesc(String fieldDesc) {
		this.fieldDesc = fieldDesc;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public String getId() {
		return fieldCode;
	}

	/**
	 * @return the fieldUsageCode
	 */
	public Integer getFieldUsageCode() {
		return fieldUsageCode;
	}

	/**
	 * @param fieldUsageCode
	 *            the fieldUsageCode to set
	 */
	public void setFieldUsageCode(Integer fieldUsageCode) {
		this.fieldUsageCode = fieldUsageCode;
	}

	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}
}
