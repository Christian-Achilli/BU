package com.citi.icg.as.exception;

import com.google.gwt.user.client.rpc.IsSerializable;

@SuppressWarnings("serial")
public class GcasRuntimeException extends RuntimeException implements IsSerializable{

	public GcasRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public GcasRuntimeException(String message) {
		super(message);
	}

}
