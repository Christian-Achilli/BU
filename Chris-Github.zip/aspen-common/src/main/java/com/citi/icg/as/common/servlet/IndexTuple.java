package com.citi.icg.as.common.servlet;

/**
 * Just a wrapper class to Tuple.
 * Created by cd68076 on 6/03/2017.
 */
public class IndexTuple extends Tuple {

    public IndexTuple(int startIndex, int endIndex) {
        super(startIndex, endIndex);
    }

    public int getStartIndex() {
        return getLeft();
    }

    public int getEndIndex() {
        return getRight();
    }
}
