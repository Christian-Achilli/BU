package com.citi.icg.as.util;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.citi.icg.as.exception.GcasException;
import com.citi.icg.as.exception.GcasRuntimeException;

/**
 * Root class to get the Application runtime environment. based on
 */
public final class GcasEnvironment {
	// --- Static variables ---
	/** Runtime environment. */
	public static final String ICG_ENV = "icg.env";

	/** Runtime: Local Development. */
	public static final String RUNTIME_LOCAL = "local";

	/** Runtime: Development. */
	public static final String RUNTIME_DEV = "dev";

	/** Runtime: INTEGRATION (QA). */
	public static final String RUNTIME_INT = "int";

	/** Runtime: UAT (STAGE). */
	public static final String RUNTIME_UAT = "uat";

	/** Runtime: Production. */
	public static final String RUNTIME_PROD = "prod";

	/** Runtime: auto test . */
	public static final String RUNTIME_AUTO_TEST = "autotest";

	/** List of environments. */
	private static final String[] ENVIRONMENTS = new String[] {
			RUNTIME_AUTO_TEST, RUNTIME_LOCAL, RUNTIME_DEV, RUNTIME_INT,
			RUNTIME_UAT, RUNTIME_PROD };

	private static final String ICG_ENV_VALUE = initIcgEnv();

	// --- Constructor(s) ---

	/**
	 * Constructs an IcgEnvironment object.
	 */
	private GcasEnvironment() {

	}

	private static String initIcgEnv() {
		String env = System.getProperty(ICG_ENV);
		if (env == null) {
			throw new GcasRuntimeException("No value for system property "
					+ ICG_ENV);
		}

		if (!ArrayUtils.contains(ENVIRONMENTS, env)) {
			throw new GcasRuntimeException("Invalid value for system property "
					+ ICG_ENV + ": " + env + ".  Valid values are: "
					+ StringUtils.join(ENVIRONMENTS, ','));
		}
		return env;
	}

	// --- Environment Methods ---

	/**
	 * Get the environment for this runtime.
	 */
	public static String getEnvironment() {
		return ICG_ENV_VALUE;
	}

	/**
	 * Indicates if the runtime environment is auto test .
	 */
	public static boolean isInAutoTest() throws GcasException {
		return RUNTIME_AUTO_TEST.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is development.
	 */
	public static boolean isInDevelopment() throws GcasException {
		return RUNTIME_DEV.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is SIT.
	 */
	public static boolean isInINT() throws GcasException {
		return RUNTIME_INT.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is UAT.
	 */
	public static boolean isInUAT() throws GcasException {
		return RUNTIME_UAT.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is production.
	 */
	public static boolean isInProduction() throws GcasException {
		return RUNTIME_PROD.equals(getEnvironment());
	}

	/**
	 * Indicates if the runtime environment is Local.
	 */
	public static boolean isInLocal() throws GcasException {
		return RUNTIME_LOCAL.equals(getEnvironment());
	}

}
