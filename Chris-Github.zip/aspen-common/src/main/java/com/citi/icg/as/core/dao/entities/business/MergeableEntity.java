package com.citi.icg.as.core.dao.entities.business;

/**
 * Marker interface for entities which when are cloned maintain a unique id to the parent from which they were derived, and can therefore be merged back into there parent when an approval cycle is
 * complete.
 *
 */
public interface MergeableEntity {
	/**
	 * Return a UUID. UUID of two entities must be equivalent if-and-only-if one was the result of cloning the other.
	 * 
	 * @return non-null uuid
	 */
	String getUuid();

}
