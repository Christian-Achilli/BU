package com.citi.icg.as.common.dao.impl;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.metadata.CollectionMetadata;
import org.hibernate.transform.Transformers;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;
import com.citi.icg.as.common.dao.ExceptionHandlerDao;
import com.citi.icg.as.core.dao.entities.ext.beans.LoggedExceptions;
import com.citi.icg.as.core.entities.constants.LoggedExceptionsConstant;
import com.citi.icg.as.dao.DaoConstants;
import com.citi.icg.as.server.GcasRequestContext;

@Repository
public class HbmExceptionHandlerDao implements ExceptionHandlerDao {

	private HibernateTemplate template;

	@Resource
	private SessionFactory sessionFactory;

	@PostConstruct
	public void afterPropertiesSet() {
		template = new HibernateTemplate(sessionFactory);
	}

	public <S, T> S getById(final Class<S> busClass, final Serializable pkId) {
		return template.get(busClass, pkId);
	}

	public List<LoggedExceptions> getExceptionList(final Integer[] pkIds) {
		HibernateCallback<List<LoggedExceptions>> callback = new HibernateCallback<List<LoggedExceptions>>() {
			public List<LoggedExceptions> doInHibernate(Session session) {
				Criteria criteria = session.createCriteria(com.citi.icg.as.core.dao.entities.ext.beans.LoggedExceptions.class);
				criteria.add(Restrictions.in(LoggedExceptionsConstant.PK_EXCEPTION_ID, pkIds));
				List<LoggedExceptions> armList = (List<LoggedExceptions>) template.findByCriteria((DetachedCriteria) criteria);
				return armList;
			}
		};
		return template.execute(callback);
	}

	public Integer executeUpdateException(final String sql) {

		return executeUpdateSQL(sql);
	}

	public void saveOrUpdateExceptions(LoggedExceptions exception) {
		template.saveOrUpdate(exception);
	}

	public <T> T getByIDProperty(final T example) {
		return template.execute(new HibernateCallback<T>() {
			@Override
			public T doInHibernate(Session session) {

				if (example instanceof BaseBusinessEntity) {
					return (T) getById(example.getClass(), (Serializable) ((BaseBusinessEntity) example).getId());
				}
				return null;
			}
		});
	}

	public Integer executeUpdateSQL(final String query) {
		return template.execute(new HibernateCallback<Integer>() {
			public Integer doInHibernate(Session session) {
				SQLQuery sql = session.createSQLQuery(query);
				return sql.executeUpdate();
			}
		});
	}

	@Override
	public Integer getNextSequenceNumber(final String sequenceName) {
		return template.execute(new HibernateCallback<Integer>() {

			@Override
			public Integer doInHibernate(Session session) throws HibernateException, SQLException {
				Criteria criteria = session.createCriteria(com.citi.icg.as.core.dao.entities.ext.beans.SequenceGenerator.class);
				criteria.add(Restrictions.eq(DaoConstants.SEQUENCE_NAME, sequenceName));
				criteria.setLockMode(LockMode.WRITE);
				com.citi.icg.as.core.dao.entities.ext.beans.SequenceGenerator generator = null;
				if (criteria.list() != null && criteria.list().size() > 0)
					generator = (com.citi.icg.as.core.dao.entities.ext.beans.SequenceGenerator) criteria.list().get(0);

				if (generator == null) {
					generator = new com.citi.icg.as.core.dao.entities.ext.beans.SequenceGenerator();
					generator.setSequenceName(sequenceName);
					generator.setLastUpdatedBy(GcasRequestContext.getUserId());
					generator.setNextSequenceNumber(DaoConstants.INITIAL_SEQUENCE_NUMBER);
					session.persist(generator);
				}
				int sequenceNumber = generator.getNextSequenceNumber();
				generator.setNextSequenceNumber(generator.getNextSequenceNumber() + 1);
				session.update(generator);
				return sequenceNumber;
			}
		});
	}

	@Override
	public List<LoggedExceptions> getLoggedExpcetions() {
		HibernateCallback<List<LoggedExceptions>> callback = new HibernateCallback<List<LoggedExceptions>>() {
			public List<LoggedExceptions> doInHibernate(Session session) {
				Criteria criteria = session.createCriteria(LoggedExceptions.class);
				criteria.add(Restrictions.eq(LoggedExceptionsConstant.IS_SENT, "N"));
				criteria.addOrder(Property.forName(LoggedExceptionsConstant.LAST_UPDATED_DATE).asc());
				List<LoggedExceptions> armList = (List<LoggedExceptions>) template.findByCriteria((DetachedCriteria) criteria);
				return armList;
			}
		};
		return template.execute(callback);
	}

	public List<Map<String, Object>> executeSQLToGetListMap(final String query) {
		return template.execute(new HibernateCallback<List<Map<String, Object>>>() {
			public List<Map<String, Object>> doInHibernate(Session session) {
				SQLQuery sql = session.createSQLQuery(query);
				sql.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
				return sql.list();
			}
		});
	}

	public <T extends BaseBusinessEntity> List<T> find(Class<T> returnClassType, String cacheRegion, String orderby) {
		return (List<T>) template.find(cacheRegion, orderby);
	}

	public <T> T merge(T obj) {
		return template.merge(obj);
	}

	public <T> void remove(T obj) {
		template.deleteAll((Collection) obj);
	}

	public <T> List<T> find(final String queryString, final Object... objs) {
		return (List<T>) template.find(queryString, objs);
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> findByCriteria(Class<T> returnClassType, final DetachedCriteria criteria) {
		return (List<T>) template.findByCriteria(criteria);
	}

	// public DetachedCriteria getDetachedCriteria(Class domClass,
	// Map<String, Object> entities, Map<String, Serializable> seMap) {
	// DetachedCriteria criteria = DetachedCriteria.forClass(domClass);
	// for (String str : entities.keySet()) {
	// criteria.add(Restrictions.eq(str, template.getDomainObject(entities
	// .get(str))));
	// }
	// for (String str : seMap.keySet()) {
	// criteria.add(Restrictions.eq(str, seMap.get(str)));
	// }
	// return criteria;
	// }

	public <T> T findUniqueByCriteria(Class<T> returnClassType, DetachedCriteria criteria) {
		List<T> list = findByCriteria(returnClassType, criteria);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public <T> Serializable add(final T obj) {
		return template.save(obj);
	}

	public CollectionMetadata getCollectionMetadata(String roleName) {
		return sessionFactory.getCollectionMetadata(roleName);
	}

	public <T> void persist(T obj) {
		template.persist(obj);
	}

	public void evict(final Object obj) {
		template.evict(obj);
	}

	public void update(final Object... objs) {
		template.update(objs);
	}

}
