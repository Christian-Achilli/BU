package com.citi.icg.as.core.entities.constants;

public class AttributeConstant {
	public static final String ATTRIBUTE_CODE = "attributeCode";
	public static final String DEBUG_STRING = "debugString";
	public static final String PK_ATTRIBUTE_ID = "pkAttributeId";
	public static final String ATTRIBUTE_DESCRIPTION = "attributeDescription";
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String VALUE = "value";
	public static final String CLASS = "class";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
	public static final String ATTRIBUTE_TYPE = "attributeType";
}