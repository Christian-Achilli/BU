package com.citi.icg.as.common.converter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.dozer.DozerBeanMapper;
import org.hibernate.collection.PersistentSet;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class ConverterFactory {

	private static DozerBeanMapper DOZER_MAPPER;

	public static class DozerMapWrapper {

		public <T> T map(Object source, Class<T> target) {

			if (source != null) {
				return getIntDozerMapper().map(source, target);
			}

			return null;

		}

		public Collection mapCol(Collection source, Class targetGenericType) {

			try {

				if (source != null && source.size() > 0) {
					DozerBeanMapper dozer = getIntDozerMapper();

					Collection rtn = null;
					if (source instanceof PersistentSet) {

						rtn = new HashSet();

					} else {

						rtn = source.getClass().newInstance();

					}

					for (Object o : source) {

						rtn.add(dozer.map(o, targetGenericType));

					}

					return rtn;
				}

			} catch (Exception e) {
				throw new RuntimeException(e);
			}

			return null;
		}

	}

	public static DozerMapWrapper getDozerMapper() {
		return new DozerMapWrapper();
	}

	private synchronized static DozerBeanMapper getIntDozerMapper() {
		if (DOZER_MAPPER == null) {

			// DOZER_MAPPER = new DozerBeanMapper();

			List<String> files = new ArrayList<String>();
//			files.add("dozer-custom-maps.xml");
			files.add("dozerBeanMapping.xml");
			DOZER_MAPPER = new DozerBeanMapper(files);
			// DOZER_MAPPER.setMappingFiles(files);

		}
		return DOZER_MAPPER;
	}

	public static Map<Class, Map<Class, EntityConverter>> converterMap = new HashMap<Class, Map<Class, EntityConverter>>();

	private ConverterFactory() {
	}

	static synchronized <S, T> EntityConverter getConverter(Class<S> source, Class<T> target, ConversionSession session) {

		// first look source to target
		Map<Class, EntityConverter> converters = converterMap.get(source);
		if (converters != null) {
			EntityConverter converter = converters.get(target);
			if (converter != null) {
				try {

					return getConverter(converter.getClass(), session);

				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}

		} else {

			// look by target if unmatched
			for (Entry<Class, Map<Class, EntityConverter>> sourceEntry : converterMap.entrySet()) {

				Map<Class, EntityConverter> targetConverters = sourceEntry.getValue();
				EntityConverter converter = targetConverters.get(source);
				if (converter != null && sourceEntry.getKey().equals(target)) {
					try {
						return getConverter(converter.getClass(), session);
					} catch (Exception e) {
						throw new RuntimeException(e);
					}
				}

			}

		}

		return null;

	}

	private static EntityConverter getConverter(Class<?> converter, ConversionSession session) throws InstantiationException, IllegalAccessException {
		EntityConverter newConverter = (EntityConverter) converter.newInstance();
		newConverter.setConversionSession(session);
		return newConverter;
	}

}
