package com.citi.icg.as.util;

import java.util.Date;

public final class DateTimeHelper {
	
	private static int ONE_HOUR = 60 * 60 * 1000;
	private static int ONE_DATE = 24 * ONE_HOUR;
	
	private DateTimeHelper(){};
	
	@SuppressWarnings("deprecation")
	public static int yearsPassedSince(Date date, Date currentDate) {
		Date currentDateTime = currentDate;
		return currentDateTime.getYear() - date.getYear();
	}
	
	public static int datesPassedSince(Date date, Date currentDate) {
		Date currentDateTime = currentDate;
		long passedMilliseconds = currentDateTime.getTime() - date.getTime();
		int passedDates = (int) (passedMilliseconds / ONE_DATE);
		return passedDates;
	}
	
	public static int hoursPassedSince(Date date, Date currentDate) {
		Date currentDateTime = currentDate;
		long passedMilliseconds = currentDateTime.getTime() - date.getTime();
		int passedDates = (int) (passedMilliseconds / ONE_HOUR);
		return passedDates;
	}
}
