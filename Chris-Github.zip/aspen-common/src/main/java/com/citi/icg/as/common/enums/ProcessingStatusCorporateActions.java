package com.citi.icg.as.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Event Status display names.
 */
public enum ProcessingStatusCorporateActions {
	INCR("In Creation"),


	// MDD001 Requirement 96. These are the new enumerated values for ProcessingStatus.
	COMP("Confirmed"), COMU("Preliminary Unconfirmed"),
	// ENTL("Confirmed"),
	INFO("For Information Only"), PREC("Preliminary Confirmed"),
	// PREU("Preliminary Unconfirmed"),
	CLSD("Closed"), CANC("Cancelled");

	private String displayName;

	private ProcessingStatusCorporateActions(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String toString() {
		return this.displayName;
	}

	public static boolean isInCreationStatus(String status) {
		if (status != null) {
			return status.equals(INCR.name());
		}
		return false;
	}

	public static Map<String, String> getValueMap() {
		Map<String, String> valueMap = new LinkedHashMap<String, String>();
		for (ProcessingStatusCorporateActions value : ProcessingStatusCorporateActions.values()) {
			valueMap.put(value.name(), value.getDisplayName());
		}
		return valueMap;
	}
}
