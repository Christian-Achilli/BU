package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.ext.beans.Attribute;
import com.citi.icg.as.core.dao.entities.ext.beans.User;

@MappedSuperclass
@Table(name = "USER_ATTRIBUTE", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseUserAttribute extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 7322747344758082932L;
	
	private int pkUserAttributeId;
	private Attribute attribute;
	private User user;
	private String attributeValue;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public BaseUserAttribute() {
	}

	public BaseUserAttribute(Attribute attribute, User user, Date lastUpdatedDate) {
		this.attribute = attribute;
		this.user = user;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BaseUserAttribute(Attribute attribute, User user, String attributeValue, String lastUpdatedBy, Date lastUpdatedDate) {
		this.attribute = attribute;
		this.user = user;
		this.attributeValue = attributeValue;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_USER_ATTRIBUTE", allocationSize = 1)
	@Column(name = "PK_USER_ATTRIBUTE_ID", unique = true, nullable = false)
	public int getPkUserAttributeId() {
		return this.pkUserAttributeId;
	}

	public void setPkUserAttributeId(int pkUserAttributeId) {
		this.pkUserAttributeId = pkUserAttributeId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_ATTRIBUTE_ID", nullable = false)
	@org.hibernate.annotations.Fetch(org.hibernate.annotations.FetchMode.SELECT)
	public Attribute getAttribute() {
		return this.attribute;
	}

	public void setAttribute(Attribute attribute) {
		this.attribute = attribute;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_USER_ID", nullable = false)
	@org.hibernate.annotations.Fetch(org.hibernate.annotations.FetchMode.SELECT)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Column(name = "ATTRIBUTE_VALUE", length = 200)
	public String getAttributeValue() {
		return this.attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	@Column(name = "LAST_UPDATED_BY", length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
