package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.base.beans.BaseUser;


@Entity
@Table(name="USERS")
//this change is for D954
//@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="hibernate.USER_PROFILE")
public class User extends BaseUser
{

	private static final long serialVersionUID = 3486431095118300539L;

}
