/**
 * 
 */
package com.citi.icg.as.feed.model;

/**
 * Enum for various feed generation status, stored in  ASPEN_FEED_INFO table
 * @author ap72338
 *
 */
public enum FeedGenerationStatus {

	IN_PROGRESS,SUCCESSFUL,ERROR,NOFEED
}
