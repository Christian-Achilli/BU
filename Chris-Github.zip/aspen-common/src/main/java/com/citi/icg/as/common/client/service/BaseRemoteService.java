package com.citi.icg.as.common.client.service;

import com.citi.icg.toolkit.web.client.IcgGwtUIException;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("BaseRemoteService")
public interface BaseRemoteService extends RemoteService {
	void declareException() throws IcgGwtUIException;
}
