package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import javax.xml.bind.annotation.XmlTransient;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class UserAttribute extends BaseBusinessEntity {
	
	private static final long serialVersionUID = -4283767580366108445L;

	private int pkUserAttributeId;
	private Attribute attribute;
	private User user;
	private String attributeValue;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public int getPkUserAttributeId() {
		return pkUserAttributeId;
	}

	public void setPkUserAttributeId(int pkUserAttributeId) {
		this.pkUserAttributeId = pkUserAttributeId;
	}

	public Attribute getAttribute() {
		return attribute;
	}

	public void setAttribute(Attribute attribute) {
		this.attribute = attribute;
	}

	@XmlTransient
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Integer getId() {
		return getPkUserAttributeId();
	}
}
