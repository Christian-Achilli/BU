package com.citi.icg.as.core.dao.entities.ext.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the ALL_DATES database table.
 * 
 */

@Entity
@Table(name="EVENT_MIN_KEY_DATES")
/*@NamedQuery(name="EVENT_MIN_KEY_DATES.findAll", query="SELECT a FROM EVENT_MIN_KEY_DATES a")*/
public class EventMinKeyDates {

		private static final long serialVersionUID = 1L;
		

		@Id
		@Column(name = "PK_ANNOUNCEMENT_ID", unique = true, nullable = false)
		private int pkAnnouncementId;

		@Column(name="MIN_AGENT_DEADLINE")
		private Date agentDeadline;

		@Column(name="MIN_AGENT_DEADLINE_FIELD_TYPE")
		private Integer agentDeadlineFieldType;

		@Column(name="MIN_EFFECTIVE_DATE")
		private Date effectiveDate;

		@Column(name="MIN_EFFECTIVE_DATE_FIELD_TYPE")
		private Integer effectiveDateFieldType;

		@Column(name="MIN_EX_DATE")
		private Date exDate;

		@Column(name="MIN_EX_DATE_FIELD_TYPE")
		private Integer exDateFieldType;

		@Column(name="MIN_INTERNAL_DEADLINE")
		private Date internalDeadline;

		@Column(name="MIN_INTERNAL_DEADLINE_FLD_TYPE")
		private Integer internalDeadlineFieldType;

		@Column(name="MIN_MARKET_DEADLINE")
		private Date marketDeadline;

		@Column(name="MIN_MARKET_DEADLINE_FIELD_TYPE")
		private Integer marketDeadlineFieldType;

		@Column(name="MIN_PAY_DATE")
		private Date payDate;

		@Column(name="MIN_PAY_DATE_FIELD_TYPE")
		private Integer payDateFieldType;

		@Column(name="MIN_RECORD_DATE")
		private Date recordDate;

		@Column(name="MIN_RECORD_DATE_FIELD_TYPE")
		private Integer recordDateFieldType;

		@Column(name="MIN_SUBS_DATE")
		private Date subsDate;

		@Column(name="MIN_SUBS_DATE_FIELD_TYPE")
		private Integer subsDateFieldType;

		public Date getAgentDeadline() {
			return this.agentDeadline;
		}

		public void setAgentDeadline(Date agentDeadline) {
			this.agentDeadline = agentDeadline;
		}

		public Integer getAgentDeadlineFieldType() {
			return this.agentDeadlineFieldType;
		}

		public void setAgentDeadlineFieldType(Integer agentDeadlineFieldType) {
			this.agentDeadlineFieldType = agentDeadlineFieldType;
		}

		public Date getEffectiveDate() {
			return this.effectiveDate;
		}

		public void setEffectiveDate(Date effectiveDate) {
			this.effectiveDate = effectiveDate;
		}

		public Integer getEffectiveDateFieldType() {
			return this.effectiveDateFieldType;
		}

		public void setEffectiveDateFieldType(Integer effectiveDateFieldType) {
			this.effectiveDateFieldType = effectiveDateFieldType;
		}

		public Date getExDate() {
			return this.exDate;
		}

		public void setExDate(Date exDate) {
			this.exDate = exDate;
		}

		public Integer getExDateFieldType() {
			return this.exDateFieldType;
		}

		public void setExDateFieldType(Integer exDateFieldType) {
			this.exDateFieldType = exDateFieldType;
		}

		public int getPkAnnouncementId() {
			return this.pkAnnouncementId;
		}

		public void setPkAnnouncementId(int pkAnnouncementId) {
			this.pkAnnouncementId = pkAnnouncementId;
		}


		public Date getInternalDeadline() {
			return this.internalDeadline;
		}

		public void setInternalDeadline(Date internalDeadline) {
			this.internalDeadline = internalDeadline;
		}

		public Integer getInternalDeadlineFieldType() {
			return this.internalDeadlineFieldType;
		}

		public void setInternalDeadlineFieldType(Integer internalDeadlineFieldType) {
			this.internalDeadlineFieldType = internalDeadlineFieldType;
		}

		public Date getMarketDeadline() {
			return this.marketDeadline;
		}

		public void setMarketDeadline(Date marketDeadline) {
			this.marketDeadline = marketDeadline;
		}

		public Integer getMarketDeadlineFieldType() {
			return this.marketDeadlineFieldType;
		}

		public void setMarketDeadlineFieldType(Integer marketDeadlineFieldType) {
			this.marketDeadlineFieldType = marketDeadlineFieldType;
		}


		public Date getPayDate() {
			return this.payDate;
		}

		public void setPayDate(Date payDate) {
			this.payDate = payDate;
		}

		public Integer getPayDateFieldType() {
			return this.payDateFieldType;
		}

		public void setPayDateFieldType(Integer payDateFieldType) {
			this.payDateFieldType = payDateFieldType;
		}


		public Date getRecordDate() {
			return this.recordDate;
		}

		public void setRecordDate(Date recordDate) {
			this.recordDate = recordDate;
		}

		public Integer getRecordDateFieldType() {
			return this.recordDateFieldType;
		}

		public void setRecordDateFieldType(Integer recordDateFieldType) {
			this.recordDateFieldType = recordDateFieldType;
		}

		public Date getSubsDate() {
			return this.subsDate;
		}

		public void setSubsDate(Date subsDate) {
			this.subsDate = subsDate;
		}

		public Integer getSubsDateFieldType() {
			return this.subsDateFieldType;
		}

		public void setSubsDateFieldType(Integer subsDateFieldType) {
			this.subsDateFieldType = subsDateFieldType;
		}

	
}
