package com.citi.icg.as.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.google.gwt.user.client.rpc.IsSerializable;

@SuppressWarnings("serial")
public class AspenServiceException extends Exception implements IsSerializable {

	protected ErrorType errorLevel;
	// --- Constructor(s) ---
	
	
	public AspenServiceException(Exception message)
	{
		super(message);
	}

	public AspenServiceException(String message)
	{
		super(message);
	}

	public AspenServiceException(String message, Throwable cause)
	{
		super(message, cause);
	}
	public AspenServiceException(String message, Throwable cause, ErrorType errorLevel)
	{
		super(message, cause);
		this.setErrorLevel(errorLevel);
	}

	public AspenServiceException(String message, ErrorType errorType) {
		super(message);
		this.setErrorLevel(errorLevel);
	}

	public static String asString(Throwable throwable)
	{
		if (throwable == null) {
			return null;
		}

		StringWriter buffer = new StringWriter();
		PrintWriter writer = new PrintWriter(buffer);
		throwable.printStackTrace(writer);
		writer.flush();

		return buffer.toString();

	}

	public void setErrorLevel(ErrorType errorLevel) {
		this.errorLevel = errorLevel;
	}

	public ErrorType getErrorLevel() {
		return errorLevel;
	}
}
