package com.citi.icg.as.common.client.util;

import java.math.BigDecimal;

import com.citi.icg.toolkit.web.client.utils.gui.AppStyle;

/**
 * Helper classes for working with string on GWT client code.
 */
public final class StringUtilGwt {
	private static final String NEW_LINE = "\n";
	public static final int MAX_NUMBER = 147483647;
	// CHECKSTYLE:OFF
	public static final String EMPTY = "";
	public static final String SPACE = " ";
	public static final String STR_EMPTY = "Empty";
	public static final String COMMA = ",";
	public static final String DOT = ".";
	public static final String PERCENT_SIGN = "%";
	public static final String STAR_SIGN = "*";
	public static final String ZERO_PIXEL = "0px";
	public static final String ZERO = "0";
	public static final String CRLF = "(\r\n|\r|\n|\n\r)";
	public static final char NO = 'N';
	public static final char YES = 'Y';
	public static final String N = "No";
	public static final String Y = "Yes";
	public static final String COLON = ":";
	public static final String SEMICOLON = ";";
	public static final String SINGLE_QUOTES = "'";
	private static final String ELLIPSIS = "...";
	public static final String BOLD_START_TAG = "<b>";
	public static final String BOLD_END_TAG = "</b>";

	// CHECKSTYLE:ON

	private StringUtilGwt() {

	}

	public static String getAsPercentString(int value) {
		return value + PERCENT_SIGN;
	}

	public static boolean isNotBlank(String value) {

		return value != null && value.trim().length() > 0;
	}

	public static boolean isNotEmpty(String s) {
		return !isEmpty(s);
	}

	public static boolean isEmpty(String value) {
		return value == null || value.length() == 0;
	}

	public static boolean isNullOrEmpty(String value) {
		return (value == null || value.trim().length() == 0);
	}

	public static boolean isInteger(String value) {
		if (value.length() == AppStyle.px10) {
			if (value.charAt(0) > AppStyle.px50) {
				return false;
			} else if (value.charAt(0) == '2' && Integer.parseInt(value.substring(1)) > MAX_NUMBER) {
				return false;
			}
		}
		return true;
	}

	public static boolean isBigDecimal(String input) {
		try {
			new BigDecimal(input);
			return true;
		} catch (NumberFormatException ex) {
			return false;
		}
	}

	public static boolean isNumber(String input) {
		if (input == null || input.length() == 0) {
			return false;
		}

		char c = input.charAt(0);
		if (!Character.isDigit(c) && c != '-' && c != '+') {
			return false;
		}

		for (int i = 1; i < input.length(); i++) {
			if (!Character.isDigit(input.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	public static String[] splitByDelemiter(String valueString, String delemiter) {
		String[] values = valueString.split(delemiter);
		return values;
	}

	public static String changeFirstLetterToUppercase(String value) {
		return value.substring(0, 1).toUpperCase() + value.substring(1);
	}

	public static String trimToEmpty(String str) {
		return str == null ? EMPTY : str.trim();
	}

	public static String trimToNull(String str) {
		String result = trimToEmpty(str);
		return result == null || result.length() == 0 ? null : result;
	}

	public static String abbreviate(String str, int maxWidth) {
		String result = null;
		if (str != null && str.length() > maxWidth) {
			int adjustedMaxWidth = maxWidth - ELLIPSIS.length();
			result = adjustedMaxWidth < 0 ? ELLIPSIS : str.substring(0, adjustedMaxWidth) + ELLIPSIS;
		} else {
			result = str;
		}
		return result;
	}

	public static String stripCRLF(String str) {
		return str == null ? null : str.replaceAll(CRLF, SPACE);
	}

	public static String join(String... strings) {
		return joinWithDelimeter(null, strings);
	}

	public static String joinWithDelimeter(String sep, String... strings) {
		StringBuffer result = new StringBuffer();

		if (strings != null) {
			for (int n = 0; n < strings.length; n++) {
				result.append(strings[n]);
				if (n + 1 < strings.length && sep != null) {
					result.append(sep);
				}
			}
		}

		return result.toString();
	}

	public static boolean equals(String str1, String str2) {
		if (str1 == null && str2 == null) {
			return true;
		} else if (str1 == null || str2 == null) {
			return false;
		} else {
			return str1.equals(str2);
		}
	}

	public static String substringBetween(String str, String tag) {
		return substringBetween(str, tag, tag);
	}

	public static String substringBetween(String str, String open, String close) {
		if (str == null || open == null || close == null) {
			return null;
		}
		int start = str.indexOf(open);
		if (start != -1) {
			int end = str.indexOf(close, start + open.length());
			if (end != -1) {
				return str.substring(start + open.length(), end);
			}
		}
		return null;
	}

	public static String wrap(String str, int wrapLength, String newLineStr, boolean wrapLongWords) {
		if (str == null) {
			return null;
		}
		if (newLineStr == null) {
			newLineStr = NEW_LINE;
		}
		if (wrapLength < 1) {
			wrapLength = 1;
		}
		int inputLineLength = str.length();
		int offset = 0;
		StringBuffer wrappedLine = new StringBuffer(inputLineLength + 32);

		while ((inputLineLength - offset) > wrapLength) {
			if (str.charAt(offset) == ' ') {
				offset++;
				continue;
			}
			int spaceToWrapAt = str.lastIndexOf(' ', wrapLength + offset);

			if (spaceToWrapAt >= offset) {
				// normal case
				wrappedLine.append(str.substring(offset, spaceToWrapAt));
				wrappedLine.append(newLineStr);
				offset = spaceToWrapAt + 1;

			} else {
				// really long word or URL
				if (wrapLongWords) {
					// wrap really long word one line at a time
					wrappedLine.append(str.substring(offset, wrapLength + offset));
					wrappedLine.append(newLineStr);
					offset += wrapLength;
				} else {
					// do not wrap really long word, just extend beyond limit
					spaceToWrapAt = str.indexOf(' ', wrapLength + offset);
					if (spaceToWrapAt >= 0) {
						wrappedLine.append(str.substring(offset, spaceToWrapAt));
						wrappedLine.append(newLineStr);
						offset = spaceToWrapAt + 1;
					} else {
						wrappedLine.append(str.substring(offset));
						offset = inputLineLength;
					}
				}
			}
		}

		// Whatever is left in line is short enough to just pass through
		wrappedLine.append(str.substring(offset));

		return wrappedLine.toString();
	}

}
