package com.citi.icg.as.client.enums;

public enum FieldQualifiersEnum {

	PAID_IN_THE_MARKET("paidInTheMarket", "Paid In The Market"),
	PROCESSING_TYPE("processingType", "Processing Type"),
	TRADED_DATE("tradedDate", "Traded Date"),
	SETTLED_DATE("settledDate", "Settled Date"),
	PAY_DATE("payDate", "Pay Date"),
	INTERNAL_DEADLINE("internalDeadline", "Internal Deadline"),
	LOCKING_DATE("lockingDate", "Locking Date"),
	POSITION_PULL_END_DATE("positionPullEndDate", "Position Pull End Date"),
	POSITION_DEADLINE_DATE("positionDeadLineDate", "Position DeadLine Date/Time"),
	OPTION_STATUS("optionStatus","Option Status"),
	WITHDRAWAL_ALLOWED_FLG("withdrawalAllowedFlag","Withdrawal Allowed Flag");
	
	private String code;
	private String displayLabel;

	private FieldQualifiersEnum(String code, String displayLabel) {
		this.code = code;
		this.displayLabel = displayLabel;
	}

	public String getCode() {
		return this.code;
	}

	public String getDisplayLabel() {
		return this.displayLabel;
	}

}
