package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;


@MappedSuperclass
@Table(name = "PROCESSING_UNIT", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseProcessingUnit extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 8228318579393250074L;
	
	private int pkProcessingUnitId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String unitName;
	private String unitAlternateName;
	private String unitLongName;
	private String groupEmailAddress;
	private String groupTelephoneNumber;

	public BaseProcessingUnit() {
	}

	public BaseProcessingUnit(String unitName, String unitAlternateName, String unitLongName, String lastUpdatedBy, Date lastUpdatedDate, String groupEmailAddress, String groupTelephoneNumber) {
		this.unitName = unitName;
		this.unitAlternateName = unitAlternateName;
		this.unitLongName = unitLongName;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.groupEmailAddress = groupEmailAddress;
		this.groupTelephoneNumber = groupTelephoneNumber;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_PROCESSING_UNIT", allocationSize = 1)
	@Column(name = "PK_PROCESSING_UNIT_ID", unique = true, nullable = false)
	public int getPkProcessingUnitId() {
		return this.pkProcessingUnitId;
	}

	public void setPkProcessingUnitId(int pkProcessingUnitId) {
		this.pkProcessingUnitId = pkProcessingUnitId;
	}

	@Column(name = "LAST_UPDATED_BY", nullable = false, length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Column(name = "UNIT_NAME", length = 50)
	public String getUnitName() {
		return this.unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	@Column(name = "UNIT_ALTERNATE_NAME", length = 255)
	public String getUnitAlternateName() {
		return this.unitAlternateName;
	}

	public void setUnitAlternateName(String unitAlternateName) {
		this.unitAlternateName = unitAlternateName;
	}

	@Column(name = "UNIT_LONG_NAME", length = 255)
	public String getUnitLongName() {
		return this.unitLongName;
	}

	public void setUnitLongName(String unitLongName) {
		this.unitLongName = unitLongName;
	}

	@Column(name = "GROUP_EMAIL_ADDRESS", length = 255)
	public String getGroupEmailAddress() {
		return groupEmailAddress;
	}

	public void setGroupEmailAddress(String groupEmailAddress) {
		this.groupEmailAddress = groupEmailAddress;
	}

	@Column(name = "GROUP_TELEPHONE_NUMBER", length = 255)
	public String getGroupTelephoneNumber() {
		return groupTelephoneNumber;
	}

	public void setGroupTelephoneNumber(String groupTelephoneNumber) {
		this.groupTelephoneNumber = groupTelephoneNumber;
	}

}
