/**
 * 
 */
package com.citi.icg.as.feed.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.citi.icg.as.feed.model.FeedGenerationStatus;

/**
 * @author ap72338
 *
 */

@Entity
@Table(name = "ASPEN_FEED_INFO")
public class FeedInfo {

	private Long runId;
	private FeedFormat feedFormat;
	private Date startTime;
	private Date endTime;
	private Integer fileCounter;
	private FeedGenerationStatus status;

	@Id
	@SequenceGenerator(name = "ASPEN_FEED_SEQ_GEN", sequenceName = "ASPEN_FEED_SEQ")
	@GeneratedValue(generator = "ASPEN_FEED_SEQ_GEN",strategy=GenerationType.SEQUENCE)
	@Column(name = "RUN_ID")
	public Long getRunId() {
		return runId;
	}

	public void setRunId(Long runId) {
		this.runId = runId;
	}

	@Enumerated(EnumType.STRING)
	@Column(name = "FEED_FORMAT")
	public FeedFormat getFeedFormat() {
		return feedFormat;
	}

	public void setFeedFormat(FeedFormat feedFormat) {
		this.feedFormat = feedFormat;
	}

	@Column(name = "START_TIME")
	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	@Column(name = "END_TIME")
	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@Column(name = "FILE_COUNTER")
	public Integer getFileCounter() {
		return fileCounter;
	}

	public void setFileCounter(Integer fileCounter) {
		this.fileCounter = fileCounter;
	}

	@Column(name = "STATUS")
	@Enumerated(EnumType.STRING)
	public FeedGenerationStatus getStatus() {
		return status;
	}

	public void setStatus(FeedGenerationStatus status) {
		this.status = status;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
            return false;
		}
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof FeedInfo)) {
            return false;
        }

        FeedInfo rhs = (FeedInfo) obj;
        return new EqualsBuilder().append(getRunId(), rhs.getRunId()).
            isEquals();
	}
	
	@Override
    public int hashCode() {
        return new HashCodeBuilder(17,31).append(this.getRunId()).hashCode();
    }
	
}
