package com.citi.icg.as.common.enums;

public enum PostPUApprovalParamKeyEnum {
	ANNOUNCEMENT_ID_KEY("ANNOUNCEMENT_ID"),
	ANNOUNCEMENT_VERSION_KEY("ANNOUNCEMENT_VERSION"),
	PU_MAP_KEY("PU_MAP"),
	PU_ID_KEY("PU_ID");
	
	
	private String code;
	
	private PostPUApprovalParamKeyEnum(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}
}
