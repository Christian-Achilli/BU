package com.citi.icg.as.server.service.comparator;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections.comparators.ComparatorChain;

@SuppressWarnings(value = { "serial", "unchecked" })
public class BeanPropertyValuesComparator<T> implements Comparator<T>, Serializable
{
	private final Comparator<T> delegate;
	
	public BeanPropertyValuesComparator(List<String> beanProperties)
	{
		List<Comparator<?>> propertyValueComparators = new ArrayList<Comparator<?>>(beanProperties.size());
		for (String prop : beanProperties)
		{
			propertyValueComparators.add(new NullSafeBeanPropertyComparator(prop));
		}
		delegate = new ComparatorChain(propertyValueComparators);
	}

	public int compare(T arg0, T arg1)
	{
		return delegate.compare(arg0, arg1);
	}

}
