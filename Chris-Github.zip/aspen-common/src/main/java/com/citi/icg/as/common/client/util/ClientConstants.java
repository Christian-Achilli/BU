package com.citi.icg.as.common.client.util;

import com.google.gwt.core.client.GWT;

/**
 * Supplies the constant values for the application.
 */
public final class ClientConstants {
	// CHECKSTYLE:OFF
	public static final String COMMA = ",";
	public static final String EMPTY = "";
	public static final String UNERSCORE = "_";
	// same as below but kept for backward compatibility
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String E = "E";
	// Same as above but gives a better perspective
	public static final String CHANGED = "Y";
	public static final String UNCHANGED = "N";
	public static final String ERROR = "E";
	public static final String OK_BUTTON_TITLE = "OK";
	public static final String CANCEL_BUTTON_TITLE = "Cancel";
	public static final String SAVE = "Save";
	public static final String CUSTOME_READ_ONLY_ATTRIBUTE = "customReadOnly";
	public static final String HTML_SPACE = "&nbsp;";
	public static final String SPACE_CHAR = " ";
	public static final char SPACE_CHARACTER = ' ';
	public static final String COLON_CHAR = ":";
	public static final String SEMICOLON = ";";
	public static final String NEWLINE = "\n";
	public static final String EMPTY_STRING = "";
	public static final String NOT_SELECT = "NOT_SELECT";
	public static final String STR_PERCENTAGE = "%";
	public static final String DOT_CHAR = ".";
	public static final String ZERO_CHAR = "0";
	public static final String FIELD_STATE = "FIELD_STATE";
	public static final String SORT_STATE = "SORT_STATE";
	public static final String DATE_TIME_COLUMNS = "DATE_TIME_COLUMNS";
	public static final String PARAM_DATE_TIME_LOCAL_FIELDS = "pDateTimeLocalFields";
	public static final String PARAM_TIMEZONE_OFFSET = "TIME_ZONE_OFFSET";
	public static final String USER_REGION = "USER_REGION";
	public static final String GLOBAL_PU = "GLOBAL_PU";
	public static final String STEP_CAIRO = "CAIRO";
	public static final String STEP_RDS = "RDS";
	public static final String MESSAGE_TYPE_564 = "I564";
	public static final String MESSAGE_TYPE_568 = "I568";
	public static final String SECURITY_NAME = "Security Name";
	public static final String POSITION_TYPE_LONG = "Long";
	public static final String POSITION_TYPE_SHORT = "Short";
	public static final String POSITION_TYPE_BOTH = "Both";
	public static final String POSITION_TYPE_UNKNOWN = "UNKNOWN";
	public static final String SEPARATOR = "-";
	public static final String MEDIA_LOCATION = GWT.getHostPageBaseURL() + "images";
	public static final String MEDIA_LOCATION_TREEGRID = GWT.getHostPageBaseURL() + "images" + "/TreeGrid/";
	public static final String FILE_SLASH = "/";
	public static final String PROPERTY_SOURCE = "src";
	public static final String NOTES_OPTIONAL = "Notes(Optional)";
	public static final String COL = "col";
	public static final String COL1 = "col1";
	public static final String COL2 = "col2";
	public static final String MAIN = "main";
	public static final String MSG_UNSAVED_CHANGES = "<b> *Local changes will not be reflected until the event is saved. <b>";
	public static final String PLUS = "+";
	public static final String MINUS = "-";
	public static final String LONG = "Long";
	public static final String SHORT = "Short";
	public static final String HOLDING_EXT_TRADE_REF = "External Trade Reference";
	public static final String FIELD_LAST_UPDATED_DATE = "lastUpdatedDate";

	public static final String LEGAL_ENTITY_UNKNOWN = "UNKNOWN";
	// Rally id 1368814467
	public static final String VIEW_SWIFT_MESSAGES = "viewSwiftMessages";
	public static final String VIEW_ERROR_RECORD = "viewErrorRecord";
	public static final String DOWNLOAD_PDF_REPORT = "DownloadPDFServlet";

	public static final String DIV_HELD = "Div Held %";
	public static final String DIV_PAID = "Div Paid %";
	public static final String MAN_ADJ = "Man Adj";
	public static final String POSITIONS = "Positions";
	public static final String TOTAL_POS = "Total Pos";
	public static final String SETTLED_QUANTITY = "Settled Quantity";
	public static final String NUMBER_FORMAT = "#,##0.###";

	public static final String SINGLE_QUOTES = "'";

	public static final String M_TEXT = "(ML)";
	public static final String STATUS_TEXT = "Status:";

	public static final String RESULTANT_SECURITY_UNKNOWN = "UNKNOWN";
	public static final String SECURITY_CANNOT_RESOLVE_DISPLAY = "TBC";
	public static final String HTML_NEW_LINE_BR = "<br/>";
	public static final String EVENT = "Event";
	public static final String CANC = "CANC";
	public static final String INTV = "INTV";
	public static final String EXCLUDED = "EXCLUDED";
	public static final String WITHDRAWN = "WITHDRAWN";
	public static final String WITHDRAWN_DISPLAY = "Withdrawn";
	public static final String CANCELLED = "Cancelled";
	public static final String INACTIVE = "Inactive";
	public static final String OTHER_STATUSES = "OTHER_STATUSES";
	public static final String OTHER_STATUSES_DISPLAY = "otherStatuses";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
	public static final String LAST_EVENT_UPDATE_TIME = "lastEventUpdateTime";
	public static final String VALUE = "value";
	public static final String AT = "at";
	public static final String SMARTGWT_PROPERTY_HIDDEN = "hidden";

	public static final String BLACK_COLOR = "Black";

	public static final int NUMBER_0 = 0;
	public static final int NUMBER_1 = 1;
	public static final int NUMBER_2 = 2;
	public static final int NUMBER_3 = 3;
	public static final int NUMBER_4 = 4;
	public static final int NUMBER_5 = 5;
	public static final int NUMBER_6 = 6;
	public static final int NUMBER_7 = 7;
	public static final int NUMBER_8 = 8;
	public static final int NUMBER_9 = 9;

	public static final String ZERO_PIXEL = "0px";

	public static final char DEFAULT_IS_MANUAL_N = 'N';

	public static final String UNKNOWN_HOLDING_TYPE = "UNKNOWN";

	public static final String EXCEPTION_STALE_EVENT = "Event is modified by another user, please check the latest status.";
	public static final String ACCOUNT_PARENT_DELETED = "Parent Account is deleted.";
	public static final String ACCOUNT_PARENT_DELETED_STYLE = "deletedAccountParent";

	private ClientConstants() {

	}

	public static final class APPLICATION_IMAGE_CONSTANTS {
		public static final String DEFAULT_INDICATOR = "/green-ball-default-indicator.png";
		public static final String NON_DEFAULT_INDICATOR = "/grey-ball-default-indicator.png";
		public static final String ADD_KEY_ENTITIES = "/add-key-entites.png";
		public static final String OPTION_INCLUDED = "/option-included.png";
		public static final String OPTION_EXCLUDED = "/option-excluded.png";
		public static final String ADD = "/add.png";
		public static final String REMOVE = "/remove.png";
	}

	public static final class APPLICATION_TOOLTIP_CONSTANTS {
		public static final String ADD_KEY_ENTITY_TOOLTIP = "Dates/Rates/Prices/Other Terms";
		public static final String ADD_ADHOC_DATES = "Add AdHoc Dates";
		public static final String ADD_PAYOUT_TOOLTIP = "Add Payout";
		public static final String REMOVE_PAYOUT_TOOLTIP = "Remove Payout";
		public static final String OPTION_INCLUDED_TOOLTIP = "Included";
		public static final String OPTION_EXCLUDED_TOOLTIP = "Excluded";
	}

	public static final class HTML_CONSTANTS {
		public static final String BOLD_START = "<B>";
		public static final String BOLD_END = "</B>";
		public static final String FONT_RED_START = "<FONT COLOR=RED>";
		public static final String FONT_RED_END = "</FONT>";
		public static final String FONT_BLUE_START = "<FONT COLOR=BLUE>";
		public static final String FONT_BLUE_END = "</FONT>";
		public static final String FONT_ORANGE_START = "<FONT COLOR=ORANGE>";
		public static final String FONT_ORANGE_END = "</FONT>";
		public static final String FONT_WHITE_START = "<FONT COLOR=WHITE>";
		public static final String FONT_WHITE_END = "</FONT>";
	}

	public static final class AUDIT_CONSTANTS {
		public static final String EVENT_VERSION = "eventVersion";
		public static final String PUED_VERSION = "puedVersion";
		public static final String PK_HOLDING_ID = "pkHoldingId";
		public static final String FK_ANNOUNCEMENT_ID = "fkAnnouncementId";
		public static final String IS_EXCLUDED = "isExcluded";
		public static final String REFERENCE = "reference";
		public static final String RECORD_TYPE = "recordType";
		public static final String POSITION_TYPE_NAME = "positionTypeName";
		public static final String TRADE_DATE = "tradeDate";
		public static final String CGM_DEPOSIT_DATE = "cgmDepositDate";
		public static final String SETTLEMENT_DATE = "settlementDate";
		public static final String BOX_LOCATION = "boxLocation";
		public static final String LEGAL_ENTITY_NAME = "legalEntityName";
		public static final String BUSINESS_UNIT = "businessUnit";
		public static final String UNIT_NAME = "unitName";
		public static final String ACCOUNT_TYPE = "accountType";
		public static final String REGION_CODE = "regionCode";
		public static final String ACCOUNT_NAME = "accountName";
		public static final String NARRATIVE = "narrative";
		public static final String SETTLED_QUANTITY = "settledQuantity";
		public static final String COMP_CLAIM_TYPE = "compClaimType";
		public static final String ON_OFF_EX_IND = "exchangeInd";

		public static final String DIV_HELD = "dividendHeld";
		public static final String DIV_PAID = "dividendPaid";
		public static final String MAN_ADJ = "manualAdjustment";
		public static final String POSITIONS = "holdingQuantity";
		public static final String TOTAL_POS = "adjustedHoldingQuantity";

	}

	public static enum OptionStatus {
		// care statuses
		CANC(ClientConstants.CANC, ClientConstants.CANCELLED), INTV(ClientConstants.INTV, ClientConstants.INACTIVE), WITHDRAWN(ClientConstants.WITHDRAWN, ClientConstants.WITHDRAWN_DISPLAY),

		// other not care statuses
		OTHER_STATUSES(ClientConstants.OTHER_STATUSES, ClientConstants.OTHER_STATUSES_DISPLAY);

		private String code;
		private String displayName;

		private OptionStatus(String code, String displayName) {
			this.code = code;
			this.displayName = displayName;
		}

		public String getCode() {
			return code;
		}

		public String getDisplayName() {
			return this.displayName;
		}

		/**
		 * If input argument code doesn't match one of listed elements codes, return OTHER_STATUSES always.
		 * 
		 * @param code
		 * @return
		 */
		public static OptionStatus getElementByCode(String code) {
			for (OptionStatus element : OptionStatus.values()) {
				if (element.code.equals(code)) {
					return element;
				}
			}
			return OTHER_STATUSES;
		}
	}

	// CHECKSTYLE:ON
	public static final class SECURITY_IND {
		private SECURITY_IND() {
		}

		public static final char SINGLE = 'S';
		public static final char UNKNOWN = 'U';
		public static final char MULTIPLE = 'M';
	}

}