package com.citi.icg.as.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citi.icg.as.core.dao.entities.ext.beans.CurrencyCode;

/**
 * This is an implementation for all the database operations for Currency
 * Calculation exposed to other components directly (Without Hessian web service
 * calls)
 *
 * @author ib13524
 *
 */

@Repository("currencyLookupDao")
public class CurrencyLookupDaoImpl implements CurrencyLookupDao {
	public static final String UNCHECKED = "unchecked";
	private static final Log log = LogFactory.getLog(CurrencyLookupDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Retrieves Currency index for a given currency code
	 * 
	 * @return code index
	 */

	@Override
	@Transactional(readOnly = true)
	public String getCodeIndex(String code) {
		final Session session = sessionFactory.getCurrentSession();
		org.hibernate.Query query = session.getNamedQuery("currencyIndexQuery").setString("Code", code);
		CurrencyCode currency = (CurrencyCode) query.uniqueResult();
		if (currency == null) {
			log.info("CurrencyCode is null");
		}
		return null != currency ? currency.getCurrencyIndex() : null;
	}

}
