package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class Privilege extends BaseBusinessEntity {
	
	private static final long serialVersionUID = -8660383924930095398L;

	private int pkPrivilegeId;
	private String privilegeName;
	private String resourceType;
	private String privilegeDescription;
	private Character actionType;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public int getPkPrivilegeId() {
		return pkPrivilegeId;
	}

	public void setPkPrivilegeId(int pkPrivilegeId) {
		this.pkPrivilegeId = pkPrivilegeId;
	}

	public String getPrivilegeName() {
		return privilegeName;
	}

	public void setPrivilegeName(String privilegeName) {
		this.privilegeName = privilegeName;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getPrivilegeDescription() {
		return privilegeDescription;
	}

	public void setPrivilegeDescription(String privilegeDescription) {
		this.privilegeDescription = privilegeDescription;
	}

	public Character getActionType() {
		return actionType;
	}

	public void setActionType(Character actionType) {
		this.actionType = actionType;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Integer getId() {
		return getPkPrivilegeId();
	}

}
