package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;
import java.util.Set;

import javax.xml.bind.annotation.XmlTransient;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class UserProcessingUnit extends BaseBusinessEntity {

	private static final long serialVersionUID = 3487506847139627279L;

	private int pkBaseUserProcessingUnitId;
	private ProcessingUnit processingUnit;
	private String isDefault;
	private User user;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private Set<UserPURegionMatrix> userPURegionMatrixSet;

	public int getPkBaseUserProcessingUnitId() {
		return this.pkBaseUserProcessingUnitId;
	}

	public void setPkBaseUserProcessingUnitId(int pkBaseUserProcessingUnitId) {
		this.pkBaseUserProcessingUnitId = pkBaseUserProcessingUnitId;
	}

	public ProcessingUnit getProcessingUnit() {
		return processingUnit;
	}

	public void setProcessingUnit(ProcessingUnit processingUnit) {
		this.processingUnit = processingUnit;
	}

	@XmlTransient
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	/**
	 * @return the processingUnitType
	 */

	public String getIsDefault() {
		return isDefault;
	}

	/**
	 * @param isDefault
	 *            the isDefault to set
	 */
	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	@Override
	public Integer getId() {
		return getPkBaseUserProcessingUnitId();
	}

	public Set<UserPURegionMatrix> getUserPURegionMatrixSet() {
		return userPURegionMatrixSet;
	}

	public void setUserPURegionMatrixSet(Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.userPURegionMatrixSet = userPURegionMatrixSet;
	}
}
