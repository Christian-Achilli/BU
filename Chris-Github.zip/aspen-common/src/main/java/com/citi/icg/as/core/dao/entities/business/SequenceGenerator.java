package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class SequenceGenerator extends BaseBusinessEntity {
	

    private int pkSequenceId;
    private String lastUpdatedBy;
    private Date lastUpdatedDate;
    private String sequenceName;
    private int nextSequenceNumber;
    
    
	
	public int getPkSequenceId() {
		return pkSequenceId;
	}






	public void setPkSequenceId(int pkSequenceId) {
		this.pkSequenceId = pkSequenceId;
	}






	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}






	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}






	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}






	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}






	public String getSequenceName() {
		return sequenceName;
	}






	public void setSequenceName(String sequenceName) {
		this.sequenceName = sequenceName;
	}






	public int getNextSequenceNumber() {
		return nextSequenceNumber;
	}






	public void setNextSequenceNumber(int nextSequenceNumber) {
		this.nextSequenceNumber = nextSequenceNumber;
	}






	@Override
	public Integer getId()
	{
		return  getPkSequenceId();
	}

}
