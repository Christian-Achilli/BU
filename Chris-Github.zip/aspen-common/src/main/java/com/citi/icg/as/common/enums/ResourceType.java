package com.citi.icg.as.common.enums;

import java.util.EnumSet;

/**
 * 
 *
 */
public enum ResourceType {
	// CHECKSTYLE:OFF
	Announcement("Announcement"), Holding("Holding"), AccountParent("AccountParent"), Account("Account"), AccountContact("AccountContact"), ContactDetail("ContactDetail"), User("User"), ResourceLock(
			"User"), ClusterMaster("User"), ProcessingUnit("BPU");
	// CHECKSTYLE:ON

	// Resource group should match ResourceType in the PRIVILEGE table.
	private String resourceGroup;

	ResourceType(String resourceGroup) {
		this.resourceGroup = resourceGroup;
	}

	public static EnumSet<ResourceType> getNonAdminResources() {
		return EnumSet.of(Announcement, Holding);
	}

	public static EnumSet<ResourceType> getAdminResources() {
		return EnumSet.of(User);
	}

	public String getResourceGroup() {
		return resourceGroup;
	}
}
