package com.citi.icg.as.server.util;

import java.math.BigDecimal;

public final class BigDecimalUtil {

	public static int compareTo(BigDecimal source, BigDecimal dest) {
		if(source == null && dest == null) {
			return 0;
		}
		else if((source == null && dest != null ) || (source != null && dest == null ))
			return -1;
		else {
			return source.compareTo(dest);
		}
	}
}
