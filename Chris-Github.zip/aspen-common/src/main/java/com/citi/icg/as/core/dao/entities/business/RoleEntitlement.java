package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class RoleEntitlement extends BaseBusinessEntity {
	
	private static final long serialVersionUID = -959981779327318953L;

	private Integer pkEntitlementId;
	private Role role;
	private Privilege privilege;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public Integer getPkEntitlementId() {
		return pkEntitlementId;
	}

	public void setPkEntitlementId(Integer pkEntitlementId) {
		this.pkEntitlementId = pkEntitlementId;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Privilege getPrivilege() {
		return privilege;
	}

	public void setPrivilege(Privilege privilege) {
		this.privilege = privilege;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public Integer getId() {
		return getPkEntitlementId();
	}
}
