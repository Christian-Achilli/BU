package com.citi.icg.as.core.entities.constants;

public class SourceSystemConstant {
	public static final String SOURCE_CODE = "sourceCode";
	public static final String DEBUG_STRING = "debugString";
	public static final String SOURCE_NAME = "sourceName";
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String VALUE = "value";
	public static final String CLASS = "class";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
	public static final String PK_SOURCE_ID = "pkSourceId";
}