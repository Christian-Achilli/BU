package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

import com.citi.icg.as.core.dao.entities.ext.beans.UserAttribute;
import com.citi.icg.as.core.dao.entities.ext.beans.UserPURegionMatrix;
import com.citi.icg.as.core.dao.entities.ext.beans.UserProcessingUnit;
import com.citi.icg.as.core.dao.entities.ext.beans.UserRegion;
import com.citi.icg.as.core.dao.entities.ext.beans.UserRole;

@MappedSuperclass
@Table(name = "USERS", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseUser extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 5660564228314190582L;

	private String userId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String userNameFirst;
	private String userNameLast;
	private String emailAddress;
	private char systemUser;
	private String soeId;
	private char activeInd;
	private Date dateOfDeletion;
	private Set<UserRole> userRoles = new HashSet<UserRole>(0);
	private Set<UserAttribute> userAttributes = new HashSet<UserAttribute>(0);
	private Set<UserProcessingUnit> userProcessingUnit = new HashSet<UserProcessingUnit>(0);
	private Set<UserRegion> userRegions = new HashSet<UserRegion>(0);
	private Set<UserPURegionMatrix> userPURegionMatrixSet = new HashSet<UserPURegionMatrix>(0);

	public BaseUser() {
	}

	public BaseUser(String userId, String lastUpdatedBy, Date lastUpdatedDate, char systemUser, char activeInd) {
		this.userId = userId;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.systemUser = systemUser;
		this.activeInd = activeInd;
	}

	public BaseUser(String userId, String lastUpdatedBy, Date lastUpdatedDate, String userNameFirst, String userNameLast, String emailAddress, char systemUser, String soeId, char activeInd,
			Set<UserRole> userRoles, Set<UserAttribute> userAttributes, Set<UserProcessingUnit> userProcessingUnit, Set<UserRegion> userRegions, Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.userId = userId;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.userNameFirst = userNameFirst;
		this.userNameLast = userNameLast;
		this.emailAddress = emailAddress;
		this.systemUser = systemUser;
		this.soeId = soeId;
		this.activeInd = activeInd;
		this.userRoles = userRoles;
		this.userAttributes = userAttributes;
		this.userProcessingUnit = userProcessingUnit;
		this.userRegions = userRegions;
		this.userPURegionMatrixSet = userPURegionMatrixSet;
	}

	@Id
	@Column(name = "USER_ID", unique = true, nullable = false, length = 20)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name = "LAST_UPDATED_BY", nullable = false, length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Column(name = "USER_NAME_FIRST", length = 50)
	public String getUserNameFirst() {
		return this.userNameFirst;
	}

	public void setUserNameFirst(String userNameFirst) {
		this.userNameFirst = userNameFirst;
	}

	@Column(name = "USER_NAME_LAST", length = 50)
	public String getUserNameLast() {
		return this.userNameLast;
	}

	public void setUserNameLast(String userNameLast) {
		this.userNameLast = userNameLast;
	}

	@Column(name = "EMAIL_ADDRESS", length = 100)
	public String getEmailAddress() {
		return this.emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Column(name = "SYSTEM_USER", nullable = false, length = 1)
	public char getSystemUser() {
		return this.systemUser;
	}

	public void setSystemUser(char systemUser) {
		this.systemUser = systemUser;
	}

	@Column(name = "SOE_ID", length = 7)
	public String getSoeId() {
		return this.soeId;
	}

	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}

	@Column(name = "ACTIVE_IND", nullable = false, length = 1)
	public char getActiveInd() {
		return this.activeInd;
	}

	public void setActiveInd(char activeInd) {
		this.activeInd = activeInd;
	}

	@Column(name = "DATE_OF_DELETION", length = 23)
	public Date getDateOfDeletion(){
		return this.dateOfDeletion;
	}
	
	public void setDateOfDeletion(Date dateOfDeletion){
		this.dateOfDeletion = dateOfDeletion;
	}
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "user")
	@Cascade({ org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN })
	public Set<UserRole> getUserRoles() {
		return this.userRoles;
	}

	public void setUserRoles(Set<UserRole> userRoles) {
		this.userRoles = userRoles;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "user")
	@Cascade({ org.hibernate.annotations.CascadeType.ALL, org.hibernate.annotations.CascadeType.DELETE_ORPHAN })
	public Set<UserAttribute> getUserAttributes() {
		return this.userAttributes;
	}

	public void setUserAttributes(Set<UserAttribute> userAttributes) {
		this.userAttributes = userAttributes;
	}

	@OneToMany(/* cascade = CascadeType.ALL, */fetch = FetchType.LAZY, mappedBy = "user")
	@Cascade({ org.hibernate.annotations.CascadeType.DELETE })
	public Set<UserProcessingUnit> getUserProcessingUnit() {
		return userProcessingUnit;
	}

	public void setUserProcessingUnit(Set<UserProcessingUnit> userProcessingUnit) {
		this.userProcessingUnit = userProcessingUnit;
	}

	@OneToMany(/* cascade = CascadeType.ALL, */fetch = FetchType.LAZY, mappedBy = "user")
	@Cascade({ org.hibernate.annotations.CascadeType.DELETE })
	public Set<UserRegion> getUserRegions() {
		return userRegions;
	}

	public void setUserRegions(Set<UserRegion> userRegions) {
		this.userRegions = userRegions;
	}

	@OneToMany(/* cascade = CascadeType.ALL, */fetch = FetchType.LAZY, mappedBy = "user")
	// @Cascade( { org.hibernate.annotations.CascadeType.ALL,
	// org.hibernate.annotations.CascadeType.DELETE_ORPHAN })
	@Cascade({ org.hibernate.annotations.CascadeType.DELETE })
	public Set<UserPURegionMatrix> getUserPURegionMatrixSet() {
		return userPURegionMatrixSet;
	}

	public void setUserPURegionMatrixSet(Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.userPURegionMatrixSet = userPURegionMatrixSet;
	}

}