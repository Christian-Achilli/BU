package com.citi.icg.as.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.basic.DateConverter;

/**
 * XML utility class for converting XML structure to entity bean
 * @author as97904
 *
 */
public class XMLUtils {

	public static final String DATE_FORMAT_YYYY_MM_DD_WITH_DASH = "yyyy-MM-dd";
	private static XStream xstream = new XStream();
	private static final Log LOG = LogFactory.getLog(XMLUtils.class);
	private static DateConverter dateConverer;
	/**
	 * Private constructor to restrict creating new instances of this class.
	 */
	
	static {
		registerDateConverter(null);
	}
	private XMLUtils() {
	}

	/**
	 * This method will be used to parse xml file and will return java bean object
	 * 
	 * @param fileName
	 * @param classz
	 *            - class from which annotations can be read
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T loadObjectsFromXML(String fileName, Class classz) {
		InputStream inputStream = null;
		Object object = null;
		try {
			inputStream = XMLUtils.class.getClassLoader().getResourceAsStream(fileName);
			if (inputStream == null) {
				LOG.warn("Test data file not found: " + fileName);
			} else {
				byte[] data = new byte[inputStream.available()];
				inputStream.read(data);
				xstream.processAnnotations(classz);
				xstream.autodetectAnnotations(true);
				
				object = xstream.fromXML(new String(data, "UTF-8"));
			}
		} catch (IOException e) {
			LOG.warn("loadObjectsFromXML failed for file" + fileName + e.getCause());
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException exception) {
					LOG.warn("Error while closing stram in loadObjectsFromXML file" + exception.getCause());
				}
			}
		}
		return (T) object;
	}
	
	public static void registerDateConverter(List<String> accFormats) {
		String[] formatArr={DATE_FORMAT_YYYY_MM_DD_WITH_DASH};
		if(CollectionUtils.isNotEmpty(accFormats) )
			ArrayUtils.addAll(formatArr, accFormats.toArray()); 
		
				
		dateConverer = new DateConverter(DATE_FORMAT_YYYY_MM_DD_WITH_DASH, formatArr);
		xstream.registerConverter(dateConverer);
	}
	
}
