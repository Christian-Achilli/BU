package com.citi.icg.as.common.enums;

/**
 * List of possible actions on an Event.
 */
public enum EventActionType {
	// CHECKSTYLE:OFF
	CREATENOTIFICATION("CreateNotification", "[SKIN]/actions/add.png"), CREATENOTIFICATION_DISABLED("CreateNotification", "[SKIN]/actions/add.png"), CHECKOUT("Checkout",
			"[SKIN]/actions/Lock-Lock-icon.png"), CHECKOUT_DISABLED("Checkout", "[SKIN]/actions/Lock-Lock-icon.png"), SAVE("Save", "[SKIN]/actions/save.png"), REVERT("Revert",
			"[SKIN]/actions/undo.png"), SUBMITFORAPPROVAL("Submit", "[SKIN]/actions/add.png"), SUBMITFORAPPROVAL_DISABLED("Submit", "[SKIN]/actions/add.png"), REASSIGN("ReAssignLock",
			"[SKIN]/actions/forward.png"), APPROVE("Approve", "[SKIN]/actions/approve.png"), REJECT("Reject", "[SKIN]/actions/remove.png"), SAVEPU("Save", "[SKIN]/actions/save.png"), SAVEPU_DISABLED(
			"Save", "[SKIN]/actions/save.png"), REVERTALLPU("Revert", "[SKIN]/actions/undo.png"), REVERTALLPU_DISABLED("Revert", "[SKIN]/actions/undo.png"), PRINTPREVIEW("PrintPreview", ""), REFERENCEDATA_CHECKOUT(
			"Checkout", "[SKIN]/actions/Lock-Lock-icon.png"), REFERENCEDATA_UNDOCHECKOUT("UndoCheckout", "[SKIN]/actions/Lock-Unlock-icon.png"), REFERENCEDATA_SAVE("Save", "[SKIN]/actions/save.png"), REFERENCEDATA_REVERT(
			"Revert", "[SKIN]/actions/undo.png"), REFERENCEDATA_SUBMIT("Submit", "[SKIN]/actions/add.png"), REFERENCEDATA_APPROVE("Approve", "[SKIN]/actions/approve.png"), REFERENCEDATA_REJECT(
			"Reject", "[SKIN]/actions/remove.png"), REFERENCEDATA_REASSIGN("ReAssignLock", "[SKIN]/actions/forward.png");
	// CHECKSTYLE:ON

	private String displayName;
	private String icon;

	private EventActionType(String displayName, String icon) {
		this.displayName = displayName;
		this.icon = icon;
	}

	public static EventActionType getActionType(String strActionType) {
		for (EventActionType actionType : EventActionType.values()) {
			if (actionType.name().equalsIgnoreCase(strActionType)) {
				return actionType;
			}
		}
		return null;
	}

	public String getIcon() {
		return icon;
	}

	public String toString() {
		return this.displayName;
	}
}
