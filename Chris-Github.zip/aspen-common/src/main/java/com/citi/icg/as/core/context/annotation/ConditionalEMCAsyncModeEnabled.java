/**
 * 
 */
package com.citi.icg.as.core.context.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Conditional;

import com.citi.icg.as.common.constants.CommonConstants;

/**
 * @author ap72338
 *         <p>
 *         The annotation that can be used in components to enable/disable the
 *         ASYNC mode for EMC, i.e when announcement while processing EMC events calls WC in async mode or not. 
 *         This checks the property {@link CommonConstants#EMC_ASYNC_MODE_ENABLED_PROPERTY} system property *         
 *         </p>
 */

@Target({ ElementType.TYPE, ElementType.METHOD })
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Conditional(OnEMCAsyncModeEnabledCondition.class)
public @interface ConditionalEMCAsyncModeEnabled {

}
