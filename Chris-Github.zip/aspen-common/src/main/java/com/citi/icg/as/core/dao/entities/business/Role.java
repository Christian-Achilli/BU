package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class Role extends BaseBusinessEntity {
	
	private static final long serialVersionUID = 1098697076396431725L;

	private int pkRoleId;
	private String roleName;
	private String roleDescription;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private Set<RoleEntitlement> roleEntitlements = new HashSet<RoleEntitlement>(0);

	public int getPkRoleId() {
		return pkRoleId;
	}

	public void setPkRoleId(int pkRoleId) {
		this.pkRoleId = pkRoleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@XmlElement(name = "roleEntitlement", type = RoleEntitlement.class)
	@XmlElementWrapper(name = "roleEntitlements")
	public Set<RoleEntitlement> getRoleEntitlements() {
		return roleEntitlements;
	}

	public void setRoleEntitlements(Set<RoleEntitlement> roleEntitlements) {
		this.roleEntitlements = roleEntitlements;
	}

	public RoleEntitlement addRoleEntitlement(Privilege privilege) {
		return addRoleEntitlement(privilege, null, null);
	}

	public RoleEntitlement addRoleEntitlement(Privilege privilege, String lastUpdatedBy, Date lastUpdatedDate) {
		if (privilege == null) {
			return null;
		}
		RoleEntitlement roleEntitlement = new RoleEntitlement();
		roleEntitlement.setPrivilege(privilege);
		lastUpdatedBy = (lastUpdatedBy == null ? "SYSTEM" : lastUpdatedBy);
		roleEntitlement.setLastUpdatedBy(lastUpdatedBy);
		lastUpdatedDate = (lastUpdatedDate == null ? new Date() : lastUpdatedDate);
		roleEntitlement.setLastUpdatedDate(lastUpdatedDate);
		roleEntitlement.setRole(this);
		this.getRoleEntitlements().add(roleEntitlement);
		return roleEntitlement;
	}

	@Override
	public Integer getId() {
		return getPkRoleId();
	}

}
