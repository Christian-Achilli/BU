package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

import com.citi.icg.as.core.dao.entities.ext.beans.ProcessingUnit;
import com.citi.icg.as.core.dao.entities.ext.beans.User;
import com.citi.icg.as.core.dao.entities.ext.beans.UserPURegionMatrix;

@MappedSuperclass
@Table(name = "USER_PROCESSING_UNIT", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseUserProcessingUnit extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = -8808010074854435573L;

	private int pkBaseUserProcessingUnitId;
	private ProcessingUnit processingUnit;
	private String isDefault;
	private User user;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private Set<UserPURegionMatrix> userPURegionMatrixSet;

	public BaseUserProcessingUnit() {
	}

	public BaseUserProcessingUnit(ProcessingUnit processingUnit, User user, String lastUpdatedBy, Date lastUpdatedDate, String isDefault) {
		this.processingUnit = processingUnit;
		this.user = user;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.isDefault = isDefault;
	}

	public BaseUserProcessingUnit(ProcessingUnit processingUnit, String isDefault, User user, String lastUpdatedBy, Date lastUpdatedDate, Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.processingUnit = processingUnit;
		this.isDefault = isDefault;
		this.user = user;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		// this.userPURegionMatrixSet = userPURegionMatrixSet;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_USER_PROCESSING_UNIT", allocationSize = 1)
	@Column(name = "PK_USER_PROCESSING_UNIT_ID", unique = true, nullable = false)
	public int getPkBaseUserProcessingUnitId() {
		return this.pkBaseUserProcessingUnitId;
	}

	public void setPkBaseUserProcessingUnitId(int pkBaseUserProcessingUnitId) {
		this.pkBaseUserProcessingUnitId = pkBaseUserProcessingUnitId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_PROCESSING_UNIT_ID", nullable = false)
	public ProcessingUnit getProcessingUnit() {
		return processingUnit;
	}

	public void setProcessingUnit(ProcessingUnit processingUnit) {
		this.processingUnit = processingUnit;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_USER_ID", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Column(name = "LAST_UPDATED_BY", length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	/**
	 * @return the processingUnitType
	 */
	@Column(name = "IS_DEFAULT")
	public String getIsDefault() {
		return isDefault;
	}

	/**
	 * @param isDefault
	 *            the isDefault to set
	 */
	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	// bi-directional many-to-one association to UserPURegionMatrix
	@OneToMany(/* cascade = CascadeType.ALL, */fetch = FetchType.EAGER, mappedBy = "userProcessingUnit")
	@Cascade({ org.hibernate.annotations.CascadeType.DELETE })
	public Set<UserPURegionMatrix> getUserPURegionMatrixSet() {
		return userPURegionMatrixSet;
	}

	public void setUserPURegionMatrixSet(Set<UserPURegionMatrix> userPURegionMatrixSet) {
		this.userPURegionMatrixSet = userPURegionMatrixSet;
	}

}
