package com.citi.icg.as.common.dto;

public final  class   FirstLoad extends CompareObject {
	
	private static final FirstLoad INSTANCE = new FirstLoad();
	
	private FirstLoad() {
	}
	
	public static FirstLoad getInstance() {
		return INSTANCE;
	}
}
