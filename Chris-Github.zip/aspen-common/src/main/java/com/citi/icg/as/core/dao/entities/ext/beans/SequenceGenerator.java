package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.base.beans.BaseSequenceGenerator;

@Entity
@Table(name="SEQUENCE_GENERATOR") 
public class SequenceGenerator extends BaseSequenceGenerator
{

}