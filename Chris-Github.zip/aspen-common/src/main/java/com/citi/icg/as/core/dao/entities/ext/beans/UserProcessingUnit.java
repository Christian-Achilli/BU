package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseUserProcessingUnit;

@Entity
@Table(name = "USER_PROCESSING_UNIT")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE, region = "hibernate.USER_PROFILE")
public class UserProcessingUnit extends BaseUserProcessingUnit {

	private static final long serialVersionUID = -4713239794584144742L;

	@Override
	public String toString() {
		return "UserProcessingUnit [getLastUpdatedBy()=" + getLastUpdatedBy() + ", getLastUpdatedDate()=" + getLastUpdatedDate() + ", getPkBaseUserProcessingUnitId()="
				+ getPkBaseUserProcessingUnitId() + ", getProcessingUnit()=" + getProcessingUnit() + ", getProcessingUnitType()=" + getIsDefault() + ", getUser()=" + getUser() + "]";
	}

}
