package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class CurrencyCode extends BaseBusinessEntity
{
	private int pkCurrencyCodeId;
    private String lastUpdatedBy;
    private Date lastUpdatedDate;
    private String currencyIndex;
    private String currencyCode;
    private String description;
    private Integer decimalPlaces;
    
	public int getPkCurrencyCodeId()
	{
		return pkCurrencyCodeId;
	}

	public void setPkCurrencyCodeId(int pkCurrencyCodeId)
	{
		this.pkCurrencyCodeId = pkCurrencyCodeId;
	}

	public String getLastUpdatedBy()
	{
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy)
	{
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate()
	{
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate)
	{
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getCurrencyIndex() {
		return currencyIndex;
	}

	public void setCurrencyIndex(String currencyIndex) {
		this.currencyIndex = currencyIndex;
	}

	public String getCurrencyCode()
	{
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode)
	{
		this.currencyCode = currencyCode;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public Integer getDecimalPlaces()
	{
		return decimalPlaces;
	}

	public void setDecimalPlaces(Integer decimalPlaces)
	{
		this.decimalPlaces = decimalPlaces;
	}

	@Override
	public Integer getId()
	{
		return getPkCurrencyCodeId();
	}

}
