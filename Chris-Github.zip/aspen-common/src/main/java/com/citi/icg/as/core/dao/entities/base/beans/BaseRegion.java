package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

@MappedSuperclass
@Table(name = "REGION", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseRegion extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 8854970284036636441L;
	
	private int pkRegionCodeId;
	private String regionCode;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String managedGeographyId;
	private String timezoneId;
	private String regionLocale;

	public BaseRegion() {
	}

	public BaseRegion(int pkRegionCodeId, String regionCode, String lastUpdatedBy, Date lastUpdatedDate,String timezoneId, String regionLocale) {
		this.pkRegionCodeId = pkRegionCodeId;
		this.regionCode = regionCode;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.timezoneId = timezoneId;
		this.regionLocale = regionLocale;
	}

	@Id
	@Column(name = "PK_REGION_CODE_ID", unique = true, nullable = false)
	public int getPkRegionCodeId() {
		return this.pkRegionCodeId;
	}

	public void setPkRegionCodeId(int pkRegionCodeId) {
		this.pkRegionCodeId = pkRegionCodeId;
	}

	@Column(name = "REGION_CODE", nullable = false, length = 5)
	public String getRegionCode() {
		return this.regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	@Column(name = "LAST_UPDATED_BY", nullable = false, length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Column(name = "MANAGED_GEOGRAPHY_ID", nullable = false, length = 20)
	public String getManagedGeographyId() {
		return managedGeographyId;
	}

	public void setManagedGeographyId(String managedGeographyId) {
		this.managedGeographyId = managedGeographyId;
	}

	@Column(name = "TIMEZONE_ID", nullable = false, length = 20)
	public String getTimezoneId() {
		return timezoneId;
	}

	public void setTimezoneId(String timezoneId) {
		this.timezoneId = timezoneId;
	}
	
	@Column(name = "Locale", nullable = false, length = 20)
	public String getRegionLocale() {
		return regionLocale;
	}
	
	
	public void setRegionLocale(String regionLocale) {
		this.regionLocale = regionLocale;
	}

}