package com.citi.icg.as.dao;


/**
 * This interface defines all the database operations for Currency
 * Calculation exposed to other components directly (Without Hassian werb service calls)
 *
 * @author ib13524
 *
 */

public interface CurrencyLookupDao {

	/**
	 * Retrieves list of Currency Index for a given currency code
	 * @param CurrencyCode
	 * @return CurrencyIndex
	 */

	String getCodeIndex(String code);
}
