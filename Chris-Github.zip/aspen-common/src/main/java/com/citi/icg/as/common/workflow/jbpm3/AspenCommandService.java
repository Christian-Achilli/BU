package com.citi.icg.as.common.workflow.jbpm3;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.JbpmConfiguration;
import org.jbpm.JbpmContext;
import org.jbpm.JbpmException;
import org.jbpm.command.Command;
import org.jbpm.command.impl.CommandServiceImpl;

import com.citi.icg.as.exception.ErrorType;

@SuppressWarnings("serial")
public class AspenCommandService extends CommandServiceImpl {

	private static final Log log = LogFactory.getLog(CommandServiceImpl.class);
	
	public AspenCommandService(JbpmConfiguration jbpmConfiguration) {
		super(jbpmConfiguration);
	}

	public Object execute(Command command)
	{
		
		/**
		 * Major change in this implementation is that it allows for nested command execution.  The block on this before was that
		 * the context was created and closed per command. It will now check for an existing context before close.
		 */
		
		boolean isCurrentContext = JbpmContext.getCurrentJbpmContext() != null;
				
		Object result = null;
		
		JbpmContext jbpmContext = null;
		if (isCurrentContext) {
			jbpmContext = JbpmContext.getCurrentJbpmContext();
		} else {
			jbpmContext = jbpmConfiguration.createJbpmContext();
		}
		
		try
		{
			log.debug("executing " + command);
			result = command.execute(jbpmContext);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new JbpmException("couldn't execute " + command, e);
		}
		finally
		{
			// only close if not part of context chain
			if (!isCurrentContext) {
				jbpmContext.close();
			}
		}
		return result;
	}


	

}
