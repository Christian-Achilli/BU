package com.citi.icg.as.common.workflow;


/**
 * 
 *
 */
public interface State 
{

	Long getId();
	
	String getName();
	
	StateType getStateType();
		
}
