package com.citi.icg.as.common.enums;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum ProcessingUnitType 
{
	DEFAULT_PU
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(1);
		}

		public String getDisplayName()
		{
			return "Default PU";
		}
	},

	PB_EQUITY
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(2);
		}

		public String getDisplayName()
		{
			return "PB Equity";
		}
	},
	
	SWAPS
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(3);
		}
		
		public String getDisplayName()
		{
			return "Swaps";
		}
	},
	
	MAIN_FIRM_EQUITY
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(4);
		}

		public String getDisplayName()
		{
			return "Main Firm Equity";
		}
	},
	
	US_DCC
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(2);
		}

		public String getDisplayName()
		{
			return "US DCC";
		}
	},

	Global_Window
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(3);
		}

		public String getDisplayName()
		{
			return "Global Window";
		}
	},
	
	FIXED_INCOME
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(5);
		}

		public String getDisplayName()
		{
			return "Fixed Income";
		}
	},
	
	CGMI_BROADRIDGE
	{
		public Integer getPkProcessingUnitId()
		{
			return Integer.valueOf(6);
		}

		public String getDisplayName()
		{
			return "CGMI Broadridge";
		}
	};
	
	public static ProcessingUnitType getPUType(String putypeName) {
		for (ProcessingUnitType p : ProcessingUnitType.values()) {
			if (p.getDisplayName().equalsIgnoreCase(putypeName)) {
				return p;
			}
		}
		return null;
	}

	public static List<ProcessingUnitType> getPUTypes(List<String> putypeNames) {
		List<ProcessingUnitType> pus = new ArrayList<ProcessingUnitType>();
		if(putypeNames == null || putypeNames.isEmpty())
			return pus;
		for (String putypeName : putypeNames) {
			for (ProcessingUnitType p : ProcessingUnitType.values()) {
				if (p.getDisplayName().equalsIgnoreCase(putypeName)) {
					pus.add(p);
				}
			}			
		}
		return pus;
	}
	
	@Deprecated
	public static List<ProcessingUnitType> getAllExceptDefaultPU() {
		List<ProcessingUnitType> allPu = new ArrayList<ProcessingUnitType>(Arrays.asList(ProcessingUnitType.values()));
		allPu.remove(ProcessingUnitType.DEFAULT_PU);
		allPu.remove(ProcessingUnitType.US_DCC); // filtered custody PU's. temparary fix, Need to merge Custody for permanent fix 
		allPu.remove(ProcessingUnitType.Global_Window); // filtered custody PU's
		allPu.remove(ProcessingUnitType.CGMI_BROADRIDGE);
		return allPu;
	}
	@Deprecated
	public static List<String> getDisplayNameForAllExceptDefaultPU() {
		List<String> displayNames = new ArrayList<String>();
		for (ProcessingUnitType pu : ProcessingUnitType.values()){
			// filtered custody PU's
			if (pu.compareTo(DEFAULT_PU) != 0 && pu.compareTo(US_DCC) != 0 && pu.compareTo(Global_Window) != 0){
				displayNames.add(pu.getDisplayName());
			}
		}
		return displayNames;
	}

	public abstract Integer getPkProcessingUnitId();

	public abstract String getDisplayName();
}
