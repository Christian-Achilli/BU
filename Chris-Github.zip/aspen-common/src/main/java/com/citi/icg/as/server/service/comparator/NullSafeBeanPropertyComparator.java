package com.citi.icg.as.server.service.comparator;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.NestedNullException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class NullSafeBeanPropertyComparator extends BeanComparator
{
	private static final long serialVersionUID = -3112754164408003425L;
	
	protected static final Log LOG = LogFactory.getLog(NullSafeBeanPropertyComparator.class);
	
	private final String property;
	private final boolean isNullLargest;
	
	public NullSafeBeanPropertyComparator(String property, boolean isNullLargest)
	{
		super(property);
		this.property = property;
		this.isNullLargest = isNullLargest;
	}
	
	public NullSafeBeanPropertyComparator(String property)
	{
		this(property, true);
	}

	@Override
	public int compare(Object arg0, Object arg1)
	{
		try
		{
			Object val0 = getBeanPropertyValue(arg0);
			Object val1 = getBeanPropertyValue(arg1);
			
			if (val0 == null && val1 == null)
			{
				return 0;
			}
			if (val0 == null)
			{
				return isNullLargest ? 1 : -1;
			}
			else if (val1 == null)
			{
				return isNullLargest ? -1 : 1;
			}
			else
			{
				return super.compare(arg0, arg1);
			}
		}
		catch (Exception e)
		{
			LOG.error(e.toString(), e);
			throw new ClassCastException();
		}
	}

	private Object getBeanPropertyValue(Object arg0) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
	{
		Object result;
		try 
		{
			result = arg0 == null ? null : BeanUtils.getProperty(arg0, property);
		}
		catch (NestedNullException e)
		{
			result = null;
		}
		return result;
	}

}
