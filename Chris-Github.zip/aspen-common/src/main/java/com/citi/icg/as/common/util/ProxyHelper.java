package com.citi.icg.as.common.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.AnnotationTransactionAttributeSource;
import org.springframework.transaction.interceptor.TransactionAttributeSource;
import org.springframework.transaction.interceptor.TransactionProxyFactoryBean;

public class ProxyHelper implements IProxyHelper {

	@Autowired
	private PlatformTransactionManager transactionManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.citi.icg.as.common.util.IProxyHelper#getTransactionalInstance(T)
	 */
	@Override
	public <T> T getTransactionalInstance(T target) {
		TransactionProxyFactoryBean factory = transactionProxyFactoryBean();
		factory.setTarget(target);
		factory.afterPropertiesSet();
		return (T) factory.getObject();
	}

	@Bean
	@Scope("prototype")
	public TransactionProxyFactoryBean transactionProxyFactoryBean() {
		TransactionAttributeSource transactionAttributeSource = new AnnotationTransactionAttributeSource();
		TransactionProxyFactoryBean factory = new TransactionProxyFactoryBean();
		factory.setTransactionManager(transactionManager);
		factory.setTransactionAttributeSource(transactionAttributeSource);

		return factory;
	}

	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

}
