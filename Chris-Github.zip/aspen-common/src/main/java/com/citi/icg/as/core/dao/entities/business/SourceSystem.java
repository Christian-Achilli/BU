package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;
import com.citi.icg.aspenlogger.Loggable;

public class SourceSystem extends BaseBusinessEntity implements Loggable{
	
	private static final long serialVersionUID = 4645463923263950642L;

	private int pkSourceId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String sourceCode;
	private String sourceName;

	public int getPkSourceId() {
		return pkSourceId;
	}

	public void setPkSourceId(int pkSourceId) {
		this.pkSourceId = pkSourceId;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getSourceCode() {
		return sourceCode;
	}

	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	@Override
	public Integer getId() {
		return getPkSourceId();
	}

	@Override
	public String toLogString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SourceSystem [pkSourceId=").append(pkSourceId)
				.append(", sourceCode=").append(sourceCode)
				.append(", sourceName=").append(sourceName).append("]");
		return builder.toString();
	}

}
