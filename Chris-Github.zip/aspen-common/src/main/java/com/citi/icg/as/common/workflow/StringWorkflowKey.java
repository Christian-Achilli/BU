package com.citi.icg.as.common.workflow;

public class StringWorkflowKey implements WorkflowKey {

	private String key;
	
	public StringWorkflowKey(String key) {
		super();
		this.key = key;
	}

	@Override
	public Class getEntityType() {
		throw new IllegalArgumentException("Not implemented.");
	}

	@Override
	public Long[] getEntityIds() {
		throw new IllegalArgumentException("Not implemented.");
	}

	@Override
	public String[] getEntityIdsWithBrackets() {
		throw new IllegalArgumentException("Not implemented.");
	}

	@Override
	public String toString() {
		return key;
	}

}
