/**
 * 
 */
package com.citi.icg.as.server.common.template.engine;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.lang.UnhandledException;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;
import freemarker.template.TemplateException;

/**
 * @author ap72338
 *
 */

public class FreeMarkerTemplateUtility {

	private Configuration configuration;	
	private final static FreeMarkerTemplateUtility utility = new FreeMarkerTemplateUtility();
	
	private FreeMarkerTemplateUtility(){
		//Empty private constructor
	}
	
	public static FreeMarkerTemplateUtility getInstance(){
		return utility;
	}

	public void setConfiguration(Configuration configuration){
		utility.configuration = configuration;
	}
	
	public String processTemplateIntoString(String templateName,Map<String,?> properties) {
		try {
			return FreeMarkerTemplateUtils.processTemplateIntoString(configuration.getTemplate(templateName), properties);
		} catch (IOException e) {
			throw new UnhandledException(e);
		} catch (TemplateException e) {
			throw new UnhandledException(e);
		}
	}
}
