package com.citi.icg.as.common.workflow;

/**
 * 
 *
 */
public enum StateType 
{
WAIT,
TASK,
ACTION,
TIMER,
MAIL;
}
