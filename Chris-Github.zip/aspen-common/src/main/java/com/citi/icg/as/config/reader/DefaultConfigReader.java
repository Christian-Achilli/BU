package com.citi.icg.as.config.reader;

import java.util.Properties;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DefaultConfigReader<T extends XMLConfiguration> extends BaseConfigReader<T>{
	
	private static final Log LOG = LogFactory.getLog(DefaultConfigReader.class);
	
	private static final String NAME_PREFIX = "configuration";
	private static final String EXT_XML = ".xml";
	public static final String DELIMETER = "-";
	private static final String CONFIG_DIRECTORY_PROPERTY = "app.config.dir";
	private static final String app_config_file_name = "appConfig.properties";

	@Override
	public String getAppConfigDirectory() {
		String appConfigDir = System.getProperty(CONFIG_DIRECTORY_PROPERTY);
		if(StringUtils.isNotBlank(appConfigDir)){
			return appConfigDir;
		}
		Properties props = new Properties();
		try {
			props.load(this.getConfigFromClassPath(app_config_file_name));
			appConfigDir = props.getProperty(CONFIG_DIRECTORY_PROPERTY);
		} catch (Exception e) {
			LOG.info("Failed to get app config directory in "+ app_config_file_name + " file");
		}
		return appConfigDir;
	}

	@Override
	public String getConfigName(Class<T> configClass) {
		String name = configClass.getSimpleName().toLowerCase();
		if (name.startsWith("icg")) {
			name = name.substring("icg".length());
		}
		if (name.endsWith("config")) {
			name = name.substring(0, name.length() - "config".length());
		}
		
		if (name.endsWith(NAME_PREFIX)) {
			name = name.substring(0, name.length() - NAME_PREFIX.length());
		}
		
		if (name.endsWith("configurations")) {
			name = name.substring(0, name.length() - "configurations".length());
		}
		String configFileName = NAME_PREFIX + DELIMETER + name + EXT_XML;
		return configFileName;
	}

}
