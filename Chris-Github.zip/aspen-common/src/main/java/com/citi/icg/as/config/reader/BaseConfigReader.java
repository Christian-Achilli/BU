package com.citi.icg.as.config.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class BaseConfigReader<T> implements ConfigReader<T> {
	
	private static final Log LOG = LogFactory.getLog(BaseConfigReader.class);

	public InputStream getConfigFileStream(Class<T> configurationClass){
		String configFileName = getConfigName(configurationClass);
		return this.getConfigFileStream(configFileName);
	}
	public InputStream getConfigFileStream(String configFileName){
		InputStream inputStream = getConfigFromFileDir(configFileName);
		if(inputStream == null){
			inputStream = getConfigFromClassPath(configFileName);
		}
		return inputStream;
	}
	/**
	 * @Descript
	 * @param configFileName
	 * @return
	 */
	protected InputStream getConfigFromClassPath(String configFileName){
		if(configFileName == null){
			return null;
		}
		InputStream inputStream = BaseConfigReader.class.getClassLoader().getResourceAsStream(configFileName);
		if(inputStream == null){
			LOG.info(configFileName +" file doestn't exist in class Path");
		}
		return inputStream;
	}
	
	/**
	 * @Description: look up config file from app config dir.
	 * @param configFileName
	 * @return
	 */
	protected InputStream getConfigFromFileDir(String configFileName){
		InputStream inputStream = null;
		String appConfigDir = this.getAppConfigDirectory();
		if (StringUtils.isNotBlank(appConfigDir)) {
			File file = new File(appConfigDir, configFileName);
			if (file.exists()) {
				try {
					inputStream  = new FileInputStream(file);
				} catch (FileNotFoundException e) {
				}
			}
			if(inputStream == null){
				LOG.info("config file doestn't exist in appConfigDir " + appConfigDir + "/" + configFileName);
			}
		}
		return inputStream;
	}
	
	/**
	 * @Description to be override in subClass to get app config directory
	 * @return
	 */
	public abstract String getAppConfigDirectory();	
}
