package com.citi.icg.as.common.enums;

/**
 * Enum for user queue type.
 *
 */
public enum QueueType {
	WorkingItems("WorkingItems"), 
	Approval("WaitingForApproval"), 
	NotificationWorkingItems("Notification Working Items"), 
	NotificationApproval("Notification Waiting for Approval"), 
	PostingsWorkingItems("Postings Working Items"),
	PostingsApproval("Postings Waiting for Approval"),
	SettlementWorkingItems("Settlement Working Items"),
	SettlementApproval("Settlement Waiting for Approval"),
	AlertsByEvent("Alerts By Event"), 
	OpenAlerts("Open Alerts"), 
	AlertApprovalItems("Approval Items"), 
	AlertManagerItems("Manager’s Items"), 
	RefWorkingItems("Reference Data Working Items"),
	RefApproval("Reference Data Waiting for Approval"), 
	History("HistoricalItems"), 
	Approved("Approved");

	private String displayName;

	private QueueType() {
	}

	private QueueType(String displayName) {
		this.displayName = displayName;
	}

	public static QueueType getQueueType(String strQueueType) {
		for (QueueType queueType : QueueType.values()) {
			if (queueType.name().equalsIgnoreCase(strQueueType)) {
				return queueType;
			}
		}
		return null;
	}

	public static QueueType getQueueTypeByDisplayName(String displayName) {
		for (QueueType queueType : QueueType.values()) {
			if (queueType.displayName.equalsIgnoreCase(displayName)) {
				return queueType;
			}
		}
		return null;
	}

	public String toString() {
		return this.displayName;
	}
}
