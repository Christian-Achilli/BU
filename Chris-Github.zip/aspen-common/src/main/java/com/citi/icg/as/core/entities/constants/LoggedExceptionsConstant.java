package com.citi.icg.as.core.entities.constants;


public class LoggedExceptionsConstant {
	public static final String EXCEPTION_MESSAGE = "exceptionMessage";
	public static final String TO_EMAIL = "toEmail";
	public static final String DEBUG_STRING = "debugString";
	public static final String IS_SENT = "isSent";
	public static final String CLASS = "class";
	public static final String EXCEPTION_NAME = "exceptionName";
	public static final String PK_EXCEPTION_ID = "pkExceptionId";
	public static final String SOURCE = "source";
	public static final String CASE_ID = "caseId";
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String SENT_DATE = "sentDate";
	public static final String VALUE = "value";
	public static final String EXCEPTION_LEVEL = "exceptionLevel";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
}