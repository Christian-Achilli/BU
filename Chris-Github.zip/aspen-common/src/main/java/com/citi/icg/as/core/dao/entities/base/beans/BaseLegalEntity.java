package com.citi.icg.as.core.dao.entities.base.beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.citi.icg.as.core.dao.entities.base.beans.JPATransferObject;

@MappedSuperclass
@Table(name = "LEGAL_ENTITY", schema = "PUBLIC", catalog = "INCOMEPROCESSING", uniqueConstraints = @UniqueConstraint(columnNames = "LEGAL_ENTITY_NAME"))
public abstract class BaseLegalEntity extends JPATransferObject implements Serializable {

	private static final long serialVersionUID = 6489715674367515916L;
	
	private int pkLegalEntityId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String legalEntityCode;
	private String legalEntityName;
	private String cairoFilterFlag;
	private String aliasName;
	private String gfcId;
	private String onOffShore;
	private String withholdingAgentRole;
	private String entityLocationCountry;
	private String swtEligibility;
	private String processingUnit;

	public BaseLegalEntity() {
	}

	public BaseLegalEntity(String lastUpdatedBy, Date lastUpdatedDate) {
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BaseLegalEntity(String lastUpdatedBy, Date lastUpdatedDate, String legalEntityCode, String legalEntityName) {
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.legalEntityCode = legalEntityCode;
		this.legalEntityName = legalEntityName;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_LEGAL_ENTITY", allocationSize = 1)
	@Column(name = "PK_LEGAL_ENTITY_ID", unique = true, nullable = false)
	public int getPkLegalEntityId() {
		return this.pkLegalEntityId;
	}

	public void setPkLegalEntityId(int pkLegalEntityId) {
		this.pkLegalEntityId = pkLegalEntityId;
	}

	@Column(name = "LAST_UPDATED_BY", nullable = false, length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Column(name = "LEGAL_ENTITY_CODE", length = 4, nullable = false)
	public String getLegalEntityCode() {
		return this.legalEntityCode;
	}

	public void setLegalEntityCode(String legalEntityCode) {
		this.legalEntityCode = legalEntityCode;
	}

	@Column(name = "LEGAL_ENTITY_NAME", unique = true, length = 50, nullable = false)
	public String getLegalEntityName() {
		return this.legalEntityName;
	}

	public void setLegalEntityName(String legalEntityName) {
		this.legalEntityName = legalEntityName;
	}

	@Column(name = "CAIRO_FILTER_FLAG", length = 1)
	public String getCairoFilterFlag() {
		return cairoFilterFlag;
	}

	public void setCairoFilterFlag(String cairoFilterFlag) {
		this.cairoFilterFlag = cairoFilterFlag;
	}

	@Column(name = "ALIAS_NAME", length = 50, nullable = true)
	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	@Column(name = "GFC_ID", length = 20, nullable = false)
	public String getGfcId() {
		return gfcId;
	}

	public void setGfcId(String gfcId) {
		this.gfcId = gfcId;
	}

	@Column(name = "ON_OFF_SHORE", length = 5)
	public String getOnOffShore() {
		return onOffShore;
	}

	public void setOnOffShore(String onOffShore) {
		this.onOffShore = onOffShore;
	}

	@Column(name = "WITHHOLDING_AGENT_ROLE", length = 20)
	public String getWithholdingAgentRole() {
		return withholdingAgentRole;
	}

	public void setWithholdingAgentRole(String withholdingAgentRole) {
		this.withholdingAgentRole = withholdingAgentRole;
	}

	@Column(name = "ENTITY_LOCATION_COUNTRY", length = 5)
	public String getEntityLocationCountry() {
		return entityLocationCountry;
	}

	public void setEntityLocationCountry(String entityLocationCountry) {
		this.entityLocationCountry = entityLocationCountry;
	}

	@Column(name = "SWT_ELIGIBILITY", length = 1)
	public String getSwtEligibility() {
		return swtEligibility;
	}

	public void setSwtEligibility(String swtEligibility) {
		this.swtEligibility = swtEligibility;
	}

	@Column(name = "PROCESSING_UNIT")
	public String getProcessingUnit() {
		return processingUnit;
	}

	public void setProcessingUnit(String processingUnit) {
		this.processingUnit = processingUnit;
	}
}
