package com.citi.icg.as.transform;

public class StringTransformer {

	// Swift X allowed character set regex
	public static final String SWIFT_X_CHAR_SET = "[^a-zA-Z0-9/\\-?:().,'+{}\r\n]";
	// Swift Y allowed character set regex
	public static final String SWIFT_Y_CHAR_SET = "[^A-Z0-9/\\-?:().,'+=!\"%&*<>;]";
	// Swift Z allowed character set regex
	public static final String SWIFT_Z_CHAR_SET = "[^a-zA-Z0-9/\\-?:().,'+=!\"%&*<>;@#{\r\n]";
	
	public static final String SWIFT_X_ALLOWED_CHAR_SET = "[a-zA-Z0-9/\\-?:().,'+{}\r\n ]+$";
	
	/**
	 * This method will replace all the characters from <code>originalString</code> with <code>replacementString</code>
	 * which are not allowed as per provided <code>allowedCharSet</code>
	 * @param allowedCharSet
	 * @param originalString
	 * @param replacementString
	 * @return
	 */
	public static String transform(String allowedCharSet, String originalString, String replacementString) {
		return originalString.replaceAll(allowedCharSet, replacementString);
	}
	
	public static boolean validate(String allowedCharSet, String inputString){
		return inputString.matches(allowedCharSet);
	}
	
}
