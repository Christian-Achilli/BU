package com.citi.icg.as.util;

import java.io.File;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.util.Assert;

import com.citi.icg.as.config.GCASAppConfiguration;

/**
 * Helps encrypt and decrypt text.
 */
public final class CommonTextEncryptUtils
{
	private static final String DEFAULT_ENCRYPTION_ALGORITHM = "PBEWithMD5AndTripleDES";
	private static final String ENCRYPTION_ALGORITHM = getEncryptionAlgorithm();
	public static final String ENCODE_INDICATOR_START = "ENC(";
	public static final String ENCODE_INDICATOR_END = ")";
	public static final int INTERATION = 15;
	private static final byte[] SALT = { (byte) 0xd7, (byte) 0x73, (byte) 0x21, (byte) 0x8c, (byte) 0x7e, (byte) 0xc8, (byte) 0xee,
			(byte) 0x99 };

	private final static ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();

	private final Cipher encrypter;
	private final Base64 base64 = new Base64();
	private final String key;

	private static final int KEYLENGTH = 256;
	public static final String ERROR_KEY_GENERATION = "Encryption key generation failed. Please verify the logs.";
	
	private static final Log log = LogFactory.getLog(CommonTextEncryptUtils.class);
	
	private static CommonTextEncryptUtils instance = initApplicaitonKey();
	
	public String encrypt(String plainText)
	{
		try
		{
			return new String(base64.encode(encrypter.doFinal(plainText.getBytes())));
		}
		catch (Exception e)
		{
			throw new RuntimeException("failed to encrypt text=[" + plainText + "]", e);
		}
	}

	public String decrypt(String encryptedText)
	{
		//log.info("call to decrypt with encryptedText = " + encryptedText);
		try
		{
			Cipher decrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.DECRYPT_MODE);
			//log.info("key = " + key);
			return new String(decrypter.doFinal(base64.decode(encryptedText.getBytes())));
		}
		catch (Exception e)
		{
			throw new RuntimeException("failed to decrypt text=[" + encryptedText + "]", e);
		}
	}

	private CommonTextEncryptUtils(String key)
	{
		this.key = key;
		try
		{
			encrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.ENCRYPT_MODE);
		}
		catch (Exception e)
		{
			// CHECKSTYLE:OFF
			throw new RuntimeException(
					"Unable to Initialize Ciphers"
							+ "\nJAVA_HOME="
							+ System.getProperty("java.home")
							+ "\nSee https://teamforge.nam.nsroot.net/sf/wiki/do/viewPage/projects.153106_1/wiki/UnableToInitializeCiphers for posible solution",
					e);
			// CHECKSTYLE:ON
		}
	}

	public static String encryptFormatted(String textToEncrypt)
	{
		if (instance != null)
		{
			return ENCODE_INDICATOR_START + instance.encrypt(textToEncrypt) + ENCODE_INDICATOR_END;
		}

		log.error("The Application Cypers were not initialized for encrypting.");

		return textToEncrypt;
	}

	public static String decryptIfEncrypted(String encryptedString)
	{
		String decryptedString = encryptedString;
		//log.info("call to decryptIfEncrypted with encryptedString = " + encryptedString);

		try
		{
			if (instance != null)
			{
				if (encryptedString!=null && encryptedString.startsWith(ENCODE_INDICATOR_START))
				{
					//log.info("It has to be decrypted!");
					decryptedString = encryptedString.substring(ENCODE_INDICATOR_START.length(), encryptedString.length() - 1);
					//log.info("decryptedString = " + decryptedString);
					return instance.decrypt(decryptedString);
				}
			}
			else
			{
				log.error("The Application Cypers were not initialized.");
			}

			return decryptedString;
		}
		catch (Exception ex)
		{
			throw new RuntimeException("failed to decrypt text", ex);
		}
	}

	private static Cipher createCipher(char[] password, byte[] salt, int noIterations, int encryptionMode) throws NoSuchAlgorithmException,
			InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException
	{
		SecretKeyFactory kf = SecretKeyFactory.getInstance(ENCRYPTION_ALGORITHM);
		PBEKeySpec keySpec = new PBEKeySpec(password);
		SecretKey key = kf.generateSecret(keySpec);
		Cipher ciph = Cipher.getInstance(ENCRYPTION_ALGORITHM);

		PBEParameterSpec params = new PBEParameterSpec(salt, noIterations);
		ciph.init(encryptionMode, key, params);
		return ciph;
	}
	
	private static String getFileName()
	{
		String path = GCASAppConfiguration.getInstance().getKeyFilePath();
		Resource keyDat = resourcePatternResolver.getResource(path);
		try {
			return keyDat.getFile().getAbsolutePath();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static synchronized CommonTextEncryptUtils initApplicaitonKey()
	{

		String fileName = getFileName();
		try
		{
			Assert.hasText(fileName, "Encryption Key File Name");
			String key = FileUtils.readFileToString(new File(fileName)).trim();
			Assert.hasText(key, "Encryption Key not found in file:" + fileName);
			if (key != null)
			{
				return new CommonTextEncryptUtils(key);
			}
		}
		catch (Exception e)
		{
			log.error("Encryption initialization failed from file " + fileName, e);
		}
		log.error("Could not initialize Application Cypers from file." + fileName);
		return null;
	}

	public static boolean isKeyFileExists()
	{
		String fileName = getFileName();
		if (StringUtils.isEmpty(fileName))
		{
			return false;
		}

		File file = new File(fileName);
		if (!file.exists())
		{
			return false;
		}
		return true;
	}

	/**
	 * Create the application key.
	 * @return If the operation was successful.
	 */
	public static boolean createAndStoreApplicaitonKey()
	{
		String fileName = getFileName();
		try
		{
			Assert.hasText(fileName, "Encryption Key File Name");
			String randomString = RandomStringUtils.randomAlphanumeric(KEYLENGTH);
			Assert.hasText(randomString, "Error while generating the Encryption Key : " + fileName);
			FileUtils.writeStringToFile(new File(fileName), randomString);
			instance = initApplicaitonKey();
		}
		catch (Exception e)
		{
			log.error(ERROR_KEY_GENERATION, e);
			log.error("Could not generate Application Ciphers from file-" + fileName);
			return false;
		}

		return true;
	}
	
	public static CommonTextEncryptUtils getInstance()
	{
		return instance;
	}
	
	private static String getEncryptionAlgorithm()
	{
		String encryptionAlgorithm = ""; //FIXME
		if (StringUtils.isEmpty(encryptionAlgorithm))
		{
			encryptionAlgorithm = DEFAULT_ENCRYPTION_ALGORITHM;
		}
		return encryptionAlgorithm;
	}
}

