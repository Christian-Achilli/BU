package com.citi.icg.as.server.util;

import org.apache.log4j.Level;
import org.apache.log4j.spi.LoggingEvent;

import com.citi.icg.as.common.exception.ExceptionHandler;
import com.citi.icg.as.exception.AspenRuntimeException;
import com.citi.icg.as.exception.AspenServiceException;
import com.citi.icg.as.exception.ErrorType;
import com.citi.icg.as.server.service.GcasRpcContext;

public class ExceptionHandlerAppender extends org.apache.log4j.AsyncAppender
{
	public ExceptionHandlerAppender(){
		super();
		this.setLocationInfo(true);
		this.addAppender(new DBAppender());
		this.setBufferSize(4096);
		this.setBlocking(false);
	}

	public static ExceptionHandler exceptionHandler;
    
	static class DBAppender extends org.apache.log4j.AppenderSkeleton{

		protected void append(LoggingEvent arg0)
		{
			if(arg0.getThrowableInformation()==null || arg0.getThrowableInformation().getThrowable()==null){
				return;
			}
			
			String level = arg0.getLevel().toString();
			int allowedLevel = 0;
			Throwable t = arg0.getThrowableInformation().getThrowable();
			ErrorType errorLevel = null;
			if (t instanceof AspenRuntimeException) {
				errorLevel = ((AspenRuntimeException)t).getErrorLevel();
			} else if (t instanceof AspenServiceException ) {
				errorLevel = ((AspenServiceException)t).getErrorLevel();
			} else allowedLevel = Level.toLevel("ERROR").toInt();
				
			if (errorLevel != null && errorLevel.equals(ErrorType.WARNING)) {
				allowedLevel = Level.toLevel("WARNING").toInt();
				level = "WARNING";
			} else if (errorLevel != null && errorLevel.equals(ErrorType.INFO)) {
				allowedLevel = Level.toLevel("INFO").toInt();
				level = "INFO";
			} else {
				allowedLevel = Level.toLevel("ERROR").toInt();
				level = "ERROR";
			}
			
			Long caseId = (Long) arg0.getMDC("caseId");
			GcasRpcContext ctx = GcasRpcContext.get(arg0);
			
			if(arg0.getLevel().toInt()>=allowedLevel){
				if(arg0.getThrowableInformation().getThrowable().getClass().getSimpleName().equalsIgnoreCase("CannotCreateTransactionException")){
					//it means db is down, can do nothing
				} else {
					if (exceptionHandler != null)
						exceptionHandler.handleException(level, arg0.getThrowableInformation().getThrowable(), arg0.getLocationInformation(), ctx, caseId);
				}
			}
		}

		public void close()
		{
		}

		public boolean requiresLayout()
		{
			return false;
		}
    	
    }
    
	public void close()
	{
	}

	public boolean requiresLayout()
	{
		return false;
	}
	
	public void setExceptionHandler(ExceptionHandler exceptionHandler) {
		ExceptionHandlerAppender.exceptionHandler = exceptionHandler;
	}

}
