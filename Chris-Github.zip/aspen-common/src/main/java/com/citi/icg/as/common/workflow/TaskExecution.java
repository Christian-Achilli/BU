package com.citi.icg.as.common.workflow;

/**
 * Equates to one running task instance in the execution context.
 *
 */
public interface TaskExecution 
{

	Long getId();
	
	String getUser();
	
	State getState();
	
	boolean isOpen();
	
}
