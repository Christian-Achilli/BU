package com.citi.icg.as.common.workflow.jbpm3;

public interface CallbackManager {

	<T> T executeCallback(final JbpmCallback<T> cb);
	
}
