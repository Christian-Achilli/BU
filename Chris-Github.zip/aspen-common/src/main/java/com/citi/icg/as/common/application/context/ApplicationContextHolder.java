/**
 * 
 */
package com.citi.icg.as.common.application.context;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.DependsOn;

/**
 * @author ap72338 <p>Due to circular dependencies between various AssetServicing
 *         components, spring {@link DependsOn} attribute doesn't work
 *         correctly. So as a final resort need to have a singleton/globalton
 *         for getting the context. This shoould not cause any issues in unit testing though</p>
 *
 */
public class ApplicationContextHolder implements ApplicationContextAware {

	private static ApplicationContextHolder holder = new ApplicationContextHolder();
	private ApplicationContext context;

	private ApplicationContextHolder() {
		// Empty private constructor
	}

	public static ApplicationContextHolder getInstance() {
		return holder;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		holder.context = applicationContext;
	}

	public ApplicationContext getContext() {
		return context;
	}
}
