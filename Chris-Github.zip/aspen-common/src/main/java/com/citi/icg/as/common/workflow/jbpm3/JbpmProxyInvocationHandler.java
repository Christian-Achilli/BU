package com.citi.icg.as.common.workflow.jbpm3;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.jbpm.JbpmContext;
import org.jbpm.command.Command;
import org.jbpm.command.CommandService;
import org.jbpm.context.exe.ContextInstance;
import org.jbpm.graph.def.Node;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.taskmgmt.exe.TaskInstance;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citi.icg.as.common.workflow.ContextVariable;
import com.citi.icg.as.common.workflow.GenericState;
import com.citi.icg.as.common.workflow.State;
import com.citi.icg.as.common.workflow.StateType;
import com.citi.icg.as.common.workflow.TaskExecution;
import com.citi.icg.as.common.workflow.Workflow;
import com.citi.icg.as.common.workflow.WorkflowConstants;
import com.citi.icg.as.common.workflow.WorkflowInstance;
import com.citi.icg.as.common.workflow.WorkflowKey;
import com.citi.icg.as.common.workflow.WorkflowTaskExecution;

/**
 * Proxy invocation handler that intercepts the method call on stub interfaces.  Each method call 
 * equates to a transition on the workflow definition.
 *
 */
public class JbpmProxyInvocationHandler implements InvocationHandler
{

	protected String processName;
	
	protected WorkflowKey key;
	
	private static final String TASK_ID = "taskId";
			
	protected CommandService commandService;
		
	private static final String TASK_NODE = "TaskNode";
	
	private Log log = LogFactory.getLog(JbpmProxyInvocationHandler.class);
	
	public JbpmProxyInvocationHandler(WorkflowKey key, String processName, CommandService commandService)
	{
		this.processName = processName;
		this.key = key;
		this.commandService = commandService;
	}
	
	protected boolean isWorkflowMethod(final Method method)
	{
		for (Method workflowMethod : Workflow.class.getMethods())
		{
			if (workflowMethod.equals(method))
			{
				return true;
			}
		}
		return false;
	}
	
	protected void addContextVariables(final Method method,
			final Object[] methodArgs, Map<String, Object> methodContextVars,
			ContextInstance context) {
		// for each method argument - add to the context if it is specified as a
		// context var
		Annotation[][] parmAnnotations = method.getParameterAnnotations();
		int i = 0;
		for (Annotation[] annotations : parmAnnotations) {
			for (Annotation a : annotations) {
				if (a instanceof ContextVariable) {
					if (((ContextVariable) a).transientVar() == false) {
						context.createVariable(((ContextVariable) a).name(),
								methodArgs[i]);
					} else {
						context.setTransientVariable(
								((ContextVariable) a).name(), methodArgs[i]);
					}

					methodContextVars.put(((ContextVariable) a).name(),
							methodArgs[i]);
				}
			}
			i++;
		}

		String transitionName = method.getName();
		context.createVariable(WorkflowConstants.TRANSITION_NAME,
				transitionName);

	}
    
//	protected void addContextVariables(final Method method, final Object[] methodArgs, 
//			ContextInstance context)
//	{
//		
//		// for each method argument - add to the context if it is specified as a context var
//		Annotation[][] parmAnnotations = method.getParameterAnnotations();
//		int i = 0;
//		for (Annotation[] annotations : parmAnnotations)
//		{
//			for (Annotation a : annotations)
//			{
//				if (a instanceof ContextVariable)
//				{
//					if (((ContextVariable) a).transientVar() == false) {
//						context.createVariable(((ContextVariable) a).name(), methodArgs[i]);
//					} else {
//						context.setTransientVariable(((ContextVariable) a).name(), methodArgs[i]);
//					}
//				}
//			}
//			i++;
//		}
//		
//		String transitionName = method.getName();
//		context.createVariable(WorkflowConstants.TRANSITION_NAME, transitionName);
//		
//	}
//	
//	protected void collectMethodVariables(final Method method, final Object[] methodArgs, Map<String, Object> methodContextVars) {	
//		Annotation[][] parmAnnotations = method.getParameterAnnotations();
//		int i = 0;
//		for (Annotation[] annotations : parmAnnotations) {
//			for (Annotation a : annotations) {
//				if (a instanceof ContextVariable) {
//					methodContextVars.put(((ContextVariable) a).name(), methodArgs[i]);
//				}
//			}
//			i++;
//		}
//		
//		String transitionName = method.getName();
//		methodContextVars.put(WorkflowConstants.TRANSITION_NAME, transitionName);	
//	}
//			
	protected void processTasks(Long taskId, String transiton, String taskDoneBy, Collection<TaskInstance> taskInstances)
	{
		
		for (TaskInstance ti : taskInstances)
		{
			if (ti.getId() == taskId)
			{
				endTask(ti, transiton, taskDoneBy);
				break;
			}
		}
	}
	
	protected void processTasks(String taskName, String transiton, String taskDoneBy, Collection<TaskInstance> taskInstances)
				{
		
		for (TaskInstance ti : taskInstances)
		{
			if (ti.getName() == taskName)
			{
				endTask(ti, transiton, taskDoneBy);
				break;
				}
		}
	}
	
	protected void processTasks(String transiton, String taskDoneBy, Collection<TaskInstance> taskInstances)
	{
		// end all running tasks on this node
		for (TaskInstance ti : taskInstances)
		{
			endTask(ti, transiton, taskDoneBy);
		}
	}
	
	/**
	 * End the task in question.  Uses the special taskDoneBy var to assign the actor id of the person who has completed the task.
	 * @param ti
	 * @param transiton
	 * @param taskDoneBy
	 */
	protected void endTask(TaskInstance ti, String transiton, String taskDoneBy)
	{
		
		if (ti.isOpen()) 
		{
			if (StringUtils.isNotEmpty(taskDoneBy))
			{
				ti.setActorId(taskDoneBy);
			}
			
			if (StringUtils.isNotEmpty(transiton)) {
				ti.end(transiton);
			} else {
				ti.end();
			}
		}
		
	}
		
	/**
	 * Look for special context variables that describe the task that should be ended.  If Task id or task name is not specified it is 
	 * assumed that any open task(s) will be closed.  In reality this should only be used if you have one task.
	 * @param methodContextVars
	 * @param taskInstances
	 * @param transiton
	 */
	protected void processTasks(Map<String, Object> methodContextVars, Collection<TaskInstance> taskInstances, String transiton) 
	{
		
		String actorId = (String) methodContextVars.get(WorkflowConstants.TASK_DONE_BY);
		
		if (methodContextVars.containsKey(TASK_ID)) {
			
			Long taskId = (Long) methodContextVars.get(TASK_ID);
			processTasks(taskId, transiton, actorId, taskInstances);
			
		} else if (methodContextVars.containsKey(WorkflowConstants.TASK_NAME)) {
			
			String taskName = (String) methodContextVars.get(WorkflowConstants.TASK_NAME);
			processTasks(taskName, transiton, actorId, taskInstances);
			
		} else {
			
			processTasks(transiton, actorId, taskInstances);
			
		}
				
	}
	
	@SuppressWarnings("unchecked")
	protected Workflow convertToWorkflow(ProcessInstance processInstance) {

		if (processInstance != null) {

			WorkflowInstance workflowInstance = new WorkflowInstance(
					processInstance.getProcessDefinition().getName(),
					processInstance.getKey());

			// current state
			Node node = processInstance.getRootToken().getNode();
			StateType type = node.toString().substring(0, 8).equals(TASK_NODE) ? StateType.TASK
					: StateType.ACTION;
			GenericState currentState = new GenericState(node.getId(), node
					.getName(), type);
			workflowInstance.setCurrentState(currentState);

			// tasks
			List<TaskExecution> convertedTasks = new ArrayList<TaskExecution>();
			
			Collection<TaskInstance> tasks = processInstance.getTaskMgmtInstance().getTaskInstances();
			if (tasks != null) {
				for (TaskInstance task : tasks) {
					convertedTasks.add(new WorkflowTaskExecution(task.getId(),
							task.getActorId(), workflowInstance
									.getCurrentState(), task.getName(), task.isOpen()));
				}
			}
			workflowInstance.setTasks(convertedTasks);

			// variables
			workflowInstance.setVariables(processInstance.getContextInstance()
					.getVariables());

			return workflowInstance;

		}

		return null;

	}
		
	protected ProcessInstance getProcessInstance(JbpmContext jbpmContext)
	{
		Criteria criteria = jbpmContext.getSession()
				.createCriteria(ProcessInstance.class);
		criteria.add(Restrictions.eq("key", key.toString()));
		criteria.createCriteria("processDefinition").add(
				Restrictions.eq("name", processName));
		criteria.add(Restrictions.isNull("end"));
		return (ProcessInstance) criteria.uniqueResult();
	}
	
	@SuppressWarnings({ "unchecked", "serial" })
	@Transactional(propagation = Propagation.MANDATORY)
	public Object invoke(Object proxy, final Method method, final Object[] methodArgs) throws Throwable
	{
		
		Command command = new Command() {

			@Override
			public Object execute(JbpmContext jbpmContext) throws Exception {
				try {
					
					ProcessInstance processInstance = getProcessInstance(jbpmContext);
					Workflow stubWorkflow  = convertToWorkflow(processInstance);
					
					// check if we need to execute any methods on the workflow stub (allows workflow introspection)				
					if (isWorkflowMethod(method))
					{
						return method.invoke(stubWorkflow, methodArgs);
					}
					
					// for each method argument - add to the context if it is specified as a context var
					Map<String, Object> methodContextVars = new HashMap<String, Object>();
					ContextInstance context = processInstance.getContextInstance();
					addContextVariables(method, methodArgs, methodContextVars, context);
					
					// check if it is task or state node
					String transiton = method.getName();
					State state = stubWorkflow.getCurrentState();
					
					//CHECKSTYLE:OFF
					if (state.getStateType().equals(StateType.TASK))
					//CHECKSTYLE:ON
					{
						
						// task node can contain 1 or more running tasks
						Collection<TaskInstance> taskInstances = processInstance.getTaskMgmtInstance()
																	.getUnfinishedTasks(processInstance.getRootToken());
						
						if (taskInstances.size() == 0)
						{
							throw new RuntimeException("No running task instances.");
						}
						
						processTasks(methodContextVars, taskInstances, transiton);
							
						} else {
							
						// signal process
						processInstance.signal(transiton);
						
					}
					
					jbpmContext.save(processInstance);
					if (log.isDebugEnabled())
					{
						//CHECKSTYLE:OFF
						log.info("New / Current state :"+stubWorkflow.getCurrentState().getName());
						//CHECKSTYLE:ON
					}
				
					// always send back the current context vars
					return context.getVariables();
				
				} catch (Exception t)
				{
					// proxy swallows runtime hence dual logging and throw
					log.error("Fatal workflow exception.", t.getCause() != null ? t.getCause() : t);
					throw new RuntimeException(t);
					
				}
			}};
		
		return this.commandService.execute(command);					
					
	}
	
}
