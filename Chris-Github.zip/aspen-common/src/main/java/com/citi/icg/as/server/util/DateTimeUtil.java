package com.citi.icg.as.server.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.collections.comparators.NullComparator;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.exception.GcasRuntimeException;

public final class DateTimeUtil {
	private DateTimeUtil() {
	}

	private static final Log LOG = LogFactory.getLog(DateTimeUtil.class);

	public static final String TIMEZONE_EUROPE_LONDON = "Europe/London";
	public static final String TIMEZONE_AMERICA_NEW_YORK = "America/New_York";
	public static final String TIMEZONE_ASIA_HONGKONG = "Asia/Hong_Kong";
	public static final String TIMEZONE_AUSTRALIA_SYDNEY = "Australia/Sydney";

	public static final TimeZone TIMEZONE_NAM = TimeZone.getTimeZone(TIMEZONE_AMERICA_NEW_YORK);
	public static final TimeZone TIMEZONE_EMEA = TimeZone.getTimeZone(TIMEZONE_EUROPE_LONDON);
	public static final TimeZone TIMEZONE_ASPAC = TimeZone.getTimeZone(TIMEZONE_ASIA_HONGKONG);
	public static final TimeZone TIMEZONE_APAC = TimeZone.getTimeZone(TIMEZONE_AUSTRALIA_SYDNEY);
	public static final TimeZone TIMEZONE_UTC = DateUtils.UTC_TIME_ZONE;

	public static final String DATE_FORMAT_DD_MM_YYYY = "dd/MM/yyyy";
	public static final String DATE_FORMAT_YYYY_MM_DD_WITH_DASH = "yyyy-MM-dd";
	public static final String DATE_FORMAT_YYYY_MM_DD_FULL_FORMAT = "yyyy-MM-dd HH:mm:ss,SSS";

	public static final String DATE_FORMAT_DD_MMM_YYYY_HH_MM_SS = "dd-MMM-yyyy HH:mm:ss";
	public static final String DATE_FORMAT_DD_MMM_YYYY = "dd-MMM-yyyy";

	public static final String NAM_REGION = "NAM";
	public static final String EMEA_REGION = "EMEA";
	public static final String ASPAC_REGION = "ASPAC";
	public static final String APAC_REGION = "APAC";
	public static final String UTC = "UTC";

	public static final int NINE_CLOCK = 9;
	public static final int ZERO_POINT = 0;

	private static final String USER_TIMEZONE = "user.timezone";

	/*
	 * ref IncomeConstants.DATE_FORMAT_yyyyMMdd
	 */
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyyMMdd";

	/*
	 * Throw an unchecked assertion error if the vm's default timezone is not UTC.
	 */
	public static void assertUTCTimeZone() {
		if (!UTC.equals(System.getProperty(USER_TIMEZONE))) {
			throw new GcasRuntimeException("Timezone must be set as \"UTC\". (java -Duser.timezone=UTC ...)");
		}
	}

	/**
	 * Returns the TimeZone for the region.
	 * 
	 * @param region
	 *            as String
	 * @return TimeZone
	 */
	public static TimeZone getTimeZone(String region) {
		TimeZone timeZone = TIMEZONE_NAM;

		if (StringUtils.equals(region, EMEA_REGION)) {
			timeZone = TIMEZONE_EMEA;
		} else if (StringUtils.equals(region, ASPAC_REGION)) {
			timeZone = TIMEZONE_ASPAC;
		} else if (StringUtils.equals(region, APAC_REGION)) {
			timeZone = TIMEZONE_APAC;
		} else if (StringUtils.equals(region, UTC)) {
			timeZone = TIMEZONE_UTC;
		}

		return timeZone;
	}

	/**
	 * Takes the given date and Time zone and returns the Date in UTC.
	 * 
	 * @param sourceDate
	 *            as Date
	 * @param srcTimeZone
	 *            as TimeZone
	 * @return Date in UTC.
	 */
	public static Date convertToUTC(Date sourceDate, TimeZone srcTimeZone) {
		Calendar toCal = Calendar.getInstance(TIMEZONE_UTC);

		if (sourceDate != null && srcTimeZone != null) {
			Calendar local = Calendar.getInstance(srcTimeZone);
			local.setTimeInMillis(sourceDate.getTime());

			toCal.setTimeInMillis(local.getTimeInMillis());
		}
		return toCal.getTime();
	}

	// copy from com.citi.icg.as.server.util.Util
	// convert the given date from a valid java date with
	// milliseconds since 01/01/1970 @ 00:00 UTC to an incorrect
	// representation with the epoch stated in the the destination
	// time zone. This method should almost never be used. Non-UTC
	// dates are wrong, and won't work as expected.
	public static Date convertDate(Date date, TimeZone toTimeZone) {
		Calendar localCalendar = Calendar.getInstance(toTimeZone);
		localCalendar.setTime(date);
		Calendar utcCalendar = Calendar.getInstance(TIMEZONE_UTC);

		int[] fieldsToUpdate = { Calendar.YEAR, Calendar.MONTH, Calendar.DAY_OF_MONTH, Calendar.HOUR_OF_DAY, Calendar.MINUTE, Calendar.SECOND, Calendar.MILLISECOND };

		for (int field : fieldsToUpdate) {
			utcCalendar.set(field, localCalendar.get(field));
		}

		return utcCalendar.getTime();
	}

	public static String formatDate(Date dt, String pattern) {
		if (null == dt) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(dt);
	}

	public static Date getDate(String strDate, String pattern) {
		try {
			if (StringUtils.isBlank(strDate) || StringUtils.isBlank(pattern)) {
				return null;
			}
			SimpleDateFormat sdf = new SimpleDateFormat(pattern);
			return sdf.parse(strDate);
		} catch (ParseException e) {
			LOG.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public static String getFormattedDate(Date dt) {
		String result = null;
		try {
			result = formatDate(dt, DATE_FORMAT_YYYY_MM_DD);
		} catch (Exception e) {
			LOG.error("Date Format Exception", e);
		}
		return result;
	}

	public static Date getFormattedDate(String dt, String pattern) {
		Date result = null;
		try {
			result = getDate(dt, pattern);
		} catch (Exception e) {
			LOG.error("Date Format Exception", e);
		}
		return result;
	}

	public static Date getDateWithoutTime(Date dt) {
		Date result = null;
		try{
			result = getDate(formatDate(dt, DATE_FORMAT_YYYY_MM_DD), DATE_FORMAT_YYYY_MM_DD);
		} catch(Exception e) {
			LOG.error("Parsing Exception", e);
		}
		return result;
	}

	public static Calendar getCalendar(Calendar calendar) {
		if (calendar == null) {
			calendar = Calendar.getInstance();
		}
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar;
	}

	/**
	 * Return true if the provided Dates fall on same Calendar day of the given TimeZone.
	 */
	public static boolean isSameDay(final Date d1, final Date d2, final TimeZone tz) {
		Calendar c1 = Calendar.getInstance(tz);
		Calendar c2 = Calendar.getInstance(tz);
		c1.setTime(d1);
		c2.setTime(d2);
		return DateUtils.isSameDay(c1, c2);
	}

	public static Comparator<Date> createDayComparator(final TimeZone tz) {
		return createDayComparator(tz, false);
	}

	/**
	 * Return a comparator which compares the day portion only of two dates. The day is determined within the given timezone.
	 */
	@SuppressWarnings("unchecked")
	public static Comparator<Date> createDayComparator(final TimeZone tz, final boolean nullsAreHigh) {
		final Comparator<Date> nullComparator = new NullComparator(nullsAreHigh);
		return new Comparator<Date>() {
			public int compare(Date arg0, Date arg1) {
				if (arg0 == null || arg1 == null) {
					return nullComparator.compare(arg0, arg1);
				} else {
					Calendar c1 = Calendar.getInstance(tz);
					Calendar c2 = Calendar.getInstance(tz);
					c1.setTime(arg0);
					c2.setTime(arg1);
					c1 = DateUtils.truncate(c1, Calendar.DAY_OF_MONTH);
					c2 = DateUtils.truncate(c2, Calendar.DAY_OF_MONTH);
					return c1.compareTo(c2);
				}
			}
		};
	}

	/**
	 * Calculate the the working days (excluding weekends) between date1 and date2, only correct to Date portion
	 * 
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static int calculateWorkdates(Date date1, Date date2, TimeZone tiemZone) {
		Calendar calendar1 = Calendar.getInstance();
		calendar1.setTime(date1);
		calendar1.setTimeZone(tiemZone);

		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(date2);
		calendar2.setTimeZone(tiemZone);

		Calendar startDate = truncateDate(calendar1);
		Calendar endDate = truncateDate(calendar2);

		long dayMillisecond = 1000 * 60 * 60 * 24L;
		long weekMillisecond = dayMillisecond * 7L;
		int startDayOffset = startDate.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;
		int endDayOffset = endDate.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;
		int adjustValue = endDayOffset < startDayOffset ? 5 : 0;
		long diff = endDate.getTimeInMillis() - startDate.getTimeInMillis();
		long workdates = diff / weekMillisecond * 5 + (Math.max(1, endDayOffset) - Math.max(1, startDayOffset)) + adjustValue;
		return (int) workdates;
	}

	/**
	 * retain the year, month, and date values others set as zero.
	 * 
	 * @param calendar
	 * @return
	 */
	public static Calendar truncateDate(Calendar calendar) {
		calendar.add(Calendar.MILLISECOND, -calendar.get(Calendar.MILLISECOND));
		calendar.add(Calendar.SECOND, -calendar.get(Calendar.SECOND));
		calendar.add(Calendar.MINUTE, -calendar.get(Calendar.MINUTE));
		calendar.add(Calendar.HOUR_OF_DAY, -calendar.get(Calendar.HOUR_OF_DAY));
		return calendar;
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	public static boolean isWeekend(Date date, TimeZone timeZone) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.setTimeZone(timeZone);
		return isWeekend(calendar);
	}

	public static boolean isWeekend(Calendar calendar) {
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		return dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY;
	}

	public static boolean isNotWeekend(Date date, TimeZone timeZone) {
		return !(isWeekend(date, timeZone));
	}

	public static boolean isNotWeekend(Calendar calendar) {
		return !(isWeekend(calendar));
	}

	public static Date computeSameRegionDayByUTCDay(String region, Date utcDay) {

		TimeZone timeZoneUTC = DateTimeUtil.getTimeZone(DateTimeUtil.UTC);
		Calendar calUTC = Calendar.getInstance(timeZoneUTC);

		TimeZone timeZoneRegion = DateTimeUtil.getTimeZone(region);
		Calendar calRegion = Calendar.getInstance(timeZoneRegion);

		calUTC.setTime(utcDay);
		calRegion.set(calUTC.get(Calendar.YEAR), calUTC.get(Calendar.MONTH), calUTC.get(Calendar.DATE), ZERO_POINT, ZERO_POINT, ZERO_POINT);
		calRegion.set(Calendar.MILLISECOND, ZERO_POINT);

		return calRegion.getTime();
	}

	public static Calendar deOrIncreaseWeekDay(Calendar calendar, int dayOffset) {

		if (dayOffset == 0) {
			return calendar;
		}

		int dayOffsetAbs = Math.abs(dayOffset);
		int step = dayOffset < 0 ? -1 : 1;

		for (int i = 0; i < dayOffsetAbs; i++) {
			calendar.add(Calendar.DAY_OF_YEAR, step);
			while (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
				calendar.add(Calendar.DAY_OF_YEAR, step);
			}
		}

		return calendar;
	}

	/**
	 * Find out previous weekday, If Today is Monday or Sunday then return Friday 
	 * @return
	 */
	public static Date getPreviousWeekDay() {
		Calendar cal = Calendar.getInstance();		
		int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		
		if(Calendar.MONDAY == dayOfWeek)
			cal.add(Calendar.DATE, -3);
		else if(Calendar.SUNDAY == dayOfWeek)
			cal.add(Calendar.DATE, -2);
		else
			cal.add(Calendar.DATE, -1);
		
		return cal.getTime();
	}
}
