package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;
import com.citi.icg.aspenlogger.Loggable;

public class LegalEntity extends BaseBusinessEntity implements Loggable {

	private static final long serialVersionUID = -391784616339317566L;

	private int pkLegalEntityId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String legalEntityCode;
	private String legalEntityName;
	private String aliasName;
	private String cairoFilterFlag;
	private String onOffShore;
	private String withholdingAgentRole;
	private String entityLocationCountry;
	private String swtEligibility;
	private String processingUnit;

	public int getPkLegalEntityId() {
		return pkLegalEntityId;
	}

	public void setPkLegalEntityId(int pkLegalEntityId) {
		this.pkLegalEntityId = pkLegalEntityId;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLegalEntityCode() {
		return legalEntityCode;
	}

	public void setLegalEntityCode(String legalEntityCode) {
		this.legalEntityCode = legalEntityCode;
	}

	public String getLegalEntityName() {
		return legalEntityName;
	}

	public void setLegalEntityName(String legalEntityName) {
		this.legalEntityName = legalEntityName;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	@Override
	public Integer getId() {
		return getPkLegalEntityId();
	}

	public void setCairoFilterFlag(String cairoFilterFlag) {
		this.cairoFilterFlag = cairoFilterFlag;
	}

	public String getCairoFilterFlag() {
		return cairoFilterFlag;
	}

	public String getOnOffShore() {
		return onOffShore;
	}

	public void setOnOffShore(String onOffShore) {
		this.onOffShore = onOffShore;
	}

	public String getWithholdingAgentRole() {
		return withholdingAgentRole;
	}

	public void setWithholdingAgentRole(String withholdingAgentRole) {
		this.withholdingAgentRole = withholdingAgentRole;
	}

	public String getEntityLocationCountry() {
		return entityLocationCountry;
	}

	public void setEntityLocationCountry(String entityLocationCountry) {
		this.entityLocationCountry = entityLocationCountry;
	}

	public String getSwtEligibility() {
		return swtEligibility;
	}

	public void setSwtEligibility(String swtEligibility) {
		this.swtEligibility = swtEligibility;
	}

	public String getProcessingUnit() {
		return processingUnit;
	}

	public void setProcessingUnit(String processingUnit) {
		this.processingUnit = processingUnit;
	}

	@Override
	public String toString() {
		return "LegalEntity [legalEntityCode=" + legalEntityCode + ", legalEntityName=" + legalEntityName + "]";
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		LegalEntity that = (LegalEntity) o;

		if (pkLegalEntityId != that.pkLegalEntityId)
			return false;
		if (lastUpdatedBy != null ? !lastUpdatedBy.equals(that.lastUpdatedBy) : that.lastUpdatedBy != null)
			return false;
		if (lastUpdatedDate != null ? !lastUpdatedDate.equals(that.lastUpdatedDate) : that.lastUpdatedDate != null)
			return false;
		if (legalEntityCode != null ? !legalEntityCode.equals(that.legalEntityCode) : that.legalEntityCode != null)
			return false;
		if (legalEntityName != null ? !legalEntityName.equals(that.legalEntityName) : that.legalEntityName != null)
			return false;
		if (aliasName != null ? !aliasName.equals(that.aliasName) : that.aliasName != null)
			return false;
		if (cairoFilterFlag != null ? !cairoFilterFlag.equals(that.cairoFilterFlag) : that.cairoFilterFlag != null)
			return false;
		if (onOffShore != null ? !onOffShore.equals(that.onOffShore) : that.onOffShore != null)
			return false;
		if (withholdingAgentRole != null ? !withholdingAgentRole.equals(that.withholdingAgentRole) : that.withholdingAgentRole != null)
			return false;
		if (processingUnit != null ? !processingUnit.equals(that.processingUnit) : that.processingUnit != null)
			return false;
		return entityLocationCountry != null ? entityLocationCountry.equals(that.entityLocationCountry) : that.entityLocationCountry == null;

	}

	@Override
	public int hashCode() {
		int result = pkLegalEntityId;
		int prime = 337;
		result = prime * result + (lastUpdatedBy != null ? lastUpdatedBy.hashCode() : 0);
		result = prime * result + (lastUpdatedDate != null ? lastUpdatedDate.hashCode() : 0);
		result = prime * result + (legalEntityCode != null ? legalEntityCode.hashCode() : 0);
		result = prime * result + (legalEntityName != null ? legalEntityName.hashCode() : 0);
		result = prime * result + (aliasName != null ? aliasName.hashCode() : 0);
		result = prime * result + (cairoFilterFlag != null ? cairoFilterFlag.hashCode() : 0);
		result = prime * result + (onOffShore != null ? onOffShore.hashCode() : 0);
		result = prime * result + (withholdingAgentRole != null ? withholdingAgentRole.hashCode() : 0);
		result = prime * result + (entityLocationCountry != null ? entityLocationCountry.hashCode() : 0);
		result = prime * result + (processingUnit != null ? processingUnit.hashCode() : 0);
		return result;
	}

	public String toLogString() {
		return this.toString();
	}
}
