package com.citi.icg.as.common.client.exception;

import java.util.Date;

import com.google.gwt.user.client.rpc.IsSerializable;

@SuppressWarnings("serial")
public class GcasUIException extends Exception implements IsSerializable {
	private static final int INT_1000 = 1000;
	private long trackingNo;
	private String message;
	private String details;

	public GcasUIException() {

	}

	public GcasUIException(String message, String stackDetails) {
		setMessage(message);
		this.details = stackDetails;
		this.trackingNo = (new Date().getTime() / INT_1000);
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public long getTrackingNo() {
		return trackingNo;
	}
}
