package com.citi.icg.as.common.dao;

import java.util.List;

import com.citi.icg.as.core.dao.entities.business.User;
import com.citi.icg.as.core.dao.entities.business.UserAttribute;
import com.citi.icg.as.core.dao.entities.business.UserProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.UserRegion;
import com.citi.icg.as.core.dao.entities.business.UserSavedSearches;

public interface UserDao {

	User getUser(String userId);

	List<UserAttribute> getAttributesForUserId(String userId);

	User mergeUser(User usr);

	List<UserAttribute> getUserAttributes(String attributeCode);

	List<User> getUsers();

	List<UserSavedSearches> getUserSavedSearchesByExample(UserSavedSearches bean);

	void saveOrUpdateUserSavedSearches(UserSavedSearches bean);

	List<User> addUsers(List<User> userList);

	void removeUsers(List<User> userList);

	List<UserSavedSearches> getDateSaveSearchData(String queueType, String userSearchId);

	UserSavedSearches getDateSaveSearchLayout(String queueType, String userId, String searchName, String searchId);

	void removeDateSearchLayout(String queueType, String userId, String gridName);

	UserProcessingUnit getUserProcessingUnitFromDb(UserProcessingUnit pu);

	UserRegion getUserRegionFromDb(UserRegion userRegion);
}
