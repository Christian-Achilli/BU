package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.ext.beans.Role;
import com.citi.icg.as.core.dao.entities.ext.beans.User;

@MappedSuperclass
@Table(name = "USER_ROLE", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseUserRole extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 2235441488096336399L;

	private int pkUserRoleId;
	private Role role;
	private User user;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;

	public BaseUserRole() {
	}

	public BaseUserRole(Role role, User user, Date lastUpdatedDate) {
		this.role = role;
		this.user = user;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public BaseUserRole(Role role, User user, String lastUpdatedBy, Date lastUpdatedDate) {
		this.role = role;
		this.user = user;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Id
	@GeneratedValue(strategy = javax.persistence.GenerationType.SEQUENCE, generator = "generator")
	@javax.persistence.SequenceGenerator(name = "generator", sequenceName = "SEQ_USER_ROLE", allocationSize = 1)
	@Column(name = "PK_USER_ROLE_ID", unique = true, nullable = false)
	public int getPkUserRoleId() {
		return this.pkUserRoleId;
	}

	public void setPkUserRoleId(int pkUserRoleId) {
		this.pkUserRoleId = pkUserRoleId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_ROLE_ID", nullable = false)
	public Role getRole() {
		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_USER_ID", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Column(name = "LAST_UPDATED_BY", length = 50)
	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Column(name = "LAST_UPDATED_DATE", nullable = false, length = 23)
	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
