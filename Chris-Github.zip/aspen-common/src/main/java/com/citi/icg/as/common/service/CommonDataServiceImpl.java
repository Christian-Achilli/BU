package com.citi.icg.as.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.citi.icg.as.common.dao.CommonDataDao;
import com.citi.icg.as.common.dao.UserDao;
import com.citi.icg.as.common.enums.AnnouncementCopyTypeEnum;
import com.citi.icg.as.core.dao.entities.business.AnnouncementCopyType;
import com.citi.icg.as.core.dao.entities.business.CountryCode;
import com.citi.icg.as.core.dao.entities.business.CurrencyCode;
import com.citi.icg.as.core.dao.entities.business.FXRate;
import com.citi.icg.as.core.dao.entities.business.LegalEntity;
import com.citi.icg.as.core.dao.entities.business.ProcessingUnit;
import com.citi.icg.as.core.dao.entities.business.User;
import com.citi.icg.as.server.GcasRequestContext;
import com.citi.icg.as.server.util.GcasConstants;

@Service
public class CommonDataServiceImpl implements CommonDataService {

	private static final Logger log = Logger.getLogger(CommonDataServiceImpl.class);
	
	@Resource private UserDao commonUserDao;
	@Resource private CommonDataDao commonDataDao;

	private List<LegalEntity> legalEntityListCache;
	private List<LegalEntity> legalEntityListForBRCache;
	private Set<ProcessingUnit> processingUnitsCache;
	
	@PostConstruct
	private void initialise(){
		legalEntityListCache = commonDataDao.getAllDefaultLegalEntities();
		legalEntityListForBRCache = commonDataDao.getAllLegalEntitiesForBR();
		processingUnitsCache = commonDataDao.getProcessingUnits();
	}
	
	@Override
	public User getCurrentUser() {
		User usr = commonUserDao.getUser(GcasRequestContext.getUserId());
		if (usr == null) {
			log.info("~~~~~~~~~~ The user was not found through the DAO ~~~~~~~~~~");
			usr = new User();
			usr.setUserId(GcasRequestContext.getUserId());
		}
		log.info("~~~~~~~~~~ The current user id in the GCAS context is: "+GcasRequestContext.getUserId()+" and the related soeid is "+usr.getSoeId());
		return usr;
	}

	@Override
	public Integer executeUpdateSQL(String query, Map<String, ? extends Object> params) {
		return commonDataDao.executeUpdateSQL(query, params);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List executeSQL(String query) {
		return commonDataDao.executeSQL(query);
	}

	@Override
	public User getUser(String userId) {
		return commonUserDao.getUser(userId);
	}

	@Override
	public List<String> getNodeNames(String clusterName) {
		return commonDataDao.getNodeNames(clusterName);
	}
	
	@Override
	public AnnouncementCopyType getQualifier(AnnouncementCopyTypeEnum item){
		return commonDataDao.getQualifier(item);
	}

	@Override
	public List<CurrencyCode> getCurrencyCodesList() {
		return commonDataDao.getCurrencyCodesList();
	}

	@Override
	public int countDataRows(Class<?> entityClass) {
		return commonDataDao.countDataRows(entityClass);
	}

	@Override
	public <T> List<T> fetchData(Class<T> entityClass, int startRow, int pageSize) {
		return commonDataDao.fetchData(entityClass, startRow, pageSize);
	}

	@Override
	public <T> List<T> fetchData(Class<T> entityClass) {
		return commonDataDao.fetchData(entityClass);
	}

	@Override
	public List<FXRate> getCurrencyFxRate(String termCurrency,String baseCurrency){
		return commonDataDao.getCurrencyFxRate(termCurrency,baseCurrency);
	}

	@Override
	public CountryCode getCountry(String alphaCode) {
		return commonDataDao.getCountry(alphaCode);
	}
	
	/**
	 * 1- aspen-3203 moved from position data service
	 * 2- Get the legal entity list for DEFAULT PUs (PB Equity, Main Firm Equity, Swaps, Fixed Income)
	 * 
	 * @return legal entities that not from cairo and with empty alias name
	 */
	@Override
	public List<LegalEntity> getLegalEntities() {
		List<LegalEntity> result = new ArrayList<>();
		for (LegalEntity legalEntity : legalEntityListCache) {
			if (!GcasConstants.Y.equals(legalEntity.getCairoFilterFlag()) && legalEntity.getAliasName() == null) {
				result.add(legalEntity);
			}
		}
		return result;
	}
	
	/**
	 * Get the legal entity list only for CGMI Broadridge PU
	 * @return 
	 */
	@Override
	public List<LegalEntity> getLegalEntitiesForBR() {
		List<LegalEntity> result = new ArrayList<>();
		for (LegalEntity legalEntity : legalEntityListForBRCache) {
			if (!GcasConstants.Y.equals(legalEntity.getCairoFilterFlag()) && legalEntity.getAliasName() == null) {
				result.add(legalEntity);
			}
		}
		return result;
	}
	
	@Override
	public LegalEntity getLegalEntity(int legalEntityId) {
		for (LegalEntity legalEntity : legalEntityListCache) {
			if (legalEntityId == legalEntity.getPkLegalEntityId()) {
				return legalEntity;
			}
		}
		return null;
	}
	
	@Override
	public Map<String, LegalEntity> getAllLegalEntityFiterAliasName() {
		Map<String, LegalEntity> legalEntitiesWithoutAlianNameMap = new HashMap<String, LegalEntity>();
		for (LegalEntity legalEntity : legalEntityListCache) {
			String legalEntityCode = legalEntity.getLegalEntityCode();
			if(legalEntity.getAliasName() == null){
				legalEntitiesWithoutAlianNameMap.put(legalEntityCode, legalEntity);
			}
		}
		return legalEntitiesWithoutAlianNameMap;
	}
	
	@Override
	public LegalEntity getLegalEntityByCode(String code) {
		List<LegalEntity> allLegalEntityListCache = legalEntityListCache;
		allLegalEntityListCache.addAll(legalEntityListForBRCache);
		for (LegalEntity legalEntity : allLegalEntityListCache) {
			String legalEntityCode = legalEntity.getLegalEntityCode();
			if(legalEntity.getAliasName() == null && legalEntityCode.equalsIgnoreCase(code)){
				return legalEntity;
			}
		}
		return null;
	}
	
	@Override
	public List<ProcessingUnit> getProcessingUnits() {
		List<ProcessingUnit> processingUnits = new ArrayList<ProcessingUnit>();
		processingUnits.addAll(processingUnitsCache);
		if (CollectionUtils.isEmpty(processingUnitsCache)) {
			log.error("there is no pu catched,please check database");
		}
		return processingUnits;
	}
	
}
