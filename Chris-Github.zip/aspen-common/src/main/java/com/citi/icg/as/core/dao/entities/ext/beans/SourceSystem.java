package com.citi.icg.as.core.dao.entities.ext.beans;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.citi.icg.as.core.dao.entities.base.beans.BaseSourceSystem;

@Entity
@Table(name = "SOURCE_SYSTEM", uniqueConstraints = @UniqueConstraint(columnNames = "SOURCE_NAME"))
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY, region = "hibernate.STATIC_DATA")
public class SourceSystem extends BaseSourceSystem {

	private static final long serialVersionUID = -4982213230346233319L;

}
