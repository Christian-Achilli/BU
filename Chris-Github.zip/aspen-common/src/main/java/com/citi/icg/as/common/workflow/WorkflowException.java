package com.citi.icg.as.common.workflow;

public class WorkflowException extends RuntimeException {
	
	public WorkflowException(String message) {
        super(message);
    }
	
	public WorkflowException(String message, Throwable cause) {
        super(message, cause);
    }
}
