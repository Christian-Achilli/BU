package com.citi.icg.as.core.entities.constants;

public class UserSavedSearchesConstant {
	public static final String GRID_LAYOUT_DATA = "gridLayoutData";
	public static final String DEBUG_STRING = "debugString";
	public static final String QUEUE_TYPE = "queueType";
	public static final String FK_USER_ID = "fkUserId";
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String SEARCH_NAME = "searchName";
	public static final String VALUE = "value";
	public static final String CLASS = "class";
	public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
	public static final String SEARCH_DATA = "searchData";
	public static final String PK_SEARCH_ID = "pkSearchId";
}