package com.citi.icg.as.common.enums;

/**
 * Source System.
 */
public enum SourceSystemEnum {
	// CHECKSTYLE:OFF
	DAS {
		public Integer getPkSourceID() {
			return Integer.valueOf(1);
		}

		public String getSourceCode() {
			return "1";
		}

		public String getSourceName() {
			return "DAS";
		}
	},

	MANUAL {
		public Integer getPkSourceID() {
			return Integer.valueOf(2);
		}

		public String getSourceCode() {
			return "2";
		}

		public String getSourceName() {
			return "MANUAL";
		}
	},

	CSL {
		public Integer getPkSourceID() {
			return Integer.valueOf(3);
		}

		public String getSourceCode() {
			return "3";
		}

		public String getSourceName() {
			return "CSL";
		}
	},

	CAIRO {
		public Integer getPkSourceID() {
			return Integer.valueOf(4);
		}

		public String getSourceCode() {
			return "4";
		}

		public String getSourceName() {
			return "CAIRO";
		}
	},

	MERVA {
		public Integer getPkSourceID() {
			return Integer.valueOf(5);
		}

		public String getSourceCode() {
			return "5";
		}

		public String getSourceName() {
			return "MERVA";
		}
	},

	GCA {
		public Integer getPkSourceID() {
			return Integer.valueOf(7);
		}

		public String getSourceCode() {
			return "7";
		}

		public String getSourceName() {
			return "GCA";
		}
	},
	MATRIX {
		public Integer getPkSourceID() {
			return Integer.valueOf(8);
		}

		public String getSourceCode() {
			return "8";
		}

		public String getSourceName() {
			return "MATRIX";
		}
	},
	EQUAL {
		public Integer getPkSourceID() {
			return Integer.valueOf(9);
		}

		public String getSourceCode() {
			return "9";
		}

		public String getSourceName() {
			return "EQUAL";
		}
	},
	EMC {
		public Integer getPkSourceID() {
			return Integer.valueOf(10);
		}

		public String getSourceCode() {
			return "10";
		}

		public String getSourceName() {
			return "EMC";
		}
	},
	GPDW {
		public Integer getPkSourceID() {
			return Integer.valueOf(11);
		}

		public String getSourceCode() {
			return "11";
		}

		public String getSourceName() {
			return "GPDW";
		}
	},
	SECORE {
		public Integer getPkSourceID() {
			return Integer.valueOf(12);
		}

		public String getSourceCode() {
			return "12";
		}

		public String getSourceName() {
			return "SECORE";
		}
	},
	AMC {
		public Integer getPkSourceID() {
			return Integer.valueOf(13);
		}

		public String getSourceCode() {
			return "13";
		}

		public String getSourceName() {
			return "AMC";
		}
	};
	;
	// CHECKSTYLE:ON

	public abstract Integer getPkSourceID();

	public abstract String getSourceCode();

	public abstract String getSourceName();
}
