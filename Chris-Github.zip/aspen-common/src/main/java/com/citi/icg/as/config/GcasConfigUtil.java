package com.citi.icg.as.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.citi.icg.as.exception.GcasError;
import com.citi.icg.as.exception.GcasException;

public final class GcasConfigUtil {
	private static final String EXT_XML = ".xml";
	private static final String JNDI_PREFIX = "java:/comp/env/icg/configuration/";
	public static final String CONFIG_FILE_PROPRTY_PREFIX = "icg.configuration.";
	public static final String NAME_PREFIX = "configuration";
	public static final String DELIMETER = "-";

	private static final Log LOG = LogFactory.getLog(GcasConfigUtil.class);

	private GcasConfigUtil() {
	}

	public static <T> T newInstance(Class<T> classToCreate) {
		T instance = null;
		try {
			instance = classToCreate.newInstance();
		} catch (InstantiationException e) {
			throw new GcasError("Error creating instance of [" + classToCreate.getCanonicalName() + "]", e);
		} catch (IllegalAccessException e) {
			throw new GcasError("Error creating instance of [" + classToCreate.getCanonicalName() + "]", e);
		}
		return instance;
	}

	public static <T extends XMLConfiguration> T getInstance(Class<T> configurationClass) {
		try {
			// 1. instantiate
			T instance = newInstance(configurationClass);

			// 2. load config
			// Get the configuration name.
			String name = getConfigName(configurationClass);
			return getInstance(instance, name);
		} catch (GcasError e) {
			LOG.error("Could not load from configuration. " + e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			LOG.error("Could not load from configuration. " + e.getMessage(), e);
			throw new GacsConfigurationException(e.getMessage(), e);
		}
	}

	public static <T extends XMLConfiguration> T getInstance(T instance, String name) {
		try {
			String configFileName = getConfigFileName(name.trim(), true);
			InputStream configStream = getConfigFileStream(configFileName);
			// If Env specific file is not present. Look for the file with the
			// same name.
			if (configStream == null) {
				configStream = getConfigFileStream(name.trim() + EXT_XML);
			}

			// if still null try without an environment override
			if (configStream == null) {
				configFileName = getConfigFileName(name.trim(), false);
				configStream = getConfigFileStream(configFileName);
			}

			instance.setDelimiterParsingDisabled(true); // Required to parse
														// delimited values
			instance.load(configStream);

			return instance;
		} catch (Error e) {
			LOG.error("Could not load from configuration. " + e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			LOG.error("Could not load from configuration. " + e.getMessage(), e);
			throw new GacsConfigurationException(e.getMessage(), e);
		}
	}

	@SuppressWarnings("unchecked")
	public static <T> T getInstanceFromName(String className, Class<T> baseType) throws GcasException {
		Class<?> clazzInstance = getClass(className);
		if (!baseType.isAssignableFrom(clazzInstance)) {
			throw new GcasException("Type [" + className + "] does not implement base type " + baseType.getClass().getName());
		}
		T objInstance = (T) newInstance(clazzInstance);
		return objInstance;

	}

	@SuppressWarnings("unchecked")
	public static <T> T getInstanceFromName(String className) throws GcasException {
		Class<?> clazzInstance = getClass(className);
		T objInstance = (T) newInstance(clazzInstance);
		return objInstance;
	}

	@SuppressWarnings("unchecked")
	public static <T> Class<T> getClass(String className) {
		try {
			return ClassUtils.getClass(className);
		} catch (ClassNotFoundException e) {
			throw new GcasError("Error loading class name [" + className + "]", e);
		}
	}

	public static <T extends XMLConfiguration> T getInstance(T instance, String name, boolean isConfigurable) {
		return getInstance(instance, name);
	}

	public static <T> InputStream getConfigFileStream(String configFileName) throws Exception {
		LOG.info("Loading config file : " + configFileName + " from file " + configFileName);

		// If did not load as resource, then load directly from file system.
		InputStream configStream = null;
		try {
			// Check as a direct filename.
			File file = new File(configFileName);
			if (file.exists()) {
				configStream = new FileInputStream(file);
			}

			// check if the file exists in the app config dir if defined.
			if (configStream == null && configFileName.indexOf("gcasapp") == -1) {
				String appConfigDir = getAppConfigDirectory();
				if (StringUtils.isNotBlank(appConfigDir)) {
					file = new File(appConfigDir, configFileName);
					if (file.exists()) {
						LOG.info("config file exists in appConfigDir " + appConfigDir + "/" + configFileName);
						configStream = new FileInputStream(file);
					}
				}
			}

			// look up in the class path.
			// read the config file that has the app config dir defined - change
			// specific to GCAS
			if (configStream == null) {
				LOG.info("look up in class path " + configFileName);
				configStream = GcasConfigUtil.class.getClassLoader().getResourceAsStream(configFileName);
				LOG.info("configStream = " + configStream);
			}
		} catch (Exception e) {
			LOG.warn(e.getMessage());
			throw e;
		}
		return configStream;
	}

	private static final String CONFIG_DIRECTORY_PROPERTY = "gcas.config.folder";

	private static String getAppConfigDirectory() {

		Properties props = null;
		String appConfigDir = StringUtils.EMPTY;

		// 1. Check for a system variable configuration.directory.
		appConfigDir = System.getProperty(CONFIG_DIRECTORY_PROPERTY);

		// 2. Check for a env property configuration.directory.
		if (StringUtils.isEmpty(appConfigDir)) {
			appConfigDir = System.getenv(CONFIG_DIRECTORY_PROPERTY);
		}

		// 3. If not found, Check for XML file called configuration-gcasapp.xml.
		// This looks for an xml file in the root of classpath.
		if (StringUtils.isEmpty(appConfigDir)) {

			// TODO String appContextPath = AppContext.getContextPath();
			String appContextPath = StringUtils.EMPTY;
			LOG.debug("appContextPath=" + appContextPath);
			try {
				if (appContextPath != null) {
					props = new Properties();
					FileInputStream fis = new FileInputStream(new File("config.properties"));
					props.load(fis);
					appConfigDir = props.getProperty(appContextPath);
					LOG.info("applicationConfigDir from config.properties file=" + appConfigDir);
					fis.close();
				}
			} catch (IOException ioex) {
				LOG.error("Exception while reading config.properties=" + ioex);
			}

			if (StringUtils.isBlank(appConfigDir)) {
				appConfigDir = GCASAppConfiguration.getInstance().getAppConfigDir();
				LOG.error("appConfigDir from config file : " + appConfigDir);
			}

		}

		LOG.debug("appConfigDir : " + appConfigDir);
		return appConfigDir;
	}

	public static String getConfigFileName(String configName, boolean useOverride) {
		String filename = null;

		// 1. Look for file name from jndi.
		String jndiName = JNDI_PREFIX + configName;
		try {
			LOG.debug("Looking " + configName + " configuration filename from JNDI name: " + jndiName);
			Context context = new InitialContext();
			filename = (String) context.lookup(jndiName);
			LOG.info("Found " + configName + " configuration filename from JNDI: " + filename);
		} catch (NamingException exIgnore) {
			LOG.error("Could not find " + configName + " configurationin jndi ");
		}

		// Look for file name from system property
		if (filename == null) {
			String sysPropertyName = CONFIG_FILE_PROPRTY_PREFIX + configName;
			LOG.error("Looking " + configName + "configuration filename from system property." + sysPropertyName);
			filename = System.getProperty(sysPropertyName);
			if (filename != null) {
				LOG.info("Found " + configName + " configuration filename from system property: " + filename);
			}
		}
		if (filename == null) {
			// If still null, use default config file name
			// format=configuration-name-env.xml
			if (useOverride) {
				filename = NAME_PREFIX + DELIMETER + configName + DELIMETER + ConfigEnv.getEnvironment() + EXT_XML;
			} else {
				filename = NAME_PREFIX + DELIMETER + configName + EXT_XML;
			}

			LOG.fatal("Could not find " + configName + " system propery. use default:" + filename);
		}
		return filename;
	}

	public static String getConfigName(Class configClass) {
		String name = configClass.getSimpleName().toLowerCase();
		if (name.startsWith("icg")) {
			name = name.substring("icg".length());
		}
		if (name.endsWith("config")) {
			name = name.substring(0, name.length() - "config".length());
		}
		if (name.endsWith(NAME_PREFIX)) {
			name = name.substring(0, name.length() - NAME_PREFIX.length());
		}
		if (name.endsWith("configurations")) {
			name = name.substring(0, name.length() - "configurations".length());
		}
		return name;
	}
}
