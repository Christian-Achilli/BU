package com.citi.icg.as.core.dao.entities.business;

import java.util.Date;

import com.citi.icg.as.common.client.entities.BaseBusinessEntity;

public class AnnouncementCopyType extends BaseBusinessEntity {

	private static final long serialVersionUID = -3779060187760581145L;
	private int pkQualifierId;
	private String lastUpdatedBy;
	private Date lastUpdatedDate;
	private String qualifierName;

	public int getPkQualifierId() {
		return pkQualifierId;
	}

	public void setPkQualifierId(int pkQualifierId) {
		this.pkQualifierId = pkQualifierId;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getQualifierName() {
		return qualifierName;
	}

	public void setQualifierName(String qualifierName) {
		this.qualifierName = qualifierName;
	}

	@Override
	public Integer getId() {
		return getPkQualifierId();
	}

}
