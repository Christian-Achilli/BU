package com.citi.icg.as.common.servlet;

/**
 * Created by cd68076 on 23/02/2017.
 */
public class Tuple {

    private final int left;
    private final int right;

    Tuple(int left, int right) {
        this.left = left;
        this.right = right;
    }

    public int getLeft() {
        return this.left;
    }
    public int getRight() {
        return this.right;
    }

    @Override
    public String toString() {
        return "Tuple{" +
                "left=" + left +
                ", right=" + right +
                '}';
    }
}
