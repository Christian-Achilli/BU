package com.citi.icg.as.common.client.compare;

import java.io.Serializable;

public interface CompareResultVisitor extends Serializable {
	void startBeanResult(String propertyName, CompareResult compareResult);

	void endBeanResult(String propertyName, CompareResult compareResult);

	void startCollectionResult(String propertyName, CompareResult[] compareResults);

	void endCollectionResult(String propertyName, CompareResult[] compareResults);

	void acceptProperty(String propertyName);
}
