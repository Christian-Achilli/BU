/**
 * 
 */
package com.citi.icg.as.server.common.config;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.util.Assert;

/**
 * @author AP72338
 *         <p>
 *         The class gives handle to the resolved properties map, which we need
 *         to use later to configure the XML files. If there are no XML
 *         configuration files, then we can use
 *         {@link PropertyPlaceholderConfigurer} only
 *         </p>
 */

public class AspenPropertyPlaceHolderConfigurer extends PropertyPlaceholderConfigurer {

	private Map<String, String> propertiesMap;
	public static final String ASPEN_STREAM = "aspen.stream";
	public static final String ASPEN_ENV = "aspen.env";
	public static final String PROPERTIES = ".properties";
	public static final String STREAM_PROPERTIES = "stream" + PROPERTIES;
	public static final String CONFIG_FOLDER = "config";
	public static final String PATH_SEPARATOR = "/";
	public static final String CONFIG_BUILD = CONFIG_FOLDER + PATH_SEPARATOR + "build.";
	public static final String GWT_HOST_FOLDER = "gwt_host_folder";
	public static final String MARKETS_GWT_HOME = "marketsassetservicing";
	public static final String CUSTODY_GWT_HOME = "custodyassetservicing";
	public static final String LOCAL = "local";
	public static final String MARKETS = "markets";
	public static final String CUSTODY = "custody";
	public static final String PROD_ENV = "prod";

	/**
	 * it's the key that can be used t retrieve the icg-config-*.xml file to be used at runtime, whether h2 or oracle
	 */
	public static final String ICG_CONFIG_XML_NAME = "ICG_CONFIG_XML_FILE_NAME";
	
	public Map<String, String> getPropertiesMap() {
		return propertiesMap;
	}

	public AspenPropertyPlaceHolderConfigurer() {
		super();
		Assert.isTrue(StringUtils.isNotBlank(System.getProperty(ASPEN_ENV)),
				"System property\"aspen.env\" must be set (local;uat1;qa3 etc). "
						+ "For local while running jetty use mvn jetty:run -Daspen.env=local."
						+ "Also while running tests in Eclipse, set it as VM argument.");
		String stream = System.getProperty(ASPEN_STREAM);
		Assert.isTrue(StringUtils.isNotBlank(stream),
				"System property\"aspen.stream\" must be set {markets|custody|funds}. "
						+ "For local while running jetty use mvn jetty:run -Daspen.stream={markets|custody}."
						+ "Also while running tests in Eclipse, set it as VM argument.");

		propertiesMap = new HashMap<String, String>();
		System.setProperty(ICG_CONFIG_XML_NAME, System.getProperty(ASPEN_ENV).equals("local") ? "icg-config-h2."+ stream +".xml" : "icg-config-oracle."+ stream +".xml");
	}

	@Override
	public void setSystemPropertiesMode(int systemPropertiesMode) {
		super.setSystemPropertiesMode(systemPropertiesMode);
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props)
			throws BeansException {
		super.processProperties(beanFactory, props);

		for (Object key : props.keySet()) {
			String keyStr = key.toString();
			try {
				String valueStr = parseStringValue(props.getProperty(keyStr), props, new HashSet());
				propertiesMap.put(keyStr, valueStr);
			} catch (Exception e) {
				logger.warn("Key: [" + keyStr + "] has issues",e);
			}
		}
	}

	public String getProperty(String name) {
		return propertiesMap.containsKey(name) ? propertiesMap.get(name).toString() : "NA";
	}
	
	

}
