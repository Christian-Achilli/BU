package com.citi.icg.as.common.workflow.jbpm3;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jbpm.command.CommandService;
import org.jbpm.graph.def.Action;
import org.jbpm.graph.def.Event;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.instantiation.Delegation;
import org.jbpm.taskmgmt.exe.TaskInstance;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citi.icg.as.common.util.IProxyHelper;
import com.citi.icg.as.common.workflow.Workflow;
import com.citi.icg.as.common.workflow.WorkflowKey;
import com.citi.icg.as.common.workflow.WorkflowService;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.DeployDefinitionCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.GetProcessCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.NewProcessCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.RetrieveDefinitionCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.SetPooledActorsCallback;
import com.citi.icg.as.common.workflow.jbpm3.CommandServiceCallbackManager.UpdateDefinitionCallback;
import com.citi.icg.toolkit.logger.IcgAppLogger;

/**
 * Implementation for JBPM3.
 * 
 */
public class JbpmWorkflowService implements WorkflowService, ProcessUpdater
{

	// special context variables that are put in on every transition - can be
	// used in the execution context to help with assignment etc.
	public static final String TRANSITION_NAME = "transitionName";

	public static final String DEFAULT_JPDL_DIRECTORY = "jpdl";

	public static final String TASK_NODE = "TaskNode";

	public static final String PROCESSDEF_SUFFIX = "/processdefinition.xml";

	public String jpdlDirectory = DEFAULT_JPDL_DIRECTORY;
	
	protected CommandService commandService;
	
	protected IProxyHelper proxyHelper;
		
	protected CallbackManager callbackManager;

	public static final String CONST_SLASH = "/";
		
	public JbpmWorkflowService(CommandService commandService,
			IProxyHelper proxyHelper) {
		this(commandService, proxyHelper, new CommandServiceCallbackManager(commandService));
	}
	
	public JbpmWorkflowService(CommandService commandService,
			IProxyHelper proxyHelper, CallbackManager callbackManager) {
		super();
		this.commandService = commandService;
		this.proxyHelper = proxyHelper;
		this.callbackManager = callbackManager;
	}
	
	protected <T extends Workflow> String getProcessName(Class<T> objectType)
	{
		return objectType.getSimpleName();
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public <T extends Workflow> void deployWorkflow(Class<T> objectType) {
		
		String processName = getProcessName(objectType);

		// will deploy the process definition if it hasn't been so already
		checkDefinitionExists(processName);
		
	}
	
	private <T extends Workflow> T newProxyWorkflowInstance(final Class<T> objectType, final WorkflowKey key)
	{
		return newProxyWorkflowInstance(objectType, key, null);
	}

	private  <T extends Workflow> T newProxyWorkflowInstance(final Class<T> objectType, final WorkflowKey key, final Map<String, Object> variables)
	{

		String processName = getProcessName(objectType);

		// will deploy the process definition if it hasn't been so already
		checkDefinitionExists(processName);

		// get a new process instance
		newProcessInstance(processName, key, variables);

		return getProxyWorkflowInstance(objectType, key);

	}
		
	protected String getStringKey(Object key)
	{
		return key.toString();
	}
	
	private ProcessInstance newProcessInstance(final String processName,
			final Object key, final Map<String, Object> variables) {
		return this.callbackManager.executeCallback(new NewProcessCallback(processName, getStringKey(key), variables));

	}
			
	private ProcessDefinition getProcessDefinition(final String processName) {
		return this.callbackManager.executeCallback(new RetrieveDefinitionCallback(processName));
	}

	private synchronized void checkDefinitionExists(String processName)
	{

		ProcessDefinition pd = getProcessDefinition(processName);
		if (pd == null)
		{
			newProcessDefinition(processName);
		}
	}
	
	@Override
	public <T extends Workflow> boolean isProcessInstanceExists(Class<T> objectType, WorkflowKey key) {
		String processName = this.getProcessName(objectType);
		if (getProcessInstance(processName, getStringKey(key)) == null) {
			return false;
		}
		return true;
	}
	
	protected String getProcessDefinitionPath(String processName)
	{
		return jpdlDirectory + CONST_SLASH + processName + PROCESSDEF_SUFFIX;
	}
			
	private ProcessDefinition newProcessDefinition(String processName) 
	{
		
		IcgAppLogger.info(JbpmWorkflowService.class, "Creating new process definiton for [" + processName + "]");

		// no pd in system so create a new one
		String processDefinitionPath = getProcessDefinitionPath(processName);
		ProcessDefinition pd = ProcessDefinition.parseXmlResource(processDefinitionPath);
		pd.setVersion(1);
		
		return newProcessDefinition(pd);
		
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateProcessDefiniton(){
		this.callbackManager.executeCallback(new UpdateDefinitionCallback());
	}
	
	private ProcessDefinition newProcessDefinition(final ProcessDefinition processDefinition) 
	{
		return this.callbackManager.executeCallback(new DeployDefinitionCallback(processDefinition));
	}

	protected InvocationHandler getInvocationHandler(WorkflowKey key, String processName)
	{
		return new JbpmProxyInvocationHandler(key, processName, this.commandService);
	}
	
	private ProcessInstance getProcessInstance(String process, String key)
	{
		return this.callbackManager.executeCallback(new GetProcessCallback(process, key));
	}
	
	@SuppressWarnings("unchecked")
	public final <T extends Workflow> T getProxyWorkflowInstance(final Class<T> objectType, WorkflowKey key)
	{
		String processName = this.getProcessName(objectType);
		
		if (!isProcessInstanceExists(objectType, key)) {
			return newProxyWorkflowInstance(objectType, key);
		}
		
		List<Class<?>> classes = new ArrayList<Class<?>>();
		for (Class<?> clazz : objectType.getInterfaces())
		{
			classes.add(clazz);
		}
		classes.add(objectType);
		
		InvocationHandler handler = getInvocationHandler(key, processName);
		handler = proxyHelper.getTransactionalInstance(handler);
		Object proxy = Proxy.newProxyInstance(objectType.getClassLoader(),classes.toArray(new Class[]{}),handler);
		
		return (T) proxy;
	}
	
	public void setPooledActors(final Set<String> groups, final TaskInstance instance)
	{
		this.callbackManager.executeCallback(new SetPooledActorsCallback(groups, instance));
		
	}

	protected void setJpdlDirectory(String jpdlDirectory)
	{
		this.jpdlDirectory = jpdlDirectory;
	}
		

}
