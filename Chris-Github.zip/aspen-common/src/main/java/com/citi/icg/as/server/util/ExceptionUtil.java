package com.citi.icg.as.server.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.citi.icg.as.common.client.exception.EntitlementException;
import com.citi.icg.toolkit.web.client.IcgGwtException;
import com.citi.icg.toolkit.web.client.IcgGwtUIException;
import com.citi.icg.toolkit.web.client.common.ErrorType;

/**
 * Exception Util.
 */
public final class ExceptionUtil
{
	private ExceptionUtil() { }

	public static IcgGwtUIException getUIException(Throwable actualException)
	{
		IcgGwtUIException icgGwtUIException = createGwtUIException(actualException);
		for (Throwable t : ExceptionUtils.getThrowables(actualException))
		{
			if (t instanceof IcgGwtUIException)
			{
				IcgGwtUIException igue = (IcgGwtUIException) t;
				if (igue.getErrorType() != null)
				{
					icgGwtUIException.setErrorType(igue.getErrorType());
				}
				return icgGwtUIException;
			}
			if (t instanceof IcgGwtException && ((IcgGwtException) t).getErrorType() != null)
			{
				icgGwtUIException.setErrorType(((IcgGwtException) t).getErrorType());
				icgGwtUIException.setMessage(t.getMessage());
			}
		}
		
		return icgGwtUIException;
	}

	private static IcgGwtUIException createGwtUIException(Throwable e)
	{
		String userMessage = null;
		if (null != e.getCause())
		{
			userMessage = e.getCause().getMessage();
		}
		else
		{
			userMessage = e.getMessage();
		}

		String details = getStackTrace(e);
		IcgGwtUIException uiException = new IcgGwtUIException(userMessage, details, ErrorType.UNKNOW);
		return uiException;
	}
	
	public static String getStackTrace(Throwable throwable)
	{
		StringWriter writer = new StringWriter();
		PrintWriter printWriter = new PrintWriter(writer, true);
		throwable.printStackTrace(printWriter);
		printWriter.close();
		return writer.getBuffer().toString();
	}
	
	public static RuntimeException wrapInRuntimeException(Throwable e)
	{
		return e instanceof RuntimeException ? (RuntimeException) e : new RuntimeException(e);
	}
	
	public static EntitlementException createEntitlementException(String msg)
	{
		EntitlementException ex = new EntitlementException(msg);
		ex.setErrorType(ErrorType.DATA_ERROR);
		return ex;
	}

}
