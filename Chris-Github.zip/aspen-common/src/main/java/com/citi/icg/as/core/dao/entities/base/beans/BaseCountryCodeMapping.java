package com.citi.icg.as.core.dao.entities.base.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import com.citi.icg.as.core.dao.entities.ext.beans.Region;

@MappedSuperclass
@Table(name = "COUNTRY_CODE_MAPPING", schema = "PUBLIC", catalog = "INCOMEPROCESSING")
public abstract class BaseCountryCodeMapping extends JPATransferObject implements java.io.Serializable {

	private static final long serialVersionUID = -4911403473082861555L;
	
	private String countryCode;
	private String alpha3Code;

	public BaseCountryCodeMapping() {
	}
	
	@Id
	@Column(name = "COUNTRY_CODE", length = 50)
	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	@Column(name = "ALPHA_3_CODE", length = 3)
	public String getAlpha3Code() {
		return this.alpha3Code;
	}

	public void setAlpha3Code(String alpha3Code) {
		this.alpha3Code = alpha3Code;
	}
}
