package com.citi.icg.as.config;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public final class ConfigEnv {
	
	private static final Log LOG = LogFactory.getLog(ConfigEnv.class);
	
	public static final String GCAS_ENV = "gcas.env";	
	private static final String ENV_VALUE = initEnv();
	private static final String WINDOWS = "windows";
	private static final String SYS_PROPERTY_OS = "os.name";
	
	private ConfigEnv()
	{

	}
	
	private static String initEnv()
	{
		if (isRunningInsideEclipse())
		{
			System.setProperty(GCAS_ENV, "local");
		}
		String env = System.getProperty(GCAS_ENV);
		if (env == null)
		{
//			throw new RuntimeException("No value for system property " + GCAS_ENV);
			LOG.error("No value for system property " + GCAS_ENV);
			
		}

		return env;
	}
	
	public static void set(String env)
	{
		System.setProperty(GCAS_ENV, env);
	}
	
	public static String getEnvironment()
	{
		return ENV_VALUE;
	}
	
	private static boolean isRunningInsideEclipse()
	{
		return getEnvironment() == null && isWindows();
	}
	
	private static boolean isWindows()
	{
		return StringUtils.containsIgnoreCase(System.getProperty(SYS_PROPERTY_OS), WINDOWS);
	}
}
