package com.citi.icg.as.common.workflow.jbpm3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.citi.icg.as.common.workflow.WorkflowException;
import com.citi.icg.as.common.workflow.WorkflowKey;

public class JbpmWorkflowKey<T> implements WorkflowKey<T> {
	private static final String CLASS_SEPERATOR = ":";
	private static final String ID_SEPERATOR = ",";
	private static final String OPEN_BRACKET = "[";
	private static final String CLOSE_BRACKET = "]";
	private Class<T> entityType;
	private Long[] entityIds;
	private String[] entityIdsWithBrackets;
	private String generatedKey;
	
	private JbpmWorkflowKey(){
		
	}
	
	/**
	 * The string format will be generated once only when initializing.
	 * @param entityType
	 * @param entityIds
	 */
	public JbpmWorkflowKey(Class<T> entityType, Long... entityIds){
		this.entityType = entityType;
		//force sort in order to avoid same 'entityIds' with different order which will generate different string formats.
		Arrays.sort(entityIds);
		this.entityIds = entityIds;
		this.entityIdsWithBrackets = addBrackets(entityIds);
		this.generatedKey = formatKey(entityType, entityIds);
	}

	/* (non-Javadoc)
	 * @see com.citi.icg.as.common.workflow.jbpm3.WorkflowKey#getEntityType()
	 */
	@Override
	public Class<T> getEntityType() {
		return entityType;
	}

	/* (non-Javadoc)
	 * @see com.citi.icg.as.common.workflow.jbpm3.WorkflowKey#getEntityIds()
	 */
	@Override
	public Long[] getEntityIds() {
		return entityIds.clone();
	}
	
	/* (non-Javadoc)
	 * @see com.citi.icg.as.common.workflow.jbpm3.WorkflowKey#getEntityIdsWithBrackets()
	 */
	@Override
	public String[] getEntityIdsWithBrackets() {
		return entityIdsWithBrackets.clone();
	}

	/**
	 * i.e. "com.citi.icg.as.core.dao.entities.business.AccountParent:[1],[2]"
	 * @param entityType
	 * @param entityIds
	 * @return
	 */
	private String formatKey(Class<T> entityType, Long[] entityIds){
		String result = entityType.getName() + CLASS_SEPERATOR;
		for(int i = 0; i < entityIds.length; i++){
			if(i != 0){
				result += ID_SEPERATOR;
			}
			result += entityIdsWithBrackets[i];
		}
		return result;
	}
	
	@Override
	public String toString(){
		return generatedKey;
	}
	
	/**
	 * parse the String to resume the key
	 * @param key
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> WorkflowKey<T> parseKey(String key){
		blankCheck(key);
		
		String[] classAndIds = splitClassAndIds(key);
		
		String className = classAndIds[0];
		String id = classAndIds[1];
		
		Class classType = parseClass(className, key);
		
		Long[] parseIds = parseIds(id, key);
		
		return new JbpmWorkflowKey(classType, parseIds);
		
	}
	
	private static void blankCheck(String key){
		if(StringUtils.isBlank(key)){
			throw new WorkflowException("The key to be parsed should not be blank");
		}
	}
	
	private static String[] splitClassAndIds(String key){
		String[] classAndIds = key.split(CLASS_SEPERATOR);
		if(classAndIds.length < 2){
			throw new WorkflowException("Unknow key format, key[" + key + "]");
		}
		return classAndIds;
	}
	
	private static Class parseClass(String className, String key){
		Class classType = null;
		try {
			classType = Class.forName(className);
		} catch (ClassNotFoundException e) {
			throw new WorkflowException("Unknow class type["+ className +"], in key[" + key + "]");
		}
		return classType;
	}
	
	private static Long[] parseIds(String id, String key){
		String[] ids = id.split(ID_SEPERATOR);
		if(ids.length == 0){
			throw new WorkflowException("Unknow key format, key[" + key + "]");
		}
		
		List<Long> list = new ArrayList<Long>();
		for(String each : ids){
			list.add(parseLong(each, key));
		}
		
		Long[] result = new Long[list.size()];
		list.toArray(result);
		return result;	
	}
	
	private static Long parseLong(String longString, String key){
		try{
			return Long.parseLong(stripBrackets(longString));
		}catch(NumberFormatException e){
			throw new WorkflowException("Can not parse '" + longString + "' to Long, please check key[" + key + "]");
		}
	}
	
	private String[] addBrackets(Long[] ids){
		String[] idsWithBrackets = new String[ids.length];
		for(int i = 0; i < ids.length; i++){
			idsWithBrackets[i] = OPEN_BRACKET + ids[i] + CLOSE_BRACKET;
		}
		return idsWithBrackets;
	}
	
	
	private static String stripBrackets(String longWithBrackets){
		String stripOpenBracket = longWithBrackets.substring(longWithBrackets.indexOf(OPEN_BRACKET) + 1);
		String stripBothBrackets = stripOpenBracket.substring(0, longWithBrackets.indexOf(CLOSE_BRACKET) - 1);
		return stripBothBrackets;
	}
}
