package com.jcraft.jsch;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

import org.apache.commons.lang.UnhandledException;

public class TectiaPrivateKey {

	public static final int TECTIA_MAGIC = 0x3f6ff9eb;
	public static final String CIPHER_NONE = "none";
	public static final String KEY_TYPE_RSA = "rsa"; 
	
	private static final String ERR_INVALID_MAGIC_NUMBER = "Invalid magic number. File not a Tectia private key? %08x != %08x.";
	private static final String ERR_PASSPHRASE_NOT_SUPPORTED = "Passphrase protected keys are not supported. cipher=%s.";
	private static final String ERR_KEY_TYPE_NOT_SUPPORTED = "Key type is not supported. type=%s'.";
	
	private byte[] e;
	private byte[] n;
	private byte[] d;
	
	public TectiaPrivateKey(Reader reader) throws IOException
	{
		BufferedReader lineReader = new BufferedReader(reader);
		StringBuffer base64Content = new StringBuffer();
		
		// append the base64 section of private key
		// to buffer. FIXME? this code isn't very
		// smart and doesn't look for being/end blocks
		for (String line = lineReader.readLine(); line != null; line = lineReader.readLine())
		{
			if (!line.contains("-") && !line.contains(":"))
			{
				base64Content.append(line);
			}
			else if (line.contains(":"))
			{
				while (line.endsWith("\\")) line = lineReader.readLine();
			}
		}
		
		// decode the base64 to binary stream
		// and wrap in big endian unpack buffer
		byte[] key;
		Buffer buffer = null;
		try {
			key = Util.fromBase64(base64Content.toString().getBytes(), 0, base64Content.length());
			buffer = new Buffer(key);
		} catch (Exception e) {
			throw new UnhandledException(e);
		}

		// fail if the buffer does not start with
		// tectia magic number, probably wrong file?
		int magic = buffer.getInt();
		if (magic != TECTIA_MAGIC)
		{
			throw new RuntimeException(String.format(ERR_INVALID_MAGIC_NUMBER, TECTIA_MAGIC, magic));
		}
		
		// the remainder of this method per openssh source
		int i1 = buffer.getInt();
		String type = new String(buffer.getString());
		String cipher = new String(buffer.getString());
		int i2 = buffer.getInt();
		int i3 = buffer.getInt();
		int i4 = buffer.getInt();
		
		if (!CIPHER_NONE.equals(cipher))
		{
			throw new RuntimeException(String.format(ERR_PASSPHRASE_NOT_SUPPORTED, cipher));
		}
		
		if (type.indexOf(KEY_TYPE_RSA) < 0)
		{
			throw new RuntimeException(String.format(ERR_KEY_TYPE_NOT_SUPPORTED, type));
		}
		
		byte e1 = (byte) buffer.getByte();
		if (e1 < 30)
		{
			e = new byte[] {e1, (byte) buffer.getByte(), (byte) buffer.getByte()};
		}
		else 
		{
			e = new byte[] {e1};
		}
		
		d = buffer.getMPIntBits();
		n = buffer.getMPIntBits();
	}

	public byte[] getE() {
		return e;
	}

	public byte[] getN() {
		return n;
	}

	public byte[] getD() {
		return d;
	}
	
}
