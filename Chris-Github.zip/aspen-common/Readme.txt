// build compiled jars + javadoc and source jars
mvn package -P buildAll

// This jar requires an aspen.env parameter at run time based on the environment its being run on
// e.g -Daspen.env={local,qa1,prod,int3,...}

------------------------------
// If you want to encrypt/decrypt passwords, please use PasswordEncryptUtils as it doesn't depend on gcas.
