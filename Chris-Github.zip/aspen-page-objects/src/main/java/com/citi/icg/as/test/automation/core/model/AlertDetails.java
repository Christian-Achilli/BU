package com.citi.icg.as.test.automation.core.model;

import org.apache.commons.lang3.StringUtils;

public class AlertDetails {
    private String priority;
    private String parentFileName;
    private String description;
    private String alertID;
    private String alertOwner;
    private String source;
    private String puName;
    private String closeType;
    private String status;
    private String alertNotes;
    private String age;



    public AlertDetails(String parentFileName, String alertID, String puName) {
        this.parentFileName = parentFileName;
        this.alertID = alertID;
        this.puName = puName;
    }
    public AlertDetails(String parentFileName, String puName) {
        this.parentFileName = parentFileName;
        this.puName = puName;
    }

   	public AlertDetails(String closingAlertId) {
		this.alertID = closingAlertId;
	}
	public void setPriority(String priority) {
        this.priority = priority;
    }

    public void setParentFileName(String parentFileName) {
        this.parentFileName = parentFileName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAlertID(String alertID) {
        this.alertID = alertID;
    }

    public void setAlertOwner(String alertOwner) {
        this.alertOwner = alertOwner;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setPuName(String puName) {
        this.puName = puName;
    }

    public void setCloseType(String closeType) {
        this.closeType = closeType;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setAlertNotes(String alertNotes) {
        this.alertNotes = alertNotes;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getAlertID() {
        return alertID;
    }

    public boolean equals(AlertDetails obj) {
        if(this==obj){
            return true;
        }else{
            return StringUtils.trimToEmpty(priority).equals(StringUtils.trimToEmpty(obj.priority))
                    && StringUtils.trimToEmpty(parentFileName).equals(StringUtils.trimToEmpty(obj.parentFileName))
                    && StringUtils.trimToEmpty(puName).equals(StringUtils.trimToEmpty(obj.puName));
        }
    }
}
