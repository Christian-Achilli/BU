/**
 * 
 */
/**
 * @author ap72338
 *
 */
package com.citi.icg.as.test.automation.core.logger.listener;