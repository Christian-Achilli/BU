package com.citi.icg.as.test.automation.core.constant;

/**
 * 
 * @author ap72338
 *
 */
public class XPathConstants {

	public static final String EVENT_ID="eventId";
	public static final String EX_DATE = "Ex Date";
	public static final String EFFETIVE_DATE = "Effective Date";
	public static final String RECORD_DATE = "Record Date";

}
