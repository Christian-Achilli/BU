package com.citi.icg.as.test.automation.core.model;

public enum AspenProcessingUnit {

    Default_PU(1, "Default PU"),
    PB_Equity(2, "PB Equity"),
    Swaps(3, "Swaps"),
    Main_Firm_Equity(4, "Main Firm Equity"),
    Fixed_Income(5, "Fixed Income");

    private final int tableId;
    
    private final String displayName;

    private AspenProcessingUnit(int puId, String displayName) {
        this.tableId = puId;
        this.displayName = displayName;
    }

    public int getTableId() {
        return tableId;
    }

    public String getDisplayName(){
    	return displayName;
    }
    public static AspenProcessingUnit fromString(String name) {
        for (AspenProcessingUnit value : AspenProcessingUnit.values()) {
            if (value.name().equals(name)) {
                return value;
            }
        }
        return null;
    }

}
