/**
 * 
 */
package com.citi.icg.as.test.automation.core.logger.listener;

/**
 * @author ap72338
 * <p>This listener can be used in page objects to perform some stuff in tests. /p>
 */
public interface ActionListener {

	void performAction();
}
