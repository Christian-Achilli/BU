package com.citi.icg.as.test.automation.core.model;

/**
 * Created by rh27929 on 15/06/2016.
 */
public enum AspenRegion {

    NAM(1), EMEA(2), ASPAC(3);

    private final int tableId;

    /**
     * @param regionId the vaue comes form the REGION table in the database.
     */
    private AspenRegion(int regionId) {
        this.tableId = regionId;
    }

    public int getTableId() {
        return tableId;
    }

    public static AspenRegion fromString(String name) {
        for (AspenRegion value : AspenRegion.values()) {
            if (value.name().equals(name)) {
                return value;
            }
        }
        return null;
    }

}
