/**
 *
 */
package com.citi.icg.as.config;

import java.io.FileNotFoundException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.citi.icg.as.config.constants.ConfigConstants;

/**
 * @author ap72338
 *         <p>
 *         TestNG test
 *         </p>
 */
public class ConfigurationUtilityTest {

	private static String existingSysStreamProperty = System.getProperty(ConfigConstants.STREAM_ENV_PROPERTY,
			StringUtils.EMPTY);

	@Test
	public void whenDev1EnvAndUserNamePropertyThenValidValueIsReturned() {
		ConfigurationUtility config = new ConfigurationUtility("unitTest");
		Assert.assertEquals("unitTestUser", config.getProperty("userName"));
		Assert.assertEquals("testCluster", config.getProperty("targets"));
		Assert.assertEquals("unitTestPassword", config.getProperty("password"));
	}

	@Test(expectedExceptions = NullPointerException.class)
	public void whenInvalidEnvThenExceptionIsThrown() {
		ConfigurationUtility config = new ConfigurationUtility("XXX");
		Assert.assertNotNull(config.getProperty("userName"));
	}

	@Test
	public void whenInvalidPathThenExceptionIsThrown() {
		try {
			ConfigurationUtility config = new ConfigurationUtility("XXX", "does not Exist");
			Assert.fail("File does not exist");
		} catch (Exception e) {
			Assert.assertTrue(e.getCause() instanceof FileNotFoundException);
		}
	}

	@Test
	public void windowsOS_IsConsideredDevelopment() {
		String os = System.getProperty("os.name").toLowerCase();
		if (os.indexOf("windows") >= 0)
			Assert.assertTrue(ConfigurationUtility.isDevelopment());
		else
			Assert.assertFalse(ConfigurationUtility.isDevelopment());
	}

	@Test
	public void whenUnitTestThenLoginandLaunchUrlsAreCorrect() {
		ConfigurationUtility config = new ConfigurationUtility("unitTest");
		Assert.assertEquals("https://localhost/CorporateActions.html", config.getLaunchURL());
		Assert.assertEquals("https://localhost/admin/login", config.getLoginURL());
	}

	@Test
	public void whenUnitTestThenPasswordIsCorrectlyDecrypted() {
		ConfigurationUtility config = new ConfigurationUtility("unitTest");
		Assert.assertEquals("aspen123", config.getDatabaseDetails().getPassword());
		Assert.assertEquals("def", config.getEMCConfig().getPassword());
		Assert.assertEquals("abc", config.getEMCConfig().getUserName());
	}

	@Test
	public void verifyDEVMongoDbConfiguration() {
		ConfigurationUtility config = new ConfigurationUtility("dev1");
		Assert.assertNotNull(config.getMongoDbConfig());
	}

	@Test(dataProvider = "asyncQueueTest")
	public void verifyAsyncQueueConfigurationForAllEnvsAndStreams(String environment, String stream) {
		System.setProperty(ConfigConstants.STREAM_ENV_PROPERTY, stream);
		ConfigurationUtility config = new ConfigurationUtility(environment);
		performAssertionsForQueues(config);
	}

	@DataProvider(name = "asyncQueueTest")
	public static Object[][] environmentsAndStreams() {
		return new Object[][] { { "dev1", "markets" }, { "dev1", "custody" }, { "int1", "markets" },
				{ "int1", "custody" }, { "int2", "markets" }, { "int2", "custody" }, { "int3", "markets" },
				{ "int3", "custody" }, { "qa1", "markets" }, { "qa1", "custody" }, { "qa2", "markets" },
				{ "qa2", "custody" }, { "qa3", "markets" }, { "qa3", "custody" }, { "uat1", "markets" },
				{ "uat1", "custody" }, { "uat2", "markets" }, { "uat2", "custody" }, { "uat3", "markets" },
				{ "uat3", "custody" }, { "uat4", "markets" }, { "uat4", "custody" }, { "prod", "markets" },
				{ "prod", "custody" } };
	}

	/**
	 * @param config
	 *            Dont want to hardcode the values for queue names
	 */
	private void performAssertionsForQueues(ConfigurationUtility config) {
		AsyncQueues queueConfig = config.getAsyncQueues();
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getAnnouncementToWc()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getEntitlementCalcToWc()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getPayRecToWc()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getPositionsToWc()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getPostingsToWc()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getWcToAnnouncement()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getWcToEntitlementCalc()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getWcToPayRec()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getWcToPositions()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getWcToPostings()));

		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getConnectionFactory()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getConnectionFactoryClass()));
		Assert.assertNotNull(StringUtils.trimToNull(queueConfig.getConnectionURL()));
	}
	
	@Test(dataProvider = "asyncQueueTest")
	/**
	 * 
	 * @param environment
	 * @param stream
	 * @throws Exception
	 * This test checks whether the regular expression we have written in config.json is correct or not
	 */
	public void asyncModeExclusionNodesRegexPattern(String environment, String stream) throws Exception{
		ConfigurationUtility config = new ConfigurationUtility(environment);
		
		//Validate the pattern
		if(StringUtils.isNotBlank(config.getAsyncModeExclusionNodes())){
			Pattern.compile(config.getAsyncModeExclusionNodes());
		}
		
		config = new ConfigurationUtility("jenkins");		
		
		Pattern p= Pattern.compile(config.getAsyncModeExclusionNodes());
		Matcher m = p.matcher("aspenDev1Node3");		
		Assert.assertTrue(m.find(), "On local env node3 should be excluded");
		m = p.matcher("aspenDev1Node4");
		
		Assert.assertTrue(m.find(), "On local env node4 should be excluded");
		Assert.assertTrue(Pattern.matches(config.getAsyncModeExclusionNodes(), "aspenDev1Node4"), "On local env node4 should be excluded");
		Assert.assertTrue(Pattern.matches(config.getAsyncModeExclusionNodes(), "aspenDev1Node3"), "On local env node4 should be excluded");
		
		m = p.matcher("aspenDev1Node1");
		
		Assert.assertFalse(m.find(), "On local env node1 should NOT be excluded");
		
	}

	@AfterClass
	public void tearDown() {
		System.setProperty(ConfigConstants.STREAM_ENV_PROPERTY, existingSysStreamProperty);
	}
}
