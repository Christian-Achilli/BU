/**
 * 
 */
package com.citi.icg.as.config;

import com.citi.icg.msst.cmot.as.config.annotation.EnableCentralJsonConfig;

/**
 * @author ap72338
 *
 */

@EnableCentralJsonConfig
public class TestConfiguration {

}
