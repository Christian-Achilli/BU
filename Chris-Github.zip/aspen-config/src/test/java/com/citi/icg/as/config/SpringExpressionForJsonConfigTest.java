/**
 * 
 */
package com.citi.icg.as.config;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.citi.icg.msst.cmot.as.config.annotation.AspenCentralJsonConfiguration;

/**
 * @author ap72338
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=TestConfiguration.class)
public class SpringExpressionForJsonConfigTest {

	@Value("#{asyncQueues.getPositionsToWc()}")
	private String positionsToWc;

	//See usage of spring expression language; Awsome :-)
	@Value("#{databaseConfig.getUrl()}")
	private String dbUrl;
	
	@BeforeClass
	public static void setUp(){
		System.setProperty(AspenCentralJsonConfiguration.SYSTEM_ENV_PROPERTY, "jenkins");
		System.setProperty(AspenCentralJsonConfiguration.SYSTEM_BUSINESS_STREAM_PROPERTY, "markets");
	}
	
	@Test
	public void testContextProperty(){
		Assert.assertNotNull(positionsToWc);
		Assert.assertNotNull(dbUrl);
	}
}

