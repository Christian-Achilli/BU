/**
 * 
 */
package com.citi.icg.as.config;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author AP72338
 *
 */
public class StreamConfigurationUtilityTest {

	
	@Test
	public void test_MarketsConfig() throws Exception {
		final String markets = "markets";
		StreamConfigurationUtility utility = new StreamConfigurationUtility(markets);
		StreamConfig config = utility.getStreamConfig();
		Assert.assertNotNull("markets config cannot be null",config);
		Assert.assertTrue(config.getAppId().equals("160109"));
		Assert.assertEquals(markets, config.getStream());
	}
	
	@Test
	public void test_CustodyConfig() throws Exception {
		final String custody = "custody";
		StreamConfigurationUtility utility = new StreamConfigurationUtility(custody);
		StreamConfig config = utility.getStreamConfig();
		Assert.assertNotNull("custody config cannot be null",config);
		Assert.assertTrue(config.getAppId().equals("169129"));
		Assert.assertEquals(custody, config.getStream());
	}
}
