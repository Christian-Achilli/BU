import hudson.model.*

// get current thread / Executor
def thr = Thread.currentThread()
// get current build
def build = thr.executable
def prjPathValue = build.getEnvironment()["WORKSPACE"]
def svnRevisionValue = build.getEnvironment()["SVN_REVISION"]
def svnUrlValue = build.getEnvironment()["SVN_URL"]

println "project path: ${prjPathValue} -- SVN url: ${svnUrlValue} -- SVN revision: ${svnRevisionValue}"
def jenkinsFile = new File(prjPathValue + "/src/main/resources/svn_build.properties")
jenkinsFile.append "SVN_REVISION=" + svnRevisionValue + "\r\n"
jenkinsFile.append "SVN_URL=" + svnUrlValue + "\r\n"