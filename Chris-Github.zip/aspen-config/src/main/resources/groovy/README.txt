The groovy script is used by jenkins to attach SVN informations to the built war file of every component.
The file is here just for versioning. The live copy of it in on the Jenkins VM vm-5c9e-4222 in the folder
/home/aspendev/continuous_delivery/groovy.

This script creates a file called svn_build.properties that contains the properties that are read by the viewConfig.vm file