/**
 * 
 */
package com.citi.icg.as.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author ap72338
 *
 */
public class MongoDbConfig {
	private String databaseName, userName, password, trustStore, trustStorePassword;
	private List<MongoServer> servers;
	private boolean SSLToBeUsed;

	public MongoDbConfig(String databaseName, String userName, String password,
			String trustStore, String trustStorePassword,boolean useSSL) {
		this.databaseName = databaseName;
		this.password = password;
		this.userName = userName;
		this.trustStore = trustStore;
		this.trustStorePassword = trustStorePassword;
		this.SSLToBeUsed = useSSL;
		this.servers = new ArrayList<MongoServer>();
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public void addServer(String host, int port) {
		servers.add(new MongoServer(host, port));
	}

	public List<MongoServer> getServers() {
		return Collections.unmodifiableList(servers);
	}

	public static class MongoServer {
		private String host;
		private int port;

		public MongoServer(String host, int port) {
			this.host = host;
			this.port = port;
		}

		public String getHost() {
			return host;
		}

		public int getPort() {
			return port;
		}

	}

	public String getTrustStore() {
		return trustStore;
	}

	public String getTrustStorePassword() {
		return trustStorePassword;
	}

	public boolean isSSLToBeUsed() {
		return SSLToBeUsed;
	}
}
