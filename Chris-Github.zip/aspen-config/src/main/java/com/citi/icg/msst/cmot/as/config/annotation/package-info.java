/**
 * 
 */
/**
 * @author ap72338
 *         <p>
 *         The package name is different from usual com.citi.icg.as because this
 *         configuration should only come into picture when
 *         {@link com.citi.icg.msst.cmot.as.config.annotation.EnableCentralJsonConfig}
 *         is used and not because someone has used component scan
 *         "com.citi.icg.as", which is the case for many.
 *         </p>
 */
package com.citi.icg.msst.cmot.as.config.annotation;