package com.citi.icg.as.config;

/**
 * 
 * @author ap72338 Model class which maps the data of table ASPEN_PROPERTIES
 */
public class DBConfig {

	private String environment;
	private String component;
	private String key;
	private String value;

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("KEY=");
		builder.append(key);
		builder.append(" ");
		builder.append("VALUE=");
		builder.append(value);
		builder.append(";");
		builder.append("COMPONENT=");
		builder.append(component);
		builder.append(";");
		builder.append("ENV=");
		return builder.toString();
	}

}
