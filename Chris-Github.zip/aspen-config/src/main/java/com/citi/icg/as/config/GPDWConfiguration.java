/**
 * 
 */
package com.citi.icg.as.config;

/**
 * @author ap72338
 *
 */
public class GPDWConfiguration extends AbstractEMSConfiguration{

	/**
	 * 
	 */	
	private static final long serialVersionUID = -4906119290071285458L;

	private String broadcastQueue;

	public GPDWConfiguration(String contextFactory, String providerURL, String userName, String password,
			String listenerQueueName, String connectionFactory,String broadcastQueue) {
		super(contextFactory, providerURL, userName, password, listenerQueueName, connectionFactory);
		this.broadcastQueue=broadcastQueue;
	}

	public String getBroadcastQueue() {
		return broadcastQueue;
	}
}
