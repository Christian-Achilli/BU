/**
 * 
 */
package com.citi.icg.as.config;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * @author ap72338
 *         <p>
 *         The class which represents the async queues as used for inter process
 *         async communication
 *         </p>
 *
 */
public class AsyncQueues {

	private static final String QUEUE_CONCURRENCY_SEPARATOR = ":";
	private String announcementToWc;
	private String positionsToWc;
	private String entitlementCalcToWc;
	private String payRecToWc;
	private String postingsToWc;

	private String wcToAnnouncement;
	private String wcToPositions;
	private String wcToEntitlementCalc;
	private String wcToPayRec;
	private String wcToPostings;

	private String announcementToWcConcurrency;
	private String positionsToWcConcurrency;
	private String entitlementCalcToWcConcurrency;
	private String payRecToWcConcurrency;
	private String postingsToWcConcurrency;

	private String wcToAnnouncementConcurrency;
	private String wcToPositionsConcurrency;
	private String wcToEntitlementCalcConcurrency;
	private String wcToPayRecConcurrency;
	private String wcToPostingsConcurrency;

	private String connectionFactory;
	private String connectionFactoryClass;
	private String connectionURL;

	public AsyncQueues(final Map<String, String> queueMap) {
		announcementToWc = getQueueName(queueMap, "annToWc");
		positionsToWc = getQueueName(queueMap, "epToWc");
		entitlementCalcToWc = getQueueName(queueMap, "ecToWc");
		payRecToWc = getQueueName(queueMap, "payRecToWc");
		postingsToWc = getQueueName(queueMap, "postingsToWc");

		wcToAnnouncement = getQueueName(queueMap, "wcToAnn");
		wcToPositions = getQueueName(queueMap, "wcToEp");
		wcToEntitlementCalc = getQueueName(queueMap, "wcToEc");
		wcToPayRec = getQueueName(queueMap, "wcToPayRec");
		wcToPostings = getQueueName(queueMap, "wcToPostings");

		//set concurrency for every queue
		announcementToWcConcurrency = getConcurrency(queueMap, "annToWc");
		positionsToWcConcurrency = getConcurrency(queueMap, "epToWc");
		entitlementCalcToWcConcurrency = getConcurrency(queueMap, "ecToWc");
		payRecToWcConcurrency = getConcurrency(queueMap, "payRecToWc");
		postingsToWcConcurrency = getConcurrency(queueMap, "postingsToWc");

		wcToAnnouncementConcurrency = getConcurrency(queueMap, "wcToAnn");
		wcToPositionsConcurrency = getConcurrency(queueMap, "wcToEp");
		wcToEntitlementCalcConcurrency = getConcurrency(queueMap, "wcToEc");
		wcToPayRecConcurrency = getConcurrency(queueMap, "wcToPayRec");
		wcToPostingsConcurrency = getConcurrency(queueMap, "wcToPostings");
		
		connectionFactory = queueMap.get("connectionFactory");
		connectionFactoryClass = queueMap.get("connectionFactoryClass");
		connectionURL = queueMap.get("connectionURL");
	}

	private String getConcurrency(final Map<String, String> queueMap, String name) {
		return StringUtils.defaultIfBlank(StringUtils.substringAfterLast(StringUtils.trimToEmpty(queueMap.get(name)),
				QUEUE_CONCURRENCY_SEPARATOR), "1");
	}

	private String getQueueName(final Map<String, String> queueMap, String name) {
		return StringUtils.substringBeforeLast(StringUtils.trimToEmpty(queueMap.get(name)),
				QUEUE_CONCURRENCY_SEPARATOR);
	}

	public String getAnnouncementToWc() {
		return announcementToWc;
	}

	public String getPositionsToWc() {
		return positionsToWc;
	}

	public String getEntitlementCalcToWc() {
		return entitlementCalcToWc;
	}

	public String getPayRecToWc() {
		return payRecToWc;
	}

	public String getPostingsToWc() {
		return postingsToWc;
	}

	public String getWcToAnnouncement() {
		return wcToAnnouncement;
	}

	public String getWcToPositions() {
		return wcToPositions;
	}

	public String getWcToEntitlementCalc() {
		return wcToEntitlementCalc;
	}

	public String getWcToPayRec() {
		return wcToPayRec;
	}

	public String getWcToPostings() {
		return wcToPostings;
	}

	public String getConnectionFactory() {
		return connectionFactory;
	}

	public String getConnectionFactoryClass() {
		return connectionFactoryClass;
	}

	public String getConnectionURL() {
		return connectionURL;
	}

	public static String getQueueConcurrencySeparator() {
		return QUEUE_CONCURRENCY_SEPARATOR;
	}

	public String getAnnouncementToWcConcurrency() {
		return announcementToWcConcurrency;
	}

	public String getPositionsToWcConcurrency() {
		return positionsToWcConcurrency;
	}

	public String getEntitlementCalcToWcConcurrency() {
		return entitlementCalcToWcConcurrency;
	}

	public String getPayRecToWcConcurrency() {
		return payRecToWcConcurrency;
	}

	public String getPostingsToWcConcurrency() {
		return postingsToWcConcurrency;
	}

	public String getWcToAnnouncementConcurrency() {
		return wcToAnnouncementConcurrency;
	}

	public String getWcToPositionsConcurrency() {
		return wcToPositionsConcurrency;
	}

	public String getWcToEntitlementCalcConcurrency() {
		return wcToEntitlementCalcConcurrency;
	}

	public String getWcToPayRecConcurrency() {
		return wcToPayRecConcurrency;
	}

	public String getWcToPostingsConcurrency() {
		return wcToPostingsConcurrency;
	}

}