/**
 * 
 */
package com.citi.icg.as.config;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author ap72338
 *  Just a testing class
 */
public class PasswordGenerator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//System.out.println(Base64Utils.encodeToString("unitTestPassword".getBytes()));
		//System.out.println(new String(Base64Utils.decodeFromString("dW5pdFRlc3RQYXNzd29yZA==")));
		System.out.println(EncryptionUtils.decrypt("pUhkuYG+akTTrR7tLe+T7Q=="));
		
		System.out.println(EncryptionUtils.encrypt("new123"));
		SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy_hhms");
		String dateTimeStamp = df.format(new Date());
		System.out.println(dateTimeStamp);
	}

}
