/**
 * 
 */
package com.citi.icg.as.config;

import java.util.Map;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author AP72338
 *
 */
public class StreamConfigurationUtility {
	private static final String SYSTEM_PROP_STREAM_KEY = "aspen.stream";
	private String configFile = "streamConfig.json";
	
	private Map<String, StreamConfig> configuration;
	private final String stream;
	
	public StreamConfigurationUtility(String stream) {
		this.stream = stream.toLowerCase().trim();
		init();
	}

	public StreamConfigurationUtility() {
		this.stream = System.getProperty(SYSTEM_PROP_STREAM_KEY).toLowerCase().trim();
		init();
	}
	
	private void init() {
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<Map<String, StreamConfig>> ref = new TypeReference<Map<String, StreamConfig>>() {
		};
		Resource res = new ClassPathResource(configFile);		
		try {
			configuration = mapper.readValue(res.getInputStream(), ref);
			Assert.isTrue(configuration.containsKey(stream), String.format("Invalid stream %s", this.stream));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}		
	}
	
	public StreamConfig getStreamConfig(){
		StreamConfig config =  configuration.get(stream);
		config.setStream(stream);
		return config;
	}
}
