/**
 * 
 */
package com.citi.icg.as.config;

import java.io.Serializable;

/**
 * @author ap72338
 *
 */
public abstract class AbstractEMSConfiguration implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1755168881350213299L;

	private String contextFactory;
	private String providerURL;
	private String userName;
	private String password;
	private String listenerQueueName;
	private String connectionFactory;

	public AbstractEMSConfiguration(String contextFactory, String providerURL, String userName, String password,
			String listenerQueueName, String connectionFactory) {
		this.connectionFactory = connectionFactory;
		this.providerURL = providerURL;
		this.userName = userName;
		this.password = password;
		this.contextFactory = contextFactory;
		this.listenerQueueName = listenerQueueName;
	}

	public String getContextFactory() {
		return contextFactory;
	}

	public void setContextFactory(String contextFactory) {
		this.contextFactory = contextFactory;
	}

	public String getProviderURL() {
		return providerURL;
	}

	public void setProviderURL(String providerURL) {
		this.providerURL = providerURL;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getListenerQueueName() {
		return listenerQueueName;
	}

	public void setListenerQueueName(String listenerQueueName) {
		this.listenerQueueName = listenerQueueName;
	}

	public String getConnectionFactory() {
		return connectionFactory;
	}

	public void setConnectionFactory(String connectionFactory) {
		this.connectionFactory = connectionFactory;
	}

}
