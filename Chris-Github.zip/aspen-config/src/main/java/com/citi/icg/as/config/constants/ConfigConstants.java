/**
 * 
 */
package com.citi.icg.as.config.constants;

import java.util.Map;

/**
 * @author ap72338
 *
 */
public class ConfigConstants {

	public static final String DATABASE_KEY = "database";
	public static final String APPLICATION_JSON_KEY = "application";
	public static final String PASSWORD = "password";
	public static final String WINDOWS = "windows";
	public static String OS = System.getProperty("os.name").toLowerCase();

	
	
	public final static String ASPEN_ENV_SYSTEM_PROPERTY = "aspen.env";
	
	public final static String LOCAL_ENV = "local";
	
	public final static String STREAM_ENV_PROPERTY="aspen.stream";
}
