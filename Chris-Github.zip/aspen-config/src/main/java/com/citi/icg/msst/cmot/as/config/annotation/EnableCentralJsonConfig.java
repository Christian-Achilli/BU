/**
 * 
 */
package com.citi.icg.msst.cmot.as.config.annotation;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * @author ap72338
 *         <p>
 *         Just put this annotation in any of your {@link Configuration} classes
 *         and you will have the beans exposed as in
 *         {@link AspenCentralJsonConfiguration}
 *         </p>
 *         <p>
 *         Just Autowire them or use them in {@link Value} as required, as
 *         spring expression language. Simple!!
 *         </p>
 */
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Configuration
@Import(AspenCentralJsonConfiguration.class)
public @interface EnableCentralJsonConfig {

}
