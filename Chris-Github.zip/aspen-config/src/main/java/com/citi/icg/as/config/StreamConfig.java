/**
 * 
 */
package com.citi.icg.as.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author AP72338
 *
 */

@JsonIgnoreProperties(ignoreUnknown=true)
public class StreamConfig {
	
	/**
	 * This property will not be there in the JSON, value map. So we will set it explicitly
	 */
	private String stream;
	
	private String appId;

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}	
}
