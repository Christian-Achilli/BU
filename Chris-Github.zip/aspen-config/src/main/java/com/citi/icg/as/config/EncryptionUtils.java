package com.citi.icg.as.config;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StringUtils;

/**
 * Helps encrypt and decrypt text.
 */
class EncryptionUtils {
	private static final String DEFAULT_ENCRYPTION_ALGORITHM = "PBEWithMD5AndTripleDES";
	private static final String ENCRYPTION_ALGORITHM = getEncryptionAlgorithm();
	public static final String ENCODE_INDICATOR_START = "ENC(";
	public static final String ENCODE_INDICATOR_END = ")";
	public static final int INTERATION = 15;
	private static final byte[] SALT = { (byte) 0xd7, (byte) 0x73, (byte) 0x21, (byte) 0x8c, (byte) 0x7e, (byte) 0xc8,
			(byte) 0xee, (byte) 0x99 };

	private static Cipher encrypter;
	private final static Base64 base64 = new Base64();
	private static String key = initApplicaitonKey();

	public static final String ERROR_KEY_GENERATION = "Encryption key generation failed. Please verify the logs.";

	private static Log log = LogFactory.getLog(EncryptionUtils.class);

	public static String encrypt(String plainText) {
		init();
		try {
			return new String(base64.encode(encrypter.doFinal(plainText.getBytes())));
		} catch (Exception e) {
			throw new RuntimeException("failed to encrypt text=[" + plainText + "]", e);
		}
	}

	public static String decrypt(String encryptedText) {
		// log.info("call to decrypt with encryptedText = " + encryptedText);
		try {
			Cipher decrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.DECRYPT_MODE);
			// log.info("key = " + key);
			return new String(decrypter.doFinal(base64.decode(encryptedText.getBytes())));
		} catch (Exception e) {
			throw new RuntimeException("failed to decrypt text=[" + encryptedText + "]", e);
		}
	}

	private static synchronized String initApplicaitonKey() {
		try {
			return IOUtils.toString(new ClassPathResource("key.dat").getInputStream());
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
	}

	private static void init() {
		if (encrypter == null) {
			initApplicaitonKey();
			try {
				encrypter = createCipher(key.toCharArray(), SALT, INTERATION, Cipher.ENCRYPT_MODE);
			} catch (Exception e) {
				throw new RuntimeException(
						"Unable to Initialize Ciphers" + "\nJAVA_HOME=" + System.getProperty("java.home")
								+ "\nSee https://teamforge.nam.nsroot.net/sf/wiki/do/viewPage/projects.153106_1/wiki/UnableToInitializeCiphers for posible solution",
						e);
			}
		}
	}

	public static String decryptIfEncrypted(String encryptedString) {
		String decryptedString = encryptedString;
		// log.info("call to decryptIfEncrypted with encryptedString = " +
		// encryptedString);

		try {

			if (encryptedString != null && encryptedString.startsWith(ENCODE_INDICATOR_START)) {
				// log.info("It has to be decrypted!");
				decryptedString = encryptedString.substring(ENCODE_INDICATOR_START.length(),
						encryptedString.length() - 1);
				// log.info("decryptedString = " + decryptedString);
				return decrypt(decryptedString);
			}

			return decryptedString;
		} catch (Exception ex) {
			throw new RuntimeException("failed to decrypt text", ex);
		}
	}

	private static Cipher createCipher(char[] password, byte[] salt, int noIterations, int encryptionMode)
			throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException,
			InvalidAlgorithmParameterException {
		SecretKeyFactory kf = SecretKeyFactory.getInstance(ENCRYPTION_ALGORITHM);
		PBEKeySpec keySpec = new PBEKeySpec(password);
		SecretKey key = kf.generateSecret(keySpec);
		Cipher ciph = Cipher.getInstance(ENCRYPTION_ALGORITHM);

		PBEParameterSpec params = new PBEParameterSpec(salt, noIterations);
		ciph.init(encryptionMode, key, params);
		return ciph;
	}

	private static String getEncryptionAlgorithm() {
		String encryptionAlgorithm = ""; // FIXME
		if (StringUtils.isEmpty(encryptionAlgorithm)) {
			encryptionAlgorithm = DEFAULT_ENCRYPTION_ALGORITHM;
		}
		return encryptionAlgorithm;
	}
}
