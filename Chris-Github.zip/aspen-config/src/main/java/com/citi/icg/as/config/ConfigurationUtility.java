/**
 * 
 */
package com.citi.icg.as.config;

import static com.citi.icg.as.config.constants.ConfigConstants.APPLICATION_JSON_KEY;
import static com.citi.icg.as.config.constants.ConfigConstants.ASPEN_ENV_SYSTEM_PROPERTY;
import static com.citi.icg.as.config.constants.ConfigConstants.DATABASE_KEY;
import static com.citi.icg.as.config.constants.ConfigConstants.LOCAL_ENV;
import static com.citi.icg.as.config.constants.ConfigConstants.OS;
import static com.citi.icg.as.config.constants.ConfigConstants.PASSWORD;
import static com.citi.icg.as.config.constants.ConfigConstants.STREAM_ENV_PROPERTY;
import static com.citi.icg.as.config.constants.ConfigConstants.WINDOWS;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.StringUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author ap72338
 *
 */
@SuppressWarnings("restriction")
public class ConfigurationUtility {

	private final String environment;
	private Map<String, Map<String, Object>> configuration;
	private Map<String, Map<String, Object>> localConfiguration;
	private String configFile = "config.json";
	private String configFileForLocalDevelopment = "config-local.json";
	
	public ConfigurationUtility(String environment) {
		this.environment = environment.toLowerCase().trim();
		init(true);
	}

	public ConfigurationUtility(String environment, String configJsonFile) {
		this.environment = environment.toLowerCase().trim();
		this.configFile = configJsonFile;
		init(false);
	}

	private void init(boolean loadFromClassPath) {
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<Map<String, Map<String, Object>>> ref = new TypeReference<Map<String, Map<String, Object>>>() {
		};
		Resource res = null;
		if (loadFromClassPath) {
			res = new ClassPathResource(configFile);
		} else {
			res = new FileSystemResource(configFile);
		}
		try {
			configuration = mapper.readValue(res.getInputStream(), ref);
			readDbConfigForLocalDevelopment(mapper,ref);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @param ref 
	 * @param mapper 
	 * @param configuration2 
	 * 
	 */
	private void readDbConfigForLocalDevelopment(ObjectMapper mapper, TypeReference<Map<String, Map<String, Object>>> ref) {
		if(isLocalEnvironment()){
			ClassPathResource localResource = new ClassPathResource(configFileForLocalDevelopment);
			if(localResource.exists()){
				try {
					localConfiguration = mapper.readValue(localResource.getInputStream(), ref);					
				} catch (Exception e) {
					throw new RuntimeException(e);
				} 
			}
		}else{
			localConfiguration = new HashMap<String, Map<String,Object>>();
		}
	}

	@SuppressWarnings("restriction")
	public Object getProperty(String propertyName) {
		Map<String, Object> settings = getSettings();
		Object value = settings.get(propertyName);
		if (PASSWORD.equals(propertyName) && value != null) {
			return new String(DatatypeConverter.parseBase64Binary(value.toString()));
		}
		return value;
	}

	/**
	 * @return true if the current build is happening on a Windows OS. Windows
	 *         is the OS for development.
	 */
	public static boolean isDevelopment() {
		return (OS.indexOf(WINDOWS) >= 0);
	}

	public static boolean isLocalEnvironment() {
		return LOCAL_ENV.equalsIgnoreCase(System.getProperty(ASPEN_ENV_SYSTEM_PROPERTY,StringUtils.EMPTY));
	}
	public String getLoginURL() {
		Map<String, Object> settings = getSettings();
		return (String) ((Map) settings.get(APPLICATION_JSON_KEY)).get("loginURL");
	}

	private Map<String, Object> getSettings() {
		Map<String, Object> settings = configuration.get(environment);
		return settings;
	}

	/**
	 * @return
	 * <p>This method reads from configFileForLocalDevelopment</p>
	 */
	private Map<String, Object> getLocalSettings() {
		return localConfiguration.get(System.getProperty("user.name").toLowerCase());
	}
	
	public String getLaunchURL() {
		Map<String, Object> settings = getSettings();
		return (String) ((Map) settings.get(APPLICATION_JSON_KEY)).get("launchURL");
	}

	@SuppressWarnings("unchecked")
	public DatabaseConfig getDatabaseDetails() {
		Map<String, String> propsMap = null;
		if(isLocalEnvironment()){
			propsMap=(Map<String, String>) getLocalSettings().get(DATABASE_KEY);
		}
		
		if(propsMap==null || propsMap.isEmpty()){
			propsMap = (Map<String, String>) getSettings().get(DATABASE_KEY);	
		}
		
		return new DatabaseConfig(propsMap.get("url"), propsMap.get("userName"),
				EncryptionUtils.decryptIfEncrypted(propsMap.get("password")), propsMap.get("driver"));
	}

	@SuppressWarnings("unchecked")
	public EMCConfiguration getEMCConfig() {
		Map<String, String> propsMap = (Map<String, String>) getSettings().get("emcConfig");

		return new EMCConfiguration(propsMap.get("contextFactory"), propsMap.get("providerURL"),
				propsMap.get("userName"), EncryptionUtils.decryptIfEncrypted(propsMap.get("password")),
				propsMap.get("listenerQueueName"), propsMap.get("connectionFactory"));
	}

	@SuppressWarnings("unchecked")
	public GPDWConfiguration getGPDWConfig() {
		Map<String, String> propsMap = (Map<String, String>) getSettings().get("gpdwConfig");

		return new GPDWConfiguration(propsMap.get("contextFactory"), propsMap.get("providerURL"),
				propsMap.get("userName"), EncryptionUtils.decryptIfEncrypted(propsMap.get("password")),
				propsMap.get("compositeListenerQueueName"), propsMap.get("connectionFactory"),propsMap.get("broadcastQueue"));
	}
	
	public AsyncQueues getAsyncQueues() {
		Map<String, Map<String,String>> asyncQueuesConfigMap = (Map<String, Map<String,String>>) getSettings().get("asyncQueuesConfig");
		Map<String,String>streamSpecificQueues = asyncQueuesConfigMap.get(System.getProperty(STREAM_ENV_PROPERTY));
		return new AsyncQueues(streamSpecificQueues);
	}
	
	@SuppressWarnings("unchecked")
	public MongoDbConfig getMongoDbConfig() {
		Map<String, Object> propsMap = (Map<String, Object>) getSettings().get("mongoDB");

		MongoDbConfig config = new MongoDbConfig(nullSafeString(propsMap.get("databaseName")),
				nullSafeString(propsMap.get("userName")),
				EncryptionUtils.decryptIfEncrypted(nullSafeString(propsMap.get("password"))),
				nullSafeString(propsMap.get("trustStore")),
				EncryptionUtils.decryptIfEncrypted(nullSafeString(propsMap.get("trustStorePassword"))), StringUtils
						.trimToEmpty(nullSafeString(propsMap.get("useSSL"))).equalsIgnoreCase(Boolean.TRUE.toString()));
		
		List<Map<String, Object>> servers = (List<Map<String, Object>>) propsMap.get("serverAddresses");
		for (Map<String, Object> map : servers) {
			config.addServer(nullSafeString(map.get("host")), Integer.valueOf(nullSafeString(map.get("port"))));
		}
		return config;
	}

	/**
	 * 
	 * @return the regex pattern for the exclusion list. This will be used in
	 *         place of cluster master table to decide which node is allowed to
	 *         pick up messages for async communication
	 */
	public String getAsyncModeExclusionNodes() {
		return (String) getSettings().get("asyncModeExclusionNodes");  
	}
	
	private String nullSafeString(Object value) {
		return null != value ? value.toString() : StringUtils.EMPTY;
	}

}
