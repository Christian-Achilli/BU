/**
 * 
 */
package com.citi.icg.msst.cmot.as.config.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citi.icg.as.config.AsyncQueues;
import com.citi.icg.as.config.ConfigurationUtility;
import com.citi.icg.as.config.DatabaseConfig;

/**
 * @author ap72338
 *         <p>
 *         Declare the beans which you want and they will be available when
 *         enabled using {@link EnableCentralJsonConfig}
 *         </p>
 */

@Configuration
public class AspenCentralJsonConfiguration {
	public static final String SYSTEM_BUSINESS_STREAM_PROPERTY = "aspen.stream";
	public static final String SYSTEM_ENV_PROPERTY = "aspen.env";
	public static final String CUSTODY_STREAM = "custody";
	public static final String MARKETS_STREAM = "markets";

	@Bean
	public ConfigurationUtility configUtility() {
		return new ConfigurationUtility(System.getProperty(SYSTEM_ENV_PROPERTY));
	}

	@Bean
	public AsyncQueues asyncQueues(ConfigurationUtility configUtility) {
		return configUtility.getAsyncQueues();
	}

	@Bean
	public DatabaseConfig databaseConfig(ConfigurationUtility configUtility) {
		return configUtility.getDatabaseDetails();
	}
}
