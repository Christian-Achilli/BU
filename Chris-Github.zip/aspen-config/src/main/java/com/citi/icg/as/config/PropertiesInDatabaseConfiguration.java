/**
 * 
 */
package com.citi.icg.as.config;

import static org.apache.commons.lang.StringUtils.isNotBlank;
import static org.apache.commons.lang.StringUtils.repeat;
import static org.springframework.util.Assert.isTrue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

/**
 * @author ap72338
 *         <p>
 *         This class will be used to read the properties from database table
 *         <b>ASPEN_PROPERTIES</b> with DDL
 *         {@code CREATE TABLE ASPEN_PROPERTIES(ENV VARCHAR2(10),COMPONENT VARCHAR2(20),KEY VARCHAR2(100), VALUE VARCHAR2(1000));}
 *         .
 *         </p>
 *         <p>
 *         Each component just needs to define a
 *         {@link PropertyPlaceholderConfigurer} and set the properties as
 *         </p>
 *         <p>
 * 
 *         <pre>
 * {@code <bean id="databaseConfig" class="com.citi.icg.as.config.DatabaseConfiguration">
 * <constructor-arg index="0" name="env" value="QA3" />
 * <constructor-arg index="1" name="component" value="POSITIONS" />
 * </bean>

*<bean id="properties" class="org.springframework.beans.factory.config.PropertyPlaceholderConfigurer">
 * &lt;property name="properties" value="#{databaseConfig.getProperties()}" />
*&lt;/bean>
 *         </pre>
 *         </p>
 */
public class PropertiesInDatabaseConfiguration implements InitializingBean {
	private Properties properties;
	private String env, component;
	private boolean lookupCommonProperties = true;
	private static final String COMMON_PROPERTIES = "COMMON";

	public PropertiesInDatabaseConfiguration(String env, String component) {
		isTrue(isNotBlank(env), "Environment must be specified: local|qa1|qa2|qa3|uat1|uat2 etc..");
		isTrue(isNotBlank(component),
				"Component must be specified. POSITIONS|ASSETSERVICING|ASPEN-DAO|POSTINGS|PAYMENTS|EC etc. For multiple components separate them by ;");

		this.env = env;
		this.component = component;
	}

	public void afterPropertiesSet() throws Exception {

		ConfigurationUtility utility = new ConfigurationUtility(this.env);
		DatabaseConfig config = utility.getDatabaseDetails();

		String[] components = this.component.split(";");

		int len = lookupCommonProperties ? components.length + 1 : components.length;

		String sqlParams = repeat("?", ",", len);
		String sql = "SELECT * FROM ASPEN_PROPERTIES WHERE ENV=? AND COMPONENT IN (" + sqlParams + ")";

		try (Connection connection = DriverManager.getConnection(config.getUrl(), config.getUser(),
				config.getPassword()); PreparedStatement ps = connection.prepareStatement(sql);) {

			ps.setString(1, this.env.trim().toUpperCase());
			int index = 2;
			for (String str : components) {
				ps.setString(index++, str.toUpperCase().trim());
			}

			if (lookupCommonProperties) {
				ps.setString(index, COMMON_PROPERTIES);
			}

			List<DBConfig> configList = new ArrayList<DBConfig>();

			try (ResultSet rs = ps.executeQuery();) {
				while (rs.next()) {
					DBConfig c = new DBConfig();
					c.setComponent(rs.getString("COMPONENT"));
					c.setEnvironment(rs.getString("ENV"));
					c.setKey(rs.getString("KEY"));
					c.setValue(rs.getString("VALUE"));
					configList.add(c);
				}
			}
			properties = new Properties();
			for (DBConfig dbConfig : configList) {
				properties.put(dbConfig.getKey(), dbConfig.getValue());
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}

	}

	public Properties getProperties() {
		return properties;
	}

	/**
	 * @param lookupCommonProperties
	 *            Set it to false if you don't need to load common properties
	 */
	public void setLookupCommonProperties(boolean lookupCommonProperties) {
		this.lookupCommonProperties = lookupCommonProperties;
	}
}
