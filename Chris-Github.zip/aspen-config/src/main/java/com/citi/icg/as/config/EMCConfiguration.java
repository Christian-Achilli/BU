/**
 * 
 */
package com.citi.icg.as.config;

/**
 * @author ap72338
 *
 */
public class EMCConfiguration extends AbstractEMSConfiguration {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3320368306077642289L;

	public EMCConfiguration(String contextFactory, String providerURL, String userName, String password,
			String listenerQueueName, String connectionFactory) {
		super(contextFactory, providerURL, userName, password, listenerQueueName, connectionFactory);
	}

	
}