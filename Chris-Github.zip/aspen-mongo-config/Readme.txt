// build compiled jars + javadoc and source jars
mvn package -P buildAll