/**
 * 
 */
package com.citi.icg.as.mongo.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * @author ap72338
 *         <p>
 *         The condition checks if the system property "useMongoDB" is true. If
 *         true, only then the required classes for MongoDB will be initialised
 *         </p>
 */
public class MongoDbCondition implements Condition {

	public static final String USE_MONGODB_IN_TESTS = "useMongoDB";
	
	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		String systemConfigurationValue = System.getProperty(USE_MONGODB_IN_TESTS, StringUtils.EMPTY);
		return Boolean.TRUE.toString().equalsIgnoreCase(systemConfigurationValue);
	}
}