/**
 * 
 */
package com.citi.icg.as.mongo.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.CustomConversions;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.citi.icg.as.config.ConfigurationUtility;
import com.citi.icg.as.config.MongoDbConfig;
import com.citi.icg.as.config.MongoDbConfig.MongoServer;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/**
 * @author ap72338
 *         <p>
 *         This class initialises the configuration for MongoDB based on
 *         {@link MongoDbCondition}
 *         </p>
 * 
 *         <p>
 *         SSL usage - Citi MaaS uses SSL and certificates to connect. So in
 *         order to connect, we must set SSL to be used {@link MongoClientURI}
 *         or {@link MongoClientOptions.sslEnabled} to true.
 *         </p>
 *         <p>
 *         For this we have been provided with the PEM file as in the
 *         src/main/resources. The default generated mongostore.ts is also
 *         present under the same folder
 *         </p>
 *         <p>
 *         We need to import that certificate in the truststore. For that, open
 *         command prompt and give the below command
 *         </p>
 *         <p>
 *         keytool -import -file ca_prod_compass.pem -alias mongoClient
 *         -keystore mongostore.ts -storepass
 *         "password as configured in aspen-config"
 *         </p>
 *         For local development, copy the mongostore.ts file to ${user.home}
 */

@Configuration
@EnableMongoRepositories
public class MongoDBConfiguration {

	@Autowired
	private ConfigurationUtility configUtility;

	/**
	 * See the ELVIS operator, (:) at the last. This makes it an optional
	 * property
	 */
	@Value("${mongo.trustStorePath:}")
	private String trustStorePath;

	@Bean
	public MongoDbConfig mongoDbConfig() {
		return configUtility.getMongoDbConfig();
	}

	@Bean
	public MongoDbFactory mongoDbFactory() throws Exception {
		return new SimpleMongoDbFactory(mongoClient(), mongoDbConfig().getDatabaseName());
	}

	@Bean
	public MongoTemplate mongoTemplate() throws Exception {
		return new MongoTemplate(mongoDbFactory(), mongoConverter());
	}

	@Bean
	public MongoClient mongoClient() throws Exception {
		final MongoDbConfig mongoConfig = mongoDbConfig();

		if (mongoConfig.isSSLToBeUsed()) {
			if (StringUtils.isBlank(trustStorePath)) {
				throw new IllegalStateException("Since SSL is enabled for the Mongo DB to connected to,\n "
						+ "The Trust store path property [mongo.trustStorePath] must be provided either as a system property or in spring property place holder configurer.");
			}
			System.setProperty("javax.net.ssl.trustStore", trustStorePath + mongoConfig.getTrustStore());
			System.setProperty("javax.net.ssl.trustStorePassword", mongoConfig.getTrustStorePassword());
		}

		List<MongoCredential> credentialList = new ArrayList<MongoCredential>();

		// Add credentials
		MongoCredential credentials = MongoCredential.createCredential(mongoConfig.getUserName(),
				mongoConfig.getDatabaseName(), mongoConfig.getPassword().toCharArray());
		credentialList.add(credentials);

		// Set SSL to be used or not
		MongoClientOptions options = MongoClientOptions.builder().sslEnabled(mongoConfig.isSSLToBeUsed())
				.sslInvalidHostNameAllowed(true).build();

		// Add all hosts / nodes
		List<ServerAddress> servers = new ArrayList<ServerAddress>();
		for (MongoServer server : mongoConfig.getServers()) {
			servers.add(new ServerAddress(server.getHost(), server.getPort()));
		}

		// Construct the actual mongo client
		return new MongoClient(servers, credentialList, options);
	}

	@Bean
	public CustomConversions customConversions() {
		List<Converter<?, ?>> converters = new ArrayList<Converter<?, ?>>();
		populateCustomConverters(converters);
		return new CustomConversions(converters);
	}

	@Bean
	public MappingMongoConverter mongoConverter() throws Exception {
		MongoMappingContext mappingContext = new MongoMappingContext();
		DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDbFactory());
		MappingMongoConverter mongoConverter = new MappingMongoConverter(dbRefResolver, mappingContext);
		mongoConverter.setCustomConversions(customConversions());
		mongoConverter.afterPropertiesSet();
		return mongoConverter;
	}

	/**
	 * @param converters
	 *            Override this method in child {@link Configuration} classes
	 */
	protected void populateCustomConverters(final List<Converter<?, ?>> converters) {
		// override this method in child classes, by extending this class
	}
}
