package com.citi.icg.as.test.automation.core.locator;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * @author ap72338
 *         <p>
 *         This class, can be used in the XPATH information of an element to
 *         describe post action. For example when we enter security in Create
 *         Manual Event, then we click on Search Image and the waiting screen is
 *         displayed till the security name gets populated.
 *         </p>
 *         <p>
 *         So this condition will specify the element name to be checked, the
 *         attribute of the element that we should poll and what should be the
 *         expected value.
 *         <p>
 *         <b>All time values {@link #setDelay(int)}, {@link #setMaxWait(int)}
 *         are in millseconds</b>
 *         </p>
 * 
 * 
 *         <p>
 *         Description of fields-
 *         <ul>
 *         <li>element - This is the name of the element NOT on UI but rather in
 *         the same JSON file which should be checked for some attribute like
 *         visibility, value etc. The condition will be evaluated against this
 *         element.</li>
 * 
 *         <li>attribute - The attribute of the above element that needs to be
 *         checked. This can be null, in which case most probably, you will specify
 *         VISIBILITY constraint.</li>
 * 
 *         <li>expectedValue - While evaluating the condition, what is the value
 *         we are expecting for the condition to be TRUE</li>
 * 
 *         <li>maxWait - We cannot keep on evaluating the condition forever. So
 *         whats the max time</li>
 * 
 *         <li>delay- This can be confusing. This field defines after how much
 *         time, we should start evaluating the condition.</li>
 *         </ul>
 *         </p>
 *         
 *         <p>Example- say the below is present in XYZ.json <br/> 
 *         	<pre>
 *         "postCondition": {
        	"delay": 2000,
        	"element": "waitDialog",
        	"attribute": "aria-hidden",
        	"expectedValue": "true",
        	"expectedValueConstraint": "VALUE",
        	"maxWait": 40000
      	}
      				</pre>
      			<p>
      			The above condition is looking for an element waitDialog, look for key in XYZ.json, which will have an XPath, that is the actual UI element we are after.
      			We will wait for 40 seconds for its attribute "aria-hidden" to be true. After that the code will timeout. 
      			Hey, but it has delay as well. Exactly- so we will first start checking the value, after a delay of 2 seconds, and not immediately after the last driver operation.
      			Hope this explains. Cheers. Enjoy coding
      			</p>
 *         </p>
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Condition {

	private String element;
	private String attribute;
	private String expectedValue;

	/**
	 * Delay after which the condition will itself be checked. This is
	 * necessary, as sometimes we need that driver should check the condition
	 * after some seconds.
	 * <p>
	 * Example - We click a button and we want to wait that wait dialog appears,
	 * and only after that we start checking it has disappeared. Value is in
	 * seconds.
	 * </p>
	 * 
	 * Default is no wait
	 */
	private int delay = -1;
	private int maxWait = -1;

	private ConstraintType expectedValueConstraint;

	public String getElement() {
		return element;
	}

	public void setElement(String element) {
		this.element = element;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public String getExpectedValue() {
		return expectedValue;
	}

	public void setExpectedValue(String expectedValue) {
		this.expectedValue = expectedValue;
	}

	public ConstraintType getExpectedValueConstraint() {
		return null == expectedValueConstraint ? ConstraintType.VALUE : expectedValueConstraint;
	}

	public void setExpectedValueConstraint(ConstraintType expectedValueConstraint) {
		this.expectedValueConstraint = expectedValueConstraint;
	}

	public int getDelay() {
		return delay;
	}

	public void setDelay(int delay) {
		this.delay = delay;
	}

	public int getMaxWait() {
		return maxWait;
	}

	public void setMaxWait(int maxWait) {
		this.maxWait = maxWait;
	}
}
