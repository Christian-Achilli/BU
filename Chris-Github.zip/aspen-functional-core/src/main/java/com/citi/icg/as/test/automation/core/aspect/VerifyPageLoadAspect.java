/**
 * 
 */
package com.citi.icg.as.test.automation.core.aspect;

import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import com.citi.icg.as.test.automation.core.annotation.VerifyPageLoad;
import com.citi.icg.as.test.automation.core.page.Component;

/**
 * @author ap72338
 *         <p>
 *         This Aspect always call the private method "load" of classes
 *         annotated with {@link VerifyPageLoad}, the default method being
 *         "load". As the tabs are Autowired by Spring, so functions just return
 *         the tab, and load may get ignored. So this Aspect picks up all
 *         methods returning and calls the load method before returning, through
 *         the {@link Around} advice.
 *         </p>
 */

@Aspect
public class VerifyPageLoadAspect {

	private final static Logger logger = LoggerFactory.getLogger(VerifyPageLoadAspect.class);
	
	@Pointcut("execution(public (@com.citi.icg.as.test.automation.core.annotation.VerifyPageLoad *)  com.citi.icg.as.test.automation.core..*.*(..))")
	private void allMethodsReturningTabsWithBeforePageLoadAnnotation() {
	}

	@Around(value = "allMethodsReturningTabsWithBeforePageLoadAnnotation()")
	public final Object handleMethod(final ProceedingJoinPoint joinPoint) throws Throwable {
		MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
		
		Component tab = (Component) joinPoint.proceed(joinPoint.getArgs());
		String methodName = tab.getClass().getAnnotation(VerifyPageLoad.class).methodName();
		/*
		 * The if condition means that we are returning the same object as the /
		 * object under work. Example wherever we use return this; we don't want
		 * / the private method to be invoked again. Only if the object is
		 * returned from a different class say InboxTab from EventdetailsTab,
		 * then only the the private method through the aspect should be called
		 */
		
		if (!methodSignature.getReturnType().equals(joinPoint.getThis().getClass())) {
			Method method = ReflectionUtils.findMethod(tab.getClass(), methodName);
			ReflectionUtils.makeAccessible(method);
			ReflectionUtils.invokeMethod(method, tab);
		}else{
			//The below message helps in debugging.
			logger.info("Return type and class from where returned are same. So no need to check whether page has been loaded or not.");
		}
		return tab;
	}

}
