package com.citi.icg.as.test.automation.core.utilities;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * 
 * @author ap72338
 *
 */

public class CommonUtils {

    private static final Logger logger = LoggerFactory.getLogger(CommonUtils.class);

    public static Timestamp getCurrentTimeStamp() {
        return new Timestamp((new Date()).getTime());
    }

    /**
     * @param duration in milliseconds
     */
    public static void delay(long duration) {
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
        	logger.error(e.getMessage(),e);
        	//Always preserve the interrupted status
            Thread.currentThread().interrupt();
        }
    }
}
