/**
 * 
 */
package com.citi.icg.as.test.automation.core.utilities;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;

import com.citi.icg.as.test.automation.core.locator.Condition;
import com.citi.icg.as.test.automation.core.locator.ConstraintType;

/**
 * @author ap72338
 *
 */
class ValueConditionEvaluator extends ConditionEvaluator {

	@Override
	protected boolean evaluateInternal(Condition condition, WebElement lookingForElement) {
		String actualValue = lookingForElement.getAttribute(condition.getAttribute());

		if (condition.getExpectedValue().startsWith(NOT)) {
			return StringUtils.isNotBlank(actualValue);
		}
		return StringUtils.isBlank(actualValue);
	}

	@Override
	protected boolean canHandle(Condition condition) {
		return ConstraintType.VALUE == condition.getExpectedValueConstraint();
	}

}
