/**
 * 
 */
package com.citi.icg.as.test.automation.core.utilities;

import java.lang.reflect.Field;

import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.ReflectionUtils.FieldCallback;

/**
 * @author ap72338
 *
 */
public class IntrospectionUtils {

	public static void clearThreadLocals(final Object target) {
		Assert.notNull(target, "Target object whose thread locals need to be cleared cannot be null");
		ReflectionUtils.doWithLocalFields(target.getClass(), new FieldCallback() {
			@Override
			public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
				if (field.getType().equals(ThreadLocal.class)) {
					ReflectionUtils.makeAccessible(field);
					((ThreadLocal<?>) field.get(this)).remove();
				}
			}
		});
	}
}
