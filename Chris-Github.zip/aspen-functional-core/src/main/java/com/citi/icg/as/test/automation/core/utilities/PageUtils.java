/**
 * 
 */
package com.citi.icg.as.test.automation.core.utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.util.Assert;

import com.citi.icg.as.test.automation.core.locator.Condition;
import com.citi.icg.as.test.automation.core.locator.ConstraintType;
import com.citi.icg.as.test.automation.core.locator.Constraints;
import com.citi.icg.as.test.automation.core.locator.Locator;

/**
 * @author ap72338
 *
 */
public class PageUtils {
	private static final int MS_UNITS = 1000;
	private final List<ConditionEvaluator> evaluatorList = new ArrayList<ConditionEvaluator>();

	private static PageUtils pageUtils = new PageUtils();

	public static PageUtils getInstance() {
		return pageUtils;
	}

	private PageUtils() {
		evaluatorList.add(new VisibilityConditionEvaluator());
		evaluatorList.add(new ValueConditionEvaluator());
	}

	public WebElement getElementByXPath(WebDriver driver, String xPath) {
		Assert.notNull(driver);
		return driver.findElement(By.xpath(xPath));
	}

	public List<WebElement> getElementsByXPath(WebDriver driver, String xPath) {
		Assert.notNull(driver);
		return driver.findElements(By.xpath(xPath));
	}

	public void postAction(final WebDriver driver, final Map<String, Locator> loc, String element) {
		Locator elementLocator = loc.get(element);
		if (elementLocator.getMetaData() != null && elementLocator.getMetaData().getPostCondition() != null) {
			final Condition condition = elementLocator.getMetaData().getPostCondition();
			executeCondition(driver, loc, elementLocator, condition);
		} else {
			if (elementLocator.getMetaData() != null && elementLocator.getMetaData().getPostActionDelay() > 0) {
				CommonUtils.delay(elementLocator.getMetaData().getPostActionDelay());
			}
		}
	}

	private void executeCondition(final WebDriver driver, final Map<String, Locator> loc, Locator elementLocator,
			final Condition condition) {

		if (condition.getDelay() > 0) {
			CommonUtils.delay(condition.getDelay());
		}

		if (condition.getExpectedValueConstraint() != null) {
			(new WebDriverWait(driver, condition.getMaxWait() / MS_UNITS)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver d) {
					try {
						final WebElement lookingForElement = driver
								.findElement(By.xpath(loc.get(condition.getElement()).getXPath()));
						boolean conditionComplete = false;
						for (ConditionEvaluator conditionEvaluator : evaluatorList) {
							if (conditionEvaluator.canHandle(condition)) {
								conditionComplete = conditionEvaluator.evaluate(driver, condition, lookingForElement);
							}
						}
						return conditionComplete;
					} catch (NotFoundException e) {
						if (ConstraintType.VISIBILITY == condition.getExpectedValueConstraint()
								&& Constraints.NOT_VISIBLE.toString().equals(condition.getExpectedValue())) {
							/*
							 * this probably means element is not present or is
							 * hidden. It means same where constraint is
							 * visibility related
							 */
							return true;
						}
						throw e;
					}
				}
			});
		} else {
			(new WebDriverWait(driver, condition.getMaxWait() / MS_UNITS)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver d) {
					return d.findElements(By.xpath(loc.get(condition.getElement()).getXPath())).size() != 0;
				}
			});
		}
	}

	public void preAction(final WebDriver driver, final Map<String, Locator> loc, String element) {
		Locator elementLocator = loc.get(element);
		if (elementLocator.getMetaData() != null && elementLocator.getMetaData().getPreCondition() != null) {
			final Condition condition = elementLocator.getMetaData().getPreCondition();
			executeCondition(driver, loc, elementLocator, condition);
		} else {
			if (elementLocator.getMetaData() != null && elementLocator.getMetaData().getPreActionDelay() > 0) {
				CommonUtils.delay(elementLocator.getMetaData().getPreActionDelay());
			}
		}
	}
}
