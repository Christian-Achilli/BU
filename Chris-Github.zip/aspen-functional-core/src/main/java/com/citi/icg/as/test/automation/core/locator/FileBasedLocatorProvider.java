/**
 * 
 */
package com.citi.icg.as.test.automation.core.locator;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.util.Assert;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author ap72338 This provider looks for the JSON files in which element XPath
 *         information is stored. The rules as under
 *         <ul>
 *         <li>If the user operation is initiated from a page say
 *         CorporateActionsPage then it will look for a JSON file
 *         CorporateActionsPage.json</li>
 *         <li>If the user operation is initiated from a tab say
 *         CreateManualEventTab then it will look for a JSON file
 *         CreateManualEventTab.json</li>
 *         <li>Same way if the operation has been invoked from a section then it
 *         will look for the file named <section>.json</li>
 *         </ul>
 *         <p>
 *         To support multiple releases/branches, we can either
 *         <ul>
 *         <li>provide the absolute path of the release itself</li>
 *         <li>provide the base path and the system will scan all the sub
 *         folders and pick up the latest JSON</li>
 *         <li>If we have multiple latest, then we can provide system property
 *         with the folder name, in which case, the most probable will not be
 *         the latest but rather from the specified folder</li>
 *         </ul>
 *         </p>
 */

public class FileBasedLocatorProvider implements LocatorProvider {

	private static final String FILE_SEPARATOR = "file.separator";
	private static final String JSON = ".json";
	private String basePath;
	private ObjectMapper objectMapper;

	private final String SPECIFIC_FOLDER_SYSTEM_PROPERTY = "specificFolderInCaseMultipleFound";

	private final static Logger LOGGER = LoggerFactory.getLogger(FileBasedLocatorProvider.class);

	public FileBasedLocatorProvider(String basePath) {
		Assert.isTrue(isNotBlank(basePath));
		if (basePath.endsWith("/") || basePath.endsWith("\\")) {
			basePath = basePath.substring(0, basePath.length() - 1);
		}
		basePath = basePath.concat(System.getProperty(FILE_SEPARATOR));
		this.basePath = basePath;
		this.objectMapper = new ObjectMapper();
	}

	public String getBasePath() {
		return this.basePath;
	}

	@Override
	@Cacheable(cacheNames = FILE_XPATH_CACHE)
	public Map<String, Locator> getLocatorInfo(String id) {
		InputStream iStream = null;
		File baseDirectory = new File(basePath);

		List<File> probables = getProbables(baseDirectory, id);

		if (probables.size() > 1) {
			logProbables(id, probables);
		}

		Assert.notEmpty(probables, String.format("No file could be found for id %s", id));

		File mostProbable = findMostProbableFile(probables, id);

		try {
			iStream = new FileInputStream(mostProbable);
		} catch (FileNotFoundException e) {
			throw new IllegalStateException(e);
		}

		TypeReference<Map<String, Locator>> ref = new TypeReference<Map<String, Locator>>() {
		};

		try {
			return objectMapper.readValue(iStream, ref);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			IOUtils.closeQuietly(iStream);
		}
	}

	/**
	 * @param probables
	 * @return This method finds the most probable file containing sought after
	 *         xPaths. In case there are multiple, then the most probable is the
	 *         latest, unless overridden by system property
	 *         {@link #SPECIFIC_FOLDER_SYSTEM_PROPERTY}, in which case, if the
	 *         probable contains that folder in the path, its picked up.
	 */
	private File findMostProbableFile(final List<File> probables, String lookingFor) {
		Collections.sort(probables, new Comparator<File>() {
			@Override
			public int compare(File file1, File file2) {
				return new Date(file2.lastModified()).compareTo(new Date(file1.lastModified()));
			}
		});

		String overrideFolder = System.getProperty(SPECIFIC_FOLDER_SYSTEM_PROPERTY);
		File mostProbable = probables.get(0);

		if (isNotBlank(overrideFolder)) {
			File folderSpecificProbable = null;
			final String specificFolder = File.separator + overrideFolder + File.separator;
			for (File file : probables) {
				if (file.getAbsolutePath().contains(specificFolder)) {
					folderSpecificProbable = file;
					break;
				}
			}
			if (folderSpecificProbable == null) {
				LOGGER.warn("File {} not found in specific folder {}. Latest will be used", lookingFor, overrideFolder);
			} else {
				mostProbable = folderSpecificProbable;
			}
		}
		return mostProbable;
	}

	private void logProbables(String id, List<File> probables) {
		LOGGER.info("Multiple files found for id {}", id);
		StringBuilder builder = new StringBuilder();
		for (File file : probables) {
			builder.append(file.getPath());
			builder.append(System.getProperty("line.separator"));
		}
		LOGGER.info(builder.toString());
	}

	/**
	 * @param baseDirectory
	 * @param id
	 * @return
	 * 		<p>
	 *         This folder recursively adds all the files with name id +.json
	 *         from a given base directory
	 *         </p>
	 */
	private List<File> getProbables(File baseDirectory, String id) {
		File[] files = baseDirectory.listFiles();
		List<File> probables = new ArrayList<File>();
		final String lookingFor = id + JSON;
		for (File file : files) {
			if (file.isDirectory()) {
				probables.addAll(getProbables(file, id));
			} else if (file.getName().equals(lookingFor)) {
				probables.add(file);
			}
		}
		return probables;
	}
}
