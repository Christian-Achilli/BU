/**
 * 
 */
package com.citi.icg.as.test.automation.core.locator;

/**
 * @author ap72338
 * The locator/xpath information can be kept in file or database. This enum represents the same
 */
public enum LocatorType {

	FILE,DB
}
