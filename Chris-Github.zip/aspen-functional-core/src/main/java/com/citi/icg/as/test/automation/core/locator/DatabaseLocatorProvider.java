/**
 * 
 */
package com.citi.icg.as.test.automation.core.locator;

import java.util.Map;

import org.apache.commons.lang3.NotImplementedException;

/**
 * @author ap72338 Can be implemented later. may be when we start keeping the
 *         XPath info in NoSQL DB
 */

public class DatabaseLocatorProvider implements LocatorProvider {

	public DatabaseLocatorProvider() {
		throw new NotImplementedException(
				"XPath configuration through DB is not configured yet. Use file based locator provider");
	}

	@Override
	public Map<String, Locator> getLocatorInfo(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
