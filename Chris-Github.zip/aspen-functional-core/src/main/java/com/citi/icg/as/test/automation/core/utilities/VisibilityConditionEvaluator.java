/**
 * 
 */
package com.citi.icg.as.test.automation.core.utilities;

import org.openqa.selenium.WebElement;

import com.citi.icg.as.test.automation.core.locator.Condition;
import com.citi.icg.as.test.automation.core.locator.ConstraintType;

/**
 * @author ap72338
 *
 */
class VisibilityConditionEvaluator extends ConditionEvaluator {
	@Override
	protected boolean evaluateInternal(Condition condition, WebElement lookingForElement) {
		if (condition.getExpectedValue().startsWith(NOT)) {
			return !lookingForElement.isDisplayed();
		} else {
			return lookingForElement.isDisplayed();
		}
	}

	@Override
	protected boolean canHandle(Condition condition) {
		return ConstraintType.VISIBILITY == condition.getExpectedValueConstraint();
	}

}
