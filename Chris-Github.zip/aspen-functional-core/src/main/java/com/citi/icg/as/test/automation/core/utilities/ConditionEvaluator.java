/**
 * 
 */
package com.citi.icg.as.test.automation.core.utilities;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.citi.icg.as.test.automation.core.locator.Condition;
import com.citi.icg.as.test.automation.core.locator.Constraints;

/**
 * @author ap72338
 *
 */
abstract class ConditionEvaluator {

	protected static final String NOT = "NOT_";
	protected final List<String> constraintList = new ArrayList<String>();
	

	protected abstract boolean evaluateInternal(Condition condition, WebElement lookingForElement);
	protected abstract boolean canHandle(Condition condition);
	
	public ConditionEvaluator() {
		for (Constraints c : Constraints.values()) {
			constraintList.add(c.toString());
		}
	}

	public List<String> getConstraintList() {
		return constraintList;
	}

	/**
	 * 
	 * @param driver
	 * @param condition
	 * @param lookingForElement
	 * @return 
	 */
	public boolean evaluate(WebDriver driver, Condition condition, WebElement lookingForElement) {		
		if (constraintList.contains(condition.getExpectedValue())) {			
			return evaluateInternal(condition, lookingForElement);
		}
		String actualValue = lookingForElement.getAttribute(condition.getAttribute());
		return condition.getExpectedValue().equals(actualValue);
	}
}
