package com.citi.icg.as.test.automation.core.locator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * @author ap72338
 *
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Locator {

	@JsonProperty(required = true)
	private String xPath;

	private MetaData metaData;

	public static class MetaData {
		private Condition preCondition;
		/**
		 * This is a fixed post delay, irrespective of the condition. Ideally we
		 * should use {@link Condition} and {@link Condition.maxWait}
		 * combination, but there are times when we just want a delay. So we can
		 * use these attributes in those cases. Time in milliseconds
		 */
		private int postActionDelay = -1;

		/**
		 * This is a fixed pre delay, irrespective of the condition. Ideally we
		 * should use {@link Condition} and {@link Condition.maxWait}
		 * combination, but there are times when we just want a delay. So we can
		 * use these attributes in those cases. Time in milliseconds
		 */
		private int preActionDelay = -1;

		private Condition postCondition;

		public Condition getPreCondition() {
			return preCondition;
		}

		public void setPreCondition(Condition preCondition) {
			this.preCondition = preCondition;
		}

		public Condition getPostCondition() {
			return postCondition;
		}

		public void setPostCondition(Condition postCondition) {
			this.postCondition = postCondition;
		}

		public int getPostActionDelay() {
			return postActionDelay;
		}

		public void setPostActionDelay(int postConditionMaxWait) {
			this.postActionDelay = postConditionMaxWait;
		}

		public int getPreActionDelay() {
			return preActionDelay;
		}

		public void setPreActionDelay(int preConditionMaxWait) {
			this.preActionDelay = preConditionMaxWait;
		}

	}

	public String getXPath() {
		return xPath;
	}

	public void setXPath(String xPath) {
		this.xPath = xPath;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}
}