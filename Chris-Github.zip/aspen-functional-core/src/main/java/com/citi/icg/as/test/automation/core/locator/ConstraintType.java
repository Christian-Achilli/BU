/**
 * 
 */
package com.citi.icg.as.test.automation.core.locator;

/**
 * @author ap72338
 *
 */


public enum ConstraintType {
	
	VALUE, VISIBILITY;
}
