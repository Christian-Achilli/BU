/**
 * 
 */
package com.citi.icg.as.test.automation.core.locator;

/**
 * @author ap72338
 *
 */
public enum Constraints {
	NOT_NULL,NULL,EMPTY,NOT_EMPTY,VISIBLE,NOT_VISIBLE;
}
