/**
 * 
 */
package com.citi.icg.as.test.automation.core.utilities;

import java.io.File;
import java.io.PrintWriter;

import org.springframework.core.io.ClassPathResource;

import com.citi.icg.as.test.automation.core.locator.Locator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.module.jsonSchema.JsonSchema;
import com.fasterxml.jackson.module.jsonSchema.factories.SchemaFactoryWrapper;

/**
 * @author ap72338
 *         <p>
 *         A small main class to generate the JSON schema based on
 *         {@link Locator}. After any change in this class, run this program and
 *         it will generate the schema in locators/schema folder
 *         </p>
 */
public class JSONSchemaGenerator {

	public static void main(String args[]) throws Exception {
		ObjectMapper m = new ObjectMapper();
		m.enable(SerializationFeature.INDENT_OUTPUT);
		SchemaFactoryWrapper visitor = new SchemaFactoryWrapper();
		m.acceptJsonFormatVisitor(m.constructType(Locator.class), visitor);
		JsonSchema jsonSchema = visitor.finalSchema();

		ClassPathResource res = new ClassPathResource("", Locator.class);
		String resourcesPath = res.getFile().getAbsolutePath().substring(0,
				res.getFile().getAbsolutePath().indexOf("target")) + "src/main/resources/locators/schema/";
		PrintWriter pw = new PrintWriter(new File(resourcesPath + "locatorSchema.json"));
		pw.println(m.writeValueAsString(jsonSchema));
		pw.close();

	}
}
