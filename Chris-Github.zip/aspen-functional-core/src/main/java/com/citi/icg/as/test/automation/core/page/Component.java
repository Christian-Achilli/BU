package com.citi.icg.as.test.automation.core.page;

import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.StrSubstitutor;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.Assert;

import com.citi.icg.as.test.automation.core.locator.Locator;
import com.citi.icg.as.test.automation.core.locator.LocatorProvider;
import com.citi.icg.as.test.automation.core.utilities.CommonUtils;
import com.citi.icg.as.test.automation.core.utilities.PageUtils;
import com.google.common.base.Strings;

/**
 * @author ap72338 The parent class for every page/tab/section. This class
 *         contains the methods to actually do the user operation like enter
 *         text, click links/button etc
 */

public abstract class Component implements ApplicationContextAware {

	private ApplicationContext applicationContext;
	protected static final String CLASS_ATTRIBUTE = "class";
	/**
	 * In search grid, to view an event, right click has been used and at that
	 * time the context menu has the below Xpath. Not sure at this time, whether
	 * it will be same on other screens (it should be ideally, if that happens
	 * then will move it to page/tab specific JSON. To start with, assuming it
	 * to be constant. Added not contains to avoid multiple elements for
	 * menuitem
	 */
	private static final String RIGHT_CLICK_CTX_MENU = "//div[@class='menuBorder'][not(contains(@style, 'hidden'))]//tr[@role='menuitem']";
	private static final Logger logger = LoggerFactory
			.getLogger(Component.class);
	private final LocatorProvider locatorProvider;
	private WebDriver driver;

	public Component(final WebDriver driver, LocatorProvider locatorProvider) {
		this.driver = driver;
		this.locatorProvider = locatorProvider;
	}

	protected WebElement getElementByXPath(String element) {
		Assert.isTrue(isNotBlank(element));
		Map<String, Locator> loc = getLocator();
		return driver.findElement(By.xpath(loc.get(element).getXPath()));
	}

	protected WebElement getElementByXPath(String element,
			Map<String, String> valuesMap) {
		Assert.isTrue(isNotBlank(element));
		Map<String, Locator> loc = getLocator();
		String dynamicText = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		return driver.findElement(By.xpath(dynamicText));
	}

	protected List<WebElement> getElementsByXPath(String element) {
		Assert.isTrue(isNotBlank(element));
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		return driver.findElements(By.xpath(loc.get(element).getXPath()));
	}

	protected List<WebElement> getElementsByXPath(String element,
			Map<String, String> valuesMap) {
		Assert.isTrue(isNotBlank(element));
		Map<String, Locator> loc = getLocator();
		String dynamicText = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		return driver.findElements(By.xpath(dynamicText));
	}

	protected void click(String element) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		driver.findElement(By.xpath(loc.get(element).getXPath())).click();
		postAction(driver, loc, element);
	}

	/**
	 * switchToFrame is used when the xpaths of elements are children of
	 * 'iframe' switchToFrame should be called first to help compiler finds
	 * elements
	 * 
	 * @param index
	 *            start from 0; ex. index=1 means the second iframe on the page
	 */
	public void switchToFrame(int index) {
		driver.switchTo().frame(index);
	}

	public void switchToFrame(String frameName) {
		driver.switchTo().frame(frameName);
	}

	/**
	 * switchToParent should be called after operations against elements
	 * complete
	 */
	public void switchToParent() {
		driver.switchTo().defaultContent();
	}

	protected void clickAfterCheckingIfVisible(String element) {
		clickAfterCheckingIfVisible(element, null);
	}

	/**
	 * check element visible and then click
	 * 
	 * @param element
	 */
	protected void clickAfterCheckingIfVisible(String element,
			Map<String, String> valuesMap) {
		if (isElementPresent(element, valuesMap)) {
			click(element, valuesMap);
		}
	}

	protected String value(String element) {
		return getAttribute(element, "value");
	}

	/**
	 * @param element
	 * @param valueMap
	 *            Use this function, when you have dynamic text in your xPath.
	 *            The XPath should specify parameters in standard property
	 *            notation as ${param}
	 */
	protected void click(String element, Map<String, String> valueMap) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valueMap);
		driver.findElement(By.xpath(dynamicXPath)).click();
		postAction(driver, loc, element);
	}

	protected void doubleClick(String element, Map<String, String> valueMap) {
		Actions action = new Actions(driver);
		Map<String, Locator> loc = getLocator();
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valueMap);
		action.click(driver.findElement(By.xpath(dynamicXPath))).click()
				.perform();
		// action.moveToElement(driver.findElement(By.xpath(dynamicXPath)))
		// .doubleClick().build().perform();
		// action.doubleClick(driver.findElement(By.xpath(dynamicXPath))).perform();
		postAction(driver, loc, element);
	}

	protected void rightClickAndOpenMenuItem(String element,
			Map<String, String> valueMap) {
		Actions action = new Actions(driver);
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valueMap);
		action.contextClick(driver.findElement(By.xpath(dynamicXPath)))
				.perform();

		// Give some time tfor the context menu to come up. Since this context
		// menu is not screen/page specific, so putting the delay here itself.
		CommonUtils.delay(1000);

		driver.findElement(By.xpath(RIGHT_CLICK_CTX_MENU)).click();
		postAction(driver, loc, element);
	}

	protected void rightClick(String element, Map<String, String> valueMap) {
		Actions action = new Actions(driver);
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valueMap);
		action.contextClick(driver.findElement(By.xpath(dynamicXPath))).build()
				.perform();
		postAction(driver, loc, element);
	}

	protected void rightClick(String element) {
		rightClick(element, null);
	}

	protected void doubleClick(String element) {
		doubleClick(element, new HashMap<String, String>());
	}

	/**
	 * @param element
	 * @return the ordered list of text contained in the element
	 */
	protected List<String> getTextList(String element) {
		return getTextList(element, Integer.MAX_VALUE);
	}

	protected List<String> getTextList(String element, int max) {
		List<WebElement> elements = getElementsByXPath(element);
		int maxValues = Math.min(elements.size(), max);
		List<String> textList = new ArrayList<String>();
		for (int i = 0; i < maxValues; i++) {
			textList.add(elements.get(i).getText());
		}
		return textList;
	}

	protected void enterText(String element, String text) {
		Map<String, Locator> loc = getLocator();
		driver.findElement(By.xpath(loc.get(element).getXPath()))
				.sendKeys(text);
		postAction(driver, loc, element);
	}

	protected void pressKey(String element, Keys key) {
		Map<String, Locator> loc = getLocator();
		driver.findElement(By.xpath(loc.get(element).getXPath())).sendKeys(key);
	}

	private void postAction(WebDriver driver, Map<String, Locator> loc,
			String element) {
		PageUtils.getInstance().postAction(driver, loc, element);
	}

	private void preAction(WebDriver driver, Map<String, Locator> loc,
			String element) {
		PageUtils.getInstance().preAction(driver, loc, element);
	}

	protected void enterText(String element, String text,
			Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		driver.findElement(By.xpath(dynamicXPath)).clear();
		driver.findElement(By.xpath(dynamicXPath)).sendKeys(text);
		postAction(driver, loc, element);
	}

	/**
	 * @param dropDownImageElement
	 *            - The image of the dropdown
	 * @param optionsElement
	 *            - The xPath for the dropdown options which get displayed on
	 *            clicking the above image
	 * @param value
	 *            - The value which you want to select
	 */
	protected void selectNonStandardDropdownByValue(
			String dropDownImageElement, String optionsElement, String value) {
		click(dropDownImageElement);
		selectDropDownValue(optionsElement, value,null);
	}

	protected void selectNonStandardDropdownByPartialValue(
			String dropDownImageElement, String optionsElement, String value) {
		click(dropDownImageElement);
		Map<String, Locator> loc = getLocator();
		List<WebElement> options = driver.findElements(By.xpath(loc.get(
				optionsElement).getXPath()));
		WebElement reqdOption = null;
		if (CollectionUtils.isNotEmpty(options)) {
			for (WebElement webElement : options) {
				String text = webElement.getAttribute("innerText");
				if (trimToEmpty(text).contains(value)) {
					reqdOption = webElement;
					break;
				}
			}
			if (reqdOption == null) {
				throw new IllegalArgumentException(String.format(
						"Element with value %s not found", value));
			}

			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView(true);", reqdOption);

			reqdOption.click();
			postAction(driver, loc, optionsElement);
		} else {
			logger.warn(
					"No options found for page/tab/component {} and element [{}]",
					this.getClass().getSimpleName(), optionsElement);
		}
	}

	/**
	 * @param element
	 *            Will clear text in TEXT and TEXTAREA elements on the page
	 */
	protected void clearText(String element) {
		Map<String, Locator> loc = getLocator();
		driver.findElement(By.xpath(loc.get(element).getXPath())).clear();
	}

	protected void clearText(String element, Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		driver.findElement(By.xpath(dynamicXPath)).clear();
	}
	
	protected void clearInputValue(String element, Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		//check if the input element already have empty string value.
		String val = driver.findElement(By.xpath(dynamicXPath)).getAttribute("value");
		if (!Strings.isNullOrEmpty(val)){
			driver.findElement(By.xpath(dynamicXPath)).clear();
		}
	}

	protected boolean isEnabled(String element) {
		Map<String, Locator> loc = getLocator();
		return driver.findElement(By.xpath(loc.get(element).getXPath()))
				.isEnabled();
	}

	protected String getAttribute(String element, String attribute) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		return StringUtils.trimToEmpty(driver.findElement(
				By.xpath(loc.get(element).getXPath())).getAttribute(attribute));
	}

	protected String getAttribute(String element,
			Map<String, String> valuesMap, String attribute) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		return StringUtils.trimToEmpty(driver.findElement(
				By.xpath(dynamicXPath)).getAttribute(attribute));
	}

	protected String getText(String element) {
		Map<String, Locator> loc = getLocator();
		return StringUtils.trimToEmpty(driver.findElement(
				By.xpath(loc.get(element).getXPath())).getText());
	}

	protected String getText(String element, Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		return StringUtils.trimToEmpty(driver.findElement(
				By.xpath(dynamicXPath)).getText());
	}

	protected boolean isElementVisible(String element) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		List<WebElement> webElements = getElementsByXPath(element);
		return webElements.size() > 0 && webElements.get(0).isDisplayed();
	}

	protected boolean isElementVisible(String element, Map<String,String> valueMap) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		List<WebElement> webElements = getElementsByXPath(element,valueMap);
		return webElements.size() > 0 && webElements.get(0).isDisplayed();
	}
	
	protected boolean isElementPresent(String element,
			Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		return getElementsByXPath(element, valuesMap).size() > 0;
	}

	/**
	 * Iterate over the table's rows and select the first row that have the
	 * value secondColumnValue in the first column.
	 * 
	 * @param tableElement
	 *            the table that has a checkbox as a first column
	 * @param secondColumnValue
	 * @return true if the value the first column is equal to secondColumnValue
	 */
	// TODO: make this algorithm generic, at the moment only look up the first
	// row. The Xpath has to be improved.
	protected boolean selectRowCheckboxWhereSecondColumnValueIs(
			String tableElement, String secondColumnValue) {
		Map<String, Locator> loc = getLocator();
		List<WebElement> table = driver.findElements(By.xpath(loc.get(
				tableElement).getXPath()));
		WebElement rowToBeSelected = null;
		if (CollectionUtils.isNotEmpty(table)) {
			for (WebElement webElement : table) {
				String text = webElement.getAttribute("innerText");
				if (trimToEmpty(text).contains(secondColumnValue)) {
					rowToBeSelected = webElement;
					click("securityCheckBox");
					break;
				}
			}
		} else {
			logger.warn("No value found for table second column value {}",
					secondColumnValue);
		}
		return rowToBeSelected != null;
	}

	/**
	 * It's a special implementation for SmarGWT grids that allows to send right
	 * arrows key to the scroll bar of the list grid. <br>
	 * 
	 * @param scrollBarElement
	 *            the id of the scrollbaer in the related json file
	 * @param rightLeft
	 *            positive values to scroll to the right. One unit equals
	 *            pressing the right arrow key once.
	 */
	protected void horizontalScrollForSmartGwtGrid(String scrollBarElement,
			int rightLeft) {
		Map<String, Locator> loc = getLocator();
		Keys scrollDirection = null;
		if (rightLeft > 0) {
			scrollDirection = Keys.RIGHT;
		} else {
			scrollDirection = Keys.LEFT;
		}
		for (int i = 0; i < Math.abs(rightLeft); i++) {
			driver.findElement(By.xpath(loc.get(scrollBarElement).getXPath()))
					.sendKeys(scrollDirection);
		}
	}

	protected void verticalScrollForSmartGwtGrid(String scrollBarElement,
			int downUp) {
		Map<String, Locator> loc = getLocator();
		Keys scrollDirection = null;
		if (downUp > 0) {
			scrollDirection = Keys.DOWN;
		} else {
			scrollDirection = Keys.UP;
		}
		if(!driver.findElement(By.xpath(loc.get(scrollBarElement).getXPath())).isDisplayed()){
            bringToView(scrollBarElement);
		}
		for (int i = 0; i < Math.abs(downUp); i++) {
			driver.findElement(By.xpath(loc.get(scrollBarElement).getXPath()))
					.sendKeys(scrollDirection);
		}
	}

	protected LocatorProvider getLocatorProvider() {
		return locatorProvider;
	}

	protected WebDriver getDriver() {
		return driver;
	}

	private Map<String, Locator> getLocator() {
		return locatorProvider.getLocatorInfo(this.getClass().getSimpleName());
	}

	private String getDynamicXPath(String xPath, Map<String, String> valuesMap) {
		if (valuesMap == null || valuesMap.isEmpty()) {
			return xPath;
		}
		StrSubstitutor sub = new StrSubstitutor(valuesMap);
		return sub.replace(xPath);
	}

	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}

	protected <T> T getComponent(Class<T> clazz) {
		return applicationContext.getBean(clazz);
	}

	protected void zoomOut(String element) {
		Map<String, Locator> loc = getLocator();
		driver.findElement(By.xpath(loc.get(element).getXPath())).sendKeys(
				Keys.chord(Keys.CONTROL, Keys.SUBTRACT));
	}

	protected void zoomOut(double percentage) {
		((JavascriptExecutor) driver).executeScript("document.body.style.zoom="
				+ percentage + ";", driver.findElement(By.xpath("//body")));
	}

	protected void resetZoom(String element) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		driver.findElement(By.xpath(loc.get(element).getXPath())).sendKeys(
				Keys.chord(Keys.CONTROL, "0"));
		postAction(driver, loc, element);
	}

	protected void bringToView(String element) {
		bringToView(element, null);
	}

	protected void bringToView(WebElement element) {
		((JavascriptExecutor) driver).executeScript(
				"arguments[0].scrollIntoView(true);", element);
	}

	protected void bringToView(String element, Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		WebElement webElement = driver.findElement(By.xpath(dynamicXPath));
		bringToView(webElement);
	}

	protected void switchToWindow(String handle) {
		driver.switchTo().window(handle);
	}

	protected String getCurrentWindowHandle() {
		return driver.getWindowHandle();
	}

	protected Set<String> getWindowHandles() {
		return driver.getWindowHandles();
	}

	protected void clickAndSwitchToChildWindow(String element) {
		String parentHandle = getCurrentWindowHandle();
		click(element);
		Set<String> handles = getWindowHandles();
		for (String handle : handles) {
			if (!handle.equals(parentHandle)) {
				switchToWindow(handle);
				break;
			}
		}
	}

	protected void disableOnWindowCloseEvent() {
		((JavascriptExecutor) driver).executeScript(
				"window.onbeforeunload = \"\";",
				driver.findElement(By.xpath("//body")));
	}

	// it checks whether the radio button is checked
	protected Boolean isSelectedRadioButton(String element,
			Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		return driver.findElement(By.xpath(dynamicXPath)).isSelected();

	}

	protected String getInnerText(String element, Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		return StringUtils.trimToEmpty(driver.findElement(
				By.xpath(dynamicXPath)).getAttribute("innerText"));
	}

	protected Boolean isSelected(String element, Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
		return driver.findElement(By.xpath(dynamicXPath)).isSelected();
	}

	/**
	 * 
	 * @param element
	 * @param text
	 * @param valuesMap
	 * 
	 *            Fix for stale element exception
	 *            count for attempts can be reduced for other scenarios
	 */
	protected void retryingEnterText(String element, String text,
			Map<String, String> valuesMap) {
		Actions actions = new Actions(driver);
		Map<String, Locator> loc = getLocator();
		preAction(driver, loc, element);
		int attempts = 0;
		while (attempts < 10) {
			try {
				String dynamicXPath = getDynamicXPath(loc.get(element)
						.getXPath(), valuesMap);
				WebElement findElement = driver.findElement(By
						.xpath(dynamicXPath));
				actions.moveToElement(findElement).click().build().perform();
				findElement.click();
				findElement.sendKeys(text);
				break;
			} catch (StaleElementReferenceException e) {
				logger.error("Trying to recover from a stale element :"
						+ e.getMessage());

			}
			attempts++;
		}
		postAction(driver, loc, element);
	}

	/**
	 * @author hb68051
	 * @param element
	 * 		  Dynamic xPath of the Grid column which you want to move to other position 
	 * @param fromColumnValueMap
	 * 		  Column Header Name which you want to move with key:'columnHeader' 	
	 * @param toColumnValueMap
	 * 		  Column Header Name where you want to move with from column key:'columnHeader'
	 * 
	 * Fix for change column position of grid From column to To column.
	 *  
	 */
	protected void changeColumnPosition(String element, Map<String, String> fromValueMap, Map<String, String> toValueMap) {
		Map<String, Locator> loc = getLocator();
		String dynamicXPathSrc = getDynamicXPath(loc.get(element).getXPath(),fromValueMap);
		String dynamicXPathTrg = getDynamicXPath(loc.get(element).getXPath(),toValueMap);
		
		WebElement fromElement= driver.findElement(By.xpath(dynamicXPathSrc));
		WebElement toElement=driver.findElement(By.xpath(dynamicXPathTrg));
		
		Actions action = new Actions(driver);
		action.dragAndDrop(fromElement, toElement).build()
		.perform();
	}
	
	/**
	 * @author tg47768
	
	 * Close tab other than main tab
	 *  
	 */
	protected void closeTabsExceptMainTab(){
		String parentHandle = driver.getWindowHandle();
		for(String handle : driver.getWindowHandles()) {
			if (!handle.equals(parentHandle)) {
				driver.switchTo().window(handle);
				driver.close();
			}
		}
		driver.switchTo().window(parentHandle);
	}

	protected void selectNonStandardDropdownByValue(
			String dropDownImageElement, String optionsElement, String value,
			Map<String, String> valuesMap) {
		click(dropDownImageElement, valuesMap);
		selectDropDownValue(optionsElement,value,valuesMap);
	}

	private void selectDropDownValue(String optionsElement,String value,Map<String, String> valuesMap) {
		Map<String, Locator> loc = getLocator();
		final String dynamicXPath = getDynamicXPath(loc.get(optionsElement)
				.getXPath(), valuesMap);
		final List<WebElement> options = driver.findElements(By
				.xpath(dynamicXPath));
		WebElement reqdOption = null;
		if (CollectionUtils.isNotEmpty(options)) {
			for (WebElement webElement : options) {
				if (trimToEmpty(webElement.getAttribute("textContent"))
						.equalsIgnoreCase(value)) {
					reqdOption = webElement;
					break;
				}
			}
			if (reqdOption == null) {
				throw new IllegalArgumentException(String.format(
						"Element with value %s not found", value));
			}
			bringToView(reqdOption);
			reqdOption.click();
			postAction(driver, loc, optionsElement);
		} else {
			logger.warn(
					"No options found for page/tab/component {} and element [{}]",
					this.getClass().getSimpleName(), optionsElement);
		}
	}
	
	protected void hoverOverElement(String element,Map<String, String> valuesMap){
        Actions actions = new Actions(driver);
        Map<String, Locator> loc = getLocator();
        preAction(driver, loc, element);
        String dynamicXPath = getDynamicXPath(loc.get(element).getXPath(),
				valuesMap);
        WebElement findElement = driver.findElement(By.xpath(dynamicXPath));
        Action action=actions.moveToElement(findElement).build();
        action.perform();
 }
}
