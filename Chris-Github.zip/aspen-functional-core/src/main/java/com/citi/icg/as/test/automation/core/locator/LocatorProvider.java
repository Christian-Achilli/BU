/**
 * 
 */
package com.citi.icg.as.test.automation.core.locator;

import java.util.Map;

/**
 * @author ap72338
 *         <p>
 *         This interface provides the locator/XPATH info for the section/tab on
 *         which we want to locate the elements
 *         </p>
 */
public interface LocatorProvider {

	
	/**
	 * @param id
	 * @return
	 * In case of FileBasedLocator the ID will be the section name/ tab name.
	 */
	public Map<String,Locator>getLocatorInfo(String id);
	String FILE_XPATH_CACHE="fileBasedXpathCache";
	
	static final String CLASSPATH = "classpath:";
}
