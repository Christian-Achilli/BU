/**
 * 
 */
package com.citi.icg.as.test.automation.core.locator;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * @author ap72338
 *
 */
public class LocatorTest {

	private ObjectMapper mapper = new ObjectMapper();

	@Test
	public void loadCreateEventDetailsLocator() throws Exception {
		TypeReference<Map<String, Locator>> ref = new TypeReference<Map<String, Locator>>() {
		};
		Map<String, Locator> locators = mapper
				.readValue(new ClassPathResource("locators/CreateManualEventTab.json").getInputStream(), ref);
		Assert.assertEquals(locators.get("securityId").getXPath(), "//input[@name='SecurityId']");
		Assert.assertEquals(locators.get("eventCategoryImage").getMetaData().getPostActionDelay(), 1000);
		Assert.assertTrue(locators.get("securitySearchIcon").getMetaData().getPostCondition() != null);
		Assert.assertTrue(locators.get("securitySearchIcon").getMetaData().getPostCondition()
				.getExpectedValueConstraint() != null);
	}
}
