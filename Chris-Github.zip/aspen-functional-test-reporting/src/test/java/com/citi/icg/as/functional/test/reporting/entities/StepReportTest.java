package com.citi.icg.as.functional.test.reporting.entities;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;

/**
 * 
 */

/**
 * @author ap72338
 *
 */
public class StepReportTest {

	@Test
	public void verifyExecutionCountIsFormattedAsString() throws Exception {
		StepReport report = new StepReport("Dummy", 5);
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(report);
		Object value = JsonPath.read(json, "$.executionCount");
		Assert.assertTrue(value instanceof String, "Execution count should be serialized as string");
	}
}
