/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;

import com.citi.icg.as.functional.test.automation.mongodb.repository.ReportRepository;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author ap72338
 *
 */

@Document(collection = ReportRepository.COLLECTION_FOR_SCENARIO_PERFORMANCE)
@JsonInclude(value = Include.NON_NULL)
public class ScenarioPerformanceReport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5254137802451865823L;

	private String environment;
	private String name;
	private String buildNumber;
	private double averageDuration;
	private double medianDuration;
	private String formattedExecutionDate;
	
	@JsonCreator
	public ScenarioPerformanceReport(@JsonProperty("environment") String environment, @JsonProperty("name") String name,@JsonProperty("buildNumber") String buildNumber,
			@JsonProperty("medianDuration") double medianDuration,@JsonProperty("average") double averageDuration,@JsonProperty("formattedExecutionDate") String formattedExecutionDate) {
		this.environment = environment;
		this.buildNumber = buildNumber;
		this.averageDuration = averageDuration;
		this.name = name;
		this.medianDuration = medianDuration;
		this.formattedExecutionDate = formattedExecutionDate;
	}

	public String getEnvironment() {
		return environment;
	}

	public String getName() {
		return name;
	}

	public String getBuildNumber() {
		return buildNumber;
	}

	public double getAverageDuration() {
		return averageDuration;
	}

	public double getMedianDuration() {
		return medianDuration;
	}

	public String getFormattedExecutionDate() {
		return formattedExecutionDate;
	}

}
