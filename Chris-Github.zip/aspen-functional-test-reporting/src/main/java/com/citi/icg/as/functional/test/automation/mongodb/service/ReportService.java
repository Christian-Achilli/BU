/**
 * 
 */
package com.citi.icg.as.functional.test.automation.mongodb.service;

import static com.citi.icg.as.functional.test.automation.mongodb.repository.ReportRepository.COLLECTION_FOR_SCENARIO_PERFORMANCE;
import static com.citi.icg.as.functional.test.automation.mongodb.repository.ReportRepository.COLLECTION_FOR_STEPS;
import static com.citi.icg.as.functional.test.automation.mongodb.repository.ReportRepository.COLLECTION_FOR_STEP_PERFORMANCE;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.citi.icg.as.functional.test.automation.mongodb.repository.ReportRepository;
import com.citi.icg.as.functional.test.automation.reporting.utils.ReportingUtils;
import com.citi.icg.as.functional.test.reporting.entities.ReportEntity;
import com.citi.icg.as.functional.test.reporting.entities.ScenarioPerformanceReport;
import com.citi.icg.as.functional.test.reporting.entities.SimplifiedReport;
import com.citi.icg.as.functional.test.reporting.entities.StepPerformanceReport;
import com.citi.icg.as.functional.test.reporting.entities.StepReport;
import com.citi.icg.as.functional.test.reporting.model.Filter;
import com.citi.icg.as.functional.test.reporting.model.GenericReportingFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.DBObject;
import com.mongodb.MapReduceOutput;
import com.mongodb.util.JSON;

/**
 * @author ap72338 The facade, which is used to perform all operations related
 *         to reporting.
 */

@Service
public class ReportService {

	private static final String MAPREDUCE_REDUCE_PERFORMANCE_JS = "mapreduce/reduceStepPerformance.js";

	private static final String MAPREDUCE_MAP_PERFORMANCE_JS = "mapreduce/mapStepPerformance.js";

	private static final String MAPREDUCE_STEPS_REDUCE_JS = "mapreduce/reduceSteps.js";

	private static final String MAPREDUCE_STEPS_MAP_JS = "mapreduce/mapSteps.js";
	
	private static final String MAPREDUCE_SCENARIO_REDUCE_PERFORMANCE_JS = "mapreduce/reduceScenarioPerformance.js";

	private static final String MAPREDUCE_SCENARIO_MAP_PERFORMANCE_JS = "mapreduce/mapScenarioPerformance.js";
	
	
	private Logger logger = LoggerFactory.getLogger(ReportService.class);
	
	@Autowired
	private ReportRepository reportRepository;

	@Autowired(required=false)
	private ObjectMapper mapper;

	private void save(final SimplifiedReport report, final Date executionDate, String reportFileName,String buildNumber,String environment) {

		Assert.notNull(mapper,String.format("Bean of class %s must be provided for this method", ObjectMapper.class));
		
		ReportEntity reportEntity = new ReportEntity();
		try {
			reportEntity.setContent((DBObject) JSON.parse(mapper.writeValueAsString(report)));
		} catch (JsonProcessingException e) {
			logger.warn("Error creating BSON from JSON ", e);
		}
		reportEntity.setBuildNumber(buildNumber);
		reportEntity.setEnvironment(environment);
		reportEntity.setExecutionDate(executionDate);
		reportEntity.setReportFileName(reportFileName);
		reportEntity.setMachine(ReportingUtils.getHostName());
		reportRepository.save(reportEntity);
	}

	/**
	 * @param reportDir
	 *            This method reads all cucumber report JSON files in the given
	 *            directory and saves them in a simplified format to MongoDB
	 *            collection as represented by {@link ReportEntity}
	 */
	public void readAndPersistTestReports(String buildNumber,String environment,File reportDir) {

		final Date executionDate = new DateTime(DateTimeZone.UTC).toDate();
		
		File[] jsonReportFiles = reportDir.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".json");
			}
		});
		TypeReference<List<SimplifiedReport>> ref = new TypeReference<List<SimplifiedReport>>() {
		};
		for (File report : jsonReportFiles) {
			try {
				List<SimplifiedReport> reportList = mapper.readValue(report, ref);
				for (SimplifiedReport simplifiedReport : reportList) {
					save(simplifiedReport,executionDate,report.getName(),buildNumber,environment);
				}
			} catch (Exception e) {
				logger.warn("Error persisting report", e);
			}
		}
	}
	
	public List<StepReport> getAllSteps(){
		return reportRepository.getStepsReport();
	}

	public List<StepPerformanceReport> getStepReport(String stepName, String environment) {
		return reportRepository.getStepPerformanceReport(stepName, environment);
	}

	public List<DBObject> getRawReportDetails(String stepName, String environment, int limit) {
		return reportRepository.getRawReportDetails(stepName, environment, limit);
	}

	public List<DBObject> getRawSummaryDetails(int limit) {
		return reportRepository.getRawSummaryDetails(limit);
	}
	
	public List<StepPerformanceReport> getSummaryOfAllSteps() {		
		return reportRepository.getSummaryOfAllSteps();
	}
	

	/**
	 * @return This function will perform map reduce on Steps and generate the
	 *         avg times, per env
	 */
	public MapReduceOutput performStepPerformanceMapReduce() {
		return reportRepository.performMapReduce(MAPREDUCE_MAP_PERFORMANCE_JS, MAPREDUCE_REDUCE_PERFORMANCE_JS,
				ReportEntity.class, COLLECTION_FOR_STEP_PERFORMANCE);
	}

	/**
	 * @return This function will perform map reduce, mainly to generate all the
	 *         steps, irrespective of env. Can be used to create a dropdown of
	 *         all steps
	 */
	public MapReduceOutput performStepsMapReduce() {
		return reportRepository.performMapReduce(MAPREDUCE_STEPS_MAP_JS, MAPREDUCE_STEPS_REDUCE_JS, ReportEntity.class,
				COLLECTION_FOR_STEPS);
	}

	
	public MapReduceOutput performScenarioPerformanceMapReduce() {
		return reportRepository.performMapReduce(MAPREDUCE_SCENARIO_MAP_PERFORMANCE_JS, MAPREDUCE_SCENARIO_REDUCE_PERFORMANCE_JS,
				ReportEntity.class, COLLECTION_FOR_SCENARIO_PERFORMANCE);
	}
	
	public List<StepPerformanceReport> getStepsSummaryByBuildNumber(String[] buildNumbers) {
		return reportRepository.getStepsSummaryByBuildNumber(buildNumbers);
	}
	
	public List<StepPerformanceReport> getReport(Filter requestFilter) {
		return reportRepository.getReport(requestFilter);
	}

	public List<ScenarioPerformanceReport> getScenarioReport(Filter requestFilter) {
		return reportRepository.getScenarioReport(requestFilter);
	}
}
