/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.util.CollectionUtils;

import com.citi.icg.as.functional.test.reporting.model.Filter;

/**
 * @author ap72338
 *
 */
public class GenericPerformanceReportCriteria {

	private Criteria criteria;
	private Filter filter;
	
	public GenericPerformanceReportCriteria(Filter filter) {
		this.filter = filter;
	}

	public GenericPerformanceReportCriteria build() {
		criteria = new Criteria();
		if (StringUtils.isNotBlank(filter.getStepName())) {
			criteria = criteria.and(PerformanceReportMetaData.STEP_NAME.getQueryColumnAlias())
					.is(filter.getStepName());
		}
		
		if (StringUtils.isNotBlank(filter.getScenarioName())) {
			criteria = criteria.and(PerformanceReportMetaData.SCENARIO_NAME.getQueryColumnAlias())
					.is(filter.getScenarioName());
		}
		
		if (!CollectionUtils.isEmpty(filter.getEnvironments())) {
			criteria = criteria.and(PerformanceReportMetaData.ENVIRONMENT.getQueryColumnAlias())
					.in(filter.getEnvironments());
		}

		if (!CollectionUtils.isEmpty(filter.getBuildNumbers())) {
			criteria = criteria.and(PerformanceReportMetaData.BUILD_NUMBER.getQueryColumnAlias())
					.in(filter.getBuildNumbers());
		}

		if (StringUtils.isNotBlank(filter.getDateFrom()) && StringUtils.isNotBlank(filter.getDateTo())) {
			criteria = criteria.and(PerformanceReportMetaData.EXECUTION_DATE.getQueryColumnAlias())
					.gte(Integer.valueOf(filter.getDateFrom())).lte(Integer.valueOf(filter.getDateTo()));
		}
		
		return this;
	}

	public Criteria getCriteria() {
		return criteria;
	}
}
