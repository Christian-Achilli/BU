/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.mongodb.DBCollection;
import com.mongodb.DBObject;

/**
 * @author ap72338
 * This class represent the MongoDb {@link DBCollection} 
 */

@Document
public class ReportEntity {

	@Id	
	private String id;
	
	private String buildNumber;
	
	private String environment;
	
	private DBObject content;

	private String machine;
	
	private String reportFileName;
	
	private Date executionDate;	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBuildNumber() {
		return buildNumber;
	}

	public void setBuildNumber(String buildNumber) {
		this.buildNumber = buildNumber;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public DBObject getContent() {
		return content;
	}

	public void setContent(DBObject content) {
		this.content = content;
	}

	public String getMachine() {
		return machine;
	}

	public void setMachine(String machine) {
		this.machine = machine;
	}

	public Date getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(Date executionDate) {
		this.executionDate = executionDate;
	}

	public String getReportFileName() {
		return reportFileName;
	}

	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}
	
}
