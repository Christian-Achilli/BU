/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.model;

import java.util.List;

/**
 * @author ap72338
 *
 */
public interface Filter {
	String getStepName();
	
	String getScenarioName();

	List<String> getBuildNumbers();

	List<String> getEnvironments();

	String getDateFrom();

	String getDateTo();
}
