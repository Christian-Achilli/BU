/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ap72338
 *
 */

@Document
@JsonIgnoreProperties(ignoreUnknown=true)
public class SimplifiedReport {
	
	private String featureId;
	
	@JsonProperty(value="name")	
	private String featureName;
	
	private String description;
	
	private List<ReportElement>elements;
	
	public String getFeatureName() {
		return featureName;
	}

	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<ReportElement> getElements() {
		return elements;
	}

	public void setElements(List<ReportElement> elements) {
		this.elements = elements;
	}

	@JsonProperty(value="featureId")
	public String getFeatureId() {
		return featureId;
	}

	@JsonProperty(value="id")
	public void setFeatureId(String featureId) {
		this.featureId = featureId;
	}

}
