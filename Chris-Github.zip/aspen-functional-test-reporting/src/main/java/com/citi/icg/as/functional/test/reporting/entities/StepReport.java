/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;

import com.citi.icg.as.functional.test.automation.mongodb.repository.ReportRepository;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author ap72338 This class is used to retrieve all fields from
 *         {@link ReportRepository #COLLECTION_FOR_STEPS}
 */
@Document(collection = ReportRepository.COLLECTION_FOR_STEPS)
public class StepReport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5070644834600523059L;

	private String name;
	private int executionCount;

	public StepReport(String name, int executionCount) {
		this.name = name;
		this.executionCount = executionCount;
	}

	public String getName() {
		return name;
	}

	@JsonFormat(shape = Shape.STRING)
	/**
	 * 
	 * @return This is being formatted as string, as angular ui which is being
	 *         used, needs data to be present as string, even though its number
	 *         so as to sort it correctly. This may seem coupling between UI, as
	 *         of now, its OK, if need can create separate getters with
	 *         different property names.
	 */
	public int getExecutionCount() {
		return executionCount;
	}

	@Override
	@JsonIgnore
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(name);
		builder.append("-");
		builder.append(executionCount);
		return builder.toString();
	}

	@Override
	@JsonIgnore
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	@JsonIgnore
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StepReport other = (StepReport) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}
