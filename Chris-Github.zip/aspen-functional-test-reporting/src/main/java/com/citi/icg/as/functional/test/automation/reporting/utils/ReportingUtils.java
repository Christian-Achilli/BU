/**
 * 
 */
package com.citi.icg.as.functional.test.automation.reporting.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author ap72338
 *
 */
public class ReportingUtils {
	private static final Logger logger = LoggerFactory.getLogger(ReportingUtils.class);

	public static String getHostName() {
		String hostName = "UNKNOWN";
		try {
			InetAddress addr = InetAddress.getLocalHost();
			hostName = addr.getHostName();
		} catch (UnknownHostException ex) {
			logger.error("Error getting host name", ex);
		}
		return hostName;
	}
	
}
