/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.model;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.citi.icg.as.functional.test.reporting.entities.validation.ScenarioValidationGroup;
import com.citi.icg.as.functional.test.reporting.entities.validation.StepValidationGroup;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author ap72338
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class GenericReportingFilter implements Filter {

	private List<String> buildNumbers;
	private List<String> environments;
	private String dateFrom;
	private String dateTo;

	@NotNull(message = "Scenario name is mandatory", groups = { ScenarioValidationGroup.class })
	private String scenarioName;

	@NotEmpty(message = "Step name cannot be null", groups = { StepValidationGroup.class })
	private String stepName;

	public List<String> getBuildNumbers() {
		return buildNumbers;
	}

	public void setBuildNumbers(List<String> buildNumbers) {
		this.buildNumbers = buildNumbers;
	}

	public List<String> getEnvironments() {
		return environments;
	}

	public void setEnvironments(List<String> environments) {
		this.environments = environments;
	}

	public String getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}

	public String getDateTo() {
		return dateTo;
	}

	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}

	@Override
	public String getStepName() {
		return stepName;
	}

	@Override
	public String getScenarioName() {
		return scenarioName;
	}

	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
}
