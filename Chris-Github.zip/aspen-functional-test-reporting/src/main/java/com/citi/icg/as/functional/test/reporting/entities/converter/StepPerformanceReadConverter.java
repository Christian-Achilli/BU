/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities.converter;

import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.AVERGAE;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.BUILD_NUMBER;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.ENVIRONMENT;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.EXECUTION_DATE;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.FAIL_PERCENTAGE;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.MEDIAN;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.PASS_PERCENTAGE;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.STEP_NAME;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

import com.citi.icg.as.functional.test.reporting.entities.StepPerformanceReport;
import com.mongodb.DBObject;

/**
 * @author ap72338
 *
 */

@ReadingConverter
public class StepPerformanceReadConverter implements Converter<DBObject, StepPerformanceReport> {

	@Override
	public StepPerformanceReport convert(DBObject dbObject) {
		DBObject id = (DBObject) dbObject.get("_id");
		DBObject value = (DBObject) dbObject.get("value");

		return new StepPerformanceReport(id.get(ENVIRONMENT.getColumnName()).toString(),
				id.get(STEP_NAME.getColumnName()).toString(),
				Double.valueOf(String.valueOf(value.get(AVERGAE.getColumnName()))),
				id.get(BUILD_NUMBER.getColumnName()).toString(),
				Double.valueOf(String.valueOf(value.get(PASS_PERCENTAGE.getColumnName()))),
				Double.valueOf(String.valueOf(value.get(FAIL_PERCENTAGE.getColumnName()))),
				Double.valueOf(String.valueOf(value.get(MEDIAN.getColumnName()))),
				id.get(EXECUTION_DATE.getColumnName()).toString());
	}

}
