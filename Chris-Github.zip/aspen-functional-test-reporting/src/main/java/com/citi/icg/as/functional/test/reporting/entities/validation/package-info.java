/**
 * 
 */
/**
 * @author AP72338
 *         <p>
 *         This package contains classes which are used to specify the
 *         validation groups along with
 *         {@link org.springframework.validation.annotation.Validated}
 *         annotation.
 *         </p>
 */
package com.citi.icg.as.functional.test.reporting.entities.validation;