/**
 * 
 */
package com.citi.icg.as.functional.test.automation.mongodb.repository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.DocumentCallbackHandler;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.citi.icg.as.functional.test.reporting.entities.GenericPerformanceReportCriteria;
import com.citi.icg.as.functional.test.reporting.entities.ReportEntity;
import com.citi.icg.as.functional.test.reporting.entities.ScenarioPerformanceReport;
import com.citi.icg.as.functional.test.reporting.entities.StepPerformanceReport;
import com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData;
import com.citi.icg.as.functional.test.reporting.entities.StepReport;
import com.citi.icg.as.functional.test.reporting.model.Filter;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceOutput;
import com.mongodb.MongoException;

/**
 * @author ap72338
 *
 */
@Repository
public class ReportRepository {

	private static final Logger logger = LoggerFactory.getLogger(ReportRepository.class);

	/**
	 * Maximum number of collections to be fetched
	 */
	private static final int MAX_DOCUMENTS_FETCH_SIZE = 500;

	/**
	 * Collection name where the results of step performance map reduce
	 * operation will be stored
	 */
	public static final String COLLECTION_FOR_STEP_PERFORMANCE = "stepsperformance";

	/**
	 * Collection name where all the steps names along with the count will be
	 * stored
	 */
	public static final String COLLECTION_FOR_STEPS = "steps";

	public static final String COLLECTION_FOR_SCENARIO_PERFORMANCE = "scenarioperformance";
	
	@Autowired
	private MongoTemplate mongoTemplate;

	public void save(ReportEntity report) {
		mongoTemplate.save(report);
	}

	private Query getQueryWithLimit(int limit) {
		Query query = new Query();
		query.limit(Math.min(Math.abs(limit), MAX_DOCUMENTS_FETCH_SIZE));
		return query;
	}

	/**
	 * @param stepName
	 * @param environment
	 * @return This method is just to peek into what data has been inserted
	 *         using Cucumber reports. For performance reasons, max 500 can be
	 *         returned.
	 */
	public List<DBObject> getRawReportDetails(String stepName, String environment, int limit) {
		Query query = getQueryWithLimit(limit);

		final List<DBObject> dbObjects = new ArrayList<DBObject>();
		mongoTemplate.executeQuery(query, mongoTemplate.getCollectionName(ReportEntity.class),
				new DocumentCallbackHandler() {

					@Override
					public void processDocument(DBObject dbObject) throws MongoException, DataAccessException {
						dbObjects.add(dbObject);
					}
				});
		return dbObjects;
	}

	/**
	 * @return This method is again to peek into results from the
	 *         {@link #COLLECTION_FOR_STEP_PERFORMANCE} collection
	 */
	public List<DBObject> getRawSummaryDetails(int limit) {
		Query query = getQueryWithLimit(limit);

		final List<DBObject> dbObjects = new ArrayList<DBObject>();

		mongoTemplate.executeQuery(query, COLLECTION_FOR_STEP_PERFORMANCE, new DocumentCallbackHandler() {

			@Override
			public void processDocument(DBObject dbObject) throws MongoException, DataAccessException {
				dbObjects.add(dbObject);
			}
		});
		return dbObjects;
	}

	/**
	 * @param stepName
	 * @param environment
	 * @return This method returns the List of {@link StepPerformanceReport}
	 *         from {@link #COLLECTION_FOR_STEP_PERFORMANCE}
	 */
	public List<StepPerformanceReport> getStepPerformanceReport(String stepName, String environment) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id.stepName").is(stepName).and("_id.environment").is(environment));
		return mongoTemplate.find(query, StepPerformanceReport.class);
	}

	public List<StepPerformanceReport> getStepPerformanceReport(String stepName, String[] environments) {
		Query query = new Query();
		query.addCriteria(Criteria.where(PerformanceReportMetaData.STEP_NAME.getQueryColumnAlias()).is(stepName)
				.and(PerformanceReportMetaData.ENVIRONMENT.getQueryColumnAlias()).in(environments));
		return mongoTemplate.find(query, StepPerformanceReport.class);
	}

	public List<StepPerformanceReport> getSummaryOfAllSteps() {
		return mongoTemplate.findAll(StepPerformanceReport.class);
	}

	/**
	 * @return This method returns all the steps from
	 *         {@link #COLLECTION_FOR_STEPS}
	 */
	public List<StepReport> getStepsReport() {
		return mongoTemplate.findAll(StepReport.class);
	}

	/**
	 * This method drops all map reduce summarised collections namely
	 * {@link #COLLECTION_FOR_STEP_PERFORMANCE} and
	 * {@link #COLLECTION_FOR_STEPS}
	 */
	public void deleteAllReports() {
		mongoTemplate.dropCollection(COLLECTION_FOR_STEP_PERFORMANCE);
		mongoTemplate.dropCollection(COLLECTION_FOR_STEPS);
		mongoTemplate.dropCollection(COLLECTION_FOR_SCENARIO_PERFORMANCE);
	}

	public void deleteCollection(String collectionName) {
		Assert.isTrue(StringUtils.isNoneBlank(collectionName),"Collection name cannot be null");
		mongoTemplate.dropCollection(collectionName);
	}
	
	/**
	 * This method drops all collections namely
	 * {@link #COLLECTION_FOR_STEP_PERFORMANCE}, {@link #COLLECTION_FOR_STEPS}
	 * and as represented by {@link ReportEntity}
	 */

	public void deleteAllAutomationCollections() {
		mongoTemplate.dropCollection(ReportEntity.class);
		deleteAllReports();
	}

	/**
	 * @param mapFile
	 * @param reduceFile
	 * @param mapReduceCollection
	 * @param outputCollectionName
	 * @return Performs the map reduce on collection as given by
	 *         mapReduceApplication, taking the map and reduce functions from
	 *         the map and reduce file respectively.The files are picked up from
	 *         classpath
	 */
	public MapReduceOutput performMapReduce(String mapFile, String reduceFile, Class<?> mapReduceEntityClass,
			String outputCollectionName) {
		DBCollection mapReduceCollection = mongoTemplate
				.getCollection(mongoTemplate.getCollectionName(mapReduceEntityClass));

		MapReduceOutput output = null;
		try {
			String map = IOUtils.toString(new ClassPathResource(mapFile).getInputStream());
			String reduce = IOUtils.toString(new ClassPathResource(reduceFile).getInputStream());

			MapReduceCommand cmd = new MapReduceCommand(mapReduceCollection, map, reduce, outputCollectionName,
					MapReduceCommand.OutputType.REPLACE, null);
			output = mapReduceCollection.mapReduce(cmd);
		} catch (IOException e) {
			logger.error("Error reading map reduce javascript function files", e);
		}
		return output;
	}

	/**
	 * @param collectionName
	 * @param field
	 * @param indexName
	 * @param unique
	 *            As we dont have a tool to administer MongoDB, so creating a
	 *            helpful function to create index.
	 */
	public void createIndex(String collectionName, String field, String indexName, boolean unique) {
		mongoTemplate.getCollection(collectionName).createIndex(new BasicDBObject(field, 1), indexName, unique);

	}

	/**
	 * @param collectionName
	 * @param indexKeys
	 * @param indexName
	 * @param unique
	 *            Helpful to create compound indexes
	 */
	public void createCompoundIndex(String collectionName, Map<String, Object> indexKeys, String indexName,
			boolean unique) {
		mongoTemplate.getCollection(collectionName).createIndex(new BasicDBObject(indexKeys), indexName, unique);

	}

	public List<StepPerformanceReport> getStepsSummaryByBuildNumber(String[] buildNumbers) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id.buildNumber").in(buildNumbers));
		return mongoTemplate.find(query, StepPerformanceReport.class);
	}

	public List<StepPerformanceReport> getReport(Filter requestFilter) {
		Query query = new Query();
		query.addCriteria(new GenericPerformanceReportCriteria(requestFilter).build().getCriteria());
		return mongoTemplate.find(query, StepPerformanceReport.class);
	}

	public List<ScenarioPerformanceReport> getScenarioReport(Filter requestFilter) {
		Query query = new Query();
		query.addCriteria(new GenericPerformanceReportCriteria(requestFilter).build().getCriteria());
		return mongoTemplate.find(query, ScenarioPerformanceReport.class);
	}
}
