/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

import com.citi.icg.as.functional.test.reporting.entities.StepReport;
import com.mongodb.DBObject;

/**
 * @author ap72338
 *
 */

@ReadingConverter
public class StepReportReadConverter implements Converter<DBObject, StepReport> {

	@Override
	public StepReport convert(DBObject dbObject) {
		DBObject id = (DBObject) dbObject.get("_id");
		DBObject value = (DBObject) dbObject.get("value");

		return new StepReport(id.get("stepName").toString(),
				Double.valueOf(value.get("executionCount").toString()).intValue());
	}

}
