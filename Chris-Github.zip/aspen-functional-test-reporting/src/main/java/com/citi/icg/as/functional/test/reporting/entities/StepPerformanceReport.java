/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;

import com.citi.icg.as.functional.test.automation.mongodb.repository.ReportRepository;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ap72338 This class is used to retrieve all fields from
 *         {@link ReportRepository #COLLECTION_FOR_STEP_PERFORMANCE}
 */

@Document(collection = ReportRepository.COLLECTION_FOR_STEP_PERFORMANCE)
@JsonInclude(value = Include.NON_NULL)
public class StepPerformanceReport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3798035688301172714L;

	private String environment;
	private String name;
	private String buildNumber;

	/**
	 * in seconds
	 */
	private double averageDuration;

	private double passPercentage;
	private double failPercentage;

	/**
	 * in seconds
	 */
	private double medianDuration;

	private String formattedExecutionDate;

	@JsonCreator
	public StepPerformanceReport(@JsonProperty("environment") String environment, @JsonProperty("name") String name,
			@JsonProperty("duration") double duration, @JsonProperty("buildNumber") String buildNumber,
			@JsonProperty("passPercentage") double passPercentage,
			@JsonProperty("failPercentage") double failPercentage,
			@JsonProperty("medianDuration") double medianDuration,
			@JsonProperty("formattedExecutionDate") String formattedExecutionDate) {
		this.environment = environment;
		this.buildNumber = buildNumber;
		this.averageDuration = duration;
		this.name = name;
		this.passPercentage = passPercentage;
		this.failPercentage = failPercentage;
		this.medianDuration = medianDuration;
		this.formattedExecutionDate = formattedExecutionDate;
	}

	public String getEnvironment() {
		return environment;
	}

	public String getName() {
		return name;
	}

	public double getDuration() {
		return averageDuration;
	}

	public String getBuildNumber() {
		return buildNumber;
	}

	public double getPassPercentage() {
		return passPercentage;
	}

	public double getFailPercentage() {
		return failPercentage;
	}

	@Override
	@JsonIgnore
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.environment);
		builder.append("-");
		builder.append(this.name);
		builder.append("-");
		builder.append(this.buildNumber);
		builder.append("-");
		builder.append(this.averageDuration);
		return builder.toString();
	}

	public double getMedianDuration() {
		return medianDuration;
	}

	// Below have been generated using Eclipse
	@Override
	@JsonIgnore
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((buildNumber == null) ? 0 : buildNumber.hashCode());
		result = prime * result + ((environment == null) ? 0 : environment.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	@JsonIgnore
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StepPerformanceReport other = (StepPerformanceReport) obj;
		if (buildNumber == null) {
			if (other.buildNumber != null)
				return false;
		} else if (!buildNumber.equals(other.buildNumber))
			return false;
		if (environment == null) {
			if (other.environment != null)
				return false;
		} else if (!environment.equals(other.environment))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public String getFormattedExecutionDate() {
		return formattedExecutionDate;
	}
}
