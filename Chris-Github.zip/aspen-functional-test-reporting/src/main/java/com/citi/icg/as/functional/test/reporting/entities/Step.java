/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author ap72338
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Step {

	private Result result;

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Result {
		private long duration;

		private String status;

		public long getDuration() {
			return duration;
		}

		/**
		 * @param duration
		 *            The duration in cucumber report is in nanoseconds. So
		 *            converting it to seconds. check
		 *            {@link Runtime #runStep(String, gherkin.formatter.model.Step, gherkin.formatter.Reporter, gherkin.I18n)}
		 *            Cucumber's StopWatch #start() uses
		 *            {@link System #nanoTime()}
		 */
		public void setDuration(long duration) {
			this.duration = TimeUnit.NANOSECONDS.toSeconds(duration);
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}
}
