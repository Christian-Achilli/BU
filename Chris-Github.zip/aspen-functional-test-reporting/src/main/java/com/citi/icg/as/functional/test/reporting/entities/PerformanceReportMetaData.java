/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

/**
 * @author ap72338
 *
 */
public enum PerformanceReportMetaData {

	BUILD_NUMBER("_id.buildNumber", "buildNumber"),
	ENVIRONMENT("_id.environment", "environment"),
	EXECUTION_DATE("_id.yearMonthDay", "yearMonthDay"),
	STEP_NAME("_id.stepName", "stepName"),
	COUNT("count", "count"),
	FAIL_PERCENTAGE("failPercentage", "failPercentage"),
	PASS_PERCENTAGE("passPercentage", "passPercentage"),
	MEDIAN("median", "median"),
	AVERGAE("average", "average"),
	SCENARIO_NAME("_id.name", "name");

	private String queryColumnAlias, columnName;

	PerformanceReportMetaData(String queryColumnAlias, String columnName) {
		this.queryColumnAlias = queryColumnAlias;
		this.columnName = columnName;
	}

	public String getQueryColumnAlias() {
		return this.queryColumnAlias;
	}

	public String getColumnName() {
		return columnName;
	}
}
