/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities.converter;

import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.AVERGAE;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.BUILD_NUMBER;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.ENVIRONMENT;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.EXECUTION_DATE;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.MEDIAN;
import static com.citi.icg.as.functional.test.reporting.entities.PerformanceReportMetaData.SCENARIO_NAME;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

import com.citi.icg.as.functional.test.reporting.entities.ScenarioPerformanceReport;
import com.mongodb.DBObject;

/**
 * @author ap72338
 *
 */

@ReadingConverter
public class ScenarioPerformanceReadConverter implements Converter<DBObject, ScenarioPerformanceReport> {

	@Override
	public ScenarioPerformanceReport convert(DBObject dbObject) {
		DBObject id = (DBObject) dbObject.get("_id");
		DBObject value = (DBObject) dbObject.get("value");

		return new ScenarioPerformanceReport(id.get(ENVIRONMENT.getColumnName()).toString(),
				id.get(SCENARIO_NAME.getColumnName()).toString(), id.get(BUILD_NUMBER.getColumnName()).toString(),
				Double.valueOf(String.valueOf(value.get(MEDIAN.getColumnName()))),
				Double.valueOf(String.valueOf(value.get(AVERGAE.getColumnName()))),
				id.get(EXECUTION_DATE.getColumnName()).toString());
	}

}
