/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author ap72338
 *
 */

@JsonIgnoreProperties(ignoreUnknown=true)
public class ReportElement {

	private List<Step>steps;

	public List<Step> getSteps() {
		return steps;
	}

	public void setSteps(List<Step> steps) {
		this.steps = steps;
	}
	
	
}
