/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities.validation;

/**
 * @author AP72338
 *
 */
public interface StepValidationGroup {

}
