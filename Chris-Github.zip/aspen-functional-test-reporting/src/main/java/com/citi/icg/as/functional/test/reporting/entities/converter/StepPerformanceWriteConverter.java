/**
 * 
 */
package com.citi.icg.as.functional.test.reporting.entities.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

import com.citi.icg.as.functional.test.reporting.entities.StepPerformanceReport;
import com.mongodb.DBObject;

/**
 * @author ap72338
 *  Not yet implemented. This is just a placeholder class, just in case we want to store data ourselves in performance report. IN that case we need to construct the {@link DBObject} ourselves.
 *  Don't forget to add this to mapping converter in custom converters
 */

@WritingConverter
public class StepPerformanceWriteConverter implements Converter<DBObject, StepPerformanceReport> {

	@Override
	public StepPerformanceReport convert(DBObject targetDbObject) {
		// TODO Auto-generated method stub
		return null;
	}

}
